'use strict';

(function($) {
  $.extend($.fn.checkboxpicker.defaults, {
    offLabel: 'Нет',
    onLabel: 'Да',
    warningMessage: 'Bootstrap-checkbox не поддерживает использование внутри label элемента.'
  });
})(jQuery);
