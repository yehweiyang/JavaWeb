angular.module('ArchivesApp').controller('RoleManageController', function($rootScope, $scope, $http, $timeout, pkiService, archivesConstant) {

    var oldMenu = new Array();

	$rootScope.$on('slot:find', function() {
		console.log("slot:find: ");
		$scope.slot = "卡片存在";
		$scope.btDisabled = false;
    });
	$rootScope.$on('slot:empty', function() {
		console.log("slot:empty: ");
		$scope.slot = "卡片不存在";
		$scope.btDisabled = true;
    });

    $scope.slot = pkiService.querySlot();

    $http({
        url : archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +"/systemTool/role/roleList",
        method : "GET",
    }).then (function(response) {
        for (var i = 0;i < response.data.length;i++) {
            response.data[i].activeStatus = (response.data[i].activeStatus == 1) ? "啟動" : "停用";
        }
        $scope.allRole = response.data;
        selectOption($scope.allRole);
    });


    function selectOption(allRole) {
        for (var i = 0;i < allRole.length;i++) {
            $('#changeRole').append('<option value="' + allRole[i].sysId + '" data-subtext="' + allRole[i].activeStatus + '">' + allRole[i].roleName + '</option>');
        }
        $('.selectpicker').selectpicker();
    }

    $scope.menuLoop = function(collection) {
        $('.archives-checkbox').checkboxpicker();
        return collection;
    };

    //選擇權限-開始
    $('#changeRole').change(function(){
        oldMenu = new Array();
        if ($('#changeRole option:checked').attr('data-subtext') == "啟動") {
            $('#roleStatus').prop('checked',true);
        } else {
            $('#roleStatus').prop('checked',false);
        }

        var changeRoleValue = {
            "SysId" : $('#changeRole').val()
        };

        $http({
            url : archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +"/systemTool/role/choiceRole",
            method : "GET",
            params : changeRoleValue
        }).then (function(response) {
            if (response.data[0].menus.length != 0) {
                response.data[0].menus.forEach(function(menu){
                    oldMenu.push(menu.sysId);
                    $('#' + menu.sysId).prop('checked',true);
                });
            } else {
                $("#menu input[type=checkbox]").each(function() {
                    $(this).prop("checked", false);
                });
            }
        }), function errorCallback(response) {
               exceptionViewer(response, false);
        };
    });
    //選擇權限-結束
    //修改權限功能-開始
    $scope.fixRole = function(){

        if (!$('#changeRole option:checked').val()) {
           alert("請選擇一個權限類型");
           setTimeout(function(){ $('.modal').trigger("click"); }, 300);
        }
        $scope.roleType = $('#changeRole option:checked').text();
        $scope.checkboxValue = ($('#changeRole option:checked').attr('data-subtext') == "啟動") ? 1 : 0;
        ($scope.checkboxValue == 1) ? $('#fixCheckboxResult').prop('checked',true) : $('#fixCheckboxResult').prop('checked',false);
        $('#fixRoleName').val($scope.roleType);
    };

    $scope.fixConfirm = function(){
        var fixCheckboxResult = ($('#fixCheckboxResult').prop('checked')) ? 1 : 0;
        var fixRoleName =  $('#fixRoleName').val();

        if ($scope.roleType == fixRoleName && $scope.checkboxValue == fixCheckboxResult) {
            alert("你尚未做修改");
            return false;
        } else if ($scope.fixRoleName == '') {
            alert("權限管理名稱不可為空");
            return false;
        } else {
            var fixValue = {
                "oldRoleName" : $scope.roleType,
                "fixStatus" : fixCheckboxResult,
                "fixRoleName" : fixRoleName
            };

            $http({
                url : archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/systemTool/role/fixRoleType",
                method : "PUT",
                params : fixValue
            }).success (function(response) {
                alert("修改成功");

                location.reload();
            }).error(function(response) {
                exceptionViewer(response, false);
            });
        }
    };

    $scope.fixGiveup = function(){
        var booleanValue = $scope.checkboxValue;
        if ($scope.checkboxValue) {
            booleanValue = true;
        } else {
            booleanValue = false;
        }
        $('#fixCheckboxResult').prop("checked",booleanValue);
        $('#fixRoleName').val($scope.roleType);
    };
    //修改權限功能-結束



    //新增權限功能-開始
    $scope.newRole = function(){
        if(!$scope.roleName){
            alert("請輸入權限名稱");
            return false;
        }

        var status = $('#addStatus').prop("checked");

        var addValue = {
            "status" : status,
            "roleName" :$scope.roleName,
        };

        $http({
            url : archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +"/systemTool/role/newRoleType",
            method : "POST",
            params : addValue
        }).success (function(response) {
            alert("新增成功");
            $('.modal').trigger("click");
        }).error(function(response) {
            exceptionViewer(response, false);
        });
    };

    $scope.newGiveup = function() {
            $('#addStatus').prop("checked",false);
            $('#addRoleName').val('');
        }
    //新增權限功能-結束

    //權限選單功能-開始
    $scope.check_all = function(cName){
        if($("input[id='" + cName+ "']").prop("checked")) {
            $("input[name='" +  cName + "']").each(function() {
                $("input[name='" +  cName + "']").prop("checked", true);
            });
        } else {
            $("input[name='" +  cName + "']").each(function() {
                $("input[name='" +  cName + "']").prop("checked", false);
            });
        }
    }

    $scope.menuConfig = function(){
        var roleSysId = $('#changeRole option:checked').val();

        if (!roleSysId) {
            alert("請選擇欲修改權限類型");
            return false;
        }

        var menuValue = $('#menu input:checkbox:checked').map(function() { return $(this).val(); }).get();
        var menuArray = new Array();


        menuValue.forEach(function(sysId_value){
            if(sysId_value != "on"){
                menuArray.push(sysId_value);
            }
        });
        oldMenu.sort();
        menuArray.sort();

        if (oldMenu.length == menuArray.length) {
            var num = 0;

            for (var i = 0;i < oldMenu.length;i++) {
                if (oldMenu[i]  == menuArray[i]) {
                    num++;
                }
            }

            if (num == oldMenu.length) {
                alert("沒有做任何修改");
                return false;
            }
        }

        var configValue = {
            "menu" : menuArray,
            "roleSysId" : roleSysId
        };
        $http({
            url : archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +"/systemTool/role/menuConfig",
            method : "POST",
            params : configValue
        }).then (function(response) {
            successViewer(archivesConstant.UPDATE_SUCCESS_MSG);
        }), function errorCallback(response) {
            exceptionViewer(response, false);
        };
    }
    //權限選單功能-結束
});
