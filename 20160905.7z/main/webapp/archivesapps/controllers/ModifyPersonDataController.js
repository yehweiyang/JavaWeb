angular.module('ArchivesApp').controller('ModifyPersonDataController',
    function($rootScope, $scope, $timeout, $http, pkiService) {

    $scope.$on('$viewContentLoaded', function() {
        queryUser();
    });

    $scope.slot = pkiService.querySlot();
    $scope.cardStatus = false;
    var errorCode = "";
    $scope.errorMessage = "";
    $scope.errorCode = "";
    $scope.showErrorMessage = false;

    $scope.user = {};

    var queryUser = function() {
        var url = "/manageWeb/v1/systemTool/user/getUser";
        return $http.get(url).then(function(response) {
            $scope.user = response.data;

        });
    };

    $rootScope.$on('slot:find', function() {
        $scope.slot = "卡片存在";
        $scope.cardStatus = true;
    });

    $rootScope.$on('slot:empty', function() {
        $scope.slot = "卡片不存在";
        $scope.cardStatus = false;
    });


    $scope.save = function() {
        var url = "/manageWeb/v1/systemTool/user/modifyUser";
        var userJson = angular.toJson($scope.user);
        $http.post(url, userJson).then(function successCallback(response) {
                console.log(response);
                //$uibModalInstance.close($scope.user);
             },
        function errorCallback(response) {
        //angular.copy(userCopy, $scope.user);
        console.log(response);
        $scope.errorCode = response.data.errorCode;
        $scope.errorMessage = response.data.errorMessage;
        if($scope.errorCode=="SYS0000" || $scope.errorCode=="SYS0001") {
            console.log("ErrorCode= "+$scope.errorCode);
            handleSysErrorMessage();
        }
        else
        handleErrorMessage()
        console.log("ErrorCode= "+$scope.errorCode);
        console.log("ErrorMsg= "+$scope.errorMessage);
    });
    };

        var handleErrorMessage = function () {
            $scope.showErrorMessage = true;
            $timeout(function() {
                $scope.showErrorMessage = false;
            }, 3000);
        };

        var handleSysErrorMessage = function() {
            $scope.errorMessage+="，即將導回首頁";
            $scope.showErrorMessage = true;
            $timeout(function() {
                $scope.showErrorMessage = false;
            }, 3000);
            $window.location.href = "/manageWeb/index";
        };
});