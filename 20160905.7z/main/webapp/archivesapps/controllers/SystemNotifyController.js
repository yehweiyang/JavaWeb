angular.module('ArchivesApp').controller('SystemNotifyController', function($rootScope, $scope, $modal, $http, pkiService) {
	$rootScope.$on('slot:find', function() {   
		console.log("slot:find: ");
		$scope.slot = "卡片存在";
		$scope.btDisabled = false;
    });
	$rootScope.$on('slot:empty', function() {   
		console.log("slot:empty: ");
		$scope.slot = "卡片不存在";
		$scope.btDisabled = true;
    });
	$rootScope.$on('sign:success', function() {
		console.log("sign:success: ");
		var systemNotify = pkiService.getSignatureCert();
		systemNotify.notifyMessage = $scope.notifyMessage;
    	return $http.post("/manageWeb/v1/notify/", systemNotify)
		.then(function(response)
		{
			console.log("success: " + response.status);
		}, 
		function(errResponse){
			console.log("failed: " + errResponse.status);
		});
    });
	$rootScope.$on('sign:failed', function() {
		console.log("sign:failed: ");
    });	
	$scope.slot = pkiService.querySlot();
	$scope.btDisabled = true;

	$scope.saveHtmlBt = function(cert) {
		var modal = $modal.open({
			templateUrl: "archivesapps/templates/pinModal.html",
            controller: function($scope, $uibModalInstance) {
            	$scope.submit = function(pin) {
            		$uibModalInstance.close(pin);
            	};
            }
		});

		return modal.result.then(function(pin) {
			pkiService.setPinCode(pin);
			pkiService.makeSignature();
		})
    }
});