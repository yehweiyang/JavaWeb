angular.module('ArchivesApp').controller('ChangeErrorQueryController',
    function($scope, $http, $rootScope, $uibModal, $log, $q, archivesConstant, archivesService) {

        $scope.archivesConstant = archivesConstant;
        $scope.archivesService = archivesService;
        $scope.archivesService.pager = {
            itemsPerPage: 100,
            pagerMaxSize: 7,
            firstItemDataNum: 0,
            currentPage: 1
        };
        $scope.userList = [];
        $scope.userID = [];




        $scope.saveHtmlBt = function(id) {
            var queryProcessId = {
                processId: id.processId
            };
            console.log('id===>' + id.processId);
            console.log('bbbbbbbb');
            $http.get('/manageWeb/v1/change/changeErrorQueryID', {
                    params: queryProcessId
                }).success(function(response, status, headers, config) {
                    $scope.abc = response;
                    console.log("\\\\\\\\\\\\\\");
                    console.log($scope.abc)
                    console.log("/////////////")

                    console.log('------Really good-------')
                    return $scope.abc;
                    console.log($scope.abc)

                })
                .error(function(errResp) {
                    console.log('------Really bad-------')
                });
            var modal = $uibModal.open({
                templateUrl: "archivesapps/views/ChangeRecord/demoForm2.html",
                scope: $scope,
                size: 'lg'
            });

        }


        $scope.checkErr = function(timeFrom, timeTo) {
            $scope.errMessage = '';

            if (timeFrom > timeTo) {
                $scope.errorValid = true
                $scope.errorCode = false;
            } else {
                $scope.errorValid = false
                $scope.errorCode = true;
            }
        };


        //        function validateDates() {
        //            console.log('rest~~!!');
        //            if (!$scope.error) return;
        //            //depending on whether the user used the date picker or typed it, this will be different (text or date type).
        //            //creating a new date object takes care of that.
        //            var endDate = new Date($scope.error.dateTo);
        //            var startDate = new Date($scope.error.dateFrom);
        //            var endTime = $scope.error.timeTo;
        //            var startTime = $scope.error.timeFrom;
        //            if (endDate != 'Invalid Date' && startDate != 'Invalid Date') {
        //                if (endDate < startDate || ((endDate = startDate) && (endTime < startTime))) {
        //                    $scope.errorValid = true
        //                    $scope.errorCode = true;
        //
        //                } else {
        //                    $scope.errorValid = false
        //                    $scope.errorCode = false;
        //
        //                }
        //            }
        //
        //            //$scope.error.dateFrom.$setValidity("endBeforeStart", endDate >= startDate);
        //        }


        $scope.$watch('hideOrShow', function() {
            $scope.toggleText = $scope.hideOrShow ? '開啟異常訊息' : '隱藏異常訊息!';
        })

        $scope.query = function() {
            console.log('query...............');
            var error = $scope.error;

            console.log(error.sendOrgNameCheck)
            console.log(error.receiverOrgNameCheck)

            var convQueryFromJson = {
                sendOrgName: error.sendOrgName,
                sendOrganId: error.sendOrganId,
                receiverOrgName: error.receiverOrgName,
                receiverOrgId: error.receiverOrgId,
                processId: error.processId,
                exchangeId: error.exchangeId,
                startNo: error.startNo,
                endNo: error.endNo,
                dateFrom: error.dateFrom,
                timeFrom: error.timeFrom,
                dateTo: error.dateTo,
                timeTo: error.timeTo,
                sendOrgNameCheck: error.sendOrgNameCheck,
                receiverOrgNameCheck: error.receiverOrgNameCheck
            };
            var value;
            $http.get('/manageWeb/v1/change/changeErrorQuery', {
                    params: convQueryFromJson
                }).success(function(data) {
                    if (data.length != 0) {
                        $scope.userList = data;
                        $scope.noResult = false;
                        $scope.myVar = true;
                        $scope.hideOrShow = true;
                        value=data;
                    } else {
                        $scope.noResult = true;
                        $scope.myVar = false;
                    }


                })
                .error(function(data, status) {
                    $scope.noResult = true;
                    $scope.myVar = false;
                    console.error('Repos error', status, data);
                })
                .finally(function() {
                console.log("finally......222......")
                   var query_value = convQueryFromJson // 序列化成 JSON 字串
                   console.log('query_value'+'****')
                   console.log(query_value)
                   var abc ={
                   total: value
                   }
                   var result_value = value // 序列化成 JSON 字串
                   console.log('result_value'+'****')
                   console.log(result_value)
                   $http.get('/manageWeb/v1/change/changeErrorQueryTemp', {
                    params: query_value,
                    abc
                     })
                });
            /*
            then(function(response) {

                            if (response.data.length != 0) {
                                $scope.userList = response.data;

                                $scope.noResult = false;
                                $scope.myVar = true;
                                $scope.hideOrShow = true;
                                //寫入暫存檔
                                response

                                //寫入暫存檔

                            } else {
                                $scope.noResult = true;
                                $scope.myVar = false;
                            }
                            $scope.error = null;
                         console.log('---------');
                         console.log($scope.error)
                        })
            */


        }

        //
        //          $scope.error={
        //          timeFrom: $scope.options.mstep,
        //          timeTo: $scope.options.mstep
        //          }



        $scope.master = {
            sendOrgName: "",
            sendOrganId: "",
            receiverOrgName: "",
            receiverOrgId: "",
            processId: "",
            exchangeId: "",
            startNo: "",
            endNo: "",
            dateFrom: new Date(),
            timeFrom: "00",
            dateTo: new Date(),
            timeTo: "23",
            sendOrgNameCheck: 'false',
            receiverOrgNameCheck: 'false'
        };
        $scope.reset = function() {
            $scope.error = angular.copy($scope.master);
        };
        $scope.reset();

        $scope.reset = function() {

            $scope.noResult = '';
            $scope.myVar = '';
            $scope.errorCode = false;
            $scope.error.sendOrgName = "",
                $scope.error.sendOrganId = "",
                $scope.error.receiverOrgName = "",
                $scope.error.receiverOrgId = "",
                $scope.error.processId = "",
                $scope.error.exchangeId = "",
                $scope.error.startNo = "",
                $scope.error.endNo = "",
                $scope.error.dateFrom = new Date(),
                $scope.error.timeFrom = "00",
                $scope.error.dateTo = new Date(),
                $scope.error.timeTo = "23",
                $scope.error.sendOrgNameCheck = 'false',
                $scope.error.receiverOrgNameCheck = 'false',
                console.log('reset');
        }

        $scope.prop = {
            "type": "select",
            "value00": "00",
            "value23": "23",
            "values": ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
                "22", "23"
            ]
        };


        var writeLog = function() {
            $http.get('/manageWeb/v1/change/changeErrorQueryLog')
            //$http.get('/manageWeb/v1/change/changeErrorQueryReadLog')
            console.log('writeLog');
        }
        writeLog();



        $scope.openDateFromCalendar = function() {
            $scope.dateFromCalendar.opened = true;
        };


        $scope.openDateToCalendar = function() {
            $scope.dateToCalendar.opened = true;
        };
        $scope.dateFromCalendar = {
            opened: false
        };

        $scope.dateToCalendar = {
            opened: false
        };

    });