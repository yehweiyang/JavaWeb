angular.module("ArchivesApp").controller('AddressSearchController', function($scope, $http) {
	var self = this;
	self.uibPageBase = 10;
    $scope.checkTestUnit = 'no';
    $scope.checkCompare = 'no';
    $scope.start = 0;
    $scope.end = self.uibPageBase;
    $scope.showTable = false;
    $scope.centerLists = [];
    $scope.queryData = {};
    $scope.showModal = false;
    $scope.showDetail = false;
    $scope.forbiddenModal = false;
	$scope.maxSize = 5;
	$scope.bigTotalItems = 0;
	$scope.currentPage = 0;
    $scope.toggleModal = function(){
    	$scope.showModal = false;
    };
    $scope.toggleDetail = function(){
    	$scope.showDetail = false;
    };
    $scope.toggleForbidden = function(){
    	$scope.forbiddenModal = false;
    };
    var fetchCenterList = function() {
    	return $http.get('/manageWeb/v1/addressSearch/center/list').then(function(response) {
    		$scope.centerLists = response.data;
    		//console.log("length: " + $scope.centerLists.length);
    		$scope.selectedCenterList = $scope.centerLists[0];
    	}, function(errResponse) {
    	});
    };
    
	$scope.bigPageChanged = function() {
		$scope.end = $scope.currentPage * self.uibPageBase
		$scope.start = $scope.end - self.uibPageBase
	};
    
	$scope.queryBt = function(form) {
        if (form.$valid) {
            var queryData = {};
	        if ($scope.queryData != null) {
	            queryData = $scope.queryData;
	        }
    	    var url = "/manageWeb/v1/addressSearch/list";
    	    if ($scope.selectedCenterList.centerId.length == 0) {
    	        queryData.gatewayId = null;
    	    } else {
    	        queryData.gatewayId = $scope.selectedCenterList.centerId;
    	    }
            queryData.exchangeStatus = $scope.selectedCenterStatus.exchangeStatus;
            queryData.exactMatch = $scope.checkCompare;
            queryData.showTestUnit = $scope.checkTestUnit;
            //console.log("showTestUnit: " + queryData.showTestUnit);
            var config = {
                params: queryData
            };
    	    $http.get(url, config).then(function(response) {
    		    $scope.addressBookList = response.data;
    		    $scope.bigTotalItems = $scope.addressBookList.length;
    		    $scope.currentPage = 1;
    		    //console.log("bigTotalItems: " + $scope.bigTotalItems);
    		    $scope.start = 0;
    		    $scope.end = self.uibPageBase
    		    $scope.showError = false;
    		    $scope.showTable = true;
    	    }, function(errResponse) {
                $scope.errorMessage = errResponse.data.errorMessage;
                $scope.showError = true;
                $scope.showTable = false;
    	    });
		} else {
            $scope.errorMessage = "輸入格式錯誤";
            $scope.showError = true;
            $scope.showTable = false;
        }
    };
    
    $scope.detailBt = function(addressBook) {
        var queryDetail = {};
        queryDetail.agencyId = addressBook.agencyId;
        queryDetail.agencyUnitId = addressBook.agencyUnitId;
        var config = {
            params: queryDetail
        };
    	var url = "/manageWeb/v1/addressSearch/detail";
    	return $http.get(url, config).then(function(response) {
    		$scope.addressBookDetail = response.data;
    		console.log("certType: " + $scope.addressBookDetail.orgCert.certType);
    		$scope.showDetail = true;
    	}, function(errResponse) {
    	    $scope.message = errResponse.data.errorMessage;
            $scope.btMsg = "確定";
            $scope.showModal = true;
    	});
    };
    
    fetchCenterList();
    
    $scope.status = [
        {centerStatus: "全部", exchangeStatus: null},
        {centerStatus: "啟用", exchangeStatus: 1},
        {centerStatus: "暫停", exchangeStatus: -1},
        {centerStatus: "停用", exchangeStatus: 0}
    ];
    $scope.selectedCenterStatus = $scope.status[0];
    
    $scope.addressBookList = [];
    $scope.addressBookDetail;
    
    $scope.resetBt = function() {
    	$scope.selectedCenterList = $scope.centerLists[0];
    	$scope.selectedCenterStatus = $scope.status[0];
    	$scope.showTable = false;
    	$scope.queryData.agencyId = null;
    	$scope.queryData.agencyUnitId = null;
    	$scope.queryData.agencyName = null;
    	$scope.checkTestUnit = 'no';
    	$scope.checkCompare = 'no';
    	$scope.start = 0;
    	$scope.end = self.uibPageBase
    	$scope.showDetail = false;
    	$scope.showError = false;
    };
});
