     var minUserLen = 5, maxUserLen = 20;
     var minFullNameLen = 5, maxFullNameLen = 20;
     var minPhoneLocalLen = 2, maxPhoneLocalLen = 4;
     var minPhoneNumLen = 3, maxPhoneNumLen = 10;
     var mineMailAddrLen = 2;
     var userNameMsg = "帳號欄位長度必需在 " + minUserLen + " 到 " +
                       maxUserLen + "間 !!!";
     var fullNameMsg = "姓名欄位長度必需在 " + minFullNameLen + " 到 " +
                       maxFullNameLen + "間 !!!";
     var phoneLocalMsg = "電話區碼欄位長度必需在 " + minPhoneLocalLen + " 到 " +
                       maxPhoneLocalLen + "間 !!!";
     var phoneNumMsg = "電話號碼欄位長度必需在 " + minPhoneNumLen + " 到 " +
                       maxPhoneNumLen + "間 !!!";
     var eMailAddrMsg = "電子郵件欄位長度必需大於 "+ mineMailAddrLen;


    $(document).ready(function() {
    var validator = $("#accountForm").validate({
        submitHandler: function(accountForm) {
             console.log("submitHandler:");
             getUserCert();
        },
        rules: {
           userName: {
              required: true,
              minlength: minUserLen,
              maxlength: maxUserLen
           },
           fullName: {
              required: true,
              minlength: minFullNameLen,
              maxlength: maxFullNameLen
           },
          phoneLocal: {
             required: true,
             minlength: minPhoneLocalLen,
             maxlength: maxPhoneLocalLen,
             digits:true
          },
         phoneNum: {
            required: true,
            minlength: minPhoneNumLen,
            maxlength: maxPhoneNumLen,
            digits:true
         },
        eMailAddr: {
           required: true,
           minlength: mineMailAddrLen,
           email:true
        },
        captcha: {
           required: true
        },
    },
        messages: {
           userName: {
              required: "帳號 是必要欄位",
              minlength: userNameMsg,
              maxlength: userNameMsg
           },
           fullName: {
              required: "姓名 是必要欄位",
              minlength: fullNameMsg,
              maxlength: fullNameMsg
           },
           phoneLocal: {
              required: "電話區碼 是必要欄位",
              minlength: phoneLocalMsg,
              maxlength: phoneLocalMsg,
              digits: "電話區碼必需是數字"
           },
           phoneNum: {
              required: "電話號碼 是必要欄位",
              minlength: phoneNumMsg,
              maxlength: phoneNumMsg,
              digits: "電話號碼必需是數字"
           },
           eMailAddr: {
              required: "電子郵件 是必要欄位",
              minlength : eMailAddrMsg,
              email : "請輸入正確的住址電子郵件"
           },
           captcha: {
              required: "圖形驗證碼 是必要欄位"
           }
        }
    });
});