ArchivesApp.factory('pkiService', ['$rootScope', '$window', '$http', '$uibModal', 'pkiErrorService', function ($rootScope, $window, $http, $uibModal, pkiErrorService) {
	var self = this;
	self.singCert;
	self.pinCode = null;
	var resultCode;
	var postTarget;
	var timeoutId;
    var document = $window.document;
    var userAgent = $window.navigator.userAgent;
    
    function postData(target,data)
    {
    	if(!http.sendRequest)
    	{
    		return null;
    	}
    	http.url=target;
    	http.actionMethod="POST";
    	var code=http.sendRequest(data);
    	if(code!=0) return null;
    	return http.responseText;
    }
    function checkFinish()
    {
    	if(postTarget)
    	{
    		postTarget.close();
    		$window.alert("尚未安裝元件");
    	}
    }

    function getTbsPackage()
    {
    	var tbsData = {};
    	tbsData["tbs"] = self.singCert.token;
    	tbsData["tbsEncoding"] = "NONE";
    	tbsData["hashAlgorithm"] = "SHA256";
    	tbsData["pin"] = self.pinCode;
    	tbsData["func"] = "MakeSignature";
    	tbsData["signatureType"] = "PKCS1";
    	var json = JSON.stringify(tbsData ).replace(/\+/g,"%2B");;
    	return json;
    }

    function setSignature(signature)
    {
    	self.pinCode = null;
    	resultCode = JSON.parse(signature);
    	if (resultCode.ret_code == 0) {
        	self.singCert.b64Signature = resultCode.signature;
    		$rootScope.$broadcast('sign:success');
    	} else {
    		$rootScope.$broadcast('sign:failed');
    	}
    }
    
    function fetchSignCertToken(serialNumber) {
    	var url = "/manageWeb/v1/token/" + serialNumber;
    	return $http.get(url).then(function(response) {
    		self.singCert = response.data;
    		$rootScope.$broadcast('slot:find');
    	}, function(errResponse) {
    		$rootScope.$broadcast('slot:empty');
    	});
    };

	function receiveMessage(event)
	{
		//if(console) console.debug(event);

		//安全起見，這邊應填入網站位址檢查
		if(event.origin!="http://localhost:61161")
			return;
		try {
			var ret = JSON.parse(event.data);
    		if(ret.func)
    		{
    			if(ret.func=="getTbs")
    			{
    				clearTimeout(timeoutId);
    				var json=getTbsPackage()
    				postTarget.postMessage(json,"*");
    			}
    			else if(ret.func=="sign")
    			{
    				setSignature(event.data);
    			}
    		}
    		else
    		{
    			if(console) console.error("no func");
    		}
    	} catch(e) {
    		if(console)
    			console.error(e);
    	}
	}
	
	function makeSignature()  {
    	if(userAgent.indexOf("MSIE")!=-1 || userAgent.indexOf("Trident")!=-1) //is IE, use ActiveX
    	{
    		postTarget=window.open("http://localhost:61161/waiting.gif", "Signing","height=200, width=200, left=100, top=20");
    		var tbsPackage=getTbsPackage();
    		document.getElementById("httpObject").innerHTML='<OBJECT id="http" width=1 height=1 style="LEFT: 1px; TOP: 1px" type="application/x-httpcomponent" VIEWASTEXT></OBJECT>';
    		var data=postData("http://localhost:61161/sign","tbsPackage="+tbsPackage);
    		postTarget.close();
    		postTarget=null;
    		if(!data) alert("尚未安裝元件");
    		else setSignature(data);
    	}
    	else
    	{
    		postTarget=window.open("http://localhost:61161/popupForm", "處理中","height=200, width=200, left=100, top=20");
    		timeoutId=setTimeout(checkFinish,3500);
    	}
	}

    if ($window.addEventListener)
    {
    	$window.addEventListener("message", receiveMessage, false);
    }
    else
    {
    	//for IE8
    	$window.attachEvent("onmessage", receiveMessage);
    }    

    function setOutput(outputJson) {
        var ret=JSON.parse(outputJson);
    	if(ret.ret_code==0x76000031)
    	{
    		$window.alert($window.location.hostname+"非信任網站，請先加入信任網站");
    		return;
    	}
    	var slots = ret.slots;
    	if(slots[0].token instanceof Object)
    	{
    		fetchSignCertToken(slots[0].token.serialNumber);
    	}
    	else
    	{
    		$rootScope.$broadcast('slot:empty');
    	}
    }

    function getImageInfo(ctx) {
	    var imgOutput="";
	    for(i=0;i<2000;i++)
	    {
		    var data=ctx.getImageData(i,0,1,1).data;
		    if(data[2]==0) break;
		    imgOutput=imgOutput+String.fromCharCode(data[2],data[1],data[0]);
	    }
	    if(imgOutput=="") imgOutput='{"ret_code": 1979711501,"message": "執行檔錯誤或逾時"}';
	    return imgOutput;
    }

	var service = {
		getResultCode: function() {
			return resultCode;
		},
		getErrorReason: function() {
			var reason = "";
			if(resultCode.ret_code!=0) {
				reason = pkiErrorService.getMajorErrorReason(resultCode.ret_code);
				if(resultCode.last_error) {
					reason += " " + pkiErrorService.getMinorErrorReason(resultCode.last_error);
				}
			}
			return reason;
		},
		getSignatureCert: function() {
			return self.singCert;
		},
		querySlot: function() {
		    var img = null;
            var ctx = null;
            var output="";
        	var document = $window.document;
            if(userAgent.indexOf("MSIE")==-1 && userAgent.indexOf("Trident")==-1) //not IE
            {
            	img=document.createElement("img");
            	img.crossOrigin = "Anonymous";
            	img.src = 'http://localhost:61161/p11Image.bmp';
            	var canvas = document.createElement("canvas");
		        canvas.width=2000;
		        canvas.height=1;
		        ctx = canvas.getContext('2d');

		        img.onload = function() {
		        	ctx.drawImage(img, 0, 0);
		        	output=getImageInfo(ctx);
			        setOutput(output);
		        };
		        img.onerror = function()
	    	    {
	    	        $window.alert("未安裝客戶端程式或未啟動服務");
		        };
            }
            else
            {
            	document.getElementById("httpObject").innerHTML='<OBJECT id="http" width=1 height=1 style="LEFT: 1px; TOP: 1px" type="application/x-httpcomponent" VIEWASTEXT></OBJECT>';
            	output=postData("http://localhost:61161/pkcs11info","");
            	if(output==null){
            		$window.alert("未安裝客戶端程式或未啟動服務");
            		return;
            	}
            	else
            		setOutput(output);
            }
            return "卡片不存在";
	    },
		openPinModal: function() {
		    console.log("openPinModal: ");
			var modal = $uibModal.open({
				templateUrl: "archivesapps/templates/pinModal.html",
	            controller: function($scope, $uibModalInstance) {
	            	$scope.submit = function(pin) {
	            		$uibModalInstance.close(pin);
	            	};
	            }
			});
            console.log("modal: " + modal);
            if (modal != null) {
			    modal.result.then(function(pin) {
				    self.pinCode = pin;
				    makeSignature();
			    }, function () {
				    $rootScope.$broadcast('slot:find');
			    });
            } else {
                $rootScope.$broadcast('slot:find');
            }
		}
	};
    return service;
}]);