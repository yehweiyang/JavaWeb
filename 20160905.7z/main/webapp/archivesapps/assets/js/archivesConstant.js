ArchivesApp.constant('archivesConstant', {
    WEB_ROOT_PATH: $('#ng_load_plugins_before').attr("value"),
    REST_API_VERSION_PATH: '/v1',
    APP_PATH: 'archivesapps',

    INSERT_SUCCESS_MSG: '新增成功',
    UPDATE_SUCCESS_MSG: '修改成功',
    DELETA_SUCCESS_MSG: '刪除成功'
});