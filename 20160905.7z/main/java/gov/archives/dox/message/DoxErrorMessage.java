package gov.archives.dox.message;

/**
 * DoxErrorMessage
 * <br>
 * dox package 之錯誤訊息設定
 * <br>
 * gemhuang, 2016/8/16.
 */
public class DoxErrorMessage {
    public static final String AP0000_ERROR_MESSAGE = "無符合條件的查詢結果";
    public static final String ED0006_ERROR_MESSAGE = "機關代碼輸入格式錯誤";
    public static final String ED0007_ERROR_MESSAGE = "機關代碼輸入長度錯誤";
    public static final String ED0008_ERROR_MESSAGE = "單位代碼輸入格式錯誤";
    public static final String ED0013_ERROR_MESSAGE = "交換中心輸入格式錯誤";
    public static final String ED0014_ERROR_MESSAGE = "機關名稱輸入格式錯誤";
    public static final String ED0015_ERROR_MESSAGE = "文號輸入格式錯誤";
    public static final String ED0016_ERROR_MESSAGE = "交換編號輸入格式錯誤";
}
