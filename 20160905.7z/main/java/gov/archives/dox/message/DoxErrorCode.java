package gov.archives.dox.message;

/**
 * DoxErrorCode
 * <br>
 * dox package 之錯誤代碼設定
 * <br>
 * gemhuang, 2016/8/16.
 */
public class DoxErrorCode {
    public static final String AP0000_DATA_NOT_FOUND = "AP0000";
    public static final String ED0006_AGENCY_ID_FORMAT_INCORRECT = "ED0006";
    public static final String ED0007_AGENCY_ID_LENGTH_INCORRECT = "ED0007";
    public static final String ED0008_UNIT_ID_FORMAT_INCORRECT = "ED0008";
    public static final String ED0013_CENTER_ID_FORMAT_INCORRECT = "ED0013";
    public static final String ED0014_AGENCY_NAME_FORMAT_INCORRECT = "ED0014";
    public static final String ED0015_DOC_ID_FORMAT_INCORRECT = "ED0015";
    public static final String ED0016_EXCHANGE_ID_FORMAT_INCORRECT = "ED0016";
}
