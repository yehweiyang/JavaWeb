package gov.archives.dox.domain.entity;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias("AddressBookInfo")
public class AddressBookInfoEntity implements Serializable {
    private String gatewayId;
    private String agencyId;
    private String agencyUnitId;
    private String agencyName;
    private Integer activeStatus;
    private String statusCode;
    private String updateTime;

    public String getGatewayId() {
        return gatewayId;
    }

    public void setGatewayId(String gatewayId) {
        this.gatewayId = gatewayId;
    }

    public String getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(String agencyId) {
        this.agencyId = agencyId;
    }

    public String getAgencyUnitId() {
        return agencyUnitId;
    }

    public void setAgencyUnitId(String agencyUnitId) {
        this.agencyUnitId = agencyUnitId;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public Integer getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }
}
