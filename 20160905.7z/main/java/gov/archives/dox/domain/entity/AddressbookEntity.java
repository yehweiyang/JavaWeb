package gov.archives.dox.domain.entity;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

import gov.archives.core.domain.entity.BaseEntity;

/**
 * AddressbookEntity
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@Alias("AddressBook")
public class AddressbookEntity extends BaseEntity implements Serializable {
    private String gatewayId;
    private String agencyId;
    private String agencyUnitId;
    private String agencyName;
    private String agencyAddress;
    private String agencyPhone;
    private String agencyFax;
    private String agencyUrl;
    private String contactName;
    private String contactEmail;
    private String contactMobile;
    private Integer activeStatus;
    private String agencyCertId;
    private String signCertSerialNum;
    private String encryptCertSerialNum;
    private String cipherModule;
    private String pbSerial;
    private String statusMsg;
    private String updateTime;
    private OrgCertEntity orgCert;
    private String orgCardStatus;

    public String getGatewayId() {
        return gatewayId;
    }

    public String getAgencyId() {
        return agencyId;
    }

    public String getAgencyUnitId() {
        return agencyUnitId;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public String getAgencyAddress() {
        return agencyAddress;
    }

    public String getAgencyPhone() {
        return agencyPhone;
    }

    public String getAgencyFax() {
        return agencyFax;
    }

    public String getAgencyUrl() {
        return agencyUrl;
    }

    public String getContactName() {
        return contactName;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public String getContactMobile() {
        return contactMobile;
    }

    public Integer getActiveStatus() {
        return activeStatus;
    }

    public String getRelatedOrgUnitId() {
        return agencyCertId;
    }

    public String getSignCertSerialNum() {
        return signCertSerialNum;
    }

    public String getEncryptCertSerialNum() {
        return encryptCertSerialNum;
    }

    public String getCipherModule() {
        return cipherModule;
    }

    public String getPbSerial() {
        return pbSerial;
    }

    public void setGatewayId(String gatewayId) {
        this.gatewayId = gatewayId;
    }

    public void setAgencyId(String agencyId) {
        this.agencyId = agencyId;
    }

    public void setAgencyUnitId(String agencyUnitId) {
        this.agencyUnitId = agencyUnitId;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public void setAgencyAddress(String agencyAddress) {
        this.agencyAddress = agencyAddress;
    }

    public void setAgencyPhone(String agencyPhone) {
        this.agencyPhone = agencyPhone;
    }

    public void setAgencyFax(String agencyFax) {
        this.agencyFax = agencyFax;
    }

    public void setAgencyUrl(String agencyUrl) {
        this.agencyUrl = agencyUrl;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public void setContactMobile(String contactMobile) {
        this.contactMobile = contactMobile;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

    public void setAgencyCertId(String agencyCertId) {
        this.agencyCertId = agencyCertId;
    }

    public void setSignCertSerialNum(String signCertSerialNum) {
        this.signCertSerialNum = signCertSerialNum;
    }

    public void setEncryptCertSerialNum(String encryptCertSerialNum) {
        this.encryptCertSerialNum = encryptCertSerialNum;
    }

    public void setCipherModule(String cipherModule) {
        this.cipherModule = cipherModule;
    }

    public void setPbSerial(String pbSerial) {
        this.pbSerial = pbSerial;
    }

    public String getStatusMsg() {
        return statusMsg;
    }

    public void setStatusMsg(String statusMsg) {
        this.statusMsg = statusMsg;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public OrgCertEntity getOrgCert() {
        return orgCert;
    }

    public void setOrgCert(OrgCertEntity orgCert) {
        this.orgCert = orgCert;
    }

    public String getOrgCardStatus() {
        return orgCardStatus;
    }

    public void setOrgCardStatus(String orgCardStatus) {
        this.orgCardStatus = orgCardStatus;
    }

    public static class Builder {
        public static synchronized Builder create() {
            return new Builder();
        }

        private AddressbookEntity addressbook;
        private Builder self;

        private Builder() {
            this.addressbook = new AddressbookEntity();
            this.self = this;
        }

        public Builder setGatewayId(String gatewayId) {
            this.addressbook.gatewayId = gatewayId;

            return self;
        }

        public Builder setAgencyId(String agencyId) {
            this.addressbook.agencyId = agencyId;

            return self;
        }

        public Builder setAgencyUnitId(String agencyUnitId) {
            this.addressbook.agencyUnitId = agencyUnitId;

            return self;
        }

        public Builder setAgencyName(String agencyName) {
            this.addressbook.agencyName = agencyName;

            return self;
        }

        public Builder setAgencyAddress(String agencyAddress) {
            this.addressbook.agencyAddress = agencyAddress;

            return self;
        }

        public Builder setAgencyPhone(String agencyPhone) {
            this.addressbook.agencyPhone = agencyPhone;

            return self;
        }

        public Builder setAgencyFax(String agencyFax) {
            this.addressbook.agencyFax = agencyFax;

            return self;
        }

        public Builder setAgencyUrl(String agencyUrl) {
            this.addressbook.agencyUrl = agencyUrl;

            return self;
        }

        public Builder setContactName(String contactName) {
            this.addressbook.contactName = contactName;

            return self;
        }

        public Builder setContactEmail(String contactEmail) {
            this.addressbook.contactEmail = contactEmail;

            return self;
        }

        public Builder setContactMobile(String contactMobile) {
            this.addressbook.contactMobile = contactMobile;

            return self;
        }

        public Builder setActiveStatus(Integer activeStatus) {
            this.addressbook.activeStatus = activeStatus;

            return self;
        }

        public Builder setAgencyCertId(String agencyCertId) {
            this.addressbook.agencyCertId = agencyCertId;

            return self;
        }

        public Builder setSignCertSerialNum(String signCertSerialNum) {
            this.addressbook.signCertSerialNum = signCertSerialNum;

            return self;
        }

        public Builder setEncryptCertSerialNum(String encryptCertSerialNum) {
            this.addressbook.encryptCertSerialNum = encryptCertSerialNum;

            return self;
        }

        public Builder setCipherModule(String cipherModule) {
            this.addressbook.cipherModule = cipherModule;

            return self;
        }

        public Builder setPbSerial(String pbSerial) {
            this.addressbook.pbSerial = pbSerial;

            return self;
        }

        public Builder initSave(String creator) {
            this.addressbook.initSave(creator);

            return self;
        }

        public AddressbookEntity build() {
            return this.addressbook;
        }
    }
}
