package gov.archives.dox.service;

import java.util.List;
import java.util.Map;

import gov.archives.dox.domain.entity.AddressBookInfoEntity;
import gov.archives.dox.domain.entity.AddressbookEntity;
import gov.archives.dox.domain.entity.OrgCertEntity;

/**
 * AddressbookService
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
public interface AddressbookService {
    List<AddressBookInfoEntity> getAllAddressBook(Map<String, Object> queryMap);

    AddressbookEntity getByOrgUnitId(Map<String, Object> queryMap);

}
