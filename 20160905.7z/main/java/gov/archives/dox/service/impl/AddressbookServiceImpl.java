package gov.archives.dox.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.exception.ArchivesException;
import gov.archives.dox.conf.DoxConf;
import gov.archives.dox.domain.entity.AddressBookInfoEntity;
import gov.archives.dox.domain.entity.AddressbookEntity;
import gov.archives.dox.domain.entity.OrgCertEntity;
import gov.archives.dox.mapper.query.AddressbookQueryMapper;
import gov.archives.dox.mapper.query.OrgCertQueryMapper;
import gov.archives.dox.message.DoxErrorCode;
import gov.archives.dox.message.DoxErrorMessage;
import gov.archives.dox.service.AddressbookService;
import gov.archives.exchange.message.ExchangeErrorCode;
import gov.archives.exchange.message.ExchangeErrorMessage;

/**
 * AddressbookServiceImpl
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@Service
@Transactional
public class AddressbookServiceImpl implements AddressbookService {

    @Autowired
    private AddressbookQueryMapper queryMapper;

    @Autowired
    private OrgCertQueryMapper orgCertQueryMapper;

    @Override
    @Transactional(value = DoxConf.QUERY_TX_MANAGER,
                   readOnly = true)
    public List<AddressBookInfoEntity> getAllAddressBook(Map<String, Object> queryMap) {
        String exchangeStatus = (String)queryMap.get("exchangeStatus");
        Integer activeStatus = null;
        if (null != exchangeStatus) {
            if (exchangeStatus.equals("1"))
                activeStatus = new Integer(1);
            else if (exchangeStatus.equals("-1"))
                activeStatus = new Integer(-1);
            else
                activeStatus = new Integer(0);
        }
        queryMap.put("activeStatus", activeStatus);
        Object exactMatch = queryMap.get("exactMatch");
        if (null == exactMatch)
            exactMatch = "yes";
        List<AddressBookInfoEntity> list;
        if (exactMatch.equals("yes"))
            list = queryMapper.findByExactMatchMap(queryMap);
        else
            list = queryMapper.findByLikeMap(queryMap);
        if (null == list || 0 == list.size()) {
            throw new ArchivesException(DoxErrorMessage.AP0000_ERROR_MESSAGE,
                    DoxErrorCode.AP0000_DATA_NOT_FOUND);
        }
        for (AddressBookInfoEntity entity : list) {
            String updateTime = entity.getUpdateTime().substring(0, 19);
            entity.setUpdateTime(updateTime);
            if (entity.getActiveStatus() > 0) {
                entity.setStatusCode("啟用");
            } else if (entity.getActiveStatus() < 0) {
                entity.setStatusCode("審查中");
            } else {
                entity.setStatusCode("停用");
            }
        }
        return list;
    }

    @Override
    @Transactional(value = DoxConf.QUERY_TX_MANAGER,
                   readOnly = true)
    public AddressbookEntity getByOrgUnitId(Map<String, Object> queryMap) {
        AddressbookEntity entity = queryMapper.findByOrgUnitId(queryMap);
        OrgCertEntity orgCert = orgCertQueryMapper.findByOrgUnitId(queryMap);
        if (null == entity || null == orgCert) {
            throw new ArchivesException(DoxErrorMessage.AP0000_ERROR_MESSAGE,
                    DoxErrorCode.AP0000_DATA_NOT_FOUND);
        } else {
            String orgCardStatus = entity.getOrgCardStatus();
            if (null != orgCardStatus) {
                if (entity.getOrgCardStatus().equals("PRIMARY"))
                    entity.setOrgCardStatus("有卡");
                else if (entity.getOrgCardStatus().equals("NONE"))
                    entity.setOrgCardStatus("無卡");
            }
            if (orgCert.isDefault())
                orgCert.setDefaultCert("是");
            else
                orgCert.setDefaultCert("否");
            entity.setOrgCert(orgCert);
            String begin = entity.getOrgCert().getEffectBegin().substring(0, 19);
            entity.getOrgCert().setEffectBegin(begin);
            String end = entity.getOrgCert().getEffectEnd().substring(0, 19);
            entity.getOrgCert().setEffectEnd(end);
            String updateTime = entity.getModifiedTime().toString().substring(0, 19);
            entity.setUpdateTime(updateTime);
            if (entity.getActiveStatus() > 0) {
                entity.setStatusMsg("啟用");
            } else if (entity.getActiveStatus() < 0) {
                entity.setStatusMsg("審查中");
            } else {
                entity.setStatusMsg("停用");
            }
        }
        return entity;
    }
}
