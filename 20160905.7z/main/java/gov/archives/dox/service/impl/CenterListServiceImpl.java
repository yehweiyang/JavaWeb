package gov.archives.dox.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.dox.conf.DoxConf;
import gov.archives.dox.domain.entity.CenterEntity;
import gov.archives.dox.mapper.query.CenterListQueryMapper;
import gov.archives.dox.service.CenterListService;

@Service
@Transactional
public class CenterListServiceImpl implements CenterListService {

    @Autowired
    CenterListQueryMapper centerQueryMapper;

    @Override
    @Transactional(value = DoxConf.QUERY_TX_MANAGER,
                   readOnly = true)
    public List<CenterEntity> getAllCenterInfo() {
        List<CenterEntity> list = centerQueryMapper.getAll();
        CenterEntity center = new CenterEntity();
        center.setCenterId("");
        center.setCenterName("全部");
        list.add(0, center);
        return list;
    }
}
