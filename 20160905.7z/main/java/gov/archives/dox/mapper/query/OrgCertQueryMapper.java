package gov.archives.dox.mapper.query;

import java.util.Map;

import gov.archives.dox.domain.entity.OrgCertEntity;

public interface OrgCertQueryMapper {

    OrgCertEntity findByOrgUnitId(Map<String, Object> queryMap);
}
