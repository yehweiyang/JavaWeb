package gov.archives.dox.conf;

/**
 * DoxConf
 * <br>
 * dox package 下之共用設定
 * <br>
 * gemhuang, 2016/8/16.
 */
public class DoxConf {
    public static final String QUERY_TX_MANAGER = "doxQueryTxManager";
    public static final String COMMAND_TX_MANAGER = "doxCommandTxManager";
    public static final String SUCCESS_MSG = "Success";
}
