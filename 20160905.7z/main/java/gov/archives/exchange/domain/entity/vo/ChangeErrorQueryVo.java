package gov.archives.exchange.domain.entity.vo;

import java.util.UUID;

/**
 * ChangeErrorQueryVo
 * <p>
 * Created by WeiYang on 2016/8/18.
 */
public class ChangeErrorQueryVo {
    private UUID sysId;
    private String serialNo;
    private String msgCode;
    private String exchangeId;
    private String senderOrgId;
    private String applicationId;
    private String exchangeType;
    private String processId;
    private String receiverOrgId;
    private String senderUnitName;
    private String receiverUnitName;
    private String startNo;
    private String endNo;
    private String dateFrom;
    private String timeFrom;
    private String dateTo;
    private String timeTo;
    private String msgInfo;
    private String docSubject;
    private String dtdName;
    private String receiverCount;
    private String userMsgTime;
    private String sysMsgTime;
    private String toServerTime;

    private String sendOrgNameCheck;
    private String receiverOrgNameCheck;

    public UUID getSysId() {
        return sysId;
    }

    public void setSysId(UUID sysId) {
        this.sysId = sysId;
    }

    public String getExchangeId() {
        return exchangeId;
    }

    public void setExchangeId(String exchangeId) {
        this.exchangeId = exchangeId;
    }

    public String getSenderOrgId() {
        return senderOrgId;
    }

    public void setSenderOrgId(String senderOrgId) {
        this.senderOrgId = senderOrgId;
    }


    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getReceiverOrgId() {
        return receiverOrgId;
    }

    public void setReceiverOrgId(String receiverOrgId) {
        this.receiverOrgId = receiverOrgId;
    }




    public String getStartNo() {
        return startNo;
    }

    public void setStartNo(String startNo) {
        this.startNo = startNo;
    }

    public String getEndNo() {
        return endNo;
    }

    public void setEndNo(String endNo) {
        this.endNo = endNo;
    }

    public String getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }

    public String getTimeFrom() {
        return timeFrom;
    }

    public void setTimeFrom(String timeFrom) {
        this.timeFrom = timeFrom;
    }

    public String getDateTo() {
        return dateTo;
    }

    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }

    public String getTimeTo() {
        return timeTo;
    }

    public void setTimeTo(String timeTo) {
        this.timeTo = timeTo;
    }

    public String getSenderUnitName() {
        return senderUnitName;
    }

    public void setSenderUnitName(String senderUnitName) {
        this.senderUnitName = senderUnitName;
    }

    public String getReceiverUnitName() {
        return receiverUnitName;
    }

    public void setReceiverUnitName(String receiverUnitName) {
        this.receiverUnitName = receiverUnitName;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getMsgCode() {
        return msgCode;
    }

    public void setMsgCode(String msgCode) {
        this.msgCode = msgCode;
    }

    public String getMsgInfo() {
        return msgInfo;
    }

    public void setMsgInfo(String msgInfo) {
        this.msgInfo = msgInfo;
    }

    public String getDocSubject() {
        return docSubject;
    }

    public void setDocSubject(String docSubject) {
        this.docSubject = docSubject;
    }

    public String getExchangeType() {
        return exchangeType;
    }

    public void setExchangeType(String exchangeType) {
        this.exchangeType = exchangeType;
    }

    public String getDtdName() {
        return dtdName;
    }

    public void setDtdName(String dtdName) {
        this.dtdName = dtdName;
    }

    public String getReceiverCount() {
        return receiverCount;
    }

    public void setReceiverCount(String receiverCount) {
        this.receiverCount = receiverCount;
    }

    public String getUserMsgTime() {
        return userMsgTime;
    }

    public void setUserMsgTime(String userMsgTime) {
        this.userMsgTime = userMsgTime;
    }

    public String getSysMsgTime() {
        return sysMsgTime;
    }

    public void setSysMsgTime(String sysMsgTime) {
        this.sysMsgTime = sysMsgTime;
    }

    public String getToServerTime() {
        return toServerTime;
    }

    public void setToServerTime(String toServerTime) {
        this.toServerTime = toServerTime;
    }

    public String getSendOrgNameCheck() {
        return sendOrgNameCheck;
    }

    public void setSendOrgNameCheck(String sendOrgNameCheck) {
        this.sendOrgNameCheck = sendOrgNameCheck;
    }

    public String getReceiverOrgNameCheck() {
        return receiverOrgNameCheck;
    }

    public void setReceiverOrgNameCheck(String receiverOrgNameCheck) {
        this.receiverOrgNameCheck = receiverOrgNameCheck;
    }

    @Override
    public String toString() {
        return "ChangeErrorQueryVo{" +
                "exchangeId='" + exchangeId + '\'' +
                ", senderOrgId='" + senderOrgId + '\'' +
                ", applicationId='" + applicationId + '\'' +
                ", processId='" + processId + '\'' +
                ", receiverOrgId='" + receiverOrgId + '\'' +
                ", senderUnitName='" + senderUnitName + '\'' +
                ", receiverUnitName='" + receiverUnitName + '\'' +
                ", startNo='" + startNo + '\'' +
                ", endNo='" + endNo + '\'' +
                ", dateFrom='" + dateFrom + '\'' +
                ", timeFrom='" + timeFrom + '\'' +
                ", dateTo='" + dateTo + '\'' +
                ", timeTo='" + timeTo + '\'' +
                ", sendOrgNameCheck='" + sendOrgNameCheck + '\'' +
                ", receiverOrgNameCheck='" + receiverOrgNameCheck + '\'' +
                '}';
    }
}
