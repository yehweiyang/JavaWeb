package gov.archives.exchange.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.exchange.domain.entity.vo.ChangeErrorQueryVo;
import gov.archives.exchange.service.ChangeErrorQueryService;

/**
 * ChangeErrorQueryController
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
@RestController
@RequestMapping(value = "/v1/change")
public class ChangeErrorQueryController {
    private static final Logger log = LoggerFactory.getLogger(ChangeErrorQueryController.class);

    public static final String module = "交換異常查詢模組";
    public static final String successMessage = "成功";
    @Autowired
    private ChangeErrorQueryService queryService;
    @Autowired
    ServletContext servletContext;
    @Autowired
    private ActionLogService actionLogService;

    @RequestMapping(value = "/changeErrorQuery",
            method = RequestMethod.GET)
    public List<ChangeErrorQueryVo> queryAll(@RequestParam Map<String, String> requestParams) {
        ChangeErrorQueryVo changeErrorQueryVo = new ChangeErrorQueryVo();
        changeErrorQueryVo.setSenderUnitName(MapUtils.getString(requestParams, "sendOrganName"));
        changeErrorQueryVo.setSenderOrgId(MapUtils.getString(requestParams, "sendOrganId"));
        changeErrorQueryVo.setReceiverUnitName(MapUtils.getString(requestParams, "receiverOrgName"));
        changeErrorQueryVo.setReceiverOrgId(MapUtils.getString(requestParams, "receiverOrgId"));
        changeErrorQueryVo.setProcessId(MapUtils.getString(requestParams, "processId"));
        changeErrorQueryVo.setExchangeId(MapUtils.getString(requestParams, "exchangeId"));
        changeErrorQueryVo.setStartNo(MapUtils.getString(requestParams, "startNo"));
        changeErrorQueryVo.setEndNo(MapUtils.getString(requestParams, "endNo"));
        changeErrorQueryVo.setDateFrom(MapUtils.getString(requestParams, "dateFrom"));
        changeErrorQueryVo.setTimeFrom(MapUtils.getString(requestParams, "timeFrom"));
        changeErrorQueryVo.setDateTo(MapUtils.getString(requestParams, "dateTo"));
        changeErrorQueryVo.setTimeTo(MapUtils.getString(requestParams, "timeTo"));
        changeErrorQueryVo.setSendOrgNameCheck(MapUtils.getString(requestParams, "sendOrgNameCheck"));
        changeErrorQueryVo.setReceiverOrgNameCheck(MapUtils.getString(requestParams, "receiverOrgNameCheck"));
        log.info(changeErrorQueryVo.toString());
        /*
        log.info("********");
        log.info(queryService.getErrorQueryList(changeErrorQueryVo).get(0).getMsgInfo());
        log.info("********");
        */
        return queryService.getErrorQueryList(changeErrorQueryVo);
    }

    @RequestMapping(value = "/changeErrorQueryID",
            method = RequestMethod.GET)
    public ChangeErrorQueryVo queryID(@RequestParam Map<String, String> requestParams) {
        ChangeErrorQueryVo changeErrorQueryVo = new ChangeErrorQueryVo();
        log.info("---*****---");
        log.info(MapUtils.getString(requestParams, "processId"));
        return queryService.getErrorQueryID(MapUtils.getString(requestParams, "processId"));
    }

    @RequestMapping(value = "/changeErrorQueryLog",
            method = RequestMethod.GET)
    public void queryLog(HttpServletRequest httpServletRequest) {
        log.info(servletContext.getRealPath("/WEB-INF/"));
        log.info("交換異常查詢test......");
        try {
            writeActionLog(httpServletRequest, HttpStatus.OK.getReasonPhrase(), successMessage,
                    CoreConf.EVENT_LEVEL_LOW);
        } catch (ArchivesException e) {
            writeActionLog(httpServletRequest, e.getErrorCode(), e.getMessage(), CoreConf.EVENT_LEVEL_LOW);
            throw ArchivesException.getInstanceByErrorCode(e.getErrorCode());
        } catch (RuntimeException e) {
            writeActionLog(httpServletRequest, CoreErrorCode.SYSTEM_ERROR, e.getMessage(), CoreConf.EVENT_LEVEL_MEDIUM);
            throw new RuntimeException(e.getMessage());
        }

    }

    private File tempFile;

    public void createFile(InputStream is) throws IOException {
        tempFile = File.createTempFile("account_error_query", ".JSON");
        OutputStream os = new FileOutputStream(tempFile);
        int n;
        byte[] buffer = new byte[1024];
        while ((n = is.read(buffer)) > -1) {
            os.write(buffer, 0, n); // Don't allow any extra bytes to creep in,
            // final write

        }
        log.info(tempFile.getAbsolutePath());

        os.close();
    }

    @RequestMapping(value = "/changeErrorQueryTemp",
            method = RequestMethod.GET)
    public void writeFile(@RequestParam Map<String, String> query_value,Map<String, String> abc) {
        log.info("query_value==>"+query_value.size()+"");
        for(int i=0;i<query_value.size();i++){
            log.info(query_value.get(i));
        }
        log.info("value==>"+abc.size()+"");
        for(int i=0;i<abc.size();i++){
            log.info(abc.get(i));
        }
    }

    private void writeActionLog(HttpServletRequest httpServletRequest, String errorCode, String message,
            String eventLevel) {
        String currentUser = httpServletRequest.getRemoteUser();
        if (null == currentUser) { throw new RestApplicationException("Not logged in"); }
        long accessedTime = httpServletRequest.getSession().getLastAccessedTime();
        ActionLogEntity actionLogEntity = ActionLogEntity.Builder.create()
                                                                 .setActionItem(module)
                                                                 .setActionResult(message)
                                                                 .setErrorCode(errorCode)
                                                                 .setEventLevel(eventLevel)
                                                                 .setActorAccount(currentUser)
                                                                 .setActionTime(new Timestamp(accessedTime))
                                                                 .setRemoteIp(httpServletRequest.getRemoteAddr())
                                                                 .build();
        actionLogEntity.initSave(currentUser);
        actionLogService.insert(actionLogEntity);
        log.info("交換異常查詢end.........");
    }

}
