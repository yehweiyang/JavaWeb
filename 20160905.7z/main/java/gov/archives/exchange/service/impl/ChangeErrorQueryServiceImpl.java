package gov.archives.exchange.service.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.util.BeanUtils;
import gov.archives.exchange.domain.entity.ChangeErrorQueryEntity;
import gov.archives.exchange.domain.entity.vo.ChangeErrorQueryVo;
import gov.archives.exchange.mapper.query.ChangeErrorQueryMapper;
import gov.archives.exchange.service.ChangeErrorQueryService;

/**
 * ChangeErrorQueryServiceImpl
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
@Service
@Transactional
public class ChangeErrorQueryServiceImpl implements ChangeErrorQueryService {
    Logger logger =Logger.getLogger("123");
    @Autowired
    ChangeErrorQueryMapper mapper;




    @Override
    public List<ChangeErrorQueryVo> getErrorQueryList(ChangeErrorQueryVo changeErrorQueryVo) {

        List<ChangeErrorQueryVo> resultQuery = new LinkedList<>();
        int i =0;
        for (ChangeErrorQueryEntity entity:mapper.findAllQuery(changeErrorQueryVo)
                ) {
            ChangeErrorQueryVo vo = new ChangeErrorQueryVo();
            BeanUtils.copyProperties(vo, entity);

            resultQuery.add(i,vo);
            i++;

        }
        return resultQuery;
    }

    @Override
    public ChangeErrorQueryVo getErrorQueryID(String ID) {
        ChangeErrorQueryEntity entity =mapper.findIDQuery(ID);
        logger.info(entity);
        ChangeErrorQueryVo vo = new ChangeErrorQueryVo();
        BeanUtils.copyProperties(vo, entity);

        switch(vo.getExchangeType()) {
            case "INNER":
                vo.setExchangeType("內部系統");
                break;
            case "OUTTER":
                vo.setExchangeType("外部系統");
                break;
            case "eOldGW":
                vo.setExchangeType("舊系統");
                break;
            default:
        }
        logger.info(ID+"****");
        return vo;
    }

}
