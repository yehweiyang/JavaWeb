package gov.archives.core.domain.vo;

import gov.archives.core.message.CoreErrorCode;

public class VerifyResult {
	public static final String ERROR_SYS001 = "使用者無此權限";
	public static final String ERROR_AP0000 = "";
	public static final String ERROR_AP0001 = "圖型驗證碼輸入錯誤,請重新登錄";
	public static final String ERROR_AP0002 = "登入失敗,請重新登錄";
	public static final String ERROR_AP0003 = "Pin 碼輸入錯誤，請重新登入";
	public static final String ERROR_AP0004 = "卡片逾期";
	public static final String ERROR_AP0005 = "卡片錯誤，請重新登錄";
	public static final String ERROR_AP0006 = "卡片錯誤，請重新登錄";
	public static final String ERROR_AP0007 = "卡片錯誤，請重新登錄";
	public static final String ERROR_AP0008 = "登入失敗三次，要等五分鐘才能再登";
	public static final String ERROR_AP0011 = "卡片需為申請人所有";
	public static final String ERROR_AP0012 = "帳號已有人使用，請另取其他帳號";
	public static final String ERROR_AP0013 = "帳號審核中";
	public static final String ERROR_AP0014 = "帳號已停用";

	public static final String ERROR_ED0001 = "電話號碼輸入格式錯誤";
	public static final String ERROR_ED0002 = "電話號碼輸入格式錯誤";
	public static final String ERROR_ED0003 = "email輸入格式錯誤";
	public static final String ERROR_ED0017 = "帳號輸入格式錯誤";
	public static final String ERROR_ED0018 = "姓名已輸入格式錯誤";



	private Boolean isVerify;
	private String errorCode;
	private String errorMessage;

	public Boolean getIsVerify() {
		return isVerify;
	}

	public void setIsVerify(Boolean isVerify) {
		this.isVerify = isVerify;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
	
	public void setErrorMessage(String errorCode) {
		switch (errorCode) {
		case "ERROR_AP0000":
				this.errorMessage = ERROR_AP0000;
				break;
		case CoreErrorCode.UNAUTHORIZED:
			this.errorMessage = ERROR_SYS001;
			break;
		case CoreErrorCode.CAPTCHA_ERROR:
			this.errorMessage = ERROR_AP0001;
			break;
		case CoreErrorCode.ACCOUNT_ERROR:
			this.errorMessage = ERROR_AP0002;
			break;
		case CoreErrorCode.PIN_ERROR:
			this.errorMessage = ERROR_AP0003;
			break;
		case CoreErrorCode.CARD_EXPIRED:
			this.errorMessage = ERROR_AP0004;
			break;
		case CoreErrorCode.CARD_NOT_AVAILABLE:
			this.errorMessage = ERROR_AP0005;
			break;
		case CoreErrorCode.SIGNATURE_ERROR:
			this.errorMessage = ERROR_AP0006;
			break;
		case CoreErrorCode.CARD_NOT_MATCH_DATA:
			this.errorMessage = ERROR_AP0007;
			break;
		case CoreErrorCode.LOGIN_EXPIRED:
			this.errorMessage = ERROR_AP0008;
			break;
		case CoreErrorCode.CARD_INCORRECT:
			this.errorMessage = ERROR_AP0011;
			break;
			case CoreErrorCode.DUPLICATE_ACCOUNT:
			this.errorMessage = ERROR_AP0012;
			break;
		case CoreErrorCode.ACCOUNT_CHECKING:
			this.errorMessage = ERROR_AP0013;
			break;
		case CoreErrorCode.ACCOUNT_STOPING:
			this.errorMessage = ERROR_AP0014;
			break;
		case CoreErrorCode.USER_ACCOUNT_FORMAT_INCORRECT:
			this.errorMessage = ERROR_ED0017;
			break;
		case CoreErrorCode.USER_NAME_FORMAT_INCORRECT:
			this.errorMessage = ERROR_ED0018;
			break;
		case "Success":
			this.errorMessage = errorCode;
			break;	
		default:
			this.errorMessage = "Undefine Error";
		}
	}

	
    @Override
    public String toString()
    {
        return "VerifyResult [isVerify=" + isVerify + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage + "]";
    }
}
