package gov.archives.core.domain.vo;

import org.iii.common.util.StringUtils;

import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.util.BeanUtils;

/**
 * Created by 140631 on 2016/7/25.
 */
public class MenuReportVo {

    public static MenuReportVo getFromMenuEntity(MenuEntity entity) {
        MenuReportVo vo = new MenuReportVo();

        BeanUtils.copyProperties(vo, entity);

        return vo;
    }

    private String menuCode;
    private String menuName;
    private String menuMemo;

    public String getMenuCode() {
        return menuCode;
    }

    public String getMenuName() {
        return menuName;
    }

    public String getMenuMemo() {
        return menuMemo;
    }

    public void setMenuCode(String menuCode) {
        this.menuCode = StringUtils.trimFromUnsafe(menuCode);
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public void setMenuMemo(String menuMemo) {
        this.menuMemo = menuMemo;
    }
}
