package gov.archives.core.domain.vo;

import java.util.List;

/**
 * Created by kshsu on 2016/7/22.
 * 主要查詢條件父類別 FilterContent
 */
public class ReportFilter {

    private List<String> reportListFromMonth;
    /**
     * 時間區間起始日期
     */
    private String dateFrom;
    /**
     * 時間區間結束日期
     */
    private String dateTo;

    public List<String> getReportListFromMonth() {
        return reportListFromMonth;
    }

    public void setReportListFromMonth(List<String> reportListFromMonth) {
        this.reportListFromMonth = reportListFromMonth;
    }

    public String getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }

    public String getDateTo() {
        return dateTo;
    }

    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }
}
