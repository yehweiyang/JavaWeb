package gov.archives.core.domain.vo;
import org.iii.common.util.StringUtils;

/**
 * Created by pywang on 2016/7/27.
 */
public class ModifyPersonDataVO {
    private String account;
    private String userName;
    private String phoneNumber;

    private String phoneAreaCode;
    private String phoneLocalNumber;
    private String phoneExtNumber;

    private String mobileNumber;
    private String mobileAreaCode;
    private String mobileLocalNumber;
    private String email;
    private String orgInfo;
    private String certCardNum;

    private String loginCount;
    private String loginIP;
    private String loginTime;

    public void rebuildPhoneNumbers() {
        composePhoneNumber();
        composeMobileNumber();
    }


    public void composePhoneNumber() {
        phoneNumber = phoneAreaCode + "-" + phoneLocalNumber +
            ((StringUtils.isEmpty(phoneExtNumber)) ? "" : ("#" + phoneExtNumber));
    }

    public void composeMobileNumber() {
        mobileNumber = (( null == mobileAreaCode || mobileAreaCode.isEmpty()) ? "" : mobileAreaCode) +
            ((StringUtils.isEmpty(mobileLocalNumber)) ? "" : "-" + mobileLocalNumber);
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPhoneAreaCode() {
        return phoneAreaCode;
    }

    public void setPhoneAreaCode(String phoneAreaCode) {
        this.phoneAreaCode = phoneAreaCode;
    }

    public String getPhoneLocalNumber() {
        return phoneLocalNumber;
    }

    public void setPhoneLocalNumber(String phoneLocalNumber) {
        this.phoneLocalNumber = phoneLocalNumber;
    }

    public String getPhoneExtNumber() {
        return phoneExtNumber;
    }

    public void setPhoneExtNumber(String phoneExtNumber) {
        this.phoneExtNumber = phoneExtNumber;
    }

    public String getMobileAreaCode() {
        return mobileAreaCode;
    }

    public void setMobileAreaCode(String mobileAreaCode) {
        this.mobileAreaCode = mobileAreaCode;
    }

    public String getMobileLocalNumber() {
        return mobileLocalNumber;
    }

    public void setMobileLocalNumber(String mobileLocalNumber) {
        this.mobileLocalNumber = mobileLocalNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOrgInfo() {
        return orgInfo;
    }

    public void setOrgInfo(String orgInfo) {
        this.orgInfo = orgInfo;
    }

    public String getCertCardNum() {
        return certCardNum;
    }

    public void setCertCardNum(String certCardNum) {
        this.certCardNum = certCardNum;
    }

    public String getLoginCount() {
        return loginCount;
    }

    public void setLoginCount(String loginCount) {
        this.loginCount = loginCount;
    }

    public String getLoginIP() {
        return loginIP;
    }

    public void setLoginIP(String loginIP) {
        this.loginIP = loginIP;
    }

    public String getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(String loginTime) {
        this.loginTime = loginTime;
    }
}
