package gov.archives.core.domain.entity;

/**
 * Created by kshsu on 2016/7/25.
 */
public class ReportResult {

}
