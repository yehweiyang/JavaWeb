package gov.archives.core.facade.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import gov.archives.core.command.OdsToByteArrayCommand;
import gov.archives.core.command.OdsToFileCommand;
import gov.archives.core.command.OdsToStreamCommand;
import gov.archives.core.command.PdfToByteArrayCommand;
import gov.archives.core.command.PdfToFileCommand;
import gov.archives.core.command.PdfToStreamCommand;
import gov.archives.core.command.ReportCommandProcessor;
import gov.archives.core.domain.vo.ReportEnum;
import gov.archives.core.domain.vo.ReportInputModel;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.facade.ReportOutputFacade;
import gov.archives.core.service.ReportCommandService;

/**
 * Created by kshsu on 2016/7/26.
 */
@Service
public class ReportOutputFacadeImpl implements ReportOutputFacade {

    @Autowired
    ApplicationContext appContext;

    @Override
    public void genReportToFile(ReportInputModel reportInputModel) throws RestApplicationException {

        ReportCommandService reportCommandService =
                (ReportCommandService) appContext.getBean(reportInputModel.getReportType() + "CommandService");

        if (ReportEnum.PDF.equalsName(reportInputModel.getReportType().toUpperCase())) {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_FILE, new PdfToFileCommand(reportInputModel));
        } else {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_FILE, new OdsToFileCommand(reportInputModel));
        }

        reportCommandService.doProcess(ReportCommandProcessor.TO_FILE);
    }

    @Override
    public void genReportToStream(ReportInputModel reportInputModel) throws RestApplicationException {

        ReportCommandService reportCommandService =
                (ReportCommandService) appContext.getBean(reportInputModel.getReportType() + "CommandService");

        if (ReportEnum.PDF.equalsName(reportInputModel.getReportType().toUpperCase())) {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_STREAM, new PdfToStreamCommand(reportInputModel));
        } else {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_STREAM, new OdsToStreamCommand(reportInputModel));
        }

        reportCommandService.doProcess(ReportCommandProcessor.TO_STREAM);
    }

    @Override
    public void genReportToByteArray(ReportInputModel reportInputModel) throws RestApplicationException {

        ReportCommandService reportCommandService =
                (ReportCommandService) appContext.getBean(reportInputModel.getReportType() + "CommandService");

        if (ReportEnum.PDF.equalsName(reportInputModel.getReportType().toUpperCase())) {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_BYTE_ARRAY, new PdfToByteArrayCommand(reportInputModel));
        } else {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_BYTE_ARRAY, new OdsToByteArrayCommand(reportInputModel));
        }

        reportCommandService.doProcess(ReportCommandProcessor.TO_BYTE_ARRAY);
    }
}
