package gov.archives.core.security;

import java.util.Collection;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import gov.archives.core.domain.entity.UserInfoEntity;

public final class CaptchaPKIAuthenticationToken extends UsernamePasswordAuthenticationToken {
	private static final long serialVersionUID = 6064887005191943988L;
	private final UserInfoEntity user;

    public CaptchaPKIAuthenticationToken(String principal, String credentials, UserInfoEntity user) {
        super(principal, credentials);
        this.user = user;
    }

    public CaptchaPKIAuthenticationToken(UserInfoEntity principal, String credentials, Collection<? extends GrantedAuthority> authorities) {
        super(principal, credentials, authorities);
        this.user = principal;
    }
    
    public UserInfoEntity getUser() {
        return user;
    }
}
