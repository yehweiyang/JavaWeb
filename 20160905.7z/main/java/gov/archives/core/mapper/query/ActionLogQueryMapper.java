package gov.archives.core.mapper.query;

import java.util.Map;

import gov.archives.core.domain.entity.ActionLogEntity;

/**
 * Created by bachen on 2016/7/16.
 */
public interface ActionLogQueryMapper {

    ActionLogEntity lastLogInByAccount(String actorAccount);
    ActionLogEntity logInCountByAccount(String actorAccount);
}
