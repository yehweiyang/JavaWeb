package gov.archives.core.exception;

/**
 * Created by kshsu on 2016/8/9.
 */
public enum ErrorCode {
    EXCEPTION_UNKNOWN("ERR_0999","無法判斷的錯誤"),
    EXCEPTION_TEST("ERR_0888","測試錯誤"),
    EXCEPTION_IN_REPORT_UTILS("ERR_1001","ReportUtil Method 內部發生錯誤"),
    EXCEPTION_IN_REPORT_BASECOMMAND("ERR_1002","ReportBaseCommand Method 內部發生錯誤"),
    EXCEPTION_IN_REPORT_COMMAND_PROCESSOR("ERR_1003","ReportCommandProcessor Method 內部發生錯誤"),
    EXCEPTION_IN_REPORT_COMMAND_SERVICE("ERR_1004","ReportCommandService Method 內部發生錯誤"),
    EXCEPTION_IN_REPORT_DATA_GEN_SERVICE("ERR_1005","ReportDataGenService Method 內部發生錯誤"),
    EXCEPTION_IN_REPORT_DATA_PREPARE_SERVICE("ERR_1006","ReportDataPrepareService Method 內部發生錯誤"),
    EXCEPTION_IN_REPORT_OUTPUT_FACADE("ERR_1007","ReportOutputFacade Method 內部發生錯誤");

    private final String errorCode;
    private final String errorMessage;

    private ErrorCode(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    @Override
    public String toString() {
        return "errorCode: " + this.errorCode + " errorMessage: " + this.errorMessage;
    }
}
