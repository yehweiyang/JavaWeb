package gov.archives.core.exception;

import org.springframework.security.core.AuthenticationException;

public class BadCaptchaException extends AuthenticationException {

	private static final long serialVersionUID = -6533116806971349076L;

	public BadCaptchaException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	public BadCaptchaException(String msg, Throwable t) {
		super(msg, t);
	}
}
