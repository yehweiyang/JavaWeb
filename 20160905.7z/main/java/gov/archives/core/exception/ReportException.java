package gov.archives.core.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by kshsu on 2016/8/9.
 */
public class ReportException extends BaseException {

    private static final Logger log = LoggerFactory.getLogger(ReportException.class);

    public ReportException() {
        super();
    }

    public ReportException(String message) {
        super(message);
    }

    public ReportException(ErrorCode errorCode) {
        super(errorCode);
    }

    public ReportException(String message, ErrorCode errorCode) {
        super(message, errorCode);
    }

    public ReportException(String message, Throwable cause) {
        super(message, cause);
    }

    public ReportException(String message, Throwable cause, ErrorCode errorCode) {
        super(message, cause, errorCode);
    }

    public ReportException(Throwable cause) {
        super(cause);
    }

    public ReportException(Throwable cause, ErrorCode errorCode) {
        super(cause, errorCode);
    }

    protected ReportException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
