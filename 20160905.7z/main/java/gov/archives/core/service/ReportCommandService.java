package gov.archives.core.service;

import gov.archives.core.command.ReportCommand;
import gov.archives.core.exception.RestApplicationException;

/**
 * Created by kshsu on 2016/7/26.
 */
public interface ReportCommandService {
    void addCommand(String process, ReportCommand command);

    void doProcess(String process) throws RestApplicationException;
}
