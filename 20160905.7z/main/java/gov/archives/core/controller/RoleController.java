package gov.archives.core.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.UUIDEditor;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.UUIDUtils;

import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.entity.RoleMenuMappingEntity;
import gov.archives.core.domain.vo.AccountVO;
import gov.archives.core.domain.vo.RoleMenuMapping;
import gov.archives.core.domain.vo.RoleName;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.RoleService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.UUIDHandler;

/**
 * Created by tristan on 2016/8/2.
 */
@RestController
@RequestMapping(value = "/v1/systemTool/role")
public class RoleController {
    @Autowired
    private RoleService roleService;

    @Autowired
    private UserInfoService userService;


    @RequestMapping(value = "/listRoleName",
            method = RequestMethod.GET)
    public Collection<RoleName> listRoleName() {
        return roleService.listRoleName();
    }

    @RequestMapping(value = "/roleList",
            method = RequestMethod.GET)
    public List<RoleEntity> roleList() {
        return roleService.getRoleList();
    }

    @RequestMapping(value = "/newRoleType",
            method = RequestMethod.POST)
    public void addRole(@RequestParam("status") Boolean status,
            @RequestParam("roleName") String roleName) {

        int activeStatus;
        RoleEntity roleEntity = new RoleEntity();

        if (status) {
            activeStatus = 1;
        } else {
            activeStatus = 0;
        }

        try {
            if (roleService.getByRoleName(roleName) != null) {
                roleEntity.setSysId(UUID.randomUUID());
                roleEntity.setActiveStatus(activeStatus);
                roleEntity.setRoleName(roleName);
                roleEntity.initSave(userService.getCurrentAccount());
                roleService.insert(roleEntity);
            }
        } catch (ArchivesException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_UPDATE);
        }
    }

    @RequestMapping(value = "/fixRoleType",
            method = RequestMethod.PUT)
    public void fixRole(@RequestParam("oldRoleName") String oldRoleName,
            @RequestParam("fixStatus") int fixStatus,
            @RequestParam("fixRoleName") String fixRoleName) {

        List<RoleEntity> sameList;
        Map<String, Boolean> updateResult = new HashMap<String, Boolean>();
        RoleEntity roleList = roleService.getByRoleName(oldRoleName);
        RoleEntity roleEntity = new RoleEntity();
        try {
            roleEntity.setRoleName(fixRoleName);
            roleEntity.setSysId(roleList.getSysId());
            roleEntity.setActiveStatus(fixStatus);
            roleEntity.initUpdate(oldRoleName);
            sameList = roleService.getOtherList(roleEntity);
            if (roleList != null && sameList.isEmpty()) {
                roleService.update(roleEntity);
            }
        } catch (ArchivesException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_UPDATE);
        }
    }

    @RequestMapping(value = "/choiceRole",
            method = RequestMethod.GET)
    public List<RoleMenuMapping> choiceRole(@RequestParam("SysId") UUID roleSysId) {

        List<RoleMenuMapping> roleMenuList = new ArrayList<RoleMenuMapping>();
        try {
            if (roleSysId != null) {
                roleMenuList.add(roleService.getMenuMappingByRoleSysId(roleSysId));
            }
            return roleMenuList;
        } catch (ArchivesException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_SEARCH);
        }
    }

    @RequestMapping(value = "/menuConfig",
            method = RequestMethod.POST)
    public void menuConfig(@RequestParam("roleSysId") UUID roleSysId,
            @RequestParam("menu") List<UUID> menu) {

        RoleMenuMapping roleMenuMapping = new RoleMenuMapping();

        try {
            roleMenuMapping = getRoleMenuMapping(roleSysId, menu);
            roleService.updateRoleMenuMapping(roleMenuMapping);
        } catch (ArchivesException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_MENUMODIFY);
        }
    }

    private RoleMenuMapping getRoleMenuMapping(UUID roleSysId, List<UUID> menu) {

        RoleMenuMapping roleMenu = new RoleMenuMapping();
        List<MenuEntity> menuList = new ArrayList<MenuEntity>();
        RoleEntity role = new RoleEntity();

        role.setSysId(roleSysId);

        menu.stream()
            .forEach(sysId -> {
                MenuEntity menuEntity = new MenuEntity();
                menuEntity.setSysId(sysId);
                menuList.add(menuEntity);
            });
        System.out.println(menuList);
        roleMenu.setRole(role);
        roleMenu.setMenus(menuList);
        roleMenu.setCreatorAccount(userService.getCurrentAccount());

        return roleMenu;
    }
}
