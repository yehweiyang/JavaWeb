package gov.archives.core.controller;

import java.io.File;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.SignCertData;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.service.SmartCardIdentityService;

import static gov.archives.core.conf.CoreConf.REST_API_VERSION;

@RestController
@RequestMapping(path = REST_API_VERSION)
public class SignCertIdentityController {
	private static final String REST_TOKEN = "/token/{serialNumber}";

	@Autowired
	private SmartCardIdentityService identityService;

	@RequestMapping(value = REST_TOKEN,
					method = RequestMethod.GET)
	public ResponseEntity<SignCertData> getSignCert(HttpServletRequest request, @PathVariable String serialNumber) {
		try {
			File file = new File(request.getServletContext().getRealPath("") + CoreConf.CERT_FOLDER, serialNumber + ".cer");
			identityService.checkSignCert(file, System.currentTimeMillis());
			SignCertData cert = new SignCertData();
			UUID uuid = UUID.randomUUID();
			cert.setToken(uuid.toString());
			return new ResponseEntity<SignCertData>(cert, HttpStatus.OK);
		} catch (RuntimeException e) {
			throw ArchivesException.getInstanceByErrorCode(e.getMessage());
		}
	}
}
