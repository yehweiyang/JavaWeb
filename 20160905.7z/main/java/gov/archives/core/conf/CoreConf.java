package gov.archives.core.conf;

import java.util.UUID;

import org.iii.security.conf.SecurityConfig;

/**
 * Created by i00021 on 2016/5/5.
 */
public class CoreConf {
    public static final String DB_TIMESTAMP_PATTERN = "yyyy-MM-dd HH:mm:ss.SSS";

    public static final String QUERY_TX_MANAGER = "g2b2cQueryTxManager";
    public static final String COMMAND_TX_MANAGER = "g2b2cCommandTxManager";

    public static final UUID DEFAULT_ID = UUID.fromString("00000000-0000-0000-0000-000000000000");

    public static final Integer STATUS_DISABLED = 0;
    public static final Integer STATUS_ENABLED = 1;
    public static final Integer STATUS_APPLYING = -1;

    public static final String ROLE_ADMIN = "ROLE_ADMIN";
    public static final String ROLE_USER = "ROLE_USER";
    public static final String ROLE_REST = "ROLE_REST";

    public static final boolean RESTFUL = true;

    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd' 'HH:mm:ss";

    //regular expression Pattern
    public static final String DIGIT_EMPTY_PATTERN = "^[\\d]*$";
    public static final String DIGIT_PATTERN = "^[\\d]+$";
    public static final String ALPHANUMERIC_PATTERN = "^[A-Za-z0-9]+$";
    public static final String UPPER_LETTER_PATTERN = "^[A-Z]+$";
    public static final String LOWER_LETTER_PATTERN = "^[a-z]+$";
    public static final String DATE_PATTERN = "^\\d{4}-\\d{2}-\\d{2}$";
    public static final String ALPHANUMERIC_NLS_PATTERN = "^[a-zA-Z0-9\\u0080-\\u9fff ]+$";
    public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                    + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        public static final String BASE64_PATTERN =
            "^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})$";
    public static final String FILE_HASH_ALGORITHM = SecurityConfig.ALGORITHM_SHA256;
    public static final String CERT_FORMAT = "X509";
    public static final String SIGN_ALGORITHM = "SHA256withRSA";
    public static final String SUFFIX_CERT = ".cer";
    public static final String CERT_FOLDER = "CertFiles";
    public static final String SUFFIX_ODS = ".ods";
    public static final String SUFFIX_PDF = ".pdf";
    public static final String SUFFIX_HTML = ".html";
    public static final String SUFFIX_JSON = ".json";
    public static final String SUFFIX_JASPER = ".jasper";
    public static final String PRIFIX_NOTIFY = "Notify_";
    public static final String NOTIFY_FOLDER = "NotifyHtmlFiles";
    public static final String REST_API_VERSION = "/v1";
    public static final String SYSTEM_NAME = "eManager";
    public static final String CORE_BASE_URL = "/core";
    public static final String INDEX_URL = "/index";
    public static final String LOGIN_URL = "/login";
    public static final String LOGOUT_URL = "/logout";
    public static final int SESSION_LIMIT = 20;
    public static final String WEB_INFO = "WEB-INF";
    public static final String REPORT_ROOT = "report";
    public static final String TEMP_FOLDER = "tmp";

    public static final String ACTION_RESULT_UPDATE_USER_SUCCESS = "使用者資料更新成功";
    public static final String EVENT_LEVEL_HIGH = "高";
    public static final String EVENT_LEVEL_MEDIUM = "中";
    public static final String EVENT_LEVEL_LOW = "低";
}
