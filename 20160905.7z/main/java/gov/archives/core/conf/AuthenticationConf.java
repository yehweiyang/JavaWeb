package gov.archives.core.conf;

/**
 * Created by 140631 on 2016/8/5.
 */
public class AuthenticationConf {
    public static final String PARAM_USER_NAME = "account";
    public static final String LOGIN_PROCESSOR_URL = "/core/login";
    public static final String NEWLOG_PROCESSOR_URL = "/core/newAccount";
    public static final String FORWARD_TO_LOGIN_URL = "forward:/login";
    public static final String REDIRECT_LOGOUT_URL = "redirect:/login?logout";
    public static final String AUTHENFAIL = "/errors/403";

    public static final String PARAM_CARD_NUM = "cardNo";
}
