angular.module('ArchivesApp').controller('HomeController', function($scope, $http, archivesConstant) {
    $scope.$on('$viewContentLoaded', function() {   
        actionAddress = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/home";
        $http.get(actionAddress).then (function(response) {
            $("#viewArea").text(response.data.viewText);
        });
    });
});