angular.module('ArchivesApp').constant('distDocRcvUnitConstant', {
    DIST_DOC_RCV_PATH: "/distDocRcvUnit"
}).controller('DistDocRcvUnitController',
    function($rootScope, $scope, $http, $timeout, $uibModal, pkiService,
        archivesConstant, archivesService, certEventListenService, distDocRcvUnitConstant) {
        $scope.archivesService = archivesService;
        $scope.archivesService.sorter.columnName = "centerId";

        $scope.receiverUnitList = [];
        $scope.isQueried = false;
        $scope.orgId = "";
        $scope.unitId = "";
        $scope.orgUnitName = "";
        $scope.exactMatch = false;
        $scope.cardStatus = false;
        $scope.slot = pkiService.querySlot();

        $scope.queryDistReceiver = function() {

            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.DOCUMENT_SYSTEM_PATH + "/listReceiverUnit";
            setError(false,'');
            var filterJson = {
                filterSymbol: {
                    [angular.element('#lblOrgId').text()]: $scope.orgId,
                    [angular.element('#lblUnitId').text()]: $scope.unitId,
                    [angular.element('#lblOrgName').text()]: $scope.orgUnitName
                }
            }
            if (!archivesService.filterPattern(filterJson)) {
                setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage)
                return;
            }
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.DOCUMENT_SYSTEM_PATH +
                distDocRcvUnitConstant.DIST_DOC_RCV_PATH + "/listReceiverUnit";
            return $http.get(url, {
                params: {
                    orgId: $scope.orgId,
                    unitId: $scope.unitId,
                    orgUnitName: $scope.orgUnitName,
                    exactMatch: $scope.exactMatch
                }
            }).then(function(response) {

                if (response.data.length > 0) {
                    $scope.receiverUnitList = response.data;
                } else {
                    errorMessage(true, archivesConstant.QUERY_WITHOUT_RESULT);
                }
            });
        }

        $scope.reset = function() {
            $scope.orgId = "";
            $scope.unitId = "";
            $scope.orgUnitName = "";
            $scope.exactMatch = false;
            $scope.receiverUnitList = [];
            $scope.errorMessage = false;
        };

        $scope.selected = {
            unit: $scope.receiverUnitList[0]
        };

        $scope.deleteConfirmModal = function() {
            $scope.uibModalInstance = $uibModal.open({
                templateUrl: 'modalConfirmDelete.html',
                scope: $scope,
                size: 'sm'
            });
        };

        $scope.modalDeleteUnit = function() {
            pkiService.getDigitalCert($scope, null);
        };

        $scope.checkCertHashSuccess = function(actionUrl) {
            $scope.deleteUnit();
        };

        $scope.deleteUnit = function() {
            var selectedDeleteJson = {
                centerId : $scope.selected.unit.centerId,
                unitId : $scope.selected.unit.unitId,
                orgId : $scope.selected.unit.orgId,
                orgUnitName : $scope.selected.unit.orgUnitName,
                exist : $scope.selected.unit.exist
            };
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.DOCUMENT_SYSTEM_PATH +
                distDocRcvUnitConstant.DIST_DOC_RCV_PATH + "/deleteReceiverUnit";
            $http.delete(url, {params: selectedDeleteJson}).then(function successCallback(response) {
                var index = $scope.receiverUnitList.indexOf($scope.selected.unit);
                if (index > -1) {
                    actionResultViewer(archivesConstant.DELETE_SUCCESS_MSG);
                    $scope.receiverUnitList.splice(index, 1);
                    $scope.uibModalInstance.dismiss();
                } else {
                    exceptionViewer(response, false);
                }
            }, function errorCallback(response) {
                $scope.uibModalInstance.dismiss();
                exceptionViewer(response, false);
            });
        };

        $scope.modalCancel = function() {
            $scope.uibModalInstance.dismiss();
        };

        $scope.addReceiverUnit = function() {
            var queryTarget = "SET_RECEIVER";
            openUnitModal(queryTarget);
        };

        var openUnitModal = function(queryTarget, selected) {
            var uibModalInstance = $uibModal.open({
                templateUrl: "archivesapps/views/DocumentSystem/distDocUnitSelector.html",
                controller: "DistDocUnitSelectorController",
                size: 'lg',
                resolve: {
                    deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                        return $ocLazyLoad.load({
                            name: 'ArchivesApp',
                            insertBefore: '#ng_load_plugins_before',
                            files: [
                                $rootScope.settings.appPath + '/controllers/DocumentSystem/DistDocUnitSelectorController.js',
                            ]
                        });
                    }],
                    target: function() {
                        return queryTarget;
                    },
                    selected: function() {
                        return selected;
                    }
                }
            });
            uibModalInstance.result.then($scope.queryDistReceiver);
        };


        function setError(errorMessage, errorPrint) {
            $scope.receiverUnitList = [];
            $scope.errorMessage = errorMessage;
            $scope.errorPrint = errorPrint;
        }

        certEventListenService.startEventListen($scope);

    });