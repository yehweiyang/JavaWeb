angular.module('ArchivesApp').constant('distDocStatusConstant', {
        DIST_DOC_STATUS_PATH: "/distDocStatus"
    }).controller('DistDocStatusController',
    function($scope, $http, $timeout, $uibModal, archivesService, archivesConstant, distDocStatusConstant) {
        $scope.$on('$viewContentLoaded', function() {
            $scope.reset();
        });
        $scope.archivesService = archivesService;
        $scope.statusEnum = {
            "全部": 0,
            "轉文處理中": 1,
            "轉文待簽收": 2,
            "轉文已簽收": 3,
            "轉文退文": 4
        };
        $scope.docList = [];
        $scope.isQueried = false;
        $scope.selected = {
            doc: $scope.docList[0]
        };

        $scope.hourList = (function getHourArray() {
            var array = [];
            for (var i = 0; i < 24; i++) {
                var h = i;
                if (i < 10)
                    h = "0" + h;
                else
                    h = h.toString();
                array.push(h);
            }
            return array;
        })();

        $scope.openDatePickerFrom = function() {
            $scope.datePickerFrom.opened = true;
        };
        $scope.datePickerFrom = {
            opened: false
        };
        $scope.openDatePickerTo = function() {
            $scope.datePickerTo.opened = true;
        };
        $scope.datePickerTo = {
            opened: false
        };

        $scope.reset = function() {
            cleanDiv();
            $scope.processId = "";
            $scope.status = 0;
            $scope.fromOrgId = "";
            $scope.fromUnitId = "";
            $scope.fromOrgUnitName = "";
            $scope.toOrgId = "";
            $scope.toUnitId = "";
            $scope.toOrgUnitName = "";
            $scope.fromDate = new Date();
            $scope.toDate = new Date();
            $scope.fromHour = $scope.hourList[0];
            $scope.toHour = $scope.hourList[$scope.hourList.length - 1];
            $scope.exactMatch = false;
            $scope.isQueried = false;
        };

        $scope.query = function() {
            cleanDiv();
            var filterJson = {
                filterSymbol: {
                    [angular.element('#lblProcessID').text()]: $scope.processId,
                    [angular.element('#lblFromOrgId').text()]: $scope.fromOrgId,
                    [angular.element('#lblFromUnitId').text()]: $scope.fromUnitId,
                    [angular.element('#lblFromUnitName').text()]: $scope.fromOrgUnitName,
                    [angular.element('#lblToOrgId').text()]: $scope.toOrgId,
                    [angular.element('#lblToUnitId').text()]: $scope.toUnitId,
                    [angular.element('#lblToOrgName').text()]: $scope.toOrgUnitName
                }
            }
            if (!archivesService.filterPattern(filterJson)) {
                errorMessage(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage)
                return;
            }
            cleanDiv();
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                    archivesConstant.DOCUMENT_SYSTEM_PATH +
                    distDocStatusConstant.DIST_DOC_STATUS_PATH + "/listDistDoc";
                $http.get(url, {
                    params: {
                        processId: $scope.processId,
                        status: $scope.status,
                        fromOrgId: $scope.fromOrgId,
                        fromUnitId: $scope.fromUnitId,
                        fromOrgUnitName: $scope.fromOrgUnitName,
                        toOrgId: $scope.toOrgId,
                        toUnitId: $scope.toUnitId,
                        toOrgUnitName: $scope.toOrgUnitName,
                        fromTime: $scope.fromDate,
                        toTime: $scope.toDate,
                        exactMatch: $scope.exactMatch
                    }
                }).then(function(response) {
                    if (response.data.length > 0) {
                        $scope.docList = response.data;
                        $scope.isQueried = true;
                    } else {
                        errorMessage(true, archivesConstant.QUERY_WITHOUT_RESULT);
                    }
                });
            };

        $scope.openFlowHistory = function() {
            $scope.uibModalInstance = $uibModal.open({
                templateUrl: 'modalFlowHistory.html',
                scope: $scope,
                size: 'lg'
            });
            $scope.uibModalInstance.opened.then(function() {
                getFlowHistory();
            });
        };

        var getFlowHistory = function() {
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.DOCUMENT_SYSTEM_PATH + "/listFlowHistory";
            return $http.get(url, {
                params: {
                    processId: $scope.selected.doc.processId
                }
            }).then(function(response) {
                $scope.historyList = response.data;
            });
        };

        $scope.closeFlowHistory = function() {
            $scope.uibModalInstance.close();
        };

        var cleanDiv = function() {
            $scope.isQueried = false;
            $scope.errorMessage = false;
        };

        function errorMessage(errorMessage, errorPrint) {
            $scope.errorMessage = errorMessage;
            $scope.errorPrint = errorPrint;
        }
    });