angular.module('ArchivesApp').constant('distDocUnitSelectorConstant', {
    DIST_DOC_UNIT_PATH: "/distDocUnit",
    DIST_DOC_RCV_PATH: "/distDocRcvUnit"
}).controller('DistDocUnitSelectorController',
    function ($rootScope, $scope, $http, $timeout, $uibModalInstance, archivesService, pkiService, target, selected,
              archivesConstant, certEventListenService, distDocUnitSelectorConstant) {
        var switchEnum = {
            "SET_SENDER": "/listCenterSenderUnit",
            "SET_RECEIVER": "/listCenterReceiverUnit",
            "SET_MAPPING": "/listUnitMappingBySender"
        }

        $uibModalInstance.opened.then(function() {
            $scope.queryUnit();
            $scope.isQueried = true;
        });

        $scope.isQueried = false;
        $scope.functionSwitch = switchEnum[target];
        $scope.unitList = {};
        var checkedUnitList = [];
        $scope.currentPage = 1;
        $scope.maxSize = 10;
        $scope.unitPerPage = 10;
        $scope.senderUnit = {};
        $scope.archivesService = archivesService;

        $scope.queryUnit = function () {
            $scope.senderUnit = selected;
            $scope.searchUnitValue = {
                currentOrgId: ($scope.functionSwitch==switchEnum.SET_MAPPING)?$scope.senderUnit.orgId:'',
                currentUnitId: ($scope.functionSwitch==switchEnum.SET_MAPPING)?$scope.senderUnit.unitId:'',
                orgId: $('#searchOrgId').val(),
                unitId: $('#searchUnitId').val(),
                orgUnitName: $('#searchOrgUnitName').val(),
                exactMatch: false
            };

            switch ($scope.functionSwitch) {
                case switchEnum.SET_SENDER:
                    queryCenterConfig(switchEnum.SET_SENDER, distDocUnitSelectorConstant.DIST_DOC_UNIT_PATH);
                    $scope.title = '新增可轉文單位設定';
                    break;
                case switchEnum.SET_RECEIVER:
                    queryCenterConfig(switchEnum.SET_RECEIVER, distDocUnitSelectorConstant.DIST_DOC_RCV_PATH);
                    $scope.title = '新增可被轉文單位設定';
                    break;
                case switchEnum.SET_MAPPING:
                    queryCenterConfig(switchEnum.SET_MAPPING, distDocUnitSelectorConstant.DIST_DOC_UNIT_PATH);
                    $scope.title = '被轉文機關設定 ' + $scope.senderUnit.orgUnitName;
                    break;
            }
        };

        $scope.reset = function() {
            $scope.search.orgId = "";
            $scope.search.unitId = "";
            $scope.search.orgUnitName = "";
            cleanDiv();
        };

        function queryCenterConfig(actionUrl, subMenuUrl){
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.DOCUMENT_SYSTEM_PATH + subMenuUrl + actionUrl;
            if ($scope.search != undefined) {
                cleanDiv();
                var filterJson = {
                    filterSymbol: {
                        [angular.element('#lblOrgId').text()]: $scope.search.orgId,
                        [angular.element('#lblUnitId').text()]: $scope.search.unitId,
                        [angular.element('#lblOrgName').text()]: $scope.search.orgUnitName
                    }
                }
                if (!archivesService.filterPattern(filterJson)) {
                    errorMessage(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage)
                    return;
                }
            }
            $http.get(url, {
                params: $scope.searchUnitValue
            }).then(function(response) {
                if (response.data.length > 0) {
                    $scope.unitList = response.data;
                } else {
                    errorMessage(true, archivesConstant.QUERY_WITHOUT_RESULT);
                }
            });
        }

        $scope.confirm = function() {

            switch ($scope.functionSwitch) {
                case switchEnum.SET_SENDER:
                    pkiService.getDigitalCert($scope, switchEnum.SET_SENDER);
                    break;
                case switchEnum.SET_RECEIVER:
                    pkiService.getDigitalCert($scope, switchEnum.SET_RECEIVER);
                    break;
                case switchEnum.SET_MAPPING:
                    pkiService.getDigitalCert($scope, switchEnum.SET_MAPPING);
                    break;
            }
        };

        $scope.checkCertHashSuccess = function(actionUrl) {
            if (actionUrl == switchEnum.SET_SENDER) {
                setSender();
            } else if (actionUrl == switchEnum.SET_RECEIVER) {
                setReceiver();
            } else if (actionUrl == switchEnum.SET_MAPPING) {
                serMapping();
            }
        }

        $scope.cancel = function() {
            $uibModalInstance.close("Cancel");
        };

        var setSender = function() {
            checkedUnitList = $scope.unitList.filter(function(unit) {
                return unit.exist;
            });
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                    archivesConstant.DOCUMENT_SYSTEM_PATH +
                    distDocUnitSelectorConstant.DIST_DOC_UNIT_PATH + "/setSenderUnit";
            $http.put(url, checkedUnitList).then(function successCallback(response) {
                $uibModalInstance.close();
            }, function errorCallback(response) {
                exceptionViewer(response, false);
            });
        };

        var setReceiver = function() {
            checkedUnitList = $scope.unitList.filter(function(unit) {
                return unit.exist;
            });
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                    archivesConstant.DOCUMENT_SYSTEM_PATH +
                distDocUnitSelectorConstant.DIST_DOC_RCV_PATH + "/setReceiverUnit";
            $http.put(url, checkedUnitList).then(function successCallback(response) {
                $uibModalInstance.close();
            }, function errorCallback(response) {
                exceptionViewer(response, false);
            });
        };

        var serMapping = function() {
            checkedUnitList = $scope.unitList.filter(function(unit) {
                return unit.exist;
            });
            var mappingMap = {
                senderOrgId: $scope.senderUnit.orgId,
                senderUnitId: $scope.senderUnit.unitId,
                mappingList: []
            };
            checkedUnitList.forEach(function(unit) {
                var mapping = {
                    senderOrgId: $scope.senderUnit.orgId,
                    senderUnitId: $scope.senderUnit.unitId,
                    receiverOrgId: unit.orgId,
                    receiverUnitId: unit.unitId
                };
                mappingMap.mappingList.push(mapping);
            });
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                    archivesConstant.DOCUMENT_SYSTEM_PATH +
                    distDocUnitSelectorConstant.DIST_DOC_UNIT_PATH + "/setDistributeMapping";
            $http.put(url, mappingMap).then(function successCallback() {
                $uibModalInstance.close();
            }, function errorCallback(response) {
                exceptionViewer(response, false);
            });
        };

        var cleanDiv = function() {
            $scope.errorMessage = false;
            $scope.unitList.length = 0;
        }

        function errorMessage(errorMessage, errorPrint) {
            $scope.errorMessage = errorMessage;
            $scope.errorPrint = errorPrint;
        }

        certEventListenService.startEventListen($scope);

    });