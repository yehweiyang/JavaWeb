
includeOtherScript("changeRecordFactory");
angular.module('ArchivesApp').controller('InsideSendChangeController', function($scope, changeRecordFactory) {
	changeRecordFactory.startServiceByScope($scope);

});