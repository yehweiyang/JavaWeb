includeOtherScript("changeRecordFactory");
angular.module('ArchivesApp').controller('OutsideReceiveChangeController', function($scope, changeRecordFactory) {
    changeRecordFactory.startServiceByScope($scope);
});