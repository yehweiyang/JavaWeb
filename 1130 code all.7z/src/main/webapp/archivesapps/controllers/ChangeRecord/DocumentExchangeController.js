includeOtherScript("changeCacheFactory");
angular.module('ArchivesApp').constant('documentExchangeConstant', {
	INSIDE_SEND_CHANGE_PATH: "/insideSendChange",
	OUTSIDE_SEND_CHANGE_PATH: "/outsideReceiveChange"
}).controller('DocumentExchangeController', function($scope, $http, $state, restUrlFactory, changeCacheFactory,
    archivesConstant, archivesService, documentExchangeConstant) {

	var prefixUrl = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH;
	$scope.archivesService = archivesService;
	$scope.uibPageBase = 10;
	$scope.start = 0;
	$scope.end = $scope.uibPageBase;
	$scope.maxSize = 5;

	$scope.pageChanged = function() {
    	$scope.end = $scope.currentPage * $scope.uibPageBase;
    	$scope.start = $scope.end - $scope.uibPageBase;
	};

	$scope.exchange = changeCacheFactory.getExchange();
	if ($scope.exchange == null) {
	    $state.go("InsideSendChange");
	} else {

	    var url = prefixUrl;

	    if ($scope.exchange.transmitType == archivesConstant.INNER_TRANSMIT_TYPE) {
	        $scope.titleMsg = archivesConstant.SENDER_TITLE_MSG
	        url += archivesConstant.CHANGE_RECORD_PATH + documentExchangeConstant.INSIDE_SEND_CHANGE_PATH +
				"/recordList/inner/detail/";
	    } else if ($scope.exchange.transmitType == archivesConstant.OUT_TRANSMIT_TYPE) {
	        $scope.titleMsg = archivesConstant.RECEIVE_TITLE_MSG
            url += archivesConstant.CHANGE_RECORD_PATH + documentExchangeConstant.OUTSIDE_SEND_CHANGE_PATH +
				"/recordList/outter/detail/";
        }
        url += $scope.exchange.exchangeSerial;
        $http.get(url).then(function(response) {
            $scope.docTransmitMsgList = response.data;
            $scope.totalItems = $scope.docTransmitMsgList.length;
            $scope.currentPage = 1;
    	    $scope.start = 0;
    	    $scope.end = $scope.uibPageBase;
    	    $scope.showError = false;
    	    $scope.showTable = true;
        }, function(errResponse) {
            $scope.errorMessage = errResponse.data.errorMessage;
            $scope.showError = true;
            $scope.showTable = false;
        });
	}

	$scope.detailBt = function(transmitMsg) {
        changeCacheFactory.setTransmitDetail(transmitMsg);
        $state.go("DocumentExchangeDetail");
	}

	$scope.returnBt = function(transmitMsg) {
	    changeCacheFactory.setExchange(null);
        if ($scope.exchange.transmitType == archivesConstant.INNER_TRANSMIT_TYPE)
            $state.go("InsideSendChange");
        else if ($scope.exchange.transmitType == archivesConstant.OUT_TRANSMIT_TYPE)
            $state.go("OutsideReceiveChange");
    }
});