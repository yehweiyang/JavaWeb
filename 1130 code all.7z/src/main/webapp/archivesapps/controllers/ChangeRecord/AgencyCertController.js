angular.module('ArchivesApp').constant('agencyCertConstant', {
    AGENCY_CERT_PATH: "/agencyCert",
    HEAD_APPLICATION: "application",
    TMP_FILE_ID: "logPath",
    TMP_FILE_CLASS: "hidden"
}).controller('AgencyCertController', function ($rootScope, $scope, $http, pkiService, archivesConstant, agencyCertConstant) {

    //取得certHash能-開始
    $scope.getCertHash = function() {
        $("#selectCertHash").empty();
        $("#selectCertHash").append('<select class="selectpicker show-tick form-control" data-live-search="true" ng-model="certHash" id="changeCerHash" style="display:none;"><option class="get-class" value="" disabled selected>請選擇</option></select>');
        setError(false, '');
        var pattern_TW = /[^\u4e00-\u9fa5a-zA-Z0-9]/;
        if ($scope.orgId == '') {
            setError(true, '$請確實填寫欄位');
            return;
        }
        if (pattern_TW.test($scope.orgId)) {
            setError(true, '$請勿輸入特殊符號');
            return;
        }


        $http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.CHANGE_RECORD_PATH + agencyCertConstant.AGENCY_CERT_PATH +
                "/certHash/" + $scope.orgId)
            .success(function(response) {
                if (response.length > 0) {
                    selectOption(response);
                    $scope.toggleOrgList = true;
                } else {
                    setError(true, '$機關代碼錯誤');
                }
            }).error(function(response) {
                exceptionViewer(response, false);
            });
        }
        //取得certHash能-結束

    function selectOption(allOrgCert) {

        for (var i = 0; i < allOrgCert.length; i++) {
            $('#changeCerHash').append('<option value="' + allOrgCert[i].signCertHash + '">' +
                allOrgCert[i].signCertHash + '</option>');
        }
        $('.selectpicker').selectpicker();
        $('#changeCerHash').css('display', 'block');
    }

    //查詢檔案功能-開始
    $scope.searchLog = function () {
        if ($('#changeCerHash option:checked').val() == ''|| !$scope.orgId) {
            setError(true, '請選擇CertHash');
            return false;
        }

        var orgValue = {
            orgId: $scope.orgId,
            certHash: $('#changeCerHash option:checked').val()
        };

        $http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.CHANGE_RECORD_PATH + agencyCertConstant.AGENCY_CERT_PATH +
                "/searchLogFile", {
                    params: orgValue
                })
            .success(function(response) {
                $scope.file = response;
                if ($scope.file.length == 0) {
                    setError(true, '查無資料');
                }
                $('#logFile').css('display', 'block');
            }).error(function(response) {
                exceptionViewer(response, false);
            });
    };
    //查詢檔案功能-結束

    //下載檔案功能-開始
    $scope.downloadLogFile = function(fileName) {

        var logValue = {
            orgId: $scope.orgId,
            certHash: $('#changeCerHash option:checked').val(),
            fileName: fileName
        };

        $http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.CHANGE_RECORD_PATH + agencyCertConstant.AGENCY_CERT_PATH + "/downloadLogFile", {params: logValue})
            .success(function (response) {
                setError(false, '');
                var exportType = fileName.split(".");
                var convertToBlob = new Blob([response], {
                    type: agencyCertConstant.HEAD_APPLICATION + "/" + exportType[1]
                });
                var createURL = URL.createObjectURL(convertToBlob);

                var fileDownload = document.createElement("a");
                fileDownload.id = agencyCertConstant.TMP_FILE_ID;
                fileDownload.class = agencyCertConstant.TMP_FILE_CLASS;
                fileDownload.href = createURL;
                fileDownload.download = fileName;
                document.body.appendChild(fileDownload);
                fileDownload.click();
                document.body.removeChild(fileDownload);
            }).error(function (response) {
                exceptionViewer(response, false);
            });
    };
    //下載檔案功能-結束

    //清空功能-開始
    $scope.giveUp = function() {
        $("#selectCertHash").empty();
        $("#selectCertHash").append('<select class="selectpicker show-tick form-control" data-live-search="true"' +
            'ng-model="certHash" id="changeCerHash" style="display:none;">' +
            '<option class="get-class" value="" disabled selected>請選擇</option></select>');
        $('#logFile').css('display', 'none');
        $scope.file = "";
        $scope.orgId = '';
        setError(false, '');
        $scope.toggleOrgList = false;
    };
    //清空功能-結束

    function setError(errorStatus, errorMessage) {
        $scope.toggleOrgList = false;
        $scope.errorMessage = errorStatus;
        $scope.error = errorMessage;
    }

});