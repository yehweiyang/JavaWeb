angular.module('ArchivesApp').constant('exchangeAbnormalConstant', {
    EXCHANGE_ABNORMAL_PATH: "/exchangeAbnormal"
}).controller('ExchangeAbnormalQueryController',function ($scope, $http, $rootScope, $uibModal, archivesConstant,
    archivesService,restUrlFactory, exchangeAbnormalConstant) {
        var prefixUrl = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
            archivesConstant.CHANGE_RECORD_PATH + exchangeAbnormalConstant.EXCHANGE_ABNORMAL_PATH;
        $scope.$on('$viewContentLoaded', function () {
            $scope.reset();
            init();
        });

        $scope.archivesService = archivesService;
        $scope.archivesService.sorter.columnName = "account";
        $scope.archivesService.pager.itemsPerPage = 100;

        $scope.saveHtmlBt = function(id) {
            var queryProcessId = {
                processId: id.processId
            };
            var url = prefixUrl + '/exchangeAbnormalQueryID';
            $http.get(url, {
                params: queryProcessId
            }).success(function(data, status, headers, config) {
                $scope.detail = data;
                switch($scope.detail.exchangeType) {
                    case '內部系統':
                        $scope.detail.exchangeType='內部對內部交換';
                        break;
                    case '外部系統':
                        $scope.detail.exchangeType='內部對外部交換';
                        break;
                    case '舊系統':
                        $scope.detail.exchangeType='內部對舊系統交換';
                        break;
                    default:
                        $scope.detail.exchangeType='系統交換';
                }
                $scope.detail.toServerTime = new Date($scope.detail.toServerTime);
                $scope.detail.sysMsgTime = new Date($scope.detail.sysMsgTime);
                $scope.detail.userMsgTime = new Date($scope.detail.userMsgTime);

                return $scope.detail;
            })
            var modal = $uibModal.open({
                templateUrl: archivesConstant.APP_PATH + "/views/ChangeRecord/detailInfo.html",
                scope: $scope,
                size: 'modal-dialog modal-lg'
            })
        }

        $scope.$watch('hideOrShow', function() {
            $scope.toggleText = $scope.hideOrShow ? '開啟異常訊息' : '隱藏異常訊息';
        })

        $scope.query = function() {
            cleanDiv();

            var startNo = '起始' + $("#lblNo").text();
            var endNo = '結束' + $("#lblNo").text();

            var filterJson = {
                filterSymbol: {
                    [angular.element('#lblSendOrgId').text()]: $scope.error.sendOrganId,
                    [angular.element('#lblSendOrgName').text()]: $scope.error.sendOrgName,
                    [angular.element('#lblReceiverOrgId').text()]: $scope.error.receiverOrgId,
                    [angular.element('#lblReceiverOrgName').text()]: $scope.error.receiverOrgName,
                    [angular.element('#lblExchangeId').text()]: $scope.error.exchangeId,
                    [angular.element('#lblProcessId').text()]: $scope.error.processId
                },
                onlyNumber: {
                    [startNo]: $scope.error.startNo,
                    [endNo]: $scope.error.endNo
                }
            }

            if (!archivesService.filterPattern(filterJson)) {
                errorMessage(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
                return
            }




            var url = prefixUrl + '/exchangeAbnormalQuery';
            $http.get(url, {
                params: $scope.error
            }).success(function(data) {
                if (data.length > 0) {
                    $scope.userList = data;
                    $scope.errorMessage = false;
                    $scope.myVar = true;
                    $scope.hideOrShow = true;
                    var url = prefixUrl + '/exchangeAbnormalQueryWriteTemp';
                    $http.get(url, {
                        params: {
                            query_value: $scope.error
                        }
                    })
                } else {
                    errorMessage(true,  archivesConstant.QUERY_WITHOUT_RESULT);
                    $scope.myVar = false;
                }
            }).error(function(response) {
                exceptionViewer(response, false);
            });
        }



        $scope.master = {
            sendOrgName: "",
            sendOrganId: "",
            receiverOrgName: "",
            receiverOrgId: "",
            processId: "",
            exchangeId: "",
            startNo: "",
            endNo: "",
            dateFrom: new Date(),
            timeFrom: "00",
            dateTo: new Date(),
            timeTo: "23",
            isCheck: 'false'
        };
        $scope.reset = function() {
            $scope.errorMessage = false;
            $scope.myVar = false;
            $scope.error = angular.copy($scope.master);
        };

        $scope.prop = {
            "type": "select",
            "value00": "00",
            "value23": "23",
            "values": ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
                "22", "23"
            ]
        };

        var init = function() {
            //讀取xml檔
            var url = prefixUrl + '/exchangeAbnormalQueryReadXML';
            $http.get(url)
                .success(function(data) {
                    if (data.length > 0) {
                        $scope.ehubName = {
                            "values": data
                        };
                    } else {
                        $scope.eHubSource = 'none';
                    }
                })

            //讀取暫存檔
            var url = prefixUrl + '/exchangeAbnormalQueryReadTemp';
            $http.get(url)
                .success(function(data) {
                    if (data != "") {
                        var url = prefixUrl + '/exchangeAbnormalQuery';
                        $http.get(url, {
                            params: data
                        }).success(function(dataInside) {
                            //如果暫存檔查詢有值則將form表單填上
                            $scope.userList = dataInside;
                            $scope.noResult = false;
                            $scope.myVar = true;
                            $scope.hideOrShow = true;
                            $scope.error = data;
                            $scope.error.dateFrom = new Date($scope.error.dateFrom);
                            $scope.error.dateTo = new Date($scope.error.dateTo);
                        })
                    }
                })
        }

        $scope.openDateFromCalendar = function() {
            $scope.dateFromCalendar.opened = true;
        };

        $scope.openDateToCalendar = function() {
            $scope.dateToCalendar.opened = true;
        };
        $scope.dateFromCalendar = {
            opened: false
        };

        $scope.dateToCalendar = {
            opened: false
        };

        function errorMessage(errorStatus, errorMessage) {
            $scope.errorMessage = errorStatus;
            $scope.errorPrint = errorMessage;
        }
        var cleanDiv = function() {
            $scope.myVar = false;
            $scope.errorMessage = false;
        };

    });