angular.module('ArchivesApp').controller('OrganReceiveController',
    function($rootScope, $scope, $http, $state, calendarPicker,
    archivesService,  archivesConstant, sessionStorageFactory) {
    var self = this;

    $scope.calendarPicker = calendarPicker;
    $scope.toggleCalendar = function (datePickerId) {
        $scope[datePickerId] = $scope.calendarPicker.toggleCalendar($scope[datePickerId]);
    };

    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = "account";
    $scope.docSubjectMsg = "顯示主旨訊息";
    $scope.exactMatch = 'no';
    $scope.exchangeList = [];
    $scope.organReceiveData = {};

    $scope.today = function() {
        $scope.startDate = new Date();
        $scope.endDate = new Date();
    };

    $scope.hourList = function() {
        var array = [];
        for (var i = 0; i < 24; i++) {
            var hour = i.toString().length < 2 ? "0" + i : i;
            array.push(hour);
        }
        return array;
    };

    $scope.docSubjectBt = function() {
        if ($scope.showDocSubject) {
            $scope.showDocSubject = false;
            $scope.docSubjectMsg = "顯示主旨訊息";
        } else {
            $scope.showDocSubject = true;
            $scope.docSubjectMsg = "隱藏主旨訊息";
        }
    };

    $scope.exchangeTypeList = [
        {exchangeType: "全部"},
        {exchangeType: "內部交換"},
        {exchangeType: "外部交換"},
        {exchangeType: "舊新交換"}
    ];
    $scope.exchangeType = $scope.exchangeTypeList[0];

    $scope.tmpExchange = function(tmpData){
        var tmpOrganReceiveData = {};
        if($scope.organReceiveData != null){
            tmpOrganReceiveData = $scope.organReceiveData;
        }

        tmpOrganReceiveData.tmpData = tmpData;
        tmpOrganReceiveData.tmpStartHour = $scope.selectedStartHour;
        tmpOrganReceiveData.tmpEndHour = $scope.selectedEndHour;
        if (tmpOrganReceiveData.startDocId != null){
            if(tmpOrganReceiveData.startDocId.length == 0){
                tmpOrganReceiveData.startDocId = null;
            }
        }
        if(tmpOrganReceiveData.endDocId != null){
            if(tmpOrganReceiveData.endDocId.length == 0){
                tmpOrganReceiveData.endDocId = null;
            }
        }

        tmpOrganReceiveData.exchangeID = $scope.exchangeID;
        tmpOrganReceiveData.senderUnitName = $scope.senderUnitName;
        tmpOrganReceiveData.senderOrgId = $scope.senderOrgID;
        tmpOrganReceiveData.receiverUnitName = $scope.receiverUnitName;
        tmpOrganReceiveData.receiverOrgID = $scope.receiverOrgID;
        tmpOrganReceiveData.applicationIdStart = $scope.startDocId;
        tmpOrganReceiveData.applicationIdEnd = $scope.endDocId;
        var startMm = $scope.startDate.getMonth() + 1;
        var startMonth = startMm<10 ? '0'+ startMm: startMm;
        tmpOrganReceiveData.startUpDateTime = $scope.startDate.getFullYear() +'-'+ startMonth +'-'+  $scope.startDate.getDate() + " " +
                                           $scope.selectedStartHour + ":00:00";
        var endMm = $scope.endDate.getMonth() + 1;
        var endMonth = endMm<10 ? '0'+ endMm: endMm;
        tmpOrganReceiveData.endUpDateTime = $scope.endDate.getFullYear() +'-'+ endMonth +'-'+  $scope.endDate.getDate() + " " +
                                         $scope.selectedEndHour + ":00:00";
        tmpOrganReceiveData.exactMatch = $scope.exactMatch;
        tmpOrganReceiveData.exchangeType = $scope.exchangeTypeList.indexOf($scope.exchangeType);
        var config = {
            params: tmpOrganReceiveData
        };

        var url = "/manageWeb/v1/ChangeRecord/organReceive/read";
        sessionStorageFactory.setDocReceiveData(tmpOrganReceiveData);
        $http.get(url, config).then(function(response) {

            //if search no data
            var hasAnyViewData = $.trim(response.data) !== '';
            $scope.showError = !hasAnyViewData;
            $scope.showTable = hasAnyViewData;
            $scope.exchangeList = hasAnyViewData ? response.data : "";
            $scope.errorPrint = archivesConstant.QUERY_WITHOUT_RESULT;

            //$scope.exchangeList = response.data;
            $scope.totalItems = $scope.exchangeList.length;

            if($scope.totalItems == 0){
                $scope.searchNoData(response);
            } else {
                $scope.currentPage = 1;
                $scope.start = 0;
                $scope.end = $scope.uibPageBase;
                $scope.showError = false;
                $scope.showTable = true;
                $scope.showTmpTable = false;
            }
        });
    };


    $scope.searchNoData = function(errResponse) {
        $scope.errorMessage = errResponse.data.errorMessage;
        $scope.showError = true;
        $scope.showTable = false;
        $scope.showTmpTable = false;
    };

    $scope.queryBt = function(form) {
        setError(false, '');
        var filterJson = {
            filterSymbol: {
                [angular.element("#lblExchangeID").text()]: $scope.exchangeID,
                [angular.element("#lblSenderOrgID").text()]: $scope.senderOrgID,
                [angular.element("#lblSenderUnitName").text()]: $scope.senderUnitName,
                [angular.element("#lblReceiverOrgID").text()]: $scope.receiverOrgID,
                [angular.element("#lblReceiverUnitName").text()]: $scope.receiverUnitName
            },
            onlyNumber: {
                ['起始文號']: $scope.startDocId,
                ['結束文號']: $scope.endDocId
            }
        }

        if (!archivesService.filterPattern(filterJson)) {
            setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
            return
        }


        if(form.$valid){
            $scope.showTmpTable = true;
            $scope.tmpExchange(false);
        }else{
            $scope.errorMessage = "輸入格式錯誤";
            $scope.showError = true;
            $scope.showTable = false;
        }
    };

    $scope.transmitBt = function(exchange) {
        exchange.receiveType = 'DocReceive';
        sessionStorageFactory.setExchange(exchange);
        $state.go("OrganReceiveDocReceive");
    };

    $scope.resetBt = function() {
        $scope.today();
        $scope.exactMatch = 'no';
        $scope.selectedStartHour = '00';
        $scope.selectedEndHour = 23;
        $scope.showError = false;
        $scope.showTable = false;
        $scope.showDocSubject = false;
        $scope.docSubjectMsg = "顯示主旨訊息";
        $scope.exchangeType = $scope.exchangeTypeList[0];
        $scope.exchangeID = null;
        $scope.senderOrgID = null;
        $scope.senderUnitName = null;
        $scope.receiverOrgID = null;
        $scope.receiverUnitName = null;
        $scope.startDocId = null;
        $scope.endDocId = null;
        sessionStorageFactory.setExchange(null);
        sessionStorageFactory.setDocReceiveData(null);
    };

    //在別的頁面返回到上一頁時,判斷是否要儲存上一頁的結果
    $scope.exchange = sessionStorageFactory.getExchange();
    $scope.organReceiveData = sessionStorageFactory.getDocReceiveData();
    if ($scope.organReceiveData != null) {
        $scope.startDate = new Date($scope.organReceiveData.startUpDateTime);
        $scope.endDate = new Date($scope.organReceiveData.endUpDateTime);
        $scope.selectedStartHour = $scope.organReceiveData.tmpStartHour;
        $scope.selectedEndHour = $scope.organReceiveData.tmpEndHour;
        $scope.exchangeType = $scope.exchangeTypeList[$scope.organReceiveData.exchangeType == -1 ? 0 : $scope.organReceiveData.exchangeType];
        $scope.exchangeID = $scope.organReceiveData.exchangeID;
        $scope.senderOrgID = $scope.organReceiveData.senderOrgId;
        $scope.senderUnitName = $scope.organReceiveData.senderUnitName;
        $scope.receiverOrgID = $scope.organReceiveData.receiverOrgID;
        $scope.receiverUnitName = $scope.organReceiveData.receiverUnitName;
        $scope.startDocId = $scope.organReceiveData.applicationIdStart;
        $scope.endDocId = $scope.organReceiveData.applicationIdEnd;
        $scope.exactMatch = $scope.organReceiveData.exactMatch;
        $scope.tmpExchange(true);
    } else {
        if ($scope.exchange != null && $scope.exchange.receiveType == 'DocReceive') {
            $scope.tmpExchange(true);
        } else {
            $scope.organReceiveData = null;
            $scope.today();
            $scope.selectedStartHour = '00';
            $scope.selectedEndHour = 23;
            sessionStorageFactory.setDocReceiveIndexPage(1);
        }
    }

    function setError(showError, errorPrint) {
                $scope.showTable = false;
                $scope.showError = showError;
                $scope.errorPrint = errorPrint;
            }
});

ArchivesApp.service('calendarPicker', function(){
    this.getToday = function() {
        return new Date();
    };

    this.toggleCalendar = function(datePicker) {
        return datePicker = { opened : typeof datePicker === 'undefined' ? true : !datePicker.opened  };
    };
});

ArchivesApp.factory('sessionStorageFactory', function () {

    if (typeof(Storage) === "undefined") {
        console.log("瀏覽器不支援Web Storage");
        successViewer("瀏覽器不支援Web Storage");
        return;
    }

    var factory = {
        getDocSendData: function () {
            return JSON.parse(sessionStorage.getItem("docSendData"));
        },
        setDocSendData: function (data) {
            sessionStorage.setItem("docSendData", JSON.stringify(data));
        },
        getDocReceiveData: function () {
            return JSON.parse(sessionStorage.getItem("docReceiveData"));
        },
        setDocReceiveData: function (data) {
            sessionStorage.setItem("docReceiveData", JSON.stringify(data));
        },
        getExchange: function () {
            return JSON.parse(sessionStorage.getItem("exchange"));
        },
        setExchange: function (data) {
            sessionStorage.setItem("exchange", JSON.stringify(data));
        },
        getTransmitDetail: function () {
            return JSON.parse(sessionStorage.getItem("transmitDetail"));
        },
        setTransmitDetail: function (data) {
            sessionStorage.setItem("transmitDetail", JSON.stringify(data));
        },
        getDocSendIndexPage: function () {
            return JSON.parse(sessionStorage.getItem("docSendIndexPage"));
        },
        setDocSendIndexPage: function (data) {
            sessionStorage.setItem("docSendIndexPage", JSON.stringify(data));
        },
        getDocReceiveIndexPage: function () {
            return JSON.parse(sessionStorage.getItem("docReceiveIndexPage"));
        },
        setDocReceiveIndexPage: function (data) {
            sessionStorage.setItem("docReceiveIndexPage", JSON.stringify(data));
        }
    };

    return factory;
});
