angular.module('ArchivesApp').controller('OrganReceiveDocReceiveController',
   function($scope, $http, $state,sessionStorageFactory) {

    $scope.exchange = sessionStorageFactory.getExchange();
    if (null == $scope.exchange ) {
        $state.go("OrganReceiveDocReceive");
    }
    console.log(sessionStorage.docSendData);

});

ArchivesApp.factory('sessionStorageFactory', function () {

    if (typeof(Storage) === "undefined") {
        console.log("瀏覽器不支援Web Storage");
        successViewer("瀏覽器不支援Web Storage");
        return;
    }

    var factory = {
        getDocSendData: function () {
            return JSON.parse(sessionStorage.getItem("docSendData"));
        },
        setDocSendData: function (data) {
            sessionStorage.setItem("docSendData", JSON.stringify(data));
        },
        getDocReceiveData: function () {
            return JSON.parse(sessionStorage.getItem("docReceiveData"));
        },
        setDocReceiveData: function (data) {
            sessionStorage.setItem("docReceiveData", JSON.stringify(data));
        },
        getExchange: function () {
            return JSON.parse(sessionStorage.getItem("exchange"));
        },
        setExchange: function (data) {
            sessionStorage.setItem("exchange", JSON.stringify(data));
        },
        getTransmitDetail: function () {
            return JSON.parse(sessionStorage.getItem("transmitDetail"));
        },
        setTransmitDetail: function (data) {
            sessionStorage.setItem("exchange", JSON.stringify(data));
        },
        getDocSendIndexPage: function () {
            return JSON.parse(sessionStorage.getItem("docSendIndexPage"));
        },
        setDocSendIndexPage: function (data) {
            sessionStorage.setItem("docSendIndexPage", JSON.stringify(data));
        },
        getDocReceiveIndexPage: function () {
            return JSON.parse(sessionStorage.getItem("docReceiveIndexPage"));
        },
        setDocReceiveIndexPage: function (data) {
            sessionStorage.setItem("docReceiveIndexPage", JSON.stringify(data));
        }
    };
    return factory;
});
