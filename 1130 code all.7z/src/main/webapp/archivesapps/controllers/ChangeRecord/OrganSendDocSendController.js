angular.module('ArchivesApp').controller('OrganSendDocSendController',
    function($rootScope, $scope, $http, $state, archivesService, archivesConstant,sessionStorageFactory)
{
    //排序
    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = "account";
//  $scope.archivesService.pager.itemsPerPage = 1000;
//--
    $scope.uibPageBase = 10;
    $scope.showPurport = false;
    $scope.DocSendData = {};
    $scope.start = 0;
    $scope.end = $scope.uibPageBase;
    $scope.showTable = true;
    $scope.maxSize = 5;
    $scope.pageChanged = function() {
       $scope.end = $scope.currentPage * $scope.uibPageBase;
       $scope.start = $scope.end - $scope.uibPageBase;
    };
//--

    $scope.exchange = sessionStorageFactory.getExchange();
    if (null == $scope.exchange ) {
            $state.go("OrganSendDocSend");
    } else {
            var url = "/manageWeb/v1/exchange/organSend/detail/" + $scope.exchange.exchangeID;

            $http.get(url).then(function(response) {
                $scope.docTransmitMsgList = response.data;
                $scope.totalItems = $scope.docTransmitMsgList.length;
                //--
                $scope.currentPage = 1;
                $scope.start = 0;
                $scope.end = $scope.uibPageBase;
                //--
                $scope.showError = false;
                $scope.showTable = true;
            }, function(errResponse) {
                $scope.errorMessage = errResponse.data.errorMessage;
                $scope.showError = true;
                $scope.showTable = false;
            });
	}
});

ArchivesApp.factory('sessionStorageFactory', function () {

    if (typeof(Storage) === "undefined") {
        console.log("瀏覽器不支援Web Storage");
        successViewer("瀏覽器不支援Web Storage");
        return;
    }

    var factory = {
        getDocSendData: function () {
            return JSON.parse(sessionStorage.getItem("docSendData"));
        },
        setDocSendData: function (data) {
            sessionStorage.setItem("docSendData", JSON.stringify(data));
        },
        getDocReceiveData: function () {
            return JSON.parse(sessionStorage.getItem("docReceiveData"));
        },
        setDocReceiveData: function (data) {
            sessionStorage.setItem("docReceiveData", JSON.stringify(data));
        },
        getExchange: function () {
            return JSON.parse(sessionStorage.getItem("exchange"));
        },
        setExchange: function (data) {
            sessionStorage.setItem("exchange", JSON.stringify(data));
        },
        getTransmitDetail: function () {
            return JSON.parse(sessionStorage.getItem("transmitDetail"));
        },
        setTransmitDetail: function (data) {
            sessionStorage.setItem("exchange", JSON.stringify(data));
        },
        getDocSendIndexPage: function () {
            return JSON.parse(sessionStorage.getItem("docSendIndexPage"));
        },
        setDocSendIndexPage: function (data) {
            sessionStorage.setItem("docSendIndexPage", JSON.stringify(data));
        },
        getDocReceiveIndexPage: function () {
            return JSON.parse(sessionStorage.getItem("docReceiveIndexPage"));
        },
        setDocReceiveIndexPage: function (data) {
            sessionStorage.setItem("docReceiveIndexPage", JSON.stringify(data));
        }
    };
    return factory;
});
