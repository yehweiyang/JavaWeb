angular.module('ArchivesApp').controller('OrganSendController',
    function($rootScope, $scope,  $http, $state, archivesService, calendarPicker,
    archivesConstant, sessionStorageFactory) {
    //var self = this;

    $scope.calendarPicker = calendarPicker;
    $scope.toggleCalendar = function (datePickerId) {
        $scope[datePickerId] = $scope.calendarPicker.toggleCalendar($scope[datePickerId]);
    };

    //排序
    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = "account";
    $scope.docSubjectMsg = "顯示主旨訊息";
    $scope.exchangeList = [];
    $scope.organSendData = {};
    $scope.docSendData = {};
    $scope.exactMatch = 'no';

    $scope.today = function() {
        $scope.startDate = new Date();
        $scope.endDate = new Date();
    };

    $scope.hourList = function() {
        var array = [];
        for (var i = 0; i < 24; i++) {
            var hour = i.toString().length < 2 ? "0" + i : i;
            array.push(hour);
        }
        return array;
    };

    $scope.queryTypeList = [
                {queryType: "全部"},
                {queryType: "部份確認"},
                {queryType: "全部確認"},
                {queryType: "全退文"}
    ];
    $scope.queryType = $scope.queryTypeList[0];

    $scope.docSubjectBt = function() {
        if ($scope.showDocSubject) {
            $scope.showDocSubject = false;
            $scope.docSubjectMsg = "顯示主旨訊息";
        } else {
            $scope.showDocSubject = true;
            $scope.docSubjectMsg = "隱藏主旨訊息";
        }
    };

    //暫存查詢資料
    $scope.tmpExchange = function(tmpData){

        var tmpOrganSendData = {};
        if($scope.organSendData != null){
            tmpOrganSendData = $scope.organSendData;
        }

        tmpOrganSendData.tmpData = tmpData;
        tmpOrganSendData.tmpStartHour = $scope.selectedStartHour;
        tmpOrganSendData.tmpEndHour = $scope.selectedEndHour;

        if (tmpOrganSendData.startDocId != null){
            if(tmpOrganSendData.startDocId.length == 0){
                tmpOrganSendData.startDocId = null;
            }
        }
        if(tmpOrganSendData.endDocId != null){
            if(tmpOrganSendData.endDocId.length == 0){
                tmpOrganSendData.endDocId = null;
            }
        }

        tmpOrganSendData.senderUnitName = $scope.senderOrgName;
        tmpOrganSendData.senderOrgId = $scope.senderOrgID;
        tmpOrganSendData.applicationIdStart = $scope.startDocId;
        tmpOrganSendData.applicationIdEnd = $scope.endDocId;
        var startMm = $scope.startDate.getMonth() + 1;
        var startMonth = startMm<10 ? '0'+ startMm: startMm;
        tmpOrganSendData.startUpDateTime = $scope.startDate.getFullYear() +'-'+ startMonth +'-'+  $scope.startDate.getDate() + " " +
                                           $scope.selectedStartHour + ":00:00";
        var endMm = $scope.endDate.getMonth() + 1;
        var endMonth = endMm<10 ? '0'+ endMm: endMm;
        tmpOrganSendData.endUpDateTime = $scope.endDate.getFullYear() +'-'+ endMonth +'-'+  $scope.endDate.getDate() + " " +
                                         $scope.selectedEndHour + ":00:00";
        tmpOrganSendData.exactMatch = $scope.exactMatch;
        tmpOrganSendData.queryType = $scope.queryTypeList.indexOf($scope.queryType);

        var config = {
            params: tmpOrganSendData
        };

        var url = "/manageWeb/v1/exchange/organSend/init";
        sessionStorageFactory.setDocSendData(tmpOrganSendData);
        $http.get(url, config).then(function(response) {
            //if search no data
            var hasAnyViewData = $.trim(response.data) !== '';
            $scope.showError = !hasAnyViewData;
            $scope.showTable = hasAnyViewData;
            $scope.exchangeList = hasAnyViewData ? response.data : "";
            $scope.errorPrint = archivesConstant.QUERY_WITHOUT_RESULT;

            $scope.totalItems = $scope.exchangeList.length;

            if($scope.totalItems == 0){
                $scope.searchNoData(response);
            } else {
                $scope.currentPage = 1;
                $scope.start = 0;
                $scope.end = $scope.uibPageBase;
                $scope.showError = false;
                $scope.showTable = true;
                $scope.showTmpTable = false;
                }
            });
    }

    $scope.searchNoData = function(errResponse) {
        $scope.errorMessage = errResponse.data.errorMessage;
        $scope.showError = true;
        $scope.showTable = false;
        $scope.showTmpTable = false;
    };

    $scope.queryBt = function(form) {
        setError(false, '');
        var filterJson = {
            filterSymbol: {
                [angular.element("#lblSenderOrgID").text()]: $scope.senderOrgID,
                [angular.element("#lblSenderOrgName").text()]: $scope.senderOrgName
            },
            onlyNumber: {
                ['起始文號']: $scope.startDocId,
                ['結束文號']: $scope.endDocId
            }
        }

        if (!archivesService.filterPattern(filterJson)) {
            setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
            return
        }
        if(form.$valid){
            $scope.showTmpTable = true;
            $scope.tmpExchange(false);
        }else{
            $scope.errorMessage = "輸入格式錯誤";
            $scope.showError = true;
            $scope.showTable = false;
        }
    };

    $scope.transmitBt = function(exchange) {
        exchange.sendType = 'DocSend';
        sessionStorageFactory.setExchange(exchange);
        $state.go("OrganSendDocSend");
    };

    $scope.resetBt = function() {
        $scope.today();
        $scope.exactMatch = 'no';
        $scope.selectedStartHour = '00';
        $scope.selectedEndHour = 23;
        $scope.showError = false;
        $scope.showTable = false;
        $scope.showDocSubject = false;
        $scope.docSubjectMsg = "顯示主旨訊息";
        $scope.senderOrgID = null;
        $scope.senderOrgName = null;
        $scope.startDocId = null;
        $scope.endDocId = null;
        $scope.queryType = $scope.queryTypeList[0];
        sessionStorageFactory.setExchange(null);
        sessionStorageFactory.setDocSendData(null);
    };

    //在別的頁面返回到上一頁時,判斷是否要儲存上一頁的結果
    $scope.exchange = sessionStorageFactory.getExchange();
    $scope.organSendData = sessionStorageFactory.getDocSendData();
    if ($scope.organSendData != null) {
        $scope.startDate = new Date($scope.organSendData.startUpDateTime);
        $scope.endDate = new Date($scope.organSendData.endUpDateTime);
        $scope.selectedStartHour = $scope.organSendData.tmpStartHour;
        $scope.selectedEndHour = $scope.organSendData.tmpEndHour;
        $scope.queryType = $scope.queryTypeList[$scope.organSendData.queryType == -1 ? 0 : $scope.organSendData.queryType];
        $scope.senderOrgID = $scope.organSendData.senderOrgId;
        $scope.senderOrgName = $scope.organSendData.senderUnitName;
        $scope.startDocId = $scope.organSendData.applicationIdStart;
        $scope.endDocId = $scope.organSendData.applicationIdEnd;
        $scope.exactMatch = $scope.organSendData.exactMatch;
        $scope.tmpExchange(true);
    } else {
        if ($scope.exchange != null && $scope.exchange.sendType == 'DocSend') {
            $scope.tmpExchange(true);
        } else {
            $scope.organSendData = null;
            $scope.today();
            $scope.selectedStartHour = '00';
            $scope.selectedEndHour = 23;
            sessionStorageFactory.setDocSendIndexPage(1);
        }
    }

    function setError(showError, errorPrint) {
                $scope.showTable = false;
                $scope.showError = showError;
                $scope.errorPrint = errorPrint;
            }
});

ArchivesApp.service('calendarPicker', function(){
    this.getToday = function() {
        return new Date();
    };

    this.toggleCalendar = function(datePicker) {
        return datePicker = { opened : typeof datePicker === 'undefined' ? true : !datePicker.opened  };
    };
});

ArchivesApp.factory('sessionStorageFactory', function () {

    if (typeof(Storage) === "undefined") {
        console.log("瀏覽器不支援Web Storage");
        successViewer("瀏覽器不支援Web Storage");
        return;
    }

    var factory = {
        getDocSendData: function () {
            return JSON.parse(sessionStorage.getItem("docSendData"));
        },
        setDocSendData: function (data) {
            sessionStorage.setItem("docSendData", JSON.stringify(data));
        },
        getDocReceiveData: function () {
            return JSON.parse(sessionStorage.getItem("docReceiveData"));
        },
        setDocReceiveData: function (data) {
            sessionStorage.setItem("docReceiveData", JSON.stringify(data));
        },
        getExchange: function () {
            return JSON.parse(sessionStorage.getItem("exchange"));
        },
        setExchange: function (data) {
            sessionStorage.setItem("exchange", JSON.stringify(data));
        },
        getTransmitDetail: function () {
            return JSON.parse(sessionStorage.getItem("transmitDetail"));
        },
        setTransmtDetail: function (data) {
            sessionStorage.setItem("transmitDetail", JSON.stringify(data));
        },
        getDocSendIndexPage: function () {
            return JSON.parse(sessionStorage.getItem("docSendIndexPage"));
        },
        setDocSendIndexPage: function (data) {
            sessionStorage.setItem("docSendIndexPage", JSON.stringify(data));
        },
        getDocReceiveIndexPage: function () {
            return JSON.parse(sessionStorage.getItem("docReceiveIndexPage"));
        },
        setDocReceiveIndexPage: function (data) {
            sessionStorage.setItem("docReceiveIndexPage", JSON.stringify(data));
        }
    };

    return factory;
});
