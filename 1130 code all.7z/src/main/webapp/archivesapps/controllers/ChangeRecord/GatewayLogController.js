angular.module('ArchivesApp').constant('gatewayLogConstant', {
    GATEWAY_LOG_PATH: "/gatewayLog"
}).controller('GatewayLogController', function($scope, $http, archivesConstant,
    archivesService, gatewayLogConstant) {

    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = 'applicationId';
    $scope.errorMessage = archivesConstant.QUERY_WITHOUT_RESULT;

    var url = archivesConstant.WEB_ROOT_PATH +
        archivesConstant.REST_API_VERSION_PATH +
        archivesConstant.CHANGE_RECORD_PATH +
        gatewayLogConstant.GATEWAY_LOG_PATH;

    $scope.$on('$viewContentLoaded', function() {
        $scope.errorMessage = false;
        $scope.reset();
        $http.get(url + '/tempRead').success(function(response) {
            if (typeof response === 'object') {
                var queryContent = JSON.parse(response.filterContent);
                queryContent.dateFromIn = new Date(queryContent.dateFromIn);
                queryContent.dateFromOut = new Date(queryContent.dateFromOut);
                queryContent.dateToIn = new Date(queryContent.dateToIn);
                queryContent.dateToOut = new Date(queryContent.dateToOut);
                angular.copy(queryContent, $scope.log);

                $scope.yesResult = true;
                $scope.queryResult = JSON.parse(response.resultContent);
            }
        })
    });

    $scope.query = function() {
        var sendOrgId = $scope.log.sendOrgId;
        var sendOrgName = $scope.log.sendOrgName;
        var receiverOrgId = $scope.log.receiverOrgId;
        var receiverOrgName = $scope.log.receiverOrgName;
        var startNo = $scope.log.startNo;
        var endNo = $scope.log.endNo;

        var startNo = '起始' + angular.element("#lblNo").text();
        var endNo = '結束' + angular.element("#lblNo").text();
        cleanDiv();
        var filterJson = {
            filterSymbol: {
                [angular.element("#lblSendOrgId").text()]: sendOrgId,
                [angular.element("#lblSendOrgName").text()]: sendOrgName,
                [angular.element("#lblReceiverOrgId").text()]: receiverOrgId,
                [angular.element("#lblReceiverOrgName").text()]: receiverOrgName
            },
            onlyNumber: {
                [startNo]: $scope.log.startNo,
                [endNo]: $scope.log.endNo
            }
        }

        if (!archivesService.filterPattern(filterJson)) {
            errorMessage(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
            return
        }
        $http.get(url + '/list', {
                params: $scope.log
            })
            .success(function(response) {
                $scope.yesResult = response.length > 0;
                errorMessage(!(response.length > 0), archivesConstant.QUERY_WITHOUT_RESULT);

                $scope.queryResult = response;
                if ($scope.yesResult) {
                    var saveFile = [];
                    saveFile.push(response);
                    var tempFile = {
                        tempQuery: $scope.log,
                        tempResult: saveFile
                    };

                    $http.get(url + '/tempSave', {
                        params: tempFile
                    }).error(function(response) {
                        exceptionViewer(response, false);
                    });
                }
            }).error(function(response) {
                exceptionViewer(response, false);
            });
    }

    $scope.hourList = function() {
        var array = [];
        for (var i = 0; i < 24; i++) {
            var hour = i.toString().length < 2 ? "0" + i : i;
            array.push(hour);
        }
        return array;
    };

    $scope.reset = function() {
        $scope.log = {
            sendOrgId: "",
            sendOrgName: "",
            receiverOrgId: "",
            receiverOrgName: "",
            dateFromIn: new Date(),
            timeFromIn: "00",
            dateToIn: new Date(),
            timeToIn: 23,
            dateFromOut: new Date(),
            timeFromOut: "00",
            dateToOut: new Date(),
            timeToOut: 23,
            startNo: "",
            endNo: "",
            isFullCmp: false
        };
        cleanDiv();
    };

    var cleanDiv = function() {
        $scope.yesResult = false;
        $scope.errorMessage = false;
    };


    $scope.archivesService.pager.itemsPerPage = 100;

    $scope.openDateFromCalendarIn = function() {
        $scope.dateFromCalendarIn.opened = true;
    };


    $scope.openDateToCalendarIn = function() {
        $scope.dateToCalendarIn.opened = true;
    };
    $scope.dateFromCalendarIn = {
        opened: false
    };

    $scope.dateToCalendarIn = {
        opened: false
    };


    $scope.openDateFromCalendarOut = function() {
        $scope.dateFromCalendarOut.opened = true;
    };


    $scope.openDateToCalendarOut = function() {
        $scope.dateToCalendarOut.opened = true;
    };
    $scope.dateFromCalendarOut = {
        opened: false
    };

    $scope.dateToCalendarOut = {
        opened: false
    };

    function errorMessage(errorStatus, errorMessage) {
        $scope.errorMessage = errorStatus;
        $scope.errorPrint = errorMessage;
    }

});