includeOtherScript("changeCacheFactory");
angular.module('ArchivesApp').controller('DocumentExchangeDetailController', function($scope, $state,
    changeCacheFactory, archivesConstant) {

    $scope.exchange = changeCacheFactory.getExchange();
    $scope.transmitMsg = changeCacheFactory.getTransmitDetail();

    if ($scope.exchange == null || $scope.transmitMsg == null) {
        $state.go("InsideSendChange");
    } else {
        if ($scope.exchange.transmitType == archivesConstant.INNER_TRANSMIT_TYPE) {
            $scope.detailTitle = archivesConstant.INNER_TITLE_MSG;
        } else if ($scope.exchange.transmitType == archivesConstant.OUT_TRANSMIT_TYPE) {
            $scope.detailTitle = archivesConstant.OUT_TITLE_MSG;
        }
    }
});