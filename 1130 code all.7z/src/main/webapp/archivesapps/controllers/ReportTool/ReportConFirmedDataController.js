includeOtherScript("reportService");

angular.module("ArchivesApp").controller('ReportConFirmedDataController', function($scope, $http, reportService,
    reportConstant, archivesService, archivesConstant) {
    var actionAddress;
    var reportName = reportConstant.REPORT_CONFIRMED_QUERY;
    $scope.reportService = reportService;

    $scope.$on('$viewContentLoaded', function() {
        actionAddress = $scope.reportService.getInitActionUrl(reportName);
        return $http.get(actionAddress)
            .success(function(data) {
                var filter = data.filterContent;
                var result = data.resultContent;
                $scope.dateFrom = new Date(filter.dateFrom);
                $scope.dateTo = new Date(filter.dateTo);
                $scope.reportService.sorter.columnName = filter.sortColumnName;
                $scope.reportService.sorter.descending = filter.sortDescending;
                $scope.reportService.currentFilter = filter;

                //load last query result
                setDataTable(result, false);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    });

    $scope.queryAction = function() {
        setError(false, '');
        var filterJson = {
            filterSymbol: {
                [angular.element("#lblGetewayId").text()]: $scope.getewayId
            }
        }

        if (!archivesService.filterPattern(filterJson)) {
            setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
            return false;
        }
        actionAddress = $scope.reportService.getQueryActionUrl(reportName);

        $scope.reportService.currentFilter = {
            getewayId: $('#getewayId').val(),
            dateFrom: $('#dateFrom').val(),
            dateTo: $('#dateTo').val(),
            sortColumnName: escape($scope.reportService.sorter.columnName),
            sortDescending: escape($scope.reportService.sorter.descending)
        };

        return $http.get(actionAddress, {
                params: $scope.reportService.currentFilter
            })
            .success(function(data) {
                setDataTable(data);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.toggleCalendar = function(datePickerId) {
        $scope[datePickerId] = $scope.reportService.toggleCalendar($scope[datePickerId]);
    };

    $scope.resetAction = function() {
        $scope.getewayId = '';
        $scope.toggleResult = false;
        $scope.toggleAlert = false;
        $scope.dateFrom = $scope.reportService.getToday();
        $scope.dateTo = $scope.reportService.getToday();
    };

    function setDataTable(viewData, isInit) {
        var hasAnyViewData = $.trim(viewData) !== '';
        if (!hasAnyViewData) {
            $scope.errorPrint = archivesConstant.QUERY_WITHOUT_RESULT;
        }
        $scope.toggleResult = hasAnyViewData;
        angular.forEach(viewData, function(currentView) {
            currentView.rowIndex = parseInt(currentView.rowIndex);
        });
        $scope.queryResult = hasAnyViewData ? viewData : "";
        $scope.toggleAlert = typeof isInit === "undefined" ?
            !hasAnyViewData : false;
    }

    function setError(showError, errorPrint) {
        $scope.toggleResult = false;
        $scope.toggleAlert = showError;
        $scope.errorPrint = errorPrint;
    }
});