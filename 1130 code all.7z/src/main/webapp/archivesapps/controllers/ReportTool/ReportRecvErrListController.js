includeOtherScript("reportService");

angular.module("ArchivesApp").controller('ReportRecvErrListController', function($scope, $http, reportService,
    reportConstant, archivesService, archivesConstant) {
    var actionAddress;
    var reportName = reportConstant.REPORT_RECEIVE_ERR_LIST;
    $scope.reportService = reportService;
    $scope.reportService.setHoursRangeFromDomId("timeTo");
    $scope.reportService.setHoursRangeFromDomId("timeFrom");

    $scope.$on('$viewContentLoaded', function() {
        actionAddress = $scope.reportService.getInitActionUrl(reportName);

        return $http.get(actionAddress)
            .success(function(data) {
                var filter = data.filterContent;
                var result = data.resultContent;
                $scope.dateFrom = new Date(filter.dateFrom);
                $scope.dateTo = new Date(filter.dateTo);
                $scope.receiverId = filter.receiverId;
                $scope.receiverName = filter.receiverName;
                $scope.contentFullCmp = filter.contentFullCmp;
                $scope.reportListFromMonth = filter.reportListFromMonth;
                $scope.reportService.sorter.columnName = filter.sortColumnName;
                $scope.reportService.sorter.descending = filter.sortDescending;
                $scope.reportService.currentFilter = filter;
                $('#timeFrom').val(filter.timeFrom);
                $('#timeTo').val(filter.timeTo);
                setDataTable(result, false);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    });

    $scope.queryAction = function() {
        setError(false, '');
        var filterJson = {
            filterSymbol: {
                [angular.element("#lblReceiverId").text()]: $scope.receiverId,
                [angular.element("#lblReceiverName").text()]: $scope.receiverName
            }
        }

        if (!archivesService.filterPattern(filterJson)) {
            setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
            return
        }
        actionAddress = $scope.reportService.getQueryActionUrl(reportName);

        $scope.reportService.currentFilter = {
            dateFrom: $('#dateFrom').val(),
            dateTo: $('#dateTo').val(),
            timeFrom: $('#timeFrom').val(),
            timeTo: $('#timeTo').val(),
            receiverId: $scope.receiverId,
            receiverName: $scope.receiverName,
            contentFullCmp: $scope.contentFullCmp,
            sortColumnName: escape($scope.reportService.sorter.columnName),
            sortDescending: escape($scope.reportService.sorter.descending)
        };

        return $http.get(actionAddress, {
                params: $scope.reportService.currentFilter
            })
            .success(function(data) {
                setDataTable(data);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.exportAction = function(exportType) {
        actionAddress = $scope.reportService.getDownloadActionUrl(reportName, exportType);
        $scope.reportService.exportReportFile(actionAddress, exportType);
    };

    $scope.exportMonthReportAction = function(exportType) {
        actionAddress = $scope.reportService.getQueryMonthActionUrl(reportName, $scope.selectedReportFromMonth);
        if (typeof $scope.selectedReportFromMonth !== "undefined" && $scope.selectedReportFromMonth !== '') {
            return $http.get(actionAddress)
                .success(function(data) {
                    var result = data.resultContent;
                    if ($.trim(result) !== '') {
                        actionAddress = $scope.reportService.getDownloadMonthActionUrl(
                            reportName,
                            exportType,
                            $scope.selectedReportFromMonth);
                        $scope.reportService.exportReportFile(actionAddress, exportType);
                    } else {
                        actionResultViewer(reportConstant.REPORT_MONTH_EMPTY);
                    }
                })
                .error(function(response) {
                    exceptionViewer(response, false);
                });
        }
    };

    $scope.toggleCalendar = function(datePickerId) {
        $scope[datePickerId] = $scope.reportService.toggleCalendar($scope[datePickerId]);
    };

    $scope.resetAction = function() {
        $scope.toggleResult = false;
        $scope.toggleAlert = false;
        $scope.dateFrom = $scope.reportService.getToday();
        $scope.dateTo = $scope.reportService.getToday();
        $scope.receiverId = "";
        $scope.receiverName = "";
        $scope.contentFullCmp = false;
        $('#timeFrom').val("00");
        $('#timeTo').val("23");
    };

    function setDataTable(viewData, isInit) {
        var hasAnyViewData = $.trim(viewData) !== '';
        if (!hasAnyViewData) {
            $scope.errorPrint = archivesConstant.QUERY_WITHOUT_RESULT;
        }
        $scope.toggleResult = hasAnyViewData;
        angular.forEach(viewData, function(currentView) {
            currentView.rowIndex = parseInt(currentView.rowIndex);
        });
        $scope.queryResult = hasAnyViewData ? viewData : "";
        $scope.toggleAlert = typeof isInit === "undefined" ?
            !hasAnyViewData : false;
    }

    function setError(showError, errorPrint) {
        $scope.toggleResult = false;
        $scope.toggleAlert = showError;
        $scope.errorPrint = errorPrint;
    }
});