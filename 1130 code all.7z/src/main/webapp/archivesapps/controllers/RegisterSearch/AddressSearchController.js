angular.module("ArchivesApp").constant('addressSearchConstant', {
    ADDRESS_SEARCH_PATH: "/addressSearch"
}).controller('AddressSearchController', function ($scope, $http, restUrlFactory, registerService,
                                                   archivesConstant, archivesService, addressSearchConstant) {
	var prefixUrl = archivesConstant.WEB_ROOT_PATH +
        archivesConstant.REST_API_VERSION_PATH +
        archivesConstant.REGISTER_SEARCH_PATH +
        addressSearchConstant.ADDRESS_SEARCH_PATH;

    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = "gatewayId";

    $scope.checkTestUnit = 'no';
    $scope.checkCompare = false;
    $scope.showTable = false;
    $scope.centerLists = [];
    $scope.addressBookList = [];
    $scope.showModal = false;
    $scope.showDetail = false;
    $scope.forbiddenModal = false;
    $scope.toggleModal = function () {
        $scope.showModal = false;
    };
    $scope.toggleDetail = function () {
        $scope.showDetail = false;
    };
    $scope.toggleForbidden = function () {
        $scope.forbiddenModal = false;
    };
    var fetchCenterList = function () {
        var url = prefixUrl + "/center/list";
        $http.get(url).then(function (response) {
            $scope.centerLists = response.data;
            $scope.queryData = registerService.getAddressQueryData();
            if ($scope.queryData != null) {
                $scope.selectedCenterList = $scope.centerLists[$scope.queryData.centerIndex];
                $scope.selectedCenterStatus = $scope.statusList[$scope.queryData.statusIndex];
                $scope.checkCompare = $scope.queryData.exactMatch;
                $scope.checkTestUnit = $scope.queryData.showTestUnit;
                $scope.queryData.cacheData = true;
                $scope.restCacheAddress($scope.queryData);
            } else {
                $scope.queryData = {};
                $scope.selectedCenterList = $scope.centerLists[0];
                $scope.selectedCenterStatus = $scope.statusList[0];
            }
        }, function (errResponse) {
            $scope.errorPrint = errResponse.data.errorMessage;
            $scope.showError = true;
        });
    };

    $scope.restAddress = function () {
        var queryData = $scope.queryData;
        queryData.cacheData = false;
        queryData.centerIndex = $scope.centerLists.indexOf($scope.selectedCenterList);
        queryData.statusIndex = $scope.statusList.indexOf($scope.selectedCenterStatus);
        queryData.exactMatch = $scope.checkCompare;
        queryData.showTestUnit = $scope.checkTestUnit;
        $scope.restCacheAddress(queryData);
    }

    $scope.restCacheAddress = function (queryData) {
        var url = prefixUrl + "/address/list";
        $http.get(url, { params: queryData }).then(function (response) {
            if(response.data.length>0){
                $scope.addressBookList = response.data;
                registerService.setAddressQueryData(queryData);
                $scope.showTable = true;
            }else{
                registerService.setAddressQueryData(null);
                $scope.errorPrint = archivesConstant.QUERY_WITHOUT_RESULT;
                $scope.showError = true;
            }

        }).catch(function (response) {
        exceptionViewer(response, false);
                  });
    }

    $scope.queryBt = function(form) {
        setError(false, '');
        var filterJson = {
            filterSymbol: {
                [angular.element("#lblOrgId").text()]: $scope.queryData.agencyId,
                [angular.element("#lblUnitId").text()]: $scope.queryData.agencyUnitId,
                [angular.element("#lblOrgUnitName").text()]: $scope.queryData.agencyName
            }
        }

        if (!archivesService.filterPattern(filterJson)) {
            setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
            return false;
        }
        if (form.$valid) {
            $scope.showLoad = true;
            $scope.restAddress();
        } else {
            $scope.errorPrint = archivesConstant.FORM_INVALID_MSG;
            $scope.showError = true;
        }
    };

    $scope.detailBt = function (addressBook) {
        var queryDetail = {};
        queryDetail.agencyId = addressBook.agencyId;
        queryDetail.agencyUnitId = addressBook.agencyUnitId;
        var config = {
            params: queryDetail
        };
        var url = prefixUrl + "/address/detail";

        $http.get(url, config).then(function (response) {
            if (response.data.length != 0) {
                $scope.addressBookDetail = response.data;
                $scope.showDetail = true;
            } else {
                $scope.message = archivesConstant.SEARCH_WITHOUT_RESULT;
                $scope.btMsg = archivesConstant.BUTTON_SUBMIT_MSG;
                $scope.showModal = true;
            }
        }, function (errResponse) {
            exceptionViewer(errResponse, false);
        });
    };

    $scope.statusList = [
        {centerStatus: archivesConstant.ALL_CENTER_STATUS},
        {centerStatus: archivesConstant.ACTIVE_CENTER_STATUS},
        {centerStatus: archivesConstant.PAUSE_CENTER_STATUS},
        {centerStatus: archivesConstant.STOP_CENTER_STATUS}
    ];

    $scope.resetBt = function () {
        $scope.selectedCenterList = $scope.centerLists[0];
        $scope.selectedCenterStatus = $scope.statusList[0];
        $scope.queryData.agencyId = null;
        $scope.queryData.agencyUnitId = null;
        $scope.queryData.agencyName = null;
        $scope.checkTestUnit = 'no';
        $scope.checkCompare = false;
        $scope.showDetail = false;
        $scope.showError = false;
        $scope.showTable = false;

        registerService.setAddressQueryData(null);
    };

    fetchCenterList();

    function setError(showError, errorPrint) {
        $scope.showTable=false;
        $scope.showError = showError;
        $scope.errorPrint = errorPrint;
    }
});
