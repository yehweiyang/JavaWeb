angular.module("ArchivesApp").constant('formRegisterConstant', {FORM_REGISTER_PATH: "/formRegister"
}).controller('FormRegisterController',
    function ($scope, $http, restUrlFactory, registerService,
              archivesService, archivesConstant, formRegisterConstant) {
        var prefixUrl = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
            archivesConstant.REGISTER_SEARCH_PATH + formRegisterConstant.FORM_REGISTER_PATH;
        $scope.archivesService = archivesService;
        $scope.archivesService.sorter.columnName = "tableId";

        $scope.checkCompare = false;
        $scope.toggleForbidden = function () {
            $scope.forbiddenModal = false;
        };
        $scope.formList = [];

        $scope.formStatusList = [
            {formStatus: "全部"},
            {formStatus: "啟用"},
            {formStatus: "暫停"},
            {formStatus: "停用"}
        ];

        $scope.formTypeList = [
            {formType: "全部"},
            {formType: "公文交換"},
            {formType: "e管家"}
        ];

        $scope.fileTypeList = [
            {fileType: "全部"},
            {fileType: "XML"},
            {fileType: "DOC"},
            {fileType: "PDF"}
        ];

        $scope.showFileTypeList = [
            {showFileType: "全部"},
            {showFileType: "無"},
            {showFileType: "PDF"},
            {showFileType: "PNG"},
            {showFileType: "TIF"}
        ];

        $scope.getRestForm = function () {
            var queryData = $scope.queryForm;
            queryData.cacheData = false;
            queryData.exactMatch = $scope.checkCompare;
            queryData.statusIndex = $scope.formStatusList.indexOf($scope.selectedFormStatus);
            queryData.formTypeIndex = $scope.formTypeList.indexOf($scope.selectedFormType);
            queryData.fileTypeIndex = $scope.fileTypeList.indexOf($scope.selectedFileType);
            queryData.showFileTypeIndex = $scope.showFileTypeList.indexOf($scope.selectedShowFileType);
            $scope.getCacheRestForm(queryData);
        }

        $scope.getCacheRestForm = function (queryData) {
            var url = prefixUrl + "/form/list";
            return $http.get(url, {params: queryData}).then(function (response) {
                if(response.data.length>0){
                 registerService.setFormQueryData(queryData);
                    $scope.formList = response.data;
                    $scope.showError = false;
                    $scope.showTable = true;
                    $scope.showLoad = false;
                }else{
                registerService.setFormQueryData(null);
                $scope.errorPrint = archivesConstant.QUERY_WITHOUT_RESULT;
                $scope.showError = true;
                $scope.showTable = false;
                $scope.showLoad = false;
                }
            }).catch(function (data) {
               exceptionViewer(data, false);
                            });;
        }

        $scope.queryBt = function (formRegisterForm) {
            if (formRegisterForm.$valid) {

               setError(false,'');
               var filterJson = {
                   filterSymbol: {
                       [angular.element("#lblTableName").text()]: $scope.queryForm.tableName,
                       [angular.element("#lblAgencyOrgId").text()]: $scope.queryForm.agencyOrgId
                   },
                        onlyNumber: {
                      [angular.element("#lblTableId").text()]: $scope.queryForm.tableId
                        }
               }

               if (!archivesService.filterPattern(filterJson)) {
                   setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
                   return false;
               }

                $scope.showLoad = true;
                $scope.getRestForm();
            }

        }

        $scope.resetBt = function () {
            $scope.showTable = false;
            $scope.showError = false;
            $scope.checkCompare = false;
            $scope.selectedFormStatus = $scope.formStatusList[0];
            $scope.selectedFormType = $scope.formTypeList[0];
            $scope.selectedFileType = $scope.fileTypeList[0];
            $scope.selectedShowFileType = $scope.showFileTypeList[0];
            $scope.queryForm.tableId = null;
            $scope.queryForm.tableName = null;
            $scope.queryForm.agencyOrgId = null;
        };

        $scope.queryForm = registerService.getFormQueryData();
        if ($scope.queryForm != null) {
            $scope.checkCompare = $scope.queryForm.exactMatch;
            $scope.selectedFormStatus = $scope.formStatusList[$scope.queryForm.statusIndex];
            $scope.selectedFormType = $scope.formTypeList[$scope.queryForm.formTypeIndex];
            $scope.selectedFileType = $scope.fileTypeList[$scope.queryForm.fileTypeIndex];
            $scope.selectedShowFileType = $scope.showFileTypeList[$scope.queryForm.showFileTypeIndex];
            $scope.queryForm.cacheData = true;
            $scope.getCacheRestForm($scope.queryForm);
        } else {
            $scope.queryForm = {};
            $scope.selectedFormStatus = $scope.formStatusList[0];
            $scope.selectedFormType = $scope.formTypeList[0];
            $scope.selectedFileType = $scope.fileTypeList[0];
            $scope.selectedShowFileType = $scope.showFileTypeList[0];
        }
          function setError(showError, errorPrint) {
                $scope.showTable = false;
                $scope.showError = showError;
                $scope.errorPrint = errorPrint;
            }
    });
