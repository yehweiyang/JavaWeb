angular.module("ArchivesApp").constant('numberSearchConstant', {
    NUMBER_SEARCH_PATH: "/numberSearch"
}).controller('NumberSearchController', function ($scope, $http, restUrlFactory,
                                                  registerService, archivesConstant,
                                                  archivesService, numberSearchConstant) {
	var prefixUrl = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
        archivesConstant.REGISTER_SEARCH_PATH + numberSearchConstant.NUMBER_SEARCH_PATH;

    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = "agencyId";

    $scope.checkCompare = false;
    $scope.queryDocWord = {};
    $scope.docWordList = [];
    $scope.toggleModal = function () {
        $scope.showModal = false;
    };
    $scope.toggleForbidden = function () {
        $scope.forbiddenModal = false;
    };
    $scope.open1 = function () {
        $scope.popup1.opened = true;
    };

    $scope.open2 = function () {
        $scope.popup2.opened = true;
    };

    $scope.open3 = function () {
        $scope.popup3.opened = true;
    };

    $scope.open4 = function () {
        $scope.popup4.opened = true;
    };

    $scope.popup1 = {
        opened: false
    };

    $scope.popup2 = {
        opened: false
    };

    $scope.popup3 = {
        opened: false
    };

    $scope.popup4 = {
        opened: false
    };

    $scope.restNumber = function () {
        var queryData = $scope.queryDocWord;
        queryData.cacheData = false;
        queryData.exactMatch = $scope.checkCompare;
        if ($scope.dt1 != null)
            queryData.effectDateStart = $scope.dt1.toISOString().substring(0, 10);
        else
            queryData.effectDateStart = null;

        if ($scope.dt2 != null)
            queryData.effectDateEnd = $scope.dt2.toISOString().substring(0, 10);
        else
            queryData.effectDateEnd = null;

        if ($scope.dt3 != null)
            queryData.validDateStart = $scope.dt3.toISOString().substring(0, 10);
        else
            queryData.validDateStart = null;

        if ($scope.dt4 != null)
            queryData.validDateEnd = $scope.dt4.toISOString().substring(0, 10);
        else
            queryData.validDateEnd = null;
        $scope.restCacheNumber(queryData);
    }

    $scope.restCacheNumber = function (queryData) {
        var url = prefixUrl + "/number/list";
        $http.get(url, { params: queryData }).then(function (response) {
        if(response.data.length>0){
            $scope.docWordList = response.data;
            registerService.setNumberQueryData(queryData);
            $scope.showError = false;
            $scope.showTable = true;
            $scope.showLoad = false;
        }else{
           $scope.errorPrint = archivesConstant.QUERY_WITHOUT_RESULT;
            registerService.setNumberQueryData(null);
            $scope.showError = true;
            $scope.showTable = false;
            $scope.showLoad = false;
        }
        }).catch(function (data) {
             exceptionViewer(data, false);
              });
    }

    $scope.queryBt = function (form) {
        if (form.$valid) {
            errorMessage(false,'');
                var filterJson = {
                    filterSymbol: {
                        [angular.element("#lblAuthAgencyId").text()]: $scope.queryDocWord.authAgencyId,
                        [angular.element("#lblAgencyId").text()]: $scope.queryDocWord.agencyId,
                        [angular.element("#lblSubRoGate").text()]: $scope.queryDocWord.subRoGate
                    }
                }
                        if (!archivesService.filterPattern(filterJson)) {
                            errorMessage(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
                            return
                        }
            $scope.showLoad = true;
            $scope.restNumber();
        }
    }

    $scope.resetBt = function () {
        $scope.showError = false;
        $scope.showTable = false;
        $scope.queryDocWord.authAgencyId = null;
        $scope.queryDocWord.agencyId = null;
        $scope.queryDocWord.subRoGate = null;
        $scope.checkCompare = false;
        $scope.dt1 = null;
        $scope.dt2 = null;
        $scope.dt3 = null;
        $scope.dt4 = null;
        registerService.setNumberQueryData(null);
    };

    $scope.queryDocWord = registerService.getNumberQueryData();
    if ($scope.queryDocWord != null) {
        $scope.checkCompare = $scope.queryDocWord.exactMatch;
        if ($scope.queryDocWord.effectDateStart != null)
            $scope.dt1 = new Date($scope.queryDocWord.effectDateStart);
        if ($scope.queryDocWord.effectDateEnd != null)
            $scope.dt2 = new Date($scope.queryDocWord.effectDateEnd);
        if ($scope.queryDocWord.validDateStart != null)
            $scope.dt3 = new Date($scope.queryDocWord.validDateStart);
        if ($scope.queryDocWord.validDateEnd != null)
            $scope.dt4 = new Date($scope.queryDocWord.validDateEnd);
        $scope.queryDocWord.cacheData = true;
        $scope.restCacheNumber($scope.queryDocWord);
    } else {
        $scope.queryDocWord = {};
    }
          function errorMessage(showError, errorPrint) {
                $scope.showTable = false;
                $scope.showError = showError;
                $scope.errorPrint = errorPrint;
            }
});
