angular.module("ArchivesApp").constant('certificateExpiredConstant', {
    CERTIFICATE_EXPIRED_PATH: "/certificateExpired"
}).controller('CertificateExpiredController',
    function ($scope, $http, $window, $filter, restUrlFactory,
              archivesConstant, archivesService, certificateExpiredConstant) {

    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = "agencyId";

    var prefixUrl = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
        archivesConstant.REGISTER_SEARCH_PATH + certificateExpiredConstant.CERTIFICATE_EXPIRED_PATH;

    var constant = {
        ODS_TYPE: "ods",
        PDF_TYPE: "pdf",
        APPLICATION_TYPE: "application/",
        ARRAY_BUFFER: "arraybuffer",
        CERT_EXPIRED_LIST: "/certExpired/list",
        CERT_EXPIRED_DOWNLOAD: "/certExpired/download/"
    };
    $scope.certList = [];
    $scope.showLoad = true;
    $scope.certExpire = function () {
        var url = prefixUrl + constant.CERT_EXPIRED_LIST;
        $http.get(url).then(function (response) {
            $scope.showLoad = false;
            $scope.certList = response.data;
            $scope.showTable = true;
        }, function (errResponse) {
            $scope.showLoad = false;
            $scope.showTable = false;
        });
    };
    $scope.outputFile = function (exportType) {
        if (exportType == constant.ODS_TYPE) {
            $scope.showODS = true;
        } else if (exportType == constant.PDF_TYPE) {
            $scope.showPDF = true;
        }
        var url = prefixUrl + constant.CERT_EXPIRED_DOWNLOAD + exportType;
        $http.get(url, { responseType: constant.ARRAY_BUFFER }).then(function (response) {
            var convertToBlob = new Blob([response.data], { type: constant.APPLICATION_TYPE + exportType })
            var createURL = URL.createObjectURL(convertToBlob);

            if (constant.ODS_TYPE === exportType) {
                var ods = document.createElement("a");
                ods.id = "odsPath";
                ods.class = "hidden";
                ods.href = createURL;
                ods.download = $filter('date')(new Date(), "yyyy-MM-dd") + ".ods";
                document.body.appendChild(ods);
                ods.click();
                document.body.removeChild(ods);

            } else if (constant.PDF_TYPE === exportType) {
                $window.open(createURL);
            }
            $scope.showODS = false;
            $scope.showPDF = false;
        }, function (errResponse) {
            $scope.showODS = false;
            $scope.showPDF = false;
        });
    };

    $scope.certExpire();
});