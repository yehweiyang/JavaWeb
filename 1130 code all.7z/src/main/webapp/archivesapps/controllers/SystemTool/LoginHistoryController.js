angular.module("ArchivesApp").constant('loginHistoryConstant', {
    LOGIN_HISTORY_PATH: "/loginHistory"
}).controller('LoginHistoryController', function($scope, $http, archivesConstant,
    archivesService, loginHistoryConstant) {
    $('.selectpicker').selectpicker();
    $('.archives-checkbox').checkboxpicker();
    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = 'account'
    $scope.$on('$viewContentLoaded', function() {
    $scope.today = new Date();
        $scope.resetBt();
    });

    $scope.queryBt = function() {
        cleanDiv();
        var filterJson = {
            filterSymbol: {
                [angular.element("#lblAccount").text()]: $scope.login.account
            }
        }

        if (!archivesService.filterPattern(filterJson)) {
            setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
            return
        }
        $http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
            archivesConstant.SYSTEM_TOOL_PATH + loginHistoryConstant.LOGIN_HISTORY_PATH + '/querLoginHistory', {
                params: $scope.login
            }
        ).success(function(response) {
            if (response.length != 0) {
                $scope.result = true;
                $scope.queryData = $scope.result ? response : [];
            } else {
                $scope.noResult = true;
                $scope.errorPrint = archivesConstant.QUERY_WITHOUT_RESULT;
            }

        }).error(function(response) {
            exceptionViewer(response, false);
        });
    };

    $scope.resetBt = function() {
        cleanDiv();
        $scope.login = {
            noResult: false,
            result: false,
            account: "",
            dateFrom: new Date(),
            timeFrom: '00',
            dateTo: new Date(),
            timeTo: 23
        }
    }

    $scope.archivesService.pager.itemsPerPage = 100;

    $scope.hourList = function() {
        var array = [];
        for (var i = 0; i < 24; i++) {
            var hour = i.toString().length < 2 ? "0" + i : i;
            array.push(hour);
        }
        return array;
    };

    $scope.openDateFromCalendar = function() {
        $scope.dateFromCalendar.opened = true;
    };

    $scope.openDateToCalendar = function() {
        $scope.dateToCalendar.opened = true;
    };
    $scope.dateFromCalendar = {
        opened: false
    };

    $scope.dateToCalendar = {
        opened: false
    };

    function cleanDiv() {
        $scope.noResult = false;
        $scope.result = false;
    };

    function setError(showError, errorPrint) {
        $scope.result = false;
        $scope.noResult = showError;
        $scope.errorPrint = errorPrint;
    }

});