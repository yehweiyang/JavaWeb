angular.module("ArchivesApp", ['ngCookies']).constant('redundantSwitchConstant', {
    REDUNDANT_SWITCH_PATH: "/redundantSwitch",
    INIT_PATH: "/init",
    UPDATE_PATH: "/update",
    HTTP_ACTION_METHOD: "PUT"
}).controller('RedundantSwitchController', function($scope, $http, $cookies,
        archivesService, archivesConstant, redundantSwitchConstant, pkiService, certEventListenService) {

    function getRedundantSwitchPath(actionPath) {
        return archivesConstant.WEB_ROOT_PATH +
                archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.SYSTEM_TOOL_PATH +
                redundantSwitchConstant.REDUNDANT_SWITCH_PATH +
                actionPath;
    }

    $scope.$on('$viewContentLoaded', function() {
        return $http.get(getRedundantSwitchPath(redundantSwitchConstant.INIT_PATH))
            .success(function(data) {
                $scope.redundantList = data;
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    });

    var prepareSendRequest = true;
    var currentRedundantId;
    var currentButtonId;
    $scope.setCheckBoxValue = function (collection) {
        angular.forEach(collection, function(currentView) {
            currentRedundantId = currentView.redundantSwitchId;
            $('#' + currentRedundantId).checkboxpicker().change(function() {
                if (prepareSendRequest) {
                    currentButtonId = $(this);
                    prepareSendRequest = false;
                    pkiService.getDigitalCert($scope,null);
                }
            });

        });
        return collection;
    };

    $scope.checkCertHashSuccess = function(actionUrl) {
        var updatePath = redundantSwitchConstant.UPDATE_PATH + "/" + currentButtonId.attr('id') + "/" +
                currentButtonId.prop('checked');
        $.ajax({
            url: getRedundantSwitchPath(updatePath),
            type: redundantSwitchConstant.HTTP_ACTION_METHOD,
            headers: { "X-XSRF-TOKEN" :  $cookies.get("XSRF-TOKEN"), "authorization" : $("#auth").val() },
            success: function(){
                prepareSendRequest = true;
                actionResultViewer(archivesConstant.RUN_SUCCESS_MSG);
            },
            error: function(response) {
                exceptionViewer(response, false);
            }
        });
    };

    certEventListenService.startEventListen($scope);

});

