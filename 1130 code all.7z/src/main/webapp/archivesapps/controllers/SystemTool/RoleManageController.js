angular.module('ArchivesApp').constant('roleManageConstant', {
    ROLE_MANAGE_PATH: "/roleManage"
}).controller('RoleManageController', function ($rootScope, $scope, $http, $timeout, pkiService,
                                                certEventListenService, archivesConstant, roleManageConstant) {
    $scope.errorMessage = false;
    $scope.fixModalErrorMessage = false;
    $scope.addModalErrorMessage = false;

    $http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
            archivesConstant.SYSTEM_TOOL_PATH +
            roleManageConstant.ROLE_MANAGE_PATH + "/roleList")
        .then(function (response) {
            for (var i = 0; i < response.data.length; i++) {
                response.data[i].activeStatus = (response.data[i].activeStatus == 1) ? "啟動" : "停用";
            }

            $scope.allRole = response.data;
            selectOption($scope.allRole);
        });
    
    $http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/core/menu/all').
    then(function (response) {
        $scope.allMenu = response.data.menu;
    });

    function selectOption(allRole) {
        for (var i = 0; i < allRole.length; i++) {
            $('#changeRole').append('<option value="' + allRole[i].sysId + '" data-subtext="' +
            allRole[i].activeStatus + '">' + allRole[i].roleName + '</option>');
        }
        $('.selectpicker').selectpicker();
    }

    $scope.menuLoop = function (collection) {
        $('.archives-checkbox').checkboxpicker();
        return collection;
    };

    //選擇權限-開始
    $('#changeRole').change(function () {
        var oldMenu = [];

        $("#menu input[type=checkbox]").prop("checked", false);

        if ($('#changeRole option:checked').attr('data-subtext') == "啟動") {
            $scope.roleStatus = '啟動';
        } else {
            $scope.roleStatus = '停用';
        }

        var changeRoleValue = {
            "SysId": $('#changeRole').val()
        };

        $http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.SYSTEM_TOOL_PATH +
                roleManageConstant.ROLE_MANAGE_PATH +"/choiceRole", {params: changeRoleValue})
            .then(function (response) {
                if (response.data[0].menus.length != 0) {
                    response.data[0].menus.forEach(function (menu) {
                        oldMenu.push(menu.sysId);
                        $('#' + menu.sysId).prop('checked', true);
                    });
                } else {
                    $("#menu input[type=checkbox]").prop("checked", false);

                }
            }), function errorCallback(response) {
                exceptionViewer(response, false);
        };
    });
    //選擇權限-結束
    //修改權限功能-開始
    $scope.fixRole = function () {

        if (!$('#changeRole option:checked').val()) {
            errorMessage(true, archivesConstant.CHOICE + archivesConstant.ROLE);
            setTimeout(function () {
                $('.modal').trigger("click");
            }, 300);
        } else {
            errorMessage(false, '');
            $('#fixRole').modal();
        }

        $scope.roleType = $('#changeRole option:checked').text();
        $scope.checkboxValue = ($('#changeRole option:checked').attr('data-subtext') == "啟動") ? 1 : 0;
        $('#fixRoleName').val($scope.roleType);
    };

    $scope.fixConfirm = function () {
        pkiService.getDigitalCert($scope, "fixRoleType");
    }

    $scope.fixRoleType = function () {
        var fixCheckboxResult = ($('#fixCheckboxResult').prop('checked')) ? 1 : 0;
        var fixRoleName = $('#fixRoleName').val();

        if ($scope.roleType == fixRoleName && $scope.checkboxValue == fixCheckboxResult) {
            fixErrorMessage(true, archivesConstant.NO_UPDATE);
            return false;
        } else if ($scope.fixRoleName == '') {
            fixErrorMessage(true, archivesConstant.ROLE + archivesConstant.CANT_EMPTY);
            return false;
        } else {
            var fixValue = {
                oldRoleName: $scope.roleType,
                fixStatus: fixCheckboxResult,
                fixRoleName: fixRoleName
            };
            $http.put(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                    archivesConstant.SYSTEM_TOOL_PATH +
                    roleManageConstant.ROLE_MANAGE_PATH + "/fixRoleType", null, {params: fixValue})
                .success(function (response) {
                    actionResultViewer(archivesConstant.UPDATE_SUCCESS_MSG);
                    setTimeout(function () {
                        location.reload();
                    }, 500);
                })
                .error(function (response) {
                    exceptionViewer(response, false);
            });
        }
    };

    $scope.fixGiveup = function () {
        var booleanValue = $scope.roleStatus;
        (booleanValue == '啟動') ? booleanValue = true : booleanValue = false;
        $('#fixCheckboxResult').prop("checked", booleanValue);
        $('#fixRoleName').val($scope.roleType);
    };
    //修改權限功能-結束

    //新增權限功能-開始
    $scope.newRole = function () {
        pkiService.getDigitalCert($scope, "newRoleType");
    }

    $scope.newRoleType = function () {
        if (!$scope.roleName) {
            addErrorMessage(true, archivesConstant.INPUT + archivesConstant.ROLE);
            return false;
        }

        var status = $('#addStatus').prop("checked");

        var addValue = {
            status: status,
            roleName: $scope.roleName,
        };

        $http.post(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
            archivesConstant.SYSTEM_TOOL_PATH +
            roleManageConstant.ROLE_MANAGE_PATH + "/newRoleType", null, {params: addValue})
            .success(function (response) {
                actionResultViewer(archivesConstant.INSERT_SUCCESS_MSG);
                setTimeout(function () {
                    location.reload();
                }, 500);
            }).error(function (response) {
            exceptionViewer(response, false);
        });
    };

    $scope.newGiveup = function () {
        $('#addStatus').prop("checked", false);
        $('#addRoleName').val('');
    }
    //新增權限功能-結束

    //權限選單功能-開始
    $scope.check_all = function (cName) {
        if ($("input[id='" + cName + "']").prop("checked")) {
            $("input[name='" + cName + "']").each(function () {
                $("input[name='" + cName + "']").prop("checked", true);
            });
        } else {
            $("input[name='" + cName + "']").each(function () {
                $("input[name='" + cName + "']").prop("checked", false);
            });
        }
    }

    $scope.checkCertHashSuccess = function(actionUrl) {
        if (actionUrl == "putMenuConfig") {
            $scope.putMenuConfig();
        } else if (actionUrl == "fixRoleType") {
            $scope.fixRoleType();
        } else if (actionUrl == "newRoleType") {
            $scope.newRoleType();
        }
    }

    $scope.menuConfig = function () {
        pkiService.getDigitalCert($scope, "putMenuConfig");
    }

    $scope.putMenuConfig = function () {
        var oldMenu = [];
        var roleSysId = $('#changeRole option:checked').val();

        if (!roleSysId) {
            errorMessage(true, archivesConstant.CHOICE + archivesConstant.ROLE);
            return false;
        }

        var menuValue = $('#subMenu input[type=checkbox]:checked').map(function () {
            return $(this).val();
        }).get();
        var menuArray = new Array();

        menuValue.forEach(function (sysId_value) {
            if (sysId_value != "on") {
                menuArray.push(sysId_value);
            }
        });
        oldMenu.sort();
        menuArray.sort();

        if (oldMenu.length == menuArray.length) {
            var num = 0;

            for (var i = 0; i < oldMenu.length; i++) {
                if (oldMenu[i] == menuArray[i]) {
                    num++;
                }
            }

            if (num == oldMenu.length) {
                errorMessage(true, archivesConstant.NO_UPDATE);
                return false;
            }
        }

        var configValue = {
            "menu": menuArray,
            "roleSysId": roleSysId
        };

        $http.put(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.SYSTEM_TOOL_PATH +
                roleManageConstant.ROLE_MANAGE_PATH + "/menuConfig", null, {params: configValue})
            .then(function (response) {
                actionResultViewer(archivesConstant.UPDATE_SUCCESS_MSG);
                setTimeout(function () {
                    location.reload();
                }, 1000);
            }), function errorCallback(response) {
            exceptionViewer(response, false);
        };
    }
    //權限選單功能-結束

    function errorMessage(errorStatus, errorMessage) {
        $scope.errorMessage = errorStatus;
        $scope.error = errorMessage;
    }

    function fixErrorMessage(fixErrorStatus, fixErrorMessage) {
        $scope.fixModalErrorMessage = fixErrorStatus;
        $scope.fixError = fixErrorMessage;
    }

    function addErrorMessage(addErrorStatus, addErrorMessage) {
        $scope.addModalErrorMessage = addErrorStatus;
        $scope.addError = addErrorMessage;
    }

    certEventListenService.startEventListen($scope);
});
