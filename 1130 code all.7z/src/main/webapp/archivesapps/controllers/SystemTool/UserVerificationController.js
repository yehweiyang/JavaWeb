angular.module('ArchivesApp').constant('userVerificationConstant', {
    USER_MANAGEMENT_PATH: "/userManagement",
    ROLE_MANAGE_PATH: "/roleManage"
}).controller('UserVerificationController', function($scope, $http, $uibModal,
    archivesConstant, archivesService, userVerificationConstant) {
    $scope.$on('$viewContentLoaded', function() {
        $scope.queryUsers();
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
            archivesConstant.SYSTEM_TOOL_PATH + userVerificationConstant.ROLE_MANAGE_PATH + "/listRoleName";
        return $http.get(url)
            .success(function(response) {
            $scope.roleList = response;
        });
    });

    $scope.archivesService = archivesService;
    $scope.userList = [];
    $scope.isQueried = false;

    $scope.queryUsers = function() {
        var nameKeyWord = {
            keyWord: $('#nameKeyWord').val(),
            verification: true,
            active: true,
            inactive: true
        };
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
            archivesConstant.SYSTEM_TOOL_PATH + userVerificationConstant.USER_MANAGEMENT_PATH + "/list";
        return $http.get(url, {
            params: nameKeyWord
        }).then(function successCallback(response) {
            $scope.userList = response.data;
            if (response.data.length == 0) {
                $scope.isQueried = true;
                $scope.errorPrint = archivesConstant.QUERY_WITHOUT_RESULT;
            }
        }, function errorCallback(response) {
            $scope.isQueried = true;
        });
    };

    $scope.selected = {
        user: $scope.userList[0]
    };

    $scope.openUserDetail = function() {
        var uibModalInstance = $uibModal.open({
            templateUrl: archivesConstant.APP_PATH + "/views/SystemTool/userAccountModification.html",
            controller: "UserAccountModificationController",
            size: 'lg',
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            $rootScope.settings.appPath +
                            '/controllers/SystemTool/UserAccountModificationController.js',
                        ]
                    });
                }],
                userList: function() {
                    return $scope.userList;
                },
                user: function() {
                    return $scope.selected.user;
                },
                roleList: function() {
                    return $scope.roleList;
                }
            }
        });
    };
});