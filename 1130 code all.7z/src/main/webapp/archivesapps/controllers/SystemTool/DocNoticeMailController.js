angular.module("ArchivesApp").constant('docNoticeMailConstant', {
    DOC_NOTICE_MAIL_PATH: "/docNoticeMail",
    READ_PATH: "/read",
    CREATE_PATH: "/create",
    UPDATE_PATH: "/update",
    DELETE_PATH: "/delete"
}).controller('DocNoticeMailController', function ($scope, $http, archivesConstant, archivesService,
    docNoticeMailConstant, certEventListenService, pkiService) {

    var docNoticeMailPath =
        archivesConstant.WEB_ROOT_PATH +
        archivesConstant.REST_API_VERSION_PATH +
        archivesConstant.SYSTEM_TOOL_PATH +
        docNoticeMailConstant.DOC_NOTICE_MAIL_PATH;

    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = "docNoticeModifiedTime";

    $scope.$on('$viewContentLoaded', function () {
        $('.archives-checkbox').checkboxpicker();
    });

    $scope.checkCertHashSuccess = function(actionUrl) {
        if (actionUrl == "updateDocNoticeMail") {
            $scope.updateDocNoticeMail();
        } else if (actionUrl == "insertDocNoticeMail") {
            $scope.insertDocNoticeMail();
        } else if (actionUrl == "deleteDocNoticeMail") {
            $scope.deleteDocNoticeMail();
        }
    };

    $scope.queryAction = function() {
        var filterMap = {
            isFullCmp: $scope.isFullCmp,
            docNoticeOrgId: $scope.queryOrgId,
            docNoticeOrgUnitName: $scope.queryOrgUnitName,
            docNoticeUnitId: $scope.queryUnitId,
            docNoticeEmails: $scope.queryEmails
        };

        setError(false, '');
        var filterJson = {
            filterSymbol: {
                [angular.element("#lblQueryOrgId").text()]: $scope.queryOrgId,
                [angular.element("#lblQueryOrgUnitName").text()]: $scope.queryOrgUnitName,
                [angular.element("#lblQueryUnitId").text()]: $scope.queryUnitId
            },
            mail: {
                [angular.element("#lblQueryEmails").text()]: $scope.queryEmails
            }
        }

        if (!archivesService.filterPattern(filterJson)) {
            setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
            return
        }

        return $http.get(docNoticeMailPath + docNoticeMailConstant.READ_PATH, {
                params: filterMap
            })
            .success(function(data) {
                setDataTable(data);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.insertAction = function () {
        pkiService.getDigitalCert($scope, "insertDocNoticeMail");
    };

    $scope.insertDocNoticeMail = function () {
        var filterMap = {
            docNoticeOrgId: $scope.insertOrgId,
            docNoticeOrgUnitName: $scope.insertOrgUnitName,
            docNoticeUnitId: $scope.insertUnitId,
            docNoticeEmails: $scope.insertEmails
        };

        return $http.post(docNoticeMailPath + docNoticeMailConstant.CREATE_PATH, null, {params: filterMap})
            .success(function (data) {
                if (null === data.message || "" === data.message) {
                    $('#insertDialog').modal('hide');
                    actionResultViewer(archivesConstant.INSERT_SUCCESS_MSG);
                    $scope.queryAction();
                } else {
                    $scope.toggleInsertAlert = true;
                    $scope.insertErrorMessage = data.message;
                }
            })
            .error(function (response) {
                exceptionViewer(response, false);
            });
    };

    $scope.updateAction = function () {
        pkiService.getDigitalCert($scope, "updateDocNoticeMail");
    };

    $scope.updateDocNoticeMail = function () {
    var filterMap = {
        docNoticeEmails: $scope.updateEmails,
        docNoticeStatus: $('#updateStatus').prop('checked')
    };
    return $http.put(docNoticeMailPath + docNoticeMailConstant.UPDATE_PATH + "/" +
    $scope.updateSysId, null, {params: filterMap})
        .success(function (data) {
            if (null === data.message || "" === data.message) {
                $('#updateDialog').modal('hide');
                actionResultViewer(archivesConstant.UPDATE_SUCCESS_MSG);
                $scope.queryAction();
            } else {
                $scope.toggleUpdateAlert = true;
                $scope.updateErrorMessage = data.message;
            }
        })
        .error(function (response) {
            exceptionViewer(response, false);
        });
    };

    $scope.deleteAction = function (currentSysId) {
        pkiService.getDigitalCert($scope, "deleteDocNoticeMail");
        $scope.currentSysId = currentSysId;
    };

    $scope.deleteDocNoticeMail = function () {
        var doDelete = confirm("確定要刪除嗎?");
        if (doDelete) {
            $http.delete(docNoticeMailPath + docNoticeMailConstant.DELETE_PATH + "/" + $scope.currentSysId)
                .success(function (data) {
                    if (null === data.message || "" === data.message) {
                        actionResultViewer(archivesConstant.DELETE_SUCCESS_MSG);
                        $scope.queryAction();
                    } else {
                        $scope.toggleAlert = true;
                        $scope.errorMessage = data.message;
                    }
                })
                .error(function (response) {
                    exceptionViewer(response, false);
                });
        }
    };

    $scope.resetAction = function () {
        $scope.toggleResult = false;
        $scope.toggleAlert = false;
        $scope.toggleUpdateAlert = false;
        $scope.queryOrgId = "";
        $scope.queryOrgUnitName = "";
        $scope.queryUnitId = "";
        $scope.queryEmails = "";
        $scope.isFullCmp = false;
        $scope.resetInsertAction();
    };

    $scope.resetInsertAction = function () {
        $scope.toggleInsertAlert = false;
        $scope.insertOrgId = "";
        $scope.insertOrgUnitName = "";
        $scope.insertUnitId = "";
        $scope.insertEmails = "";
    };

    $scope.updateViewer = function (currentResult) {
        $scope.updateOrgId = currentResult.docNoticeOrgId;
        $scope.updateOrgUnitName = currentResult.docNoticeOrgUnitName;
        $scope.updateUnitId = currentResult.docNoticeUnitId;
        $scope.updateEmails = currentResult.docNoticeEmails;
        $scope.updateSysId = currentResult.docNoticeId;
        $('#updateStatus').prop('checked', currentResult.docNoticeStatus === "Y");
        $scope.toggleUpdateAlert = false;
    };

    $scope.breakPoints = function (strParam) {
        return typeof strParam === "undefined" ? "" : strParam.split(";").join("<br>");
    };

    function setDataTable(viewData, isInit) {
        var hasAnyViewData = $.trim(viewData) !== '';
        $scope.toggleResult = hasAnyViewData;
        angular.forEach(viewData, function (currentView) {
            currentView.docNoticeStatus = typeof currentView.docNoticeStatus === 'boolean' ?
                (currentView.docNoticeStatus ? "Y" : "N") : "N";
        });
        $scope.queryResult = hasAnyViewData ? viewData : "";
        $scope.toggleAlert = !hasAnyViewData;
        $scope.errorMessage = archivesConstant.QUERY_WITHOUT_RESULT;
    }
   function setError(showError, errorPrint) {
       $scope.toggleResult = false;
       $scope.toggleAlert = showError;
       $scope.errorMessage = errorPrint;
   }
    certEventListenService.startEventListen($scope);
});
