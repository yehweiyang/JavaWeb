angular.module('ArchivesApp').constant('userAccountModificationConstant', {
    USER_MANAGEMENT_PATH: "/userManagement"
}).controller('UserAccountModificationController',
    function($rootScope, $scope, $http, $uibModalInstance, $timeout, $window, $uibModal,
        pkiService, userList, user, roleList, certEventListenService, archivesConstant,
        userAccountModificationConstant, archivesService) {

        var urlForTemplate = archivesConstant.APP_PATH + archivesConstant.HTML_FOLDER +
            archivesConstant.SYSTEM_TOOL_FOLDER_PATH + '/changeCert.html';
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
            archivesConstant.SYSTEM_TOOL_PATH + userAccountModificationConstant.USER_MANAGEMENT_PATH;
        setTimeout(function() {
            switch ($scope.shadowUser.activeStatus) {
                case 1:
                    $scope.shadowUser.activeStatus = 1;
                    break;
                case 0:
                    $scope.shadowUser.activeStatus = 0;
                    break;
                default:
                    $scope.shadowUser.activeStatus = 0;
                    break;
            }
            $('.archives-checkbox').checkboxpicker().prop('checked', $scope.shadowUser.activeStatus);
            $('.selectpicker').selectpicker();
        }, 500);

        $rootScope.$on('withCardAndGetCert', function(even, data) {
            var certJson = {
                "account": $scope.user.account,
                "certb64": data.slots[0].token.certs[2].certb64,
                "serialNumber": data.slots[0].token.serialNumber
            };
            $http.get(url + "/queryCert", {
                params: certJson
            }).then(function(response) {
                if (!response.data.withOldCard) {
                    $http.put(url + "/modifyCert", certJson).error(function(response) {
                        exceptionViewer(response, false);
                    });

                    var uibModalController = function($scope, $uibModalInstance) {
                        $scope.cardChangeMsg = '使用者新憑證卡片讀取完成，請更換回管理者憑證卡片並按下「確定鍵」';
                        $scope.okBtn = '確定';
                        $scope.submit = function() {
                            $uibModalInstance.close();
                        };
                    };

                    setUibModal(uibModalController).result.then(function() {
                        $window.location.reload();
                    });
                } else {
                    var uibModalController = function($scope, $uibModalInstance) {
                        $scope.cardChangeMsg = '卡片未變更，請確定新憑證已插入讀卡機';
                        $scope.okBtn = '確定';
                        $scope.submit = function() {
                            pkiService.changeUser();
                            $uibModalInstance.close();
                        };
                    };

                    setUibModal(uibModalController);
                }
            });
        });

        $scope.checkCertHashSuccess = function(actionUrl) {
            if (actionUrl === 'saveUser') {
                $scope.saveUser();
            } else {
                var uibModalController = function($scope, $uibModalInstance) {
                    $scope.cardChangeMsg = '請將卡片更換為使用者新憑證後，按「下一步」鍵繼續作業，或按「取消」鍵取消憑證變更作業';
                    $scope.okBtn = '下一步';

                    $scope.submit = function() {
                        pkiService.changeUser();
                        $uibModalInstance.close();
                    };

                    $scope.cancel = function() {
                        $uibModalInstance.close();
                    };
                };

                setUibModal(uibModalController);
            }
        }

        function setUibModal(func) {
            return $uibModal.open({
                templateUrl: urlForTemplate,
                controller: func
            });
        }

        $scope.changeCert = function() {
            pkiService.getDigitalCert($scope);
        };

        $scope.userList = userList;
        $scope.user = user;
        $scope.shadowUser = angular.copy(user);
        var userCopy = angular.copy(user);
        $scope.roleList = [];
        $scope.cardStatus = false;
        $scope.slot = pkiService.querySlot();
        $scope.errorMessage = "";
        $scope.showErrorMessage = false;

        $scope.searchRoleName = function(keyword) {
            angular.forEach($scope.roleList, function(role) {
                if (role.roleName.match(keyword))
                    $scope.shadowUser.roleName = role.roleName;
            });
        };

        $scope.save = function() {
            setError(false, '');
            var filterJson = {
                filterSymbol: {
                    [angular.element("#lblOrgInfo").text()]: $scope.shadowUser.orgInfo.trim()
                }
            }

            if (!archivesService.filterPattern(filterJson)) {
                $scope.showErrorMessage = true;
                $scope.errorMessage = '所屬單位請勿輸入特殊符號';
                return false;
            }

            pkiService.getDigitalCert($scope, 'saveUser');
        };

        $scope.saveUser = function() {
            switch ($('.archives-checkbox').checkboxpicker().prop('checked')) {
                case true:
                    $scope.shadowUser.activeStatus = 1;
                    break;
                case false:
                    $scope.shadowUser.activeStatus = 0;
                    break;
                default:
                    $scope.shadowUser.activeStatus = -1;
                    break;
            }
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.SYSTEM_TOOL_PATH + userAccountModificationConstant.USER_MANAGEMENT_PATH + "/saveUser";
            $scope.shadowUser.phoneNumber = $scope.shadowUser.phoneAreaCode + "-" + $scope.shadowUser.phoneLocalNumber +
                ($scope.shadowUser.phoneExtNumber ? ("#" + $scope.shadowUser.phoneExtNumber) : "");

            angular.copy($scope.shadowUser, $scope.user);
            var userJson = angular.toJson($scope.user);
            $http.put(url, userJson).then(function successCallback(response) {
                actionResultViewer(archivesConstant.UPDATE_SUCCESS_MSG);
                setTimeout(function() {
                    $uibModalInstance.close($scope.user);
                }, 500);
                $scope.showErrorMessage = false;

            }, function errorCallback(response) {
                handleErrorMessage(response);
            });
        };

        $scope.rollback = function() {
            abc();
            $('#roleSelect').selectpicker('refresh');
            angular.copy(userCopy, $scope.shadowUser);
            angular.copy(userCopy, $scope.user);
            $scope.userDetailForm.$setPristine();
        };
        var abc = function() {
            $('#roleSelect').selectpicker('refresh');
            angular.copy(userCopy, $scope.shadowUser);
            angular.copy(userCopy, $scope.user);
            $scope.userDetailForm.$setPristine();
        }

        function handleErrorMessage(response) {
            angular.copy(userCopy, $scope.user);
            if (response.data.errorCode == "SYS0000" || response.data.errorCode == "SYS0001") {
                exceptionViewer(response, true);
            } else {
                $scope.showErrorMessage = true;
                $scope.errorMessage = response.data.errorMessage;
                $timeout(function() {
                    $scope.showErrorMessage = false;
                }, 3000);
            }
        }

        $scope.cancel = function() {
            angular.copy(userCopy, $scope.shadowUser);
            angular.copy(userCopy, $scope.user);
            $scope.userDetailForm.$setPristine();
            $uibModalInstance.dismiss('cancel');
        };

        function setError(showError, errorPrint) {
            $scope.toggleResult = false;
            $scope.showErrorMessage = showError;
            $scope.errorMessage = errorPrint;
        }
        certEventListenService.startEventListen($scope);

        $uibModalInstance.opened.then(function() {
            $scope.roleList = roleList;
        });
    });