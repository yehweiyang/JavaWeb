angular.module('ArchivesApp').constant('smtpConfigConstant', {
    SMTP_CONFIG_PATH: "/smtpConfig"
}).controller('SmtpConfigController', function ($rootScope, $scope, $http, pkiService,
                                                archivesConstant, certEventListenService, smtpConfigConstant) {
    $('.archives-checkbox').checkboxpicker();

    $scope.errorMessage = false;

    $http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
            archivesConstant.SYSTEM_TOOL_PATH +
            smtpConfigConstant.SMTP_CONFIG_PATH + '/searchConfig')
        .then(function (response) {
            $scope.account = isNull(response.data.loginAccount);
            $scope.smtpIP = isNull(response.data.smtpServerIp);
            $scope.smtpSecretNumber = isNull(response.data.loginPassword);
            $scope.portNumber = (isNull(response.data.smtpServerPort) != '') ? parseInt(response.data.smtpServerPort) : '';
            $scope.lastUpdateTime = isNull(response.data.lastUpdateTime);
            $('#ssl').prop('checked', (response.data.useSsl === 'true'));
            $('#certification').prop('checked',(response.data.certification === 'true'));
        }), function errorCallback(response) {
                exceptionViewer(response, false);
    };

        $scope.updateInfo = function () {
            if ($scope.account == '' || $scope.smtpIP == '' || $scope.portNumber == '') {
                errorMessage(true, '請確實填寫欄位');
                return;
            }

            if (isNaN($scope.portNumber)){
                errorMessage(true, '埠號只能輸入數字');
                return;
            }

            if ($scope.smtpSecretNumber == '' && $scope.firstPassword == '') {
                errorMessage(true, '第一次輸入請設定密碼');
                return;
            }

            if ($scope.firstSecretNumber != $scope.secSecretNumber) {
                errorMessage(true, '密碼與第一次不符');
                return;
            }
        pkiService.getDigitalCert($scope, null);
    };

    $scope.checkCertHashSuccess = function (actionUrl) {
        $scope.updateSmtp();
    };

    $scope.updateSmtp = function () {

        var infoValue = {
            account: $scope.account,
            firstSecretNumber: $scope.firstSecretNumber,
            smtpIP: $scope.smtpIP,
            portNumber: $scope.portNumber,
            sslValue: $('#ssl').prop('checked'),
            authenticateValue: $('#certification').prop('checked')
        };

        $http.put(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.SYSTEM_TOOL_PATH +
                smtpConfigConstant.SMTP_CONFIG_PATH + '/updateConfig', null, {params: infoValue})
            .then(function (response) {
                errorMessage(false, '');
                actionResultViewer(archivesConstant.UPDATE_SUCCESS_MSG);
            }), function errorCallback(response) {
                exceptionViewer(response, false);
        };
    };

    function isNull(infoValue){
        (infoValue == 'null') ? infoValue = '' : infoValue = infoValue;
        return infoValue;
    }

    function errorMessage(errorStatus, errorMessage) {
        $scope.errorMessage = errorStatus;
        $scope.error = errorMessage;
    }

    certEventListenService.startEventListen($scope);
});