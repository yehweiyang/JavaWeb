angular.module('ArchivesApp').constant('editAnnouncementConstant', {
    EDIT_ANNOUNCEMENT_PATH: "/editAnnouncement"
}).controller('EditAnnouncementController', function($rootScope, $scope, $http, pkiService,
    restUrlFactory, certEventListenService, archivesConstant,
    editAnnouncementConstant) {

    var announceUrl = archivesConstant.WEB_ROOT_PATH +
        archivesConstant.REST_API_VERSION_PATH +
        archivesConstant.SYSTEM_TOOL_PATH +
        editAnnouncementConstant.EDIT_ANNOUNCEMENT_PATH;

    var constant = {
        SAVE_SUCCESS_MSG: '儲存成功',
        NO_INPUT: '尚未輸入資料',
    };

    $scope.announceMessage = null;
    $scope.showAlertMessage = false;

    $scope.checkCertHashSuccess = function(actionUrl) {
        var announcement = {};
        announcement.announceMessage = $scope.announceMessage;
        $http.put(announceUrl + "/announce", announcement).then(function (response) {
            actionResultViewer(constant.SAVE_SUCCESS_MSG);
            $scope.btDisabled = false;
        },
        function (errResponse) {
            $scope.alertMessage = errResponse.data.errorCode;
            $scope.showAlertMessage = true;
        });
    }

    $scope.initAnnounce = function() {
        var url = announceUrl + "/read/announce";
        $http.get(url)
		.then(function(response) {
    		$scope.announceMessage = response.data.announceMessage;
		},
		function(errResponse) {
		    $scope.announceMessage = "";
		});
    }

	$scope.saveHtmlBt = function() {
	    if ($scope.announceMessage != null) {
	        $scope.showAlertMessage = false;
        	pkiService.getDigitalCert($scope, null);
        	$scope.btDisabled = true;
	    } else {
	        $scope.alertMessage = archivesConstant.NO_INPUT;
            $scope.showAlertMessage = true;
	    }
    }
    certEventListenService.startEventListen($scope);
});