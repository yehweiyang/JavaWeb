angular.module("ArchivesApp").controller('DemoTextFormController', function($scope, $http) {
    $('.selectpicker').selectpicker();
    $('.archives-checkbox').checkboxpicker();
});
