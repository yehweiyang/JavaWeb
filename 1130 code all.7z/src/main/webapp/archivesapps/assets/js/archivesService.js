ArchivesApp.service('archivesService', function() {

    this.sorter = {
        columnName: null,
        descending: false
    };

    this.sortByColumnName = function(columnName) {
        this.sorter.descending = columnName === this.sorter.columnName ? !this.sorter.descending : false;
        this.sorter.columnName = columnName;
    };

    this.pager = {
        itemsPerPage: 20,
        pagerMaxSize: 7,
        firstItemDataNum: 0,
        currentPage: 1
    };

    this.changePager = function() {
        this.pager.firstItemDataNum = (this.pager.currentPage - 1) * this.pager.itemsPerPage;
    };

    this.setHoursRangeFromDomId = function(domId) {
        domId = '#' + domId;
        var formatTime = function(timeValue) {
            return timeValue.toString().length < 2 ? "0" + timeValue : timeValue;
        };
        for (var i = 0; i < 24; i++) {
            $(domId).append($('<option>', {
                value: formatTime(i),
                text: formatTime(i)
            }));
        }
    };

    this.toggleCalendar = function(datePicker) {
        return datePicker = {
            opened: typeof datePicker === 'undefined' ? true : !datePicker.opened
        };
    };

    this.filterJson = {
        errorStatus: false,
        errorMessage: ''
    };


    this.filterPattern = (function(inputData) {
        var pattern_TW = /[^\u4e00-\u9fa5a-zA-Z0-9]/;
        var pattern_Number = /[^0-9]$/;
        var pattern_EMail = /[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
        var keepGoing = true;
        var errorStatusInside;
        var errorMessageInside = '';
        angular.forEach(inputData, function(valueOut, keyOut) {
            if (keyOut === 'filterSymbol') {
                angular.forEach(valueOut, function(value, key) {
                    if (typeof value != 'undefined'&&typeof value==='string') {
                    console.log(value)
                        if (pattern_TW.test(value.trim())) {
                            errorStatusInside = true;
                            errorMessageInside = errorMessageInside + '$' + key + '請勿輸入特殊符號%';
                            keepGoing = false;
                        }
                    }
                });
            }
            if (keyOut === 'onlyNumber') {
                angular.forEach(valueOut, function(value, key) {
                    if (typeof value != 'undefined'&&typeof value==='string') {
                        if (pattern_Number.test(value.trim())) {
                            errorStatusInside = true;
                            errorMessageInside = errorMessageInside + '$' + key + '請輸入數字%';
                            keepGoing = false;
                        }
                    }
                });
            }
            if (keyOut === 'mail') {
                angular.forEach(valueOut, function(value, key) {
                    if (typeof value != 'undefined'&&typeof value==='string') {
                        if (!pattern_EMail.test(value.trim())) {
                            errorStatusInside = true;
                            errorMessageInside = errorMessageInside + '$' + key + '請輸入正確email格式%';
                            keepGoing = false;
                        }
                    }
                });
            }
        });
        this.filterJson.errorStatus = errorStatusInside;
        this.filterJson.errorMessage = errorMessageInside;
        return keepGoing;
    });

});