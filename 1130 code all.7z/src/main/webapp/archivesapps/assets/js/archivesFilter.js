// Setup the filter
ArchivesApp.filter('addHintMsg', function() {
  // Create the return function
  return function(strParam) {
    var notation = '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>'
        return typeof strParam === "undefined" ? "" : strParam.split("%").join("<br>").split("$").join(notation);
  }
});