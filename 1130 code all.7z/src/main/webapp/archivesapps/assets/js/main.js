var ArchivesApp = angular.module("ArchivesApp", [
    "ui.router",
    "ui.bootstrap",
    "oc.lazyLoad",
    "ngSanitize"
]);

ArchivesApp.config(['$ocLazyLoadProvider', function ($ocLazyLoadProvider) {
    $ocLazyLoadProvider.config({});
}]);


ArchivesApp.config(['$controllerProvider', function ($controllerProvider) {
    $controllerProvider.allowGlobals();
}]);

ArchivesApp.config(function ($httpProvider) {
    var auth = document.getElementById("auth").value;
    $httpProvider.interceptors.push(function ($q) {
        return {
            request: function (request) {
                request.headers.authorization = auth;
                return request;
            },
            response: function (response) {
                response.data.status = response.status;
                return response;
            },
            responseError: function (rejection) {
                return $q.reject(rejection);
            }
        }
    });
});


ArchivesApp.factory('settings', ['$rootScope', function ($rootScope) {
    var settings = {
        layout: {
            pageSidebarClosed: false,
            pageContentWhite: true,
            pageBodySolid: false,
            pageAutoScrollOnLoad: 1000
        },
        appPath: 'archivesapps',
        assetsPath: 'resources/assets',
        globalPath: 'resources/assets/global',
        layoutPath: 'resources/assets/layouts/layout',
        SEARCH_BUTTON_TEXT: '查詢',
        RESET_BUTTON_TEXT: '重填',
        ADD_BUTTON_TEXT: '新增',
        UPDATE_BUTTON_TEXT: '修改',
        DELETE_BUTTON_TEXT: '刪除',
        BACK_BUTTON_TEXT: '返回',
        FULL_COMPARISON_TEXT: '完全比對',
        TIME_FROM:'小時（起）：00：00',
        TIME_TO:'小時（迄）：59：59'
    };

    $rootScope.settings = settings;

    return settings;
}]);

ArchivesApp.controller('AppController', ['$scope', '$rootScope', function ($scope) {
    $scope.$on('$viewContentLoaded', function () {

    });
}]);

ArchivesApp.controller('HeaderController', ['$scope', '$http', 'restUrlFactory', 'accountFactory','archivesConstant',
    function ($scope, $http, restUrlFactory, accountFactory, archivesConstant) {
    $scope.$on('$includeContentLoaded', function () {
        var url = archivesConstant.WEB_ROOT_PATH +
                archivesConstant.REST_API_VERSION_PATH +
                archivesConstant.SESSION_PATH +
                '/detail';
        $http.get(url).then(function(response) {
            $scope.account = response.data.account;
            accountFactory.setAccountDetail(response.data);
        });
    });
}]);


ArchivesApp.controller('SidebarController', ['$scope', '$http', '$rootScope', 'archivesConstant',
    function ($scope, $http, $rootScope, archivesConstant) {
    $scope.$on('$includeContentLoaded', function () {
        var menuUrl = archivesConstant.WEB_ROOT_PATH +
                archivesConstant.REST_API_VERSION_PATH +
                '/core/menu';

        $http.get(menuUrl).then(function (response) {
            $rootScope.menus = response.data.menu;
        }), function errorCallback(response) {
            exceptionViewer(response, false);
        };

        var webSide;
        if (location.href.indexOf('home') == -1) {
            if (location.href.indexOf('#') == -1) {
                webSide = location.pathname;
                webSide = testUrl.split(archivesConstant.WEB_ROOT_PATH)[1];
            } else {
                webSide = location.hash;
            }
            setTimeout(function () {
                $('#menu-head-' + getCurrentTopMenu(webSide)).trigger('click');
            }, 1200);
        }
    });

    var getCurrentTopMenu = function(topMenuName) {
        topMenuName = topMenuName.match(/\/[a-zA-Z0-9]*\//);
        return topMenuName[0].substr(1, topMenuName[0].length - 2);
    };

         $scope.toLowUrl = function (topMenu, submenu) {
            return '/' + $scope.toLowerCamelCase(topMenu) + '/' + $scope.toLowerCamelCase(submenu);
        }
        $scope.toLowerCamelCase = function (menuCode) {
            return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
        }
}]);


ArchivesApp.controller('PageHeadController', ['$scope', '$rootScope', 'pkiService', function ($scope, $rootScope, pkiService) {

    $rootScope.$on('slot:find', function () {
        $rootScope.slot = true;
        $rootScope.btDisabled = false;
    });
    $rootScope.$on('slot:empty', function () {
        $rootScope.slot = false;
        $rootScope.btDisabled = true;
    });

    $rootScope.slot = pkiService.querySlot();
}]);


ArchivesApp.controller('FooterController', ['$scope', function ($scope) {
    $scope.$on('$includeContentLoaded', function () {

    });
}]);

ArchivesApp.run(["$rootScope", "settings", "$state", "accountFactory",
    function ($rootScope, settings, $state, accountFactory) {
    $rootScope.$state = $state;
    $rootScope.$settings = settings;
    var expireTime;
    var accountDetail

    $rootScope.$on('$viewContentLoaded', function() {
        accountDetail = accountFactory.getAccountDetail();
        if (accountDetail != null) {
            expireTime = accountDetail.timeOut;
            accountFactory.checkSessionId();
        }
    });
    var lastDigestRun = new Date();
    $rootScope.$watch(function detectIdle() {
        if (expireTime != null) {
            var now = new Date();
            if (now - lastDigestRun > expireTime * 1000) {
                // time expire logout here ...
                $state.go("home");
                accountFactory.sessionExpired();
            }
            lastDigestRun = now;
        }
    });

}]);


ArchivesApp.factory('exchangeService', function () {
    var self = this;
    self.innerQueryData;
    self.outQueryData;
    self.exchangeInfo;
    self.detailInfo;

    self.innerIndexPage;
    self.outsideIndexPage;

    var service = {
        getExchange: function () {
            return self.exchangeInfo;
        }, setExchange: function (exchange) {
            self.exchangeInfo = exchange;
        }, getTransmitDetail: function () {
            return self.detailInfo;
        }, setTransmitDetail: function (detail) {
            self.detailInfo = detail;
        }, getInnerQueryData: function () {
            return self.innerQueryData;
        }, setInnerQueryData: function (data) {
            self.innerQueryData = data;
        }, getOutQueryData: function () {
            return self.outQueryData;
        }, setOutQueryData: function (data) {
            self.outQueryData = data;
        }, getInnerIndexPage: function () {
            return self.innerIndexPage;
        }, setInnerIndexPage: function (index) {
            self.innerIndexPage = index;
        }, getOutsideIndexPage: function () {
            return self.outsideIndexPage;
        }, setOutsideIndexPage: function (index) {
            self.outsideIndexPage = index;
        }
    };
    return service;
});




