ArchivesApp.constant("reportConstant", {
    //path name setting
    REPORT_TOOL_PATH: "/reportTool",
    INIT_PATH: "/init",
    LIST_PATH: "/list",
    DOWNLOAD_PATH: "/download",
    MONTH_PATH: "/month",
    PDF_FILE: "pdf",
    ODS_FILE: "ods",
    //report name setting
    REPORT_SEND_RANK: "reportSendRank",
    REPORT_ERROR_RANK: "reportErrRank",
    REPORT_RS_STATE_STATIC: "reportRSState",
    REPORT_R_STATE_STATIC: "reportRecvStateStatistic",
    REPORT_S_STATE_STATIC: "reportSendStateStatistic",
    REPORT_SEND_ERROR: "reportSendErr",
    REPORT_SEND_STATE: "reportSendState",
    REPORT_SEND_LIST: "reportSendList",
    REPORT_SEND_UNCONFIRM: "reportSendUnConfm",
    REPORT_SEND_ERROR_LIST: "reportSendErrList",
    REPORT_RECEIVE_STATE: "reportRecvState",
    REPORT_RECEIVE_LIST: "reportRecvList",
    REPORT_RECEIVE_ERR_LIST: "reportRecvErrList",
    REPORT_CONFIRMED_QUERY: "reportConFirmedData",
    REPORT_ODF_SEND_RATE: "reportODFSendRate",
    //msg setting
    REPORT_MONTH_EMPTY: "此月報表查無紀錄",
    //other setting
    UNDEFINED: "undefined",
    RESPONSE_ARRAY_BUFFER: "arraybuffer",
    HEAD_APPLICATION: "application",
    TMP_ODS_ID: "odsPath",
    TMP_ODS_CLASS: "hidden"
}).service("reportService", function($http, $filter, $window, archivesConstant, reportConstant) {

    this.currentReportName = "";

    this.checkEmptyValue = function(checkValue, initValue) {
        return (typeof checkValue === reportConstant.UNDEFINED) || "null" === checkValue || null === checkValue ?
                           ((typeof initValue === reportConstant.UNDEFINED) ? "" : initValue)
                           : checkValue;
    };

    this.exportReportFile = function (actionAddress, exportType) {
        return $http.get(actionAddress, { responseType: reportConstant.RESPONSE_ARRAY_BUFFER })
            .success(function(response) {
                var convertToBlob = new Blob([response], {
                        type: reportConstant.HEAD_APPLICATION + "/" + exportType
                    });
                var createURL = URL.createObjectURL(convertToBlob);

                if (reportConstant.ODS_FILE === exportType) {
                    var ods = document.createElement("a");
                    var dateFormat = "yyyy-MM-dd";
                    var odsSuffix = ".ods";

                    ods.id = reportConstant.TMP_ODS_ID;
                    ods.class = reportConstant.TMP_ODS_CLASS;
                    ods.href = createURL;
                    ods.download = $filter('date')(new Date(), dateFormat) + odsSuffix;
                    document.body.appendChild(ods);
                    ods.click();
                    document.body.removeChild(ods);

                } else if (reportConstant.PDF_FILE === exportType) {
                    $window.open(createURL);
                }
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    this.getAverageFromCollection = function (collection, column) {
        var totalCount = this.getTotalCountFromCollection(collection, column);
        return typeof collection !== reportConstant.UNDEFINED ? totalCount / collection.length : totalCount;
    };

    this.getDownloadActionUrl = function (reportName, exportType) {
        return archivesConstant.WEB_ROOT_PATH +
            archivesConstant.REST_API_VERSION_PATH +
            reportConstant.REPORT_TOOL_PATH +
            "/" + reportName +
            reportConstant.DOWNLOAD_PATH +
            "/" + exportType;
    };

    this.getDownloadMonthActionUrl = function (reportName, exportType, selectedMonth) {
        return archivesConstant.WEB_ROOT_PATH +
            archivesConstant.REST_API_VERSION_PATH +
            reportConstant.REPORT_TOOL_PATH +
            "/" + reportName +
            reportConstant.DOWNLOAD_PATH +
            "/" + exportType +
            "/" + selectedMonth;
    };


    this.getInitActionUrl = function (reportName) {
        this.currentReportName = reportName;
        return archivesConstant.WEB_ROOT_PATH +
            archivesConstant.REST_API_VERSION_PATH +
            reportConstant.REPORT_TOOL_PATH +
            "/" + reportName +
            reportConstant.INIT_PATH;
    };

    this.getQueryActionUrl = function (reportName) {
        this.currentReportName = reportName;
        return archivesConstant.WEB_ROOT_PATH +
            archivesConstant.REST_API_VERSION_PATH +
            reportConstant.REPORT_TOOL_PATH +
            "/" + reportName +
            reportConstant.LIST_PATH;
    };

    this.getQueryMonthActionUrl = function (reportName, selectedMonth) {
        return archivesConstant.WEB_ROOT_PATH +
            archivesConstant.REST_API_VERSION_PATH +
            reportConstant.REPORT_TOOL_PATH +
            "/" + reportName +
            reportConstant.MONTH_PATH +
            "/" + selectedMonth;
    };

    this.getToday = function() {
        return new Date();
    };

    this.getTotalCountFromCollection = function (collection, column) {
        var totalCount = 0;
        if (typeof collection !== reportConstant.UNDEFINED) {
            angular.forEach(collection, function(item) {
                totalCount += parseInt(item[column]);
            });
        }
        return totalCount;
    };

    this.setHoursRangeFromDomId = function(domId) {
        domId = "#" + domId;
        var formatTime = function(timeValue) {
            return timeValue.toString().length < 2 ? "0" + timeValue : timeValue;
        };
        for (var i = 0 ; i < 24 ; i++) {
            $(domId).append($("<option>", {
                value:  formatTime(i),
                text:   formatTime(i)
            }));
        }
    };

    this.sorter = {
        columnName : null,
        descending : false
    };

    this.currentFilter = { };

    this.sortByColumnName = function(columnName) {
        this.sorter.descending = columnName === this.sorter.columnName ? !this.sorter.descending : false;
        this.sorter.columnName = columnName;
        /*
        TODO: block until fix solution finish
        this.asyncReportResult();
        */
    };

    this.toggleCalendar = function(datePicker) {
        return datePicker = { opened : typeof datePicker === reportConstant.UNDEFINED ? true : !datePicker.opened  };
    };

    this.asyncReportResult = function () {
        this.currentFilter.sortColumnName = this.sorter.columnName;
        this.currentFilter.sortDescending = this.sorter.descending;

        $http.get(this.getQueryActionUrl(this.currentReportName), { params: this.currentFilter })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };
});