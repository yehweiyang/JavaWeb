ArchivesApp.factory('exchangeService', function () {
    var self = this;
    self.innerQueryData;
    self.outQueryData;
    self.exchangeInfo;
    self.detailInfo;

    self.innerIndexPage;
    self.outsideIndexPage;

    var service = {
        getExchange: function () {
            return self.exchangeInfo;
        }, setExchange: function (exchange) {
            self.exchangeInfo = exchange;
        }, getTransmitDetail: function () {
            return self.detailInfo;
        }, setTransmitDetail: function (detail) {
            self.detailInfo = detail;
        }, getInnerQueryData: function () {
            return self.innerQueryData;
        }, setInnerQueryData: function (data) {
            self.innerQueryData = data;
        }, getOutQueryData: function () {
            return self.outQueryData;
        }, setOutQueryData: function (data) {
            self.outQueryData = data;
        }, getInnerIndexPage: function () {
            return self.innerIndexPage;
        }, setInnerIndexPage: function (index) {
            self.innerIndexPage = index;
        }, getOutsideIndexPage: function () {
            return self.outsideIndexPage;
        }, setOutsideIndexPage: function (index) {
            self.outsideIndexPage = index;
        }
    };
    return service;
});

ArchivesApp.factory('registerService', function () {
    var self = this;
    self.addressQueryData;
    self.numberQueryData;
    self.formQueryData;

    var service = {
        getAddressQueryData: function () {
            return self.addressQueryData;
        }, setAddressQueryData: function (data) {
            self.addressQueryData = data;
        }, getNumberQueryData: function () {
            return self.numberQueryData;
        }, setNumberQueryData: function (data) {
            self.numberQueryData = data;
        }, getFormQueryData: function () {
            return self.formQueryData;
        }, setFormQueryData: function (data) {
            self.formQueryData = data;
        }
    };
    return service;
});