
ArchivesApp.service('restUrlFactory', function ($state, $http, archivesConstant) {
    var self = this;
    self.restUrlMap = null;
    self.restPrefixUrl = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH;
    var getRestUrlMap = function() {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/core/rest/urlMap';
        $http.get(url).then(function(response) {
            self.restUrlMap = response.data;
            self.getPrefixRestUrl();
        });
    }
    getRestUrlMap();
    self.toLowerCamelCase = function(menuCode) {
        return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
    };

    self.getPrefixRestUrl = function() {
        if (self.restUrlMap == null) {
            getRestUrlMap();
        }
        var menuCode = self.toLowerCamelCase($state.current.name);
        for (var key in self.restUrlMap) {
    	    if (key == menuCode) {
                return self.restPrefixUrl + self.restUrlMap[key];
            }
        }
        return self.restPrefixUrl
    }
});