ArchivesApp.config(['$stateProvider', '$urlRouterProvider', 'archivesConstant', function($stateProvider, $urlRouterProvider, archivesConstant) {
    $urlRouterProvider.otherwise("/home");

    //html名稱改小寫駝峰

    var toLowerCamelCase = function(menuCode) {
        return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
    };
    //project名
    $.ajaxSetup({
        async: false
    });

    $.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/core/menu').then(function(response) {
        angular.forEach(response.menu, function(topMenuValue) {
            angular.forEach(topMenuValue.subMenus, function(subMenuValue) {
                if (typeof(subMenuValue.menuName) != 'undefined') {
                    $stateProvider
                        .state(subMenuValue.menuCode, {
                            url: '/' + toLowerCamelCase(topMenuValue.menuCode) + '/' + toLowerCamelCase(subMenuValue.menuCode),
                            views: {
                                "content": {
                                    templateUrl: archivesConstant.APP_PATH + '/views/' + topMenuValue.menuCode + '/' +
                                        toLowerCamelCase(subMenuValue.menuCode) + '.html',
                                    controller: subMenuValue.menuCode + "Controller"
                                }
                            },
                            data: {
                                pageTitle: subMenuValue.menuName
                            },
                            resolve: {
                                deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                                    return $ocLazyLoad.load({
                                        name: 'ArchivesApp',
                                        insertBefore: '#ng_load_plugins_before',
                                        files: [
                                            archivesConstant.APP_PATH + '/controllers/' + topMenuValue.menuCode +'/' + subMenuValue.menuCode + 'Controller.js',
                                        ]
                                    });
                                }]
                            }
                        })
                }
            });
        });
    })
    $stateProvider
        .state('home', {
            url: '/home',
            views: {
                "content": {
                    templateUrl: archivesConstant.APP_PATH + '/views/home.html',
                    controller: "HomeController"
                }
            },
            data: {
                pageTitle: ''
            },
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            archivesConstant.APP_PATH + '/controllers/HomeController.js',
                        ]
                    });
                }]
            }
        })


         .state('OrganReceiveDocReceive', {
                url: "/ChangeRecord/OrganReceiveDocReceive",
                views: {
                    "content": {
                        templateUrl: archivesConstant.APP_PATH + "/views/ChangeRecord/organReceiveDocReceive.html",
                        controller: "OrganReceiveDocReceiveController"
                    }
                },
                data: {pageTitle: '機關接收記錄查詢 / 公文接收訊息'},
                resolve: {
                    deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                        return $ocLazyLoad.load({
                            name: 'ArchivesApp',
                            insertBefore: '#ng_load_plugins_before',
                            files: [
                                archivesConstant.APP_PATH + '/controllers/ChangeRecord/OrganReceiveDocReceiveController.js',
                            ]
                        });
                    }]
                }
        })

        .state('OrganSendDocSend', {
                url: "/ChangeRecord/OrganSendDocSend",
                views: {
                    "content": {
                        templateUrl: archivesConstant.APP_PATH + "/views/ChangeRecord/organSendDocSend.html",
                        controller: "OrganSendDocSendController"
                    }
                },
                data: {pageTitle: '機關傳送記錄查詢 / 公文傳送訊息'},
                resolve: {
                    deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                        return $ocLazyLoad.load({
                            name: 'ArchivesApp',
                            insertBefore: '#ng_load_plugins_before',
                            files: [
                                archivesConstant.APP_PATH + '/controllers/ChangeRecord/OrganSendDocSendController.js',
                            ]
                        });
                    }]
                }
            })


        .state('DocumentExchange', {
            url: "/changeRecord/documentExchange",
            views: {
                "content": {
                    templateUrl: archivesConstant.APP_PATH + "/views/ChangeRecord/documentExchange.html",
                    controller: "DocumentExchangeController"
                }
            },
            data: {pageTitle: '交換記錄彙整'},
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            archivesConstant.APP_PATH + '/controllers/ChangeRecord/DocumentExchangeController.js',
                        ]
                    });
                }]
            }
        })
        .state('DocumentExchangeDetail', {
            url: "/changeRecord/documentExchangeDetail",
            views: {
                "content": {
                    templateUrl: archivesConstant.APP_PATH + "/views/ChangeRecord/documentExchangeDetail.html",
                    controller: "DocumentExchangeDetailController"
                }
            },
            data: {pageTitle: '交換記錄彙整'},
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            archivesConstant.APP_PATH + '/controllers/ChangeRecord/DocumentExchangeDetailController.js',
                        ]
                    });
                }]
            }
        })

}]);