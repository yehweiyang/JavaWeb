
ArchivesApp.factory('accountFactory', function($http, $window, archivesConstant) {
    var self = this;
	self.accountDetail;

	var factory = {
        getAccountDetail: function() {
    	    return self.accountDetail;
        }, setAccountDetail: function(detail) {
            self.accountDetail = detail;
        }, checkSessionId: function() {
            $http.post(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + archivesConstant.SESSION_PATH + '/checkSessionId')
            .error(function(response) {
                $window.location.href = archivesConstant.WEB_ROOT_PATH + "/logout/conflict"

            });
        }, sessionExpired: function() {
            self.accountDetail = null;
            $window.location.href = archivesConstant.WEB_ROOT_PATH + "/logout/expired"
        }
    };
    return factory;
});