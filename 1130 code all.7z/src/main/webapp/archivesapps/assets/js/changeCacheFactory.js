
ArchivesApp.factory('changeCacheFactory', function () {
    var self = this;
    self.innerQueryData;
    self.outQueryData;
    self.exchangeInfo;
    self.detailInfo;

    var factory = {
        getExchange: function () {
            return self.exchangeInfo;
        }, setExchange: function (exchange) {
            self.exchangeInfo = exchange;
        }, getTransmitDetail: function () {
            return self.detailInfo;
        }, setTransmitDetail: function (detail) {
            self.detailInfo = detail;
        }, getInnerQueryData: function () {
            return self.innerQueryData;
        }, setInnerQueryData: function (data) {
            self.innerQueryData = data;
        }, getOutQueryData: function () {
            return self.outQueryData;
        }, setOutQueryData: function (data) {
            self.outQueryData = data;
        }
    };
    return factory;
});