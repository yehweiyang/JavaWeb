var postTarget;
var timeoutId;
function postData(target,data)
{
	if(!http.sendRequest)
	{
		return null;
	}
	http.url=target;
	http.actionMethod="POST";
	var code=http.sendRequest(data);
	if(code!=0) return null;
	return http.responseText;

}
function checkFinish(){
	if(postTarget){
		postTarget.close();
		alert("尚未安裝元件");
	}
}

function getUserCert()
{
   var ua = window.navigator.userAgent;
	if(ua.indexOf("MSIE")!=-1 || ua.indexOf("Trident")!=-1) //is IE, use ActiveX
	{
		postTarget=window.open("http://localhost:61161/waiting.gif", "Reading","height=200, width=200, left=100, top=20");
		document.getElementById("httpObject").innerHTML='<OBJECT id="http" width=1 height=1 style="LEFT: 1px; TOP: 1px" type="application/x-httpcomponent" VIEWASTEXT></OBJECT>';
		var data=postData("http://localhost:61161/pkcs11info?withcert=true","");
		postTarget.close();
		postTarget=null;
		if(!data)
			alert("尚未安裝元件");
		else
			setUserCert(data);
	}
	else{
		postTarget=window.open("http://localhost:61161/popupForm", "處理中","height=200, width=200, left=100, top=20");
		timeoutId=setTimeout(checkFinish,3500);
	}
}
function setUserCert(certData)
{

	var ret=JSON.parse(certData);
	document.getElementById("returnCode").value=ret.ret_code;
	if(ret.ret_code!=0){
		alert(MajorErrorReason(ret.ret_code));
		if(ret.last_error)
			alert(MinorErrorReason(ret.last_error));
		return;
	}
	var usage="digitalSignature";
	var slots = ret.slots;
	for(var index in slots){
		if(slots[index].token==null || slots[index].token==="unknown token") continue;
		var certs=slots[index].token.certs;
		for(var indexCert in certs){
			if(certs[indexCert].usage==usage){
			    document.getElementById('cardNo').value = slots[index].token.serialNumber;
				document.getElementById("certb64").value=certs[indexCert].certb64;
				document.getElementById('accountForm').submit()
				return;
			}
		}
	}
	alert("找不到可用來加密的憑證");
}

function receiveMessage(event)
{
	if(console)
		console.debug(event);
	
	//安全起見，這邊應填入網站位址檢查
	if(event.origin!="http://localhost:61161")
		return;
	try{
		var ret = JSON.parse(event.data);
		console.debug(ret);
		if(ret.func){
			if(ret.func=="getTbs"){
				clearTimeout(timeoutId);
				var tbsData = {"func":"GetUserCert"};
				var json=JSON.stringify(tbsData);
				postTarget.postMessage(json,"*");
			}else if(ret.func=="pkcs11info"){
				setUserCert(event.data);
			}
		}else{
			if(console) console.error("no func");
		}
	}catch(e){
		//errorhandle
		if(console)
			console.error(e);
	}
}
if (window.addEventListener) {
	window.addEventListener("message", receiveMessage, false);
	}else {
	//for IE8
		window.attachEvent("onmessage", receiveMessage);
	}
	//for IE8
var console=console||{"log":function(){}, "debug":function(){}, "error":function(){}};