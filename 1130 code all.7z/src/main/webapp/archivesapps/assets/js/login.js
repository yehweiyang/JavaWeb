$(document).ready(function() {
      var validator = $("#loginForm").validate({
        rules: {
           account: {
              required: true
           },
           pin: {
              required: true
           },
           captcha: {
           required: true
        },
    },
        messages: {
           account: {
              required: "帳號 是必要欄位"
           },
           pin: {
             required: "卡片PIN碼 是必要欄位"
          },
           captcha: {
             required: "圖形驗證碼 是必要欄位"
           }
        },
        submitHandler: function(loginForm) {
             makeSignature();
        }
    });
});