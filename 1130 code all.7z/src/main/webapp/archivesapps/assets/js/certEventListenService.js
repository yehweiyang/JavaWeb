
ArchivesApp.service('certEventListenService', function ($rootScope, $http, restUrlFactory, archivesConstant) {
    var self = this;

    self.startEventListen = function($scope) {
        $scope.getCertSuccess = function(certB64, actionUrl) {
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/cert/check";
            $http.post(url, certB64).then(function (response) {

                var doAction = actionUrl || "default";
                $scope.checkCertHashSuccess(doAction);
            },
            function (errResponse) {
                exceptionViewer(response, false);
                $rootScope.btDisabled = false;
            });
        }

        $scope.slotEmpty = function() {
            $rootScope.$broadcast('slot:empty');
            actionResultViewer(archivesConstant.NO_REG_CERT);
        }
    }
});