includeOtherScript("changeCacheFactory");
ArchivesApp.service('changeRecordFactory', function ($state, $http, restUrlFactory, changeCacheFactory,
archivesService,archivesConstant) {
    var self = this;
    var subMenuCode = {
        INSIDE_SEND: "InsideSendChange",
        OUTSIDE_RECEIVE: "OutsideReceiveChange"
    };
    var constant = {
        RECORD_LIST: "/recordList",
        INNER_URL: "/inner",
        OUT_URL: "/outter",
        INNER_TYPE: "INNER",
        OUTSIDE_TYPE: "OUTSIDE",
        SHOW_PURPORT_MSG: "顯示主旨訊息",
        HIDE_PURPORT_MSG: "隱藏主旨訊息",
        FORM_INVALID_MSG: "輸入格式錯誤",
        DOC_EXCHANGE_STATE: "DocumentExchange"
    };
    self.startServiceByScope = function($scope) {
        var currentName = $state.current.name;
		var prefixUrl = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
			archivesConstant.CHANGE_RECORD_PATH + '/' +restUrlFactory.toLowerCamelCase(currentName);
        $scope.archivesService = archivesService;
        $scope.archivesService.sorter.columnName = "exchangeSerial";
	    $scope.showPurport = false;
	    $scope.purportMsg = constant.SHOW_PURPORT_MSG;
        $scope.exactMatch = false;

    	$scope.today = function() {
	    	$scope.startDate = new Date();
    		$scope.endDate = new Date();
    	};

    	$scope.stOpen = function(){
        	$scope.stPopup.opened = true;
        };

	    $scope.edOpen = function(){
    	    $scope.edPopup.opened = true;
        };

        $scope.stPopup = {
    	    opened: false
        };
        $scope.edPopup = {
      	    opened: false
        };

	    $scope.hourList = [
	        {hour: "00"},
	        {hour: "01"},
	        {hour: "02"},
	        {hour: "03"},
	        {hour: "04"},
	        {hour: "05"},
	        {hour: "06"},
	        {hour: "07"},
	        {hour: "08"},
	        {hour: "09"},
	        {hour: "10"},
	        {hour: "11"},
	        {hour: "12"},
	        {hour: "13"},
	        {hour: "14"},
	        {hour: "15"},
	        {hour: "16"},
	        {hour: "17"},
	        {hour: "18"},
	        {hour: "19"},
	        {hour: "20"},
	        {hour: "21"},
	        {hour: "22"},
	        {hour: "23"},
	    ];

	    $scope.purportBt = function() {
		    if ($scope.showPurport) {
			    $scope.showPurport = false;
			    $scope.purportMsg = constant.SHOW_PURPORT_MSG;
		    } else {
			    $scope.showPurport = true;
			    $scope.purportMsg = constant.HIDE_PURPORT_MSG;
		    }
	    }

        $scope.restExchange = function() {
            var queryData = {};
            if ($scope.QueryData != null)
                queryData = $scope.QueryData;
			    queryData.cacheData = false;
			    queryData.startHour = $scope.hourList.indexOf($scope.selectedStartHour);
			    queryData.endHour = $scope.hourList.indexOf($scope.selectedEndHour);
	        if (queryData.startDocId != null) {
	            if (queryData.startDocId.length == 0) {
	                queryData.startDocId = null;
	            }
	        }
	        if (queryData.endDocId != null) {
	            if (queryData.endDocId.length == 0) {
    	            queryData.endDocId = null;
    	        }
    	    }

	        queryData.startUpDateTime = $scope.startDate.toISOString().substring(0, 10) + " " + $scope
    	    .selectedStartHour.hour + ":00:00";
	        queryData.endUpDateTime = $scope.endDate.toISOString().substring(0, 10) + " " + $scope
	        .selectedEndHour.hour + ":59:59";
	        queryData.exactMatch = $scope.exactMatch;
            $scope.restCacheExchange(queryData);
    	}

    		$scope.restCacheExchange = function(queryData) {

                    var filterJson = []
                    var filterSymbol= {
                    [angular.element("#lblInsideSendAgencyId").text()]:
                    angular.element("#inputInsideSendAgencyId").val(),
                    [angular.element("#lblInsideExchangeSerial").text()]:
                    angular.element("#inputInsideExchangeSerial").val(),
                    [angular.element("#lblInsideSendAgencyName").text()]:
                    angular.element("#inputInsideSendAgencyName").val(),
                    [angular.element("#lblOutsideSendAgencyId").text()]:
                    angular.element("#inputOutsideSendAgencyId").val(),
                    [angular.element("#lblOutsideExchangeSerial").text()]:
                    angular.element("#inputOutsideExchangeSerial").val(),
                    [angular.element("#lblOutsideSendAgencyName").text()]:
                    angular.element("#inputOutsideSendAgencyName").val()
                    }

                    var url;
                    if (currentName == subMenuCode.INSIDE_SEND) {
                        url = prefixUrl + constant.RECORD_LIST + constant.INNER_URL;
                         var onlyNumber= {
                             '起始文號': angular.element("#inputInsideStartDocId").val(),
                             '結束文號': angular.element("#inputInsideEndDocId").val()
                        }
                        filterJson={filterSymbol,onlyNumber};
                    } else if (currentName == subMenuCode.OUTSIDE_RECEIVE) {
                      url = prefixUrl + constant.RECORD_LIST + constant.OUT_URL;
                            var onlyNumber= {
                             '起始文號': angular.element("#inputOutsideStartDocId").val(),
                             '結束文號': angular.element("#inputOutsideEndDocId").val()
                        }
                     filterJson={filterSymbol,onlyNumber};
                    }
                      setError(false,'');
                    if (!archivesService.filterPattern(filterJson)) {
                        setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
                        return
                            }
                    $http.get(url, {params: queryData}).then(function(response) {

              	        $scope.exchangeList = response.data;
                        if(response.data.length>0){
                             if (currentName == subMenuCode.INSIDE_SEND) {
                                 changeCacheFactory.setInnerQueryData(queryData);
                             } else if (currentName == subMenuCode.OUTSIDE_RECEIVE) {
                                 changeCacheFactory.setOutQueryData(queryData);
                             }
                                $scope.showTable = true;
                        }else{
                            if (currentName == subMenuCode.INSIDE_SEND) {
                                changeCacheFactory.setInnerQueryData(null);
                            } else if (currentName == subMenuCode.OUTSIDE_RECEIVE) {
                                changeCacheFactory.setOutQueryData(null);
                            }
                            $scope.errorMessage = archivesConstant.QUERY_WITHOUT_RESULT;
                            $scope.showError = true;
                        }

                    }, function(errResponse) {
                        exceptionViewer(errResponse, false);
                    });
            	}

	    $scope.queryBt = function(form) {

	        if (form.$valid) {
	            $scope.showLoad = true;
                $scope.restExchange();
	        } else {
                $scope.errorMessage = constant.FORM_INVALID_MSG;
                $scope.showError = true;
                $scope.showTable = false;
	        }
	    }

	    $scope.resetBt = function() {
		    $scope.today();
	        $scope.exactMatch = false;
		    $scope.selectedStartHour = $scope.hourList[0];
		    $scope.selectedEndHour = $scope.hourList[23];
		    $scope.showError = false;
		    $scope.showTable = false;
		    $scope.showPurport = false;
	        $scope.purportMsg = constant.SHOW_PURPORT_MSG;
	        if ($scope.QueryData != null) {
		        $scope.QueryData.sendAgencyName = null;
		        $scope.QueryData.sendAgencyId = null;
                $scope.QueryData.exchangeSerial = null;
		        $scope.QueryData.startDocId = null;
                $scope.QueryData.endDocId = null;
	        }
	        changeCacheFactory.setInnerQueryData(null);
	    }

	    $scope.transmitBt = function(exchange) {
	        if (currentName == subMenuCode.INSIDE_SEND)
	            exchange.sendType = constant.INNER_TYPE;
            else if (currentName == subMenuCode.OUTSIDE_RECEIVE)
                exchange.sendType = constant.OUTSIDE_TYPE;
            changeCacheFactory.setExchange(exchange);
            $state.go(constant.DOC_EXCHANGE_STATE);
	    }

	    if (currentName == subMenuCode.INSIDE_SEND)
            $scope.QueryData = changeCacheFactory.getInnerQueryData();
        else if (currentName == subMenuCode.OUTSIDE_RECEIVE)
            $scope.QueryData = changeCacheFactory.getOutQueryData();
        if ($scope.QueryData != null) {
    	    $scope.startDate = new Date($scope.QueryData.startUpDateTime);
    	    $scope.endDate = new Date($scope.QueryData.endUpDateTime);
            $scope.selectedStartHour = $scope.hourList[$scope.QueryData.startHour];
    	    $scope.selectedEndHour = $scope.hourList[$scope.QueryData.endHour];
            $scope.QueryData.cacheData = true;
            $scope.restCacheExchange($scope.QueryData);
        } else {
	        $scope.today();
	        $scope.selectedStartHour = $scope.hourList[0];
	        $scope.selectedEndHour = $scope.hourList[23];
        }
          function setError(showError, errorPrint) {
                $scope.showTable = false;
                $scope.showError = showError;
                $scope.errorMessage = errorPrint;
            }
    }
});