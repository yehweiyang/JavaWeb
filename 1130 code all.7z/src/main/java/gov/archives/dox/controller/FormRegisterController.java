package gov.archives.dox.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.ActionLogConf;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.controller.RestControllerBase;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.dox.domain.entity.FormEntity;
import gov.archives.dox.service.FormInfoService;

import static gov.archives.dox.conf.DoxConf.DOC_FORM_TYPE;
import static gov.archives.dox.conf.DoxConf.MANGER_FORM_TYPE;
import static gov.archives.dox.conf.DoxConf.REST_REGISTER_SEARCH_FORM;
import static gov.archives.dox.conf.DoxConf.STATUS_INDEX;

@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + REST_REGISTER_SEARCH_FORM)
public class FormRegisterController extends RestControllerBase {
    private static final String TABLE_ID = "tableId";
    private static final String TABLE_NAME = "tableName";
    private static final String AGENCY_ORG_ID = "agencyOrgId";
    private static final String FORM_TYPE = "formType";
    private static final String STATUS_CODE = "statusCode";
    private static final String MAIN_FILE_TYPE = "mainFileType";
    private static final String FORM_TYPE_INDEX = "formTypeIndex";
    private static final String FILE_TYPE_INDEX = "fileTypeIndex";
    private static final String SHOW_FILE_TYPE_INDEX = "showFileTypeIndex";
    private static final String VIEW_FILE_TYPE = "viewFileType";
    private static final String ALIVE_FORM_STATUS = "ALIVE";
    private static final String SUSPEND_FORM_STATUS = "SUSPEND";
    private static final String STOP_FORM_STATUS = "STOP";
    private static final String XML_FILE = "XML";
    private static final String DOC_FILE = "DOC";
    private static final String PDF_FILE = "PDF";
    private static final String PNG_FILE = "PNG";
    private static final String TIF_FILE = "TIF";
    private static final String NONE_FILE = "無";
    private static final String FORM_LIST = "/form/list";

    @Autowired
    private FormInfoService formInfoService;

    private List<FormEntity> entityList;

    private Map<String, String> validateMap;

    private Map<String, String> validateExceptMap;

    public FormRegisterController() {
        buildValidateMap();
        buildValidateExceptMap();
    }

    private void buildValidateMap() {
        validateMap = new HashMap<>();
        validateMap.put(TABLE_ID, CoreConf.DIGIT_PATTERN);
        validateMap.put(TABLE_NAME, CoreConf.ALPHANUMERIC_NLS_PATTERN);
        validateMap.put(AGENCY_ORG_ID, CoreConf.ALPHANUMERIC_PATTERN);
    }

    private void buildValidateExceptMap() {
        validateExceptMap = new HashMap<>();
        validateExceptMap.put(TABLE_ID, CoreErrorCode.ED0013_CENTER_ID_FORMAT_INCORRECT);
        validateExceptMap.put(TABLE_NAME, CoreErrorCode.ED0006_AGENCY_ID_FORMAT_INCORRECT);
        validateExceptMap.put(AGENCY_ORG_ID, CoreErrorCode.ED0008_UNIT_ID_FORMAT_INCORRECT);
    }

    @RequestMapping(value = FORM_LIST, method = RequestMethod.GET)
    public ResponseEntity<List<FormEntity>> getAllFormList(HttpServletRequest request, @RequestParam Map<String, Object>
            params) {
        try {
            Object cacheData = params.get(CACHE_DATE);
            formParamsValidate(params);
            if ("false".equals(cacheData)) {
                entityList = formInfoService.getByQueryMap(params);
            } else if ("true".equals(cacheData)) {
                if (null == entityList) {
                    entityList = formInfoService.getByQueryMap(params);
                }
            }

            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_FORM_REGISTER,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
            return new ResponseEntity<>(entityList, HttpStatus.OK);
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_FORM_REGISTER,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR),
                    CoreErrorCode.SEARCH_ERROR, ActionLogConf.EVENT_LEVEL_HIGH);
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode(), e);
        }
    }

    private void formParamsValidate(Map<String, Object> params) {
        if (params.isEmpty()) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ED0030_QUERY_DATA_EMPTY);
        } else {
            genStatusCodeParam(params);
            genFormTypeParam(params);
            genMainFileTypeParam(params);
            genViewFileTypeParam(params);
            Set<String> keySet = validateMap.keySet();
            for (String query : keySet) {
                if (!validateFiled((String) params.get(query), validateMap.get(query))) {
                    String CoreErrorCode = validateExceptMap.get(query);
                    throw new ArchivesException(CoreErrorMessage.findByCode(CoreErrorCode), CoreErrorCode);
                }
            }
        }
    }

    private void genStatusCodeParam(Map<String, Object> params) {
        String[] formStatusArray = {null, ALIVE_FORM_STATUS, SUSPEND_FORM_STATUS, STOP_FORM_STATUS};
        int index = new Integer((String) params.get(STATUS_INDEX));
        if (index >= 0 && index < formStatusArray.length) {
            params.put(STATUS_CODE, formStatusArray[index]);
        } else {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ED0025_FORM_STATUS_INDEX_INCORRECT);
        }
    }

    private void genFormTypeParam(Map<String, Object> params) {
        String[] formTypeArray = {null, DOC_FORM_TYPE, MANGER_FORM_TYPE};
        int index = new Integer((String) params.get(FORM_TYPE_INDEX));
        if (index >= 0 && index < formTypeArray.length) {
            params.put(FORM_TYPE, formTypeArray[index]);
        } else {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ED0026_FORM_TYPE_INDEX_INCORRECT);
        }
    }

    private void genMainFileTypeParam(Map<String, Object> params) {
        String[] fileTypeArray = {null, XML_FILE, DOC_FILE, PDF_FILE};
        int index = new Integer((String) params.get(FILE_TYPE_INDEX));
        if (index >= 0 && index < fileTypeArray.length) {
            params.put(MAIN_FILE_TYPE, fileTypeArray[index]);
        } else {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ED0027_MAIN_FILE_TYPE_INDEX_INCORRECT);
        }
    }

    private void genViewFileTypeParam(Map<String, Object> params) {
        String[] viewFileTypeArray = {null, NONE_FILE, PDF_FILE, PNG_FILE, TIF_FILE};
        int index = new Integer((String) params.get(SHOW_FILE_TYPE_INDEX));
        if (index >= 0 && index < viewFileTypeArray.length) {
            params.put(VIEW_FILE_TYPE, viewFileTypeArray[index]);
        } else {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ED0028_VIEW_FILE_TYPE_INDEX_INCORRECT);
        }
    }
}
