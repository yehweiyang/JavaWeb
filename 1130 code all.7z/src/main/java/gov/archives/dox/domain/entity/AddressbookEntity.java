package gov.archives.dox.domain.entity;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

import gov.archives.core.util.EscapeUtils;

import static gov.archives.dox.conf.DoxConf.*;

/**
 * AddressbookEntity
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@Alias("AddressBook")
public class AddressbookEntity extends AddressBookBase implements Serializable {
    private String agencyAddress;
    private String agencyPhone;
    private String agencyFax;
    private String agencyUrl;
    private String contactName;
    private String contactEmail;
    private String contactMobile;
    private String agencyCertId;
    private String signCertSerialNum;
    private String encryptCertSerialNum;
    private String cipherModule;
    private String pbSerial;
    private String orgCardStatus;
    private OrgCertEntity orgCert;

    public String getAgencyAddress() {
        return agencyAddress;
    }

    public String getAgencyPhone() {
        return agencyPhone;
    }

    public String getAgencyFax() {
        return agencyFax;
    }

    public String getAgencyUrl() {
        return agencyUrl;
    }

    public String getContactName() {
        return contactName;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public String getContactMobile() {
        return contactMobile;
    }

    public String getRelatedOrgUnitId() {
        return agencyCertId;
    }

    public String getSignCertSerialNum() {
        return signCertSerialNum;
    }

    public String getEncryptCertSerialNum() {
        return encryptCertSerialNum;
    }

    public String getCipherModule() {
        return cipherModule;
    }

    public String getPbSerial() {
        return pbSerial;
    }

    public void setAgencyAddress(String agencyAddress) {
        this.agencyAddress = agencyAddress;
    }

    public void setAgencyPhone(String agencyPhone) {
        this.agencyPhone = agencyPhone;
    }

    public void setAgencyFax(String agencyFax) {
        this.agencyFax = agencyFax;
    }

    public void setAgencyUrl(String agencyUrl) {
        this.agencyUrl = agencyUrl;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public void setContactMobile(String contactMobile) {
        this.contactMobile = contactMobile;
    }

    public void setAgencyCertId(String agencyCertId) {
        this.agencyCertId = agencyCertId;
    }

    public void setSignCertSerialNum(String signCertSerialNum) {
        this.signCertSerialNum = signCertSerialNum;
    }

    public void setEncryptCertSerialNum(String encryptCertSerialNum) {
        this.encryptCertSerialNum = encryptCertSerialNum;
    }

    public void setCipherModule(String cipherModule) {
        this.cipherModule = cipherModule;
    }

    public void setPbSerial(String pbSerial) {
        this.pbSerial = pbSerial;
    }

    public OrgCertEntity getOrgCert() {
        return orgCert;
    }

    public void setOrgCert(OrgCertEntity orgCert) {
        this.orgCert = orgCert;
    }

    public String getOrgCardStatus() {
        return orgCardStatus;
    }

    public void setOrgCardStatus(String orgCardStatus) {
        this.orgCardStatus = orgCardStatus;
    }

    public void buildAgencyAddress() {
        setAgencyAddress(EscapeUtils.escapeHtml(agencyAddress));
    }

    public void buildAgencyPhone() {
        setAgencyPhone(EscapeUtils.escapeHtml(agencyPhone));
    }

    public void buildAgencyFax() {
        setAgencyFax(EscapeUtils.escapeHtml(agencyFax));
    }

    public void buildContactName() {
        setContactName(EscapeUtils.escapeHtml(contactName));
    }

    public void buildContactEmail() {
        setContactEmail(EscapeUtils.escapeHtml(contactEmail));
    }

    public void buildAgencyCertId() {
        setAgencyCertId(EscapeUtils.escapeHtml(agencyCertId));
    }

    public void buildCipherModule() {
        setCipherModule(EscapeUtils.escapeHtml(cipherModule));
    }

    public void buildOrgCardStatus() {
        String orgCardStatus = getOrgCardStatus();
        if (null != orgCardStatus) {
            if (getOrgCardStatus().equals(PRIMARY_RELATED_ATTRIBUTE))
                setOrgCardStatus(PRIMARY_ORG_CARD_STATUS);
            else if (getOrgCardStatus().equals(NONE_RELATED_ATTRIBUTE))
                setOrgCardStatus(NONE_ORG_CARD_STATUS);
        }
    }

    public void buildApplyType() {
        orgCert.setApplyType(EscapeUtils.escapeHtml(orgCert.getApplyType()));
    }

    public void buildSmartCardType() {
        orgCert.setSmartCardType(EscapeUtils.escapeHtml(orgCert.getSmartCardType()));
    }

    public void buildSignDigitalNum() {
        orgCert.setSignDigitalNum(EscapeUtils.escapeHtml(orgCert.getSignDigitalNum()));
    }

    public void buildEncryptDigitalNum() {
        orgCert.setEncryptDigitalNum(EscapeUtils.escapeHtml(orgCert.getEncryptDigitalNum()));
    }

    public void buildEffectBegin() {
        orgCert.setEffectBegin(EscapeUtils.escapeHtml(orgCert.getEffectBegin()));
    }

    public void buildEffectEnd() {
        orgCert.setEffectEnd(EscapeUtils.escapeHtml(orgCert.getEffectEnd()));
    }

    public void buildDefaultCert() {
        if (orgCert.isDefault())
            orgCert.setDefaultCert(YES_DEFAULT_CERT);
        else
            orgCert.setDefaultCert(NO_DEFAULT_CERT);
    }

    public void buildCertCardSerial() {
        orgCert.setCertCardSerial(EscapeUtils.escapeHtml(orgCert.getCertCardSerial()));
    }

    public void buildPublicKeySerial() {
        orgCert.setPublicKeySerial(EscapeUtils.escapeHtml(orgCert.getPublicKeySerial()));
    }

    public static class Builder {
        public static synchronized Builder create() {
            return new Builder();
        }

        private AddressbookEntity addressbook;
        private Builder self;

        private Builder() {
            this.addressbook = new AddressbookEntity();
            this.self = this;
        }

        public Builder setGatewayId(String gatewayId) {
            this.addressbook.setGatewayId(gatewayId);

            return self;
        }

        public Builder setAgencyId(String agencyId) {
            this.addressbook.setAgencyId(agencyId);

            return self;
        }

        public Builder setAgencyUnitId(String agencyUnitId) {
            this.addressbook.setAgencyUnitId(agencyUnitId);

            return self;
        }

        public Builder setAgencyName(String agencyName) {
            this.addressbook.setAgencyName(agencyName);

            return self;
        }

        public Builder setAgencyAddress(String agencyAddress) {
            this.addressbook.agencyAddress = agencyAddress;

            return self;
        }

        public Builder setAgencyPhone(String agencyPhone) {
            this.addressbook.agencyPhone = agencyPhone;

            return self;
        }

        public Builder setAgencyFax(String agencyFax) {
            this.addressbook.agencyFax = agencyFax;

            return self;
        }

        public Builder setAgencyUrl(String agencyUrl) {
            this.addressbook.agencyUrl = agencyUrl;

            return self;
        }

        public Builder setContactName(String contactName) {
            this.addressbook.contactName = contactName;

            return self;
        }

        public Builder setContactEmail(String contactEmail) {
            this.addressbook.contactEmail = contactEmail;

            return self;
        }

        public Builder setContactMobile(String contactMobile) {
            this.addressbook.contactMobile = contactMobile;

            return self;
        }

        public Builder setActiveStatus(Integer activeStatus) {
            this.addressbook.setActiveStatus(activeStatus);

            return self;
        }

        public Builder setAgencyCertId(String agencyCertId) {
            this.addressbook.agencyCertId = agencyCertId;

            return self;
        }

        public Builder setSignCertSerialNum(String signCertSerialNum) {
            this.addressbook.signCertSerialNum = signCertSerialNum;

            return self;
        }

        public Builder setEncryptCertSerialNum(String encryptCertSerialNum) {
            this.addressbook.encryptCertSerialNum = encryptCertSerialNum;

            return self;
        }

        public Builder setCipherModule(String cipherModule) {
            this.addressbook.cipherModule = cipherModule;

            return self;
        }

        public Builder setPbSerial(String pbSerial) {
            this.addressbook.pbSerial = pbSerial;

            return self;
        }

        public Builder initSave(String creator) {
            this.addressbook.initSave(creator);

            return self;
        }

        public AddressbookEntity build() {
            return this.addressbook;
        }
    }
}
