package gov.archives.dox.domain.entity;

import org.apache.ibatis.type.Alias;

import static gov.archives.dox.conf.DoxConf.*;

@Alias("FormInfo")
public class FormEntity {
    private String tableId;
    private String tableName;
    private String tableType;
    private String mainFileType;
    private String viewFileType;
    private String statusCode;
    private String agencyOrgName;
    private String updateTime;

    public String getTableId() {
        return tableId;
    }

    public void setTableId(String tableId) {
        this.tableId = tableId;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getTableType() {
        return tableType;
    }

    public void setTableType(String tableType) {
        this.tableType = tableType;
    }

    public String getMainFileType() {
        return mainFileType;
    }

    public void setMainFileType(String mainFileType) {
        this.mainFileType = mainFileType;
    }

    public String getViewFileType() {
        return viewFileType;
    }

    public void setViewFileType(String viewFileType) {
        this.viewFileType = viewFileType;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getAgencyOrgName() {
        return agencyOrgName;
    }

    public void setAgencyOrgName(String agencyOrgName) {
        this.agencyOrgName = agencyOrgName;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public void buildTableType() {
        if (getTableType().equals(DOC_FORM_TYPE))
            setTableType(DOC_FORM_VALE);
        else if (getTableType().equals(MANGER_FORM_TYPE))
            setTableType(MANGER_FORM_VALDE);
    }

    public void buildStatusCode() {
        if (getStatusCode().equals("ALIVE"))
            setStatusCode("啟用");
        if (getStatusCode().equals("SUSPEND"))
            setStatusCode("暫停");
        if (getStatusCode().equals("STOP"))
            setStatusCode("停用");
    }

    public void buildUpdateTime() {
        setUpdateTime(getUpdateTime().substring(0, 19));
    }
}
