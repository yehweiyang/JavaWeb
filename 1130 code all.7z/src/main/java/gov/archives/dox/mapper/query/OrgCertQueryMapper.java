package gov.archives.dox.mapper.query;

import java.util.List;
import java.util.Map;

import gov.archives.dox.domain.entity.OrgCertEntity;
import gov.archives.dox.domain.entity.OrgCertExpiredEntity;

public interface OrgCertQueryMapper {
    String KEY_VALID_END = "validEnd";

    OrgCertEntity findByOrgUnitId(Map<String, Object> queryMap);

    List<OrgCertExpiredEntity> findByValidEnd(Map<String, String> queryMap);
}
