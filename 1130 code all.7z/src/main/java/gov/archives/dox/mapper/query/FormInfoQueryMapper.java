package gov.archives.dox.mapper.query;

import java.util.List;
import java.util.Map;

import gov.archives.dox.domain.entity.FormEntity;

public interface FormInfoQueryMapper {
    List<FormEntity> findByMap(Map<String, Object> map);
}
