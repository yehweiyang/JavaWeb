package gov.archives.dox.service;

import java.util.List;
import java.util.Map;

import gov.archives.dox.domain.entity.OrgCertExpiredEntity;

public interface OrgCertService {
    String TITLE_NAME = "憑證即將過期清單";
    String TITLE_PARAMETER = "title";
    String YEAR_PARAMETER = "year";
    String MONTH_PARAMETER = "month";
    String DAY_PARAMETER = "day";

    List<OrgCertExpiredEntity> getCertExpired();
}
