package gov.archives.dox.service;


import java.util.List;
import java.util.Map;

import gov.archives.dox.domain.entity.FormEntity;

public interface FormInfoService {
    List<FormEntity> getByQueryMap(Map<String, Object> queryMap);
}
