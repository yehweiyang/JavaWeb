package gov.archives.dox.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.dox.conf.DoxConf;
import gov.archives.dox.domain.entity.FormEntity;
import gov.archives.dox.mapper.query.FormInfoQueryMapper;
import gov.archives.dox.service.FormInfoService;

@Service
@Transactional
public class FormInfoServiceImpl implements FormInfoService {

    @Autowired
    private FormInfoQueryMapper queryMapper;

    @Override
    @Transactional(value = DoxConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<FormEntity> getByQueryMap(Map<String, Object> queryMap) {
        List<FormEntity> entityList = queryMapper.findByMap(queryMap);
        for (FormEntity entity : entityList) {
            entity.buildTableType();
            entity.buildStatusCode();
            entity.buildUpdateTime();
        }

        return entityList;
    }
}
