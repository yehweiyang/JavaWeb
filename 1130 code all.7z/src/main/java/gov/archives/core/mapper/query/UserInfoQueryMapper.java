package gov.archives.core.mapper.query;

import java.util.List;
import java.util.Map;

import gov.archives.core.domain.entity.ModifyPersonDataEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.entity.UserRoleInfoEntity;

/**
 * UserInfoQueryMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/15.
 */
public interface UserInfoQueryMapper {
    UserInfoEntity findByAccount(String account);

    List<UserRoleInfoEntity> list();

    List<UserRoleInfoEntity> listByKeyWord(Map<String, Object> nameSearchMap);

    ModifyPersonDataEntity personDataByAccount(String personAccount);
}
