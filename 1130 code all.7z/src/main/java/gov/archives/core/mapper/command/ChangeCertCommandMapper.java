package gov.archives.core.mapper.command;

import gov.archives.core.domain.entity.ChangeCertEntity;

/**
 * ChangeCertCommandMapper
 * <p>
 * Created by WeiYang on 2016/10/17.
 */
public interface ChangeCertCommandMapper {

    void update(ChangeCertEntity changeCertEntity);

}
