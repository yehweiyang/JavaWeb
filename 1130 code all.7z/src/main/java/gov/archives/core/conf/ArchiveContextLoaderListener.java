package gov.archives.core.conf;

import javax.servlet.ServletContext;

import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;

/**
 * Created by kshsu on 2016/10/6.
 */
public class ArchiveContextLoaderListener extends ContextLoaderListener {

    @Override
    public WebApplicationContext initWebApplicationContext(ServletContext servletContext) {
        ArchivesInitializers.getSecKeyInitializer().init();
        ArchivesInitializers.getPropertyInitializer().init();
        return super.initWebApplicationContext(servletContext);
    }
}
