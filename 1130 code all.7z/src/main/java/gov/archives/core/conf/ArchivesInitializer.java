package gov.archives.core.conf;

/**
 * Created by kshsu on 2016/10/7.
 */
public interface ArchivesInitializer {
    void init();
}
