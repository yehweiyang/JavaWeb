package gov.archives.core.conf;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.util.ObjectUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.security.encrypt.Aes256Cipher;
import gov.archives.core.security.encrypt.CipherConf;
import gov.archives.core.security.encrypt.TripleDesCipher;
import gov.archives.core.util.EncryptUtils;

/**
 * Created by kshsu on 2016/9/30.
 */
public class ArchivesPropertyConfigurer extends PropertyPlaceholderConfigurer {

    private static final String PROPERTY_DB_COMMANDER = "db.g2b2c.commander";
    private static final String PROPERTY_DB_COMMANDER_PWD = "db.g2b2c.commanderPwd";
    private static final String PROPERTY_DB_QUERIER = "db.g2b2c.querier";
    private static final String PROPERTY_DB_QUERIER_PWD = "db.g2b2c.querierPwd";

    /**
     * properties need decrypt
     */
    private static final List<String> decryptItem;

    static {
        decryptItem = new ArrayList<>();
        decryptItem.add(PROPERTY_DB_COMMANDER);
        decryptItem.add(PROPERTY_DB_COMMANDER_PWD);
        decryptItem.add(PROPERTY_DB_QUERIER);
        decryptItem.add(PROPERTY_DB_QUERIER_PWD);
    }

    @Override
    protected void convertProperties(Properties props) {
        super.convertProperties(props);

        Enumeration propertyNames = props.propertyNames();

        while (propertyNames.hasMoreElements()) {
            String propertyName = (String) propertyNames.nextElement();
            String propertyValue = props.getProperty(propertyName);
            String convertedValue;

            if (decryptItem.contains(propertyName)) {
                try {
                    if (Aes256Cipher.ALIAS_NAME.equals(CipherConf.ENCRYPT_METHOD)) {
                        convertedValue = EncryptUtils.enCryptOrDeCrypt(propertyValue, CipherConf.Method.AES256,
                                CipherConf.Mode.DECRYPT);
                    } else if (TripleDesCipher.ALIAS_NAME.equals(CipherConf.ENCRYPT_METHOD)) {
                        convertedValue = EncryptUtils.enCryptOrDeCrypt(propertyValue, CipherConf.Method.TRIPLE_DES,
                                CipherConf.Mode.DECRYPT);
                    } else {
                        convertedValue = propertyValue;
                    }

                    if (!ObjectUtils.nullSafeEquals(propertyValue, convertedValue)) {
                        props.setProperty(propertyName, convertedValue);
                    }
                } catch (CoreException e) {
                    throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR, e);
                }
            }
        }
    }
}
