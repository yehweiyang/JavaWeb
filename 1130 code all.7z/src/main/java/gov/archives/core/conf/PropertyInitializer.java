package gov.archives.core.conf;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Properties;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;

import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.security.encrypt.Aes256Cipher;
import gov.archives.core.security.encrypt.CipherConf;
import gov.archives.core.security.encrypt.TripleDesCipher;
import gov.archives.core.util.EncryptUtils;
import gov.archives.core.util.LogUtils;

/**
 * Created by kshsu on 2016/10/7.
 */
public class PropertyInitializer implements ArchivesInitializer {

    private static final String ENCRYPT_CONFIG_FILE_NAME = "encryptUtils.properties";
    private static final String INIT_PROPERTIES_FILE_NAME = "init.properties";
    private static final String DS_CONFIG_FILE_NAME = "ds-development.properties";
    private static File INIT_PROPERTIES_FILE;
    private static File ENCRYPT_CONFIG_FILE;
    private static File DS_CONFIG_FILE;

    private static final String PROPERTY_INIT_COMMANDER = "init.commander";
    private static final String PROPERTY_INIT_COMMANDER_PWD = "init.commanderPwd";
    private static final String PROPERTY_INIT_QUERIER = "init.querier";
    private static final String PROPERTY_INIT_QUERIER_PWD = "init.querierPwd";

    private static final String PROPERTY_DB_COMMANDER = "db.g2b2c.commander";
    private static final String PROPERTY_DB_COMMANDER_PWD = "db.g2b2c.commanderPwd";
    private static final String PROPERTY_DB_QUERIER = "db.g2b2c.querier";
    private static final String PROPERTY_DB_QUERIER_PWD = "db.g2b2c.querierPwd";

    private String INIT_COMMANDER;
    private String INIT_COMMANDER_PWD;
    private String INIT_QUERIER;
    private String INIT_QUERIER_PWD;

    static {
        try {
            INIT_PROPERTIES_FILE =
                    Paths.get(IOUtils.loadResourceURLInClasspath(INIT_PROPERTIES_FILE_NAME).toURI()).toFile();

            ENCRYPT_CONFIG_FILE =
                    Paths.get(IOUtils.loadResourceURLInClasspath(ENCRYPT_CONFIG_FILE_NAME).toURI()).toFile();

            DS_CONFIG_FILE = Paths.get(IOUtils.loadResourceURLInClasspath(DS_CONFIG_FILE_NAME).toURI()).toFile();
        } catch (URISyntaxException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        }
    }

    @Override
    public void init() {
        Properties propInit;
        Properties propDs;
        try {
            propInit = new Properties();
            propDs = new Properties();

            propInit.load(IOUtils.loadResourceInClasspath(INIT_PROPERTIES_FILE_NAME));
            propDs.load(IOUtils.loadResourceInClasspath(DS_CONFIG_FILE_NAME));

            INIT_COMMANDER = propInit.getProperty(PROPERTY_INIT_COMMANDER, "");
            INIT_COMMANDER_PWD = propInit.getProperty(PROPERTY_INIT_COMMANDER_PWD, "");
            INIT_QUERIER = propInit.getProperty(PROPERTY_INIT_QUERIER, "");
            INIT_QUERIER_PWD = propInit.getProperty(PROPERTY_INIT_QUERIER_PWD, "");

            if (!checkStringsIsEmpty(INIT_COMMANDER, INIT_COMMANDER_PWD, INIT_QUERIER, INIT_QUERIER_PWD)) {
                if (CipherConf.ENCRYPT_METHOD.equals(Aes256Cipher.ALIAS_NAME)) {
                    dsPropertiesFileEncrypt(DS_CONFIG_FILE, propDs, CipherConf.Method.AES256);
                } else if (CipherConf.ENCRYPT_METHOD.equals(TripleDesCipher.ALIAS_NAME)) {
                    dsPropertiesFileEncrypt(DS_CONFIG_FILE, propDs, CipherConf.Method.TRIPLE_DES);
                }
                clearPropertiesFile(INIT_PROPERTIES_FILE, propInit);
            }
        } catch (IOException | CoreException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, e);
        }
    }

    private static void reloadPropertiesFile(File propertiesFile) {
        try {
            new PropertiesConfiguration(propertiesFile).setReloadingStrategy(new FileChangedReloadingStrategy());
        } catch (ConfigurationException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, e);
        }
    }

    private boolean checkStringsIsEmpty(String... strings) {

        for (String string : strings) {
            if (StringUtils.isEmpty(string)) { return true; }
        }
        return false;
    }

    private static void storePropertiesFile(File propertyFile, Properties properties) {
        OutputStream fos = null;

        try {
            createFile(propertyFile);
            fos = new FileOutputStream(propertyFile);
            properties.store(fos, propertyFile.getName());
            fos.flush();
        } catch (IOException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        } finally {
            if (null != fos) {
                try {
                    fos.close();
                } catch (IOException ex) {
                    LogUtils.logException(ex);
                }
            }
        }

        reloadPropertiesFile(propertyFile);
    }

    private void clearPropertiesFile(File propertyFile, Properties properties) throws CoreException {

        Collections.list(properties.propertyNames()).forEach(propertyObject -> {
            properties.setProperty(propertyObject.toString(), "");
        });

        storePropertiesFile(propertyFile, properties);

        reloadPropertiesFile(propertyFile);
    }

    private static boolean createFile(File file) {
        if (!IOUtils.isFileExist(file)) {
            try {
                return file.createNewFile();
            } catch (IOException ex) {
                throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR, ex);
            }
        }
        return false;
    }

    private void dsPropertiesFileEncrypt(File dsPropertiesFile, Properties properties,
            CipherConf.Method encryptMethod) {
        try {
            properties.setProperty(PROPERTY_DB_COMMANDER,
                    EncryptUtils.enCryptOrDeCrypt(INIT_COMMANDER, encryptMethod,
                            CipherConf.Mode.ENCRYPT));
            properties.setProperty(PROPERTY_DB_COMMANDER_PWD,
                    EncryptUtils.enCryptOrDeCrypt(INIT_COMMANDER_PWD, encryptMethod,
                            CipherConf.Mode.ENCRYPT));
            properties.setProperty(PROPERTY_DB_QUERIER,
                    EncryptUtils.enCryptOrDeCrypt(INIT_QUERIER, encryptMethod,
                            CipherConf.Mode.ENCRYPT));
            properties.setProperty(PROPERTY_DB_QUERIER_PWD,
                    EncryptUtils.enCryptOrDeCrypt(INIT_QUERIER_PWD, encryptMethod,
                            CipherConf.Mode.ENCRYPT));
            storePropertiesFile(dsPropertiesFile, properties);
        } catch (CoreException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, e);
        }
    }
}
