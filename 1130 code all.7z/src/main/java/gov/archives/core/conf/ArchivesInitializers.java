package gov.archives.core.conf;

/**
 * Created by kshsu on 2016/10/7.
 */
public class ArchivesInitializers {
    public static synchronized PropertyInitializer getPropertyInitializer() {
        return new PropertyInitializer();
    }

    public static synchronized SecKeyInitializer getSecKeyInitializer() {
        return new SecKeyInitializer();
    }
}
