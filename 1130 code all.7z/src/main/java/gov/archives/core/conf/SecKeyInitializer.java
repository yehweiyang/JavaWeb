package gov.archives.core.conf;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.apache.commons.lang3.RandomStringUtils;

import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.security.encrypt.CipherConf;
import gov.archives.core.util.EncryptUtils;
import gov.archives.core.util.LogUtils;

/**
 * Created by kshsu on 2016/10/7.
 */
public class SecKeyInitializer implements ArchivesInitializer {

    private static final String ENCRYPT_CONFIG_FILE_NAME = "encryptUtils.properties";
    private static File ENCRYPT_CONFIG_FILE;

    // sk split setting
    private static String SECRETKEY;

    private static final String SECRETKEY_SEGMENT;
    private static final String DEFAULT_SECRETKEY_SEGMENT = "1,5,7";

    private static String IV;
    private static String IV256;
    private static final String PROPERTY_SKSEG = "skseg";
    private static final String PROPERTY_IV256 = "iv256";
    private static final String PROPERTY_IV = "iv";
    private static final String PROPERTY_SECRETKEY_PART1 = "sk01";
    private static final String PROPERTY_SECRETKEY_PART2 = "sk02";
    private static final String PROPERTY_SECRETKEY_PART3 = "sk03";
    private static final String PROPERTY_SECRETKEY_PART4 = "sk04";
    private static final String PROPERTY_SECRETKEY_PART5 = "sk05";
    private static final String PROPERTY_SECRETKEY_PART6 = "sk06";
    private static final String PROPERTY_SECRETKEY_PART7 = "sk07";
    private static final String PROPERTY_SECRETKEY_PART8 = "sk08";
    private static final String PROPERTY_SECRETKEY_PART9 = "sk09";
    private static final String PROPERTY_SECRETKEY_PART10 = "sk10";
    private static final String[] PROPERTY_SECRETKEY_PART = new String[]{
            PROPERTY_SECRETKEY_PART1, PROPERTY_SECRETKEY_PART2, PROPERTY_SECRETKEY_PART3,
            PROPERTY_SECRETKEY_PART4, PROPERTY_SECRETKEY_PART5, PROPERTY_SECRETKEY_PART6,
            PROPERTY_SECRETKEY_PART7, PROPERTY_SECRETKEY_PART8, PROPERTY_SECRETKEY_PART9,
            PROPERTY_SECRETKEY_PART10
    };

    static {
        Properties propEn = new Properties();
        try {
            ENCRYPT_CONFIG_FILE =
                    Paths.get(IOUtils.loadResourceURLInClasspath(ENCRYPT_CONFIG_FILE_NAME).toURI()).toFile();
            propEn.load(
                    IOUtils.loadResourceInClasspath(ENCRYPT_CONFIG_FILE_NAME));
        } catch (IOException | URISyntaxException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        } finally {
            SECRETKEY_SEGMENT = propEn.getProperty(PROPERTY_SKSEG, DEFAULT_SECRETKEY_SEGMENT);
        }
    }

    private static final String PROPERTY_INIT_COMMANDER = "init.commander";
    private static final String PROPERTY_INIT_COMMANDER_PWD = "init.commanderPwd";
    private static final String PROPERTY_INIT_QUERIER = "init.querier";
    private static final String PROPERTY_INIT_QUERIER_PWD = "init.querierPwd";
    private static final String INIT_PROPERTIES_FILE_NAME = "init.properties";

    private static String INIT_COMMANDER;
    private static String INIT_COMMANDER_PWD;
    private static String INIT_QUERIER;
    private static String INIT_QUERIER_PWD;

    @Override
    public void init() {
        if(checkStartInit()){
            genRandomSeckey();
            genRandomIv();
        }
    }

    public static void genRandomSeckey() {
        Properties propEn = new Properties();
        // 拆解出來參數資料,size 為拆解段數
        List<String> sk_list;
        Map<Integer, String> sk_list_data = new HashMap<>();

        try {
            propEn.load(
                    IOUtils.loadResourceInClasspath(ENCRYPT_CONFIG_FILE_NAME));

            SECRETKEY = EncryptUtils.txtToBase64(RandomStringUtils.random(24, true, true));

            sk_list = Arrays.asList(SECRETKEY_SEGMENT.split(","));

            // 要添加的資料
            String appendData = getRandomBase64Text(SECRETKEY.length() % sk_list.size());

            // 若有設定加密
            if (!StringUtils.isEmpty(CipherConf.ENCRYPT_METHOD)) {
                for (Integer j = 0; j < sk_list.size(); j++) {
                    // 分段資料長度(實際SK) = sercrtkey長度 / 分幾段
                    int segmentSecretDataLength = SECRETKEY.length() / sk_list.size();
                    if (!StringUtils.isEmpty(sk_list.get(j))) {
                        if (j == 0) {
                            sk_list_data.put(Integer.valueOf(sk_list.get(j)),
                                    SECRETKEY.substring(j, segmentSecretDataLength) +
                                            (!j.equals(sk_list.size() - 1) ? appendData : ""));
                        } else if (j == (sk_list.size() - 1)) {
                            sk_list_data.put(Integer.valueOf(sk_list.get(j)),
                                    SECRETKEY.substring(j * segmentSecretDataLength, SECRETKEY.length()));
                        } else {
                            sk_list_data.put(Integer.valueOf(sk_list.get(j)),
                                    SECRETKEY
                                            .substring(j * segmentSecretDataLength, (j + 1) * segmentSecretDataLength) +
                                            (!j.equals(sk_list.size() - 1) ? appendData : ""));
                        }
                    } else {
                        throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR);
                    }
                }

                for (Integer i = 0; i < PROPERTY_SECRETKEY_PART.length; i++) {
                    // 分段資料長度(虛擬SK) = sercrtkey 長度 / 分幾段 + 添加資料長度
                    int segmentSecretDataLength = SECRETKEY.length() / sk_list.size() + appendData.length();

                    propEn.setProperty(PROPERTY_SECRETKEY_PART[i], getRandomBase64Text(segmentSecretDataLength));

                    for (Integer sk_list_data_key : sk_list_data.keySet()) {
                        if (sk_list_data_key.equals(i + 1) ) {
                            propEn.setProperty(PROPERTY_SECRETKEY_PART[i], sk_list_data.get(sk_list_data_key));
                        }
                    }
                }
                storePropertiesFile(ENCRYPT_CONFIG_FILE, propEn);
            }
        } catch (IOException | CoreException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        }
    }

    public static void genRandomIv() {
        Properties propEn = new Properties();

        try {
            propEn.load(
                    IOUtils.loadResourceInClasspath(ENCRYPT_CONFIG_FILE_NAME));

            // 若有設定加密
            if (!StringUtils.isEmpty(CipherConf.ENCRYPT_METHOD)) {
                IV = EncryptUtils.txtToBase64(RandomStringUtils.randomNumeric(8));
                IV256 = EncryptUtils.txtToBase64(RandomStringUtils.randomNumeric(16));
                propEn.setProperty(PROPERTY_IV, IV);
                propEn.setProperty(PROPERTY_IV256, IV256);

                storePropertiesFile(ENCRYPT_CONFIG_FILE, propEn);
            }
        } catch (IOException | CoreException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        }
    }

    private static String getRandomBase64Text(int size) throws CoreException {
        return EncryptUtils.txtToBase64(RandomStringUtils.random(24, true, true)).substring(0, size);
    }

    private static void reloadPropertiesFile(File propertiesFile) {
        getPropertiesConfiguration(propertiesFile).setReloadingStrategy(new FileChangedReloadingStrategy());
    }

    private static void storePropertiesFile(File propertyFile, Properties properties) {
        OutputStream fos = null;

        try {
            createFile(propertyFile);
            fos = new FileOutputStream(propertyFile);
            properties.store(fos, propertyFile.getName());
            fos.flush();
        } catch (IOException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        } finally {
            if (null != fos) {
                try {
                    fos.close();
                } catch (IOException ex) {
                    LogUtils.logException(ex);
                }
            }
        }

        reloadPropertiesFile(propertyFile);
    }

    private static void createFile(File file) {
        if (!IOUtils.isFileExist(file)) {
            try {
                file.createNewFile();
            } catch (IOException ex) {
                throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR, ex);
            }
        }
    }

    public static String getRandomSecKey() {
        Properties propEn = new Properties();
        List<String> sk_list;
        Map<Integer, String> sk_list_data = new HashMap<>();
        String rtnSecKey = "";
        try {
            if (!StringUtils.isEmpty(CipherConf.ENCRYPT_METHOD)) {
                propEn.load(
                        IOUtils.loadResourceInClasspath(ENCRYPT_CONFIG_FILE_NAME));

                SECRETKEY = EncryptUtils.txtToBase64(RandomStringUtils.random(24, true, true));

                sk_list = Arrays.asList(SECRETKEY_SEGMENT.split(","));

                // 要添加的資料
                String appendData = getRandomBase64Text(SECRETKEY.length() % sk_list.size());

                for (Integer j = 0; j < sk_list.size(); j++) {
                    sk_list_data
                            .put(j, propEn.getProperty(PROPERTY_SECRETKEY_PART[Integer.parseInt(sk_list.get(j)) - 1]));
                }

                for (Integer i = 0; i < sk_list_data.size(); i++) {
                    if (i.equals(sk_list_data.size() - 1)) {
                        rtnSecKey += sk_list_data.get(i);
                    } else {
                        rtnSecKey +=
                                sk_list_data.get(i).substring(0, sk_list_data.get(i).length() - appendData.length());
                    }
                }
            } else {
                rtnSecKey = CipherConf.SECRET_KEY;
            }
        } catch (IOException | CoreException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        }
        return rtnSecKey;
    }

    public static String getRandomIv(CipherConf.Method method) {
        Properties propEn = new Properties();
        try {
            propEn.load(
                    IOUtils.loadResourceInClasspath(ENCRYPT_CONFIG_FILE_NAME));

            if (method.equals(CipherConf.Method.TRIPLE_DES)) {
                return propEn.getProperty(PROPERTY_IV);
            } else if (method.equals(CipherConf.Method.AES256)) {
                return propEn.getProperty(PROPERTY_IV256);
            }
        } catch (IOException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        }
        return "";
    }

    protected static PropertiesConfiguration getPropertiesConfiguration(Object propertiesObj) {
        PreconditionUtils.checkArguments(propertiesObj);
        try {
            if (propertiesObj instanceof File) {
                return new PropertiesConfiguration((File) propertiesObj);
            } else if (propertiesObj instanceof String) {
                return new PropertiesConfiguration((String) propertiesObj);
            } else if (propertiesObj instanceof URL) {
                return new PropertiesConfiguration((URL) propertiesObj);
            } else {
                return new PropertiesConfiguration();
            }
        } catch (ConfigurationException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        }
    }

    private static boolean checkStartInit() {
        Properties propInit;
        try {
            propInit = new Properties();

            propInit.load(IOUtils.loadResourceInClasspath(INIT_PROPERTIES_FILE_NAME));

            INIT_COMMANDER = propInit.getProperty(PROPERTY_INIT_COMMANDER, "");
            INIT_COMMANDER_PWD = propInit.getProperty(PROPERTY_INIT_COMMANDER_PWD, "");
            INIT_QUERIER = propInit.getProperty(PROPERTY_INIT_QUERIER, "");
            INIT_QUERIER_PWD = propInit.getProperty(PROPERTY_INIT_QUERIER_PWD, "");

            if (!checkStringsIsEmpty(INIT_COMMANDER, INIT_COMMANDER_PWD, INIT_QUERIER, INIT_QUERIER_PWD)) {
                return true;
            }
        } catch (IOException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, e);
        }

        return false;
    }

    private static boolean checkStringsIsEmpty(String... strings) {

        for (String string : strings) {
            if (StringUtils.isEmpty(string)) { return true; }
        }
        return false;
    }
}
