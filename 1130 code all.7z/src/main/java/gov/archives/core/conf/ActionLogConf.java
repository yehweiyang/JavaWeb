package gov.archives.core.conf;


/**
 * Created by wtjiang on 2016/10/13.
 */
public class ActionLogConf {
    public static final String SUCCESS_CODE = "0000";
    public static final String SUCCESS_MSG = "成功";
    public static final String FAIL_MSG = "失敗";
    public static final String EVENT_LEVEL_HIGH = "高";
    public static final String EVENT_LEVEL_MEDIUM = "中";
    public static final String EVENT_LEVEL_LOW = "低";
    public static final String HIPKI_AUTH_LOGIN = "自然人憑證簽章驗證登入模組";
    public static final String REGISTER_ACCOUNT = "帳號申請模組";
    public static final String ACCOUNT_LOGOUT = "帳號登出模組";
    public static final String SEARCH_INSIDE_CHANGE = "內部傳送查詢模組";
    public static final String SEARCH_OUTSIDE_CHANGE = "外部傳送查詢模組";
    public static final String SEARCH_ORGAN_SEND = "機關傳送查詢模組";
    public static final String SEARCH_ORGAN_RECEIVE = "機關接收查詢模組";
    public static final String SEARCH_EXCHANGE_ABNORMAL = "交換異常查詢模組";
    public static final String SEARCH_TEMP_EXCHANGE_ABNORMAL = "交換異常查詢暫存檔模組";
    public static final String ADD_TEMP_EXCHANGE_ABNORMAL = "交換異常查詢新增暫存檔模組";
    public static final String SEARCH_XML_EXCHANGE_ABNORMAL = "交換異常查詢查詢XML檔模組";
    public static final String SEARCH_AGENCY_CERTHASH = "用戶端紀錄檔查詢certHASH模組";
    public static final String SEARCH_AGENCY_FILE = "用戶端紀錄檔查詢檔案模組";
    public static final String DOWNLOAD_AGENCY_FILE = "用戶端紀錄檔下載certHASH模組";
    public static final String ADD_DOCUMENT_UNIT = "可轉文單位設定新增單位模組";
    public static final String SEARCH_DOCUMENT_UNIT = "可轉文單位設定查詢單位模組";
    public static final String DELETE_DOCUMENT_UNIT = "可轉文單位設定刪除單位模組";
    public static final String UPDATE_DOCUMENT_UNIT = "可轉文單位設定修改單位模組";
    public static final String SEARCH_RECEIVER_DOCUMENT_UNIT = "可被轉文單位設定查詢單位模組";
    public static final String ADD_RECEIVER_DOCUMENT_UNIT = "可被轉文單位設定新增單位模組";
    public static final String UPDATE_RECEIVER_DOCUMENT_UNIT = "可被轉文單位設定修改單位模組";
    public static final String DELETE_RECEIVER_DOCUMENT_UNIT = "可被轉文單位設定刪除單位模組";
    public static final String SEARCH_DOCUMENT_STATUS_UNIT = "轉文簽收查詢查詢模組";
    public static final String SEARCH_HISTORY_DOCUMENT_STATUS_UNIT = "轉文簽收查詢查詢歷史流程模組";
    public static final String SEARCH_ADRESS = "地址簿查詢查詢模組";
    public static final String SEARCH_ADRESS_DETAIL = "地址簿查詢檢視明細模組";
    public static final String SEARCH_NUMBER = "代字號查詢查詢模組";
    public static final String SEARCH_FORM_REGISTER = "表單註冊查詢查詢模組";
    public static final String SEARCH_CERTIFICATEEXPIRED = "憑證即將過期查詢模組";
    public static final String DOWNLOAD_CERTIFICATEEXPIRED = "憑證即將過期下載模組";
    public static final String SEARCH_PERSON_DATA = "修改個人資料查詢模組";
    public static final String UPDATE_PERSON_DATA = "修改個人資料修改模組";
    public static final String SEARCH_ACCOUNT_KEYWORD = "使用者管理查詢帳號模組";
    public static final String SEARCH_ACCOUNT_VERFICATION_LIST = "使用者管理查詢帳號清單模組";
    public static final String UPDATE_ACCOUNT_DATA = "使用者管理修改帳號模組";
    public static final String UPDATE_MENU_CONFIG = "權限管理權限類型修改模組";
    public static final String UPDATE_ROLE = "權限管理修改權限模組";
    public static final String ADD_ROLE = "權限管理新增權限模組";
    public static final String SEARCH_ROLE = "權限管理查詢權限模組";
    public static final String UPDATE_EDITANNOUNCEMENT = "編輯系統公告修改模組";
    public static final String SEARCH_EDITANNOUNCEMENT = "編輯系統公告查詢模組";
    public static final String ADD_DOCUMENT_NOTICE_MAIL = "收文通知資訊查詢新增模組";
    public static final String DELETE_DOCUMENT_NOTICE_MAIL = "收文通知資訊查詢刪除模組";
    public static final String SEARCH_DOCUMENT_NOTICE_MAIL = "收文通知資訊查詢模組";
    public static final String UPDATE_DOCUMENT_NOTICE_MAIL = "收文通知資訊修改模組";
    public static final String SEARCH_LOGIN_HISTORY = "登入歷程查詢查詢模組";
    public static final String SEARCH_GATEWAYLOG_HISTORY = "閘道收發文記錄查詢模組";
    public static final String UPDATE_SMTP_CONFIG= "SMTP設定修改模組";
    public static final String SEARCH_SMTP_CONFIG= "SMTP設定查詢模組";
    public static final String UPDATE_REDUNTDENT_SWITCH = "備援中心設定修改模組";
    public static final String SEARCH_REDUNTDENT_SWITCH = "備援中心設定查詢初始化模組";
    public static final String ACTION_REPORT_SCHEDULE = "月報表產出執行模組";
    public static final String SEARCH_REPORT_SCHEDULE = "月報表產出查詢模組";
    public static final String SEARCH_REPORT_SEND_RANK = "中心交換量排行查詢模組";
    public static final String SEARCH_REPORT_ERR_RANK = "中心異常排行查詢模組";
    public static final String SEARCH_REPORT_RS_STATE = "收發文狀態統計查詢模組";
    public static final String SEARCH_REPORT_SEND_ERR = "交換異常統計查詢模組";
    public static final String SEARCH_REPORT_SEND_STATE = "發文統計查詢模組";
    public static final String SEARCH_REPORT_SEND_LIST = "發文清單查詢模組";
    public static final String SEARCH_REPORT_SEND_UNCONFM = "發文待確認查詢模組";
    public static final String SEARCH_REPORT_SEND_ERR_LIST = "發文異常清單查詢模組";
    public static final String SEARCH_REPORT_RECV_STATE = "收文統計查詢模組";
    public static final String SEARCH_REPORT_RECV_LIST = "收文清單查詢模組";
    public static final String SEARCH_REPORT_RECV_ERR_LIST = "收文異常清單查詢模組";
    public static final String SEARCH_REPORT_CONFIRMED_DATA = "確認率查詢查詢模組";
    public static final String SEARCH_REPORT_ODF_SEND_RATE = "ODF統計查詢模組";
    public static final String DOWNLOAD_REPORT = "報表下載模組";
    public static final String DOWNLOAD_REPORT_MONTH = "月報表下載模組";
    public static final String INIT_REPORT = "初始化模組";
    public static final String SEARCH_REPORT_MONTH = "月報表查詢模組";


}
