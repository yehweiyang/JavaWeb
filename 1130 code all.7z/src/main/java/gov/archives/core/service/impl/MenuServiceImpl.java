package gov.archives.core.service.impl;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.vo.TopMenuVo;
import gov.archives.core.mapper.command.MenuCommandMapper;
import gov.archives.core.mapper.query.MenuQueryMapper;
import gov.archives.core.service.MenuService;

/**
 * MenuServiceImpl <br> (尚未描述類別目的與用途) <br> gemhuang, 2016/7/18.
 */
@Service
@Transactional
public class MenuServiceImpl implements MenuService {

    @Autowired
    private MenuQueryMapper queryMapper;

    @Autowired
    private MenuCommandMapper commandMapper;

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public MenuEntity getByMenuCode(String menuCode) {
        PreconditionUtils.checkArguments(menuCode);

        return queryMapper.findByMenuCode(menuCode);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public MenuEntity getBySysId(UUID sysId) {
        PreconditionUtils.checkArguments(sysId);

        return queryMapper.findBySysId(sysId);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<MenuEntity> getAllMenu() {
        return queryMapper.findAllMenu();
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void insert(MenuEntity menu) {
        PreconditionUtils.checkArguments(menu);

        commandMapper.save(menu);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void update(MenuEntity menu) {
        PreconditionUtils.checkArguments(menu);

        commandMapper.update(menu);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void delete(MenuEntity menu) {
        PreconditionUtils.checkArguments(menu);

        commandMapper.remove(menu);
    }

    @Override
    public Map<Integer, TopMenuVo> getMenuTree() {
        return getMenuTree(getAllMenu());
    }

    @Override
    public Map<Integer, TopMenuVo> getMenuTree(List<MenuEntity> menuEntities) {

        List<MenuEntity> allMenu = getAllMenu();

        if (CollectionUtils.isEmpty(menuEntities) || CollectionUtils.isEmpty(allMenu)) {
            return new HashMap();
        }

        Map<Integer, TopMenuVo> resultMenu = new LinkedHashMap();

        List<MenuEntity> topMenus = allMenu.stream()
                                           .filter(menu -> menu.getTopMenuId().equals(CoreConf.DEFAULT_ID))
                                           .collect(Collectors.toList());

        topMenus.stream()
                .forEach(top -> {
                    Map<Integer, MenuEntity> subMenu = menuEntities.stream()
                                                                   .filter(sub -> sub.getTopMenuId()
                                                                                     .equals(top.getSysId()))
                                                                   .collect(Collectors.toMap(MenuEntity::getMenuSeq,
                                                                           Function.identity()));
                    if (!MapUtils.isEmpty(subMenu)) {
                        resultMenu.put(top.getMenuSeq(),
                                TopMenuVo.Builder.create()
                                                 .setMenuCode(top.getMenuCode())
                                                 .setMenuName(top.getMenuName())
                                                 .setSubMenus(subMenu)
                                                 .build());
                    }
                });

        return resultMenu;
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public Map<String, String> getMenuUrlMap() {
        Map<String, String> menuUrlMap = new HashMap<>();
        List<MenuEntity> menuEntityList = getAllMenu();
        for (MenuEntity subMenu : menuEntityList) {
            MenuEntity topMenu = getBySysId(subMenu.getTopMenuId());
            if (null != topMenu) {
                menuUrlMap.put(toLowerCamelCase(subMenu.getMenuCode()),
                        new StringBuilder().append("/").append(toLowerCamelCase(topMenu.getMenuCode())).append("/")
                                           .append(toLowerCamelCase(subMenu.getMenuCode())).toString());
            }
        }
        return menuUrlMap;
    }

    private String toLowerCamelCase(String menuCode) {
        return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
    }
}
