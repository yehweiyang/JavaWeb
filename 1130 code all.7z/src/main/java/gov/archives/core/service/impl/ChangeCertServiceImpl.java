package gov.archives.core.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ChangeCertEntity;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.mapper.command.ChangeCertCommandMapper;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ChangeCertService;

/**
 * ChangeCertServiceImpl
 * <p>
 * Created by WeiYang on 2016/10/17.
 */
@Service
public class ChangeCertServiceImpl implements ChangeCertService {

    @Autowired
    private ChangeCertCommandMapper certCommandMapper;

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void update(ChangeCertEntity changeCertEntity) {
        try {
            PreconditionUtils.checkArguments(changeCertEntity);
            certCommandMapper.update(changeCertEntity);
        } catch (ApplicationException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.CARD_NOT_AVAILABLE, ex);
        }
    }
}
