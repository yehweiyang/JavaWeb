package gov.archives.core.service;

import java.io.File;
import java.util.UUID;

import org.springframework.security.core.AuthenticationException;

import gov.archives.core.domain.vo.SignCertData;
import gov.archives.core.domain.vo.VerifyResult;

public interface SmartCardIdentityService {

	void smartCarVerifyHandler(SignCertData signCert, File file, String signCertHash, UUID uuid, long lastAccessedTime);

	String saveRequestCertificate(String base64Cert, File file, String certCardNum, long lastAccessedTime);

	void checkSignCert(File file, long lastAccessedTime);

	void checkDigitalSignatureCert(String certB64);

	VerifyResult userIdentityException(AuthenticationException e);

	void cleanSignCertFile(File certFile);
}
