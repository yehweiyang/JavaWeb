package gov.archives.core.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gov.archives.core.domain.entity.ModifyPersonDataEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.controller.RoleController;
import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.entity.UserRoleInfoEntity;
import gov.archives.core.domain.vo.UserInfo;

import gov.archives.core.mapper.command.UserInfoCommandMapper;
import gov.archives.core.mapper.query.RoleQueryMapper;
import gov.archives.core.mapper.query.UserInfoQueryMapper;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.BeanUtils;

/**
 * UserInfoServiceImpl <br> (尚未描述類別目的與用途) <br> gemhuang, 2016/7/15.
 */
@Service
@Transactional
public class UserInfoServiceImpl implements UserInfoService {
    private static final Logger log = LoggerFactory.getLogger(UserInfoServiceImpl.class);

    @Autowired
    private UserInfoCommandMapper commandMapper;

    @Autowired
    private UserInfoQueryMapper queryMapper;

    @Autowired
    private RoleQueryMapper roleQueryMapper;

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public UserInfoEntity getByAccount(String account) {
        PreconditionUtils.checkArguments(account);
        return queryMapper.findByAccount(account);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void insert(UserInfoEntity user) {
        PreconditionUtils.checkArguments(user);
        commandMapper.save(user);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void update(UserInfoEntity user) {
        PreconditionUtils.checkArguments(user);
        commandMapper.update(user);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void delete(UserInfoEntity user) {
        PreconditionUtils.checkArguments(user);
        commandMapper.remove(user);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void updateUserByRoleName(UserInfoEntity user, String roleName) {
        PreconditionUtils.checkArguments(user, roleName);
        Map<String, Object> params = new HashMap<>();
        params.put(UserInfoCommandMapper.KEY_USER_ACCOUNT, user.getAccount());
        params.put(UserInfoCommandMapper.KEY_SYS_ID, user.getSysId());
        params.put(UserInfoCommandMapper.KEY_ROLE_NAME, roleName);
        params.put(UserInfoCommandMapper.KEY_MODIFIER_ACCOUNT, user.getModifierAccount());
        params.put(UserInfoCommandMapper.KEY_MODIFIED_TIME, user.getModifiedTime());
        commandMapper.updateUserByRoleName(params);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<UserInfo> list() throws ApplicationException {
        return compositionAccountList(queryMapper.list());
    }

    @Override
    public List<UserInfo> listByKeyWord(Map<String, Object> nameSearchMap) {
        return compositionAccountList(queryMapper.listByKeyWord(nameSearchMap));
    }

    @Override
    public ModifyPersonDataEntity getAccountInfo(String personAccount) {
        PreconditionUtils.checkArguments(personAccount);

        return  queryMapper.personDataByAccount(personAccount);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void updateUserByAccount(UserInfo userInfo) throws ApplicationException {
        String account = getCurrentAccount();
        UserInfoEntity userInfoEntity = new UserInfoEntity();
        userInfo.rebuildPhoneNumbers();
        BeanUtils.copyProperties(userInfoEntity, userInfo);
        String roleName = userInfo.getRoleName();
        if (StringUtils.isEmpty(roleName)) {
            userInfoEntity.setRoleSysId(CoreConf.DEFAULT_ID);
        } else {
            RoleEntity roleEntity = roleQueryMapper.findByRoleName(userInfo.getRoleName());
            userInfoEntity.setRoleSysId(roleEntity.getSysId());
        }
        userInfoEntity.initUpdate(account);

        commandMapper.updateUserByAccount(userInfoEntity);
    }

    @Override
    public String getCurrentAccount() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (null != authentication && authentication instanceof UsernamePasswordAuthenticationToken) {
            return authentication.getName();
        }
        return "unknown";
    }

    private List<UserInfo> compositionAccountList(List<UserRoleInfoEntity> userRoleInfoEntitiesList){
        if (null == userRoleInfoEntitiesList || userRoleInfoEntitiesList.isEmpty()) {
            return new ArrayList<>();
        }
        List<UserInfo> userInfoList = new ArrayList<>();
        for (UserInfoEntity userInfoEntity : userRoleInfoEntitiesList) {
            UserInfo userInfo = new UserInfo();
            BeanUtils.copyProperties(userInfo, userInfoEntity);
            userInfoList.add(userInfo);
        }
        return userInfoList;
    }
}
