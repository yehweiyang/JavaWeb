package gov.archives.core.service.impl;

import java.util.SortedMap;
import java.util.TreeMap;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Service;

import gov.archives.core.domain.vo.AccountDetail;
import gov.archives.core.security.CaptchaPKIAuthenticationToken;
import gov.archives.core.service.SessionManageService;

/**
 * Created by yflin on 9/21/16.
 */
@Service
public class SessionManageServiceImpl implements SessionManageService {
    private SortedMap<String, AccountDetail> treeMap = new TreeMap<>();
    private AccountDetail accountDetail;

    @Override
    public synchronized void setAccountDetail(AccountDetail detail) {
        accountDetail = detail;
    }

    @Override
    public synchronized AccountDetail getAccountDetail() {
        if (null != accountDetail) {
            String account = accountDetail.getAccount();
            if (null != account) { treeMap.put(accountDetail.getAccount(), accountDetail); }
        }
        return accountDetail;
    }

    @Override
    public Boolean checkAccountSessionId() {
        Authentication auth = SecurityContextHolder.getContext()
                                                   .getAuthentication();
        String account = auth.getName();
        if (checkSessionId(account, (WebAuthenticationDetails) auth.getDetails())) {
            return true;
        }
        return false;
    }

    @Override
    public int removeCurrentAccount(Authentication auth) {
        String account;
        if (null != auth && auth instanceof CaptchaPKIAuthenticationToken) {
            CaptchaPKIAuthenticationToken token = (CaptchaPKIAuthenticationToken) auth;
            account = token.getUser().getAccount();
        } else {
            account = auth.getName();
        }
        if (checkSessionId(account, (WebAuthenticationDetails) auth.getDetails())) {
            treeMap.remove(account);
        }
        return treeMap.size();
    }

    private synchronized Boolean checkSessionId(String account, WebAuthenticationDetails authDetails) {
        AccountDetail details = treeMap.get(account);
        if (null != details) {
            return details.getSessionId().equals(authDetails.getSessionId());
        }
        return false;
    }
}

