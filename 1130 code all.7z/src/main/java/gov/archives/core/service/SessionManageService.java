package gov.archives.core.service;

import org.springframework.security.core.Authentication;

import gov.archives.core.domain.vo.AccountDetail;

/**
 * Created by yflin on 9/21/16.
 */
public interface SessionManageService {
    void setAccountDetail(AccountDetail detail);

    AccountDetail getAccountDetail();

    Boolean checkAccountSessionId();

    int removeCurrentAccount(Authentication auth);
}
