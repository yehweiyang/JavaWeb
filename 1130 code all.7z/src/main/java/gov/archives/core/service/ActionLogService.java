package gov.archives.core.service;

import gov.archives.core.domain.entity.ActionLogEntity;

import javax.servlet.http.HttpServletRequest;

/**
 * ActionLogService
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
public interface ActionLogService {

    void insertsAndRsysLog(ActionLogEntity actionLog);

    void insert(ActionLogEntity actionLog);

    void delete(ActionLogEntity actionLog);

    void logEvent(ActionLogEntity actionLog);

}
