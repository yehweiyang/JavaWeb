package gov.archives.core.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.archives.core.domain.entity.RoleMenuMappingEntity;
import gov.archives.core.mapper.query.RoleMenuMappingQueryMapper;
import gov.archives.core.service.RoleMenuService;

/**
 * Created by Otaku Lee on 2016/9/10.
 */
@Service
public class RoleMenuServiceImpl implements RoleMenuService {

    @Autowired
    private RoleMenuMappingQueryMapper roleMenuMappingQueryMapper;

    @Override
    public List<RoleMenuMappingEntity> getRoleMenuMappingListByRoleName(String roleName) {
        return roleMenuMappingQueryMapper.findByRoleName(roleName);
    }

    @Override
    public List<RoleMenuMappingEntity> getRoleMenuMappingListByRoleSysId(UUID roleSysId) {
        return roleMenuMappingQueryMapper.findByRoleSysId(roleSysId);
    }
}
