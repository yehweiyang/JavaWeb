package gov.archives.core.service;

import gov.archives.core.domain.entity.RoleMenuMappingEntity;

import java.util.List;
import java.util.UUID;

/**
 * Created by wtjiang on 2016/9/10.
 */
public interface RoleMenuService {

    List<RoleMenuMappingEntity> getRoleMenuMappingListByRoleName(String roleName);

    List<RoleMenuMappingEntity> getRoleMenuMappingListByRoleSysId(UUID roleSysId);
}
