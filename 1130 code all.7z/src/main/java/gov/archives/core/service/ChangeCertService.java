package gov.archives.core.service;

import gov.archives.core.domain.entity.ChangeCertEntity;

/**
 * ChangeCertService
 * <p>
 * Created by WeiYang on 2016/10/17.
 */
public interface ChangeCertService {

    void update(ChangeCertEntity changeCertEntity);

}
