package gov.archives.core.message;

/**
 * Created by 140631 on 2016/7/26.
 */
public class CoreErrorCode {
    public static final String SYSTEM_ERROR = "SYS0000";
    public static final String UNAUTHORIZED = "SYS0001";
    public static final String FILE_SAVE_FAIL = "SYS0003";
    public static final String ENCRYPT_OR_DECRYPT_ERROR = "SYS004";
    public static final String PROPERTY_SETTING_ERROR = "SYS005";
    public static final String FILE_SAVE_ERROR = "SYS0006";
    public static final String SEARCH_ERROR = "SYS0007";
    public static final String UPDATE_ERROR = "SYS0008";
    public static final String DOWNLOAD_ERROR = "SYS0009";
    public static final String DELETE_ERROR = "SYS0010";
    public static final String ADD_ERROR = "SYS0011";
    public static final String HIPKI_ERROR = "SYS0012";
    public static final String DATA_NOT_FOUND = "AP0000";
    public static final String CAPTCHA_ERROR = "AP0001";
    public static final String ACCOUNT_ERROR = "AP0002";
    public static final String PIN_ERROR = "AP0003";
    public static final String CARD_EXPIRED = "AP0004";
    public static final String CARD_NOT_AVAILABLE = "AP0005";
    public static final String SIGNATURE_ERROR = "AP0006";
    public static final String CARD_NOT_MATCH_DATA = "AP0007";
    public static final String LOGIN_EXPIRED = "AP0008";
    public static final String CARD_INCORRECT = "AP0011";
    public static final String DUPLICATE_ACCOUNT = "AP0012";
    public static final String ACCOUNT_PROCESSING = "AP0013";
    public static final String ACCOUNT_SUSPENDED = "AP0014";
    public static final String PROCESS_CAPTCHA_ERROR = "AP0015";
    public static final String AUTHORITY_ROLE_ERROR = "AP0016";
    public static final String REGISTER_ACCOUNT_ERROR = "AP0017";
    public static final String LOGOUT_ACCOUNT_ERROR = "AP0018";
    public static final String PHONE_TYPE_INCORRECT = "ED0001";
    public static final String PHONE_FORMAT_INCORRECT = "ED0002";
    public static final String EMAIL_FORMAT_INCORRECT = "ED0003";
    public static final String USER_ACCOUNT_FORMAT_INCORRECT = "ED0017";
    public static final String USER_NAME_FORMAT_INCORRECT = "ED0018";
    public static final String ROLE_VALUE_INCORRECT = "ED9000";
    public static final String ORG_INFO_FORMAT_INCORRECT = "ED9001";

    public static final String ROLE_VALUE_SEARCH = "RO0001";
    public static final String ROLE_VALUE_ADD = "RO0002";
    public static final String ROLE_VALUE_UPDATE = "RO0003";
    public static final String ROLE_VALUE_MENUMODIFY = "RO0004";

    public static final String REPORT_INIT_ERROR = "PR0001";
    public static final String REPORT_QUERY_ERROR = "PR0002";
    public static final String REPORT_DOWNLOAD_ERROR = "PR0003";
    public static final String REPORT_BACKGROUND_ERROR = "PR0004";

    public static final String REPORT_EXCEPTION_UNKNOWN = "PR9001";
    public static final String REPORT_EXCEPTION_TEST = "PR9002";
    public static final String REPORT_EXCEPTION_IN_UTILS = "PR9003";
    public static final String REPORT_EXCEPTION_IN_BASECOMMAND = "PR9004";
    public static final String REPORT_EXCEPTION_IN_COMMAND_PROCESSOR = "PR9005";
    public static final String REPORT_EXCEPTION_IN_COMMAND_SERVICE = "PR9006";
    public static final String REPORT_EXCEPTION_IN_DATA_GEN_SERVICE = "PR9007";
    public static final String REPORT_EXCEPTION_IN_DATA_PREPARE_SERVICE = "PR9008";
    public static final String REPORT_EXCEPTION_IN_OUTPUT_FACADE = "PR9009";
    public static final String REPORT_EXCEPTION_IN_NOT_LOGIN = "PR9010";
    public static final String REPORT_EXCEPTION_IN_INIT_FOLDER = "PR9011";

    public static final String ORG_ID_INCORRECT = "CEX0001";
    public static final String LOG_FILE_INEXISTENCE = "CEX0002";
    public static final String LOG_FILE_ERROR = "CEX0003";
    public static final String FILE_NOT_EXIST = "CEX0004";

    public static final String SEARCH_MENU_ERROR = "MENU001";

    public static final String SEARCH_SMTP_ERROR = "SMTP001";
    public static final String UPDATE_SMTP_ERROR = "SMTP002";


    public static final String DOC_NOTICE_MAIL_READ_ERROR = "DNM0001";
    public static final String DOC_NOTICE_MAIL_CREATE_ERROR = "DNM0002";
    public static final String DOC_NOTICE_MAIL_UPDATE_ERROR = "DNM0003";
    public static final String DOC_NOTICE_MAIL_DELETE_ERROR = "DNM0004";

    public static final String REDUNDANT_SWITCH_INIT_ERROR = "RED001";
    public static final String REDUNDANT_SWITCH_UPDATE_ERROR = "RED002";

    public static final String REQUEST_MATCHER_NULL_ERROR = "SEC001";

    public static final String AP0000_DATA_NOT_FOUND = "AP0000";
    public static final String ED0006_AGENCY_ID_FORMAT_INCORRECT = "ED0006";
    public static final String ED0007_AGENCY_ID_LENGTH_INCORRECT = "ED0007";
    public static final String ED0008_UNIT_ID_FORMAT_INCORRECT = "ED0008";
    public static final String ED0009_AUTH_AGENCY_ID_FORMAT_INCORRECT = "ED0009";
    public static final String ED0010_AGENCY_ID_FORMAT_INCORRECT = "ED0010";
    public static final String ED0011_SUBROGATE_ID_FORMAT_INCORRECT = "ED0011";
    public static final String ED0013_CENTER_ID_FORMAT_INCORRECT = "ED0013";
    public static final String ED0014_AGENCY_NAME_FORMAT_INCORRECT = "ED0014";
    public static final String ED0015_DOC_ID_FORMAT_INCORRECT = "ED0015";
    public static final String ED0016_EXCHANGE_ID_FORMAT_INCORRECT = "ED0016";
    public static final String ED0017_EFFECT_DATE_FORMAT_INCORRECT = "ED0017";
    public static final String ED0018_EXPIRED_DATE_FORMAT_INCORRECT = "ED0018";
    public static final String ED0019_OUTPUT_FILE_FORMAT_INCORRECT = "ED0019";
    public static final String ED0020_FORM_ID_FORMAT_INCORRECT = "ED0020";
    public static final String ED0021_FORM_NAME_FORMAT_INCORRECT = "ED0021";
    public static final String ED0022_AGENCY_ID_UNIT_FORMAT_INCORRECT = "ED0022";
    public static final String ED0023_CENTER_INDEX_INCORRECT = "ED0023";
    public static final String ED0024_STATUS_INDEX_INCORRECT = "ED0024";
    public static final String ED0025_FORM_STATUS_INDEX_INCORRECT = "ED0025";
    public static final String ED0026_FORM_TYPE_INDEX_INCORRECT = "ED0026";
    public static final String ED0027_MAIN_FILE_TYPE_INDEX_INCORRECT = "ED0027";
    public static final String ED0028_VIEW_FILE_TYPE_INDEX_INCORRECT = "ED0028";
    public static final String ED0029_DOWNLOAD_IO_EXCEPTION = "ED0029";
    public static final String ED0030_QUERY_DATA_EMPTY = "ED0030";
}
