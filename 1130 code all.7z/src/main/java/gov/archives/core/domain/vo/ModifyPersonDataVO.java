package gov.archives.core.domain.vo;


/**
 * Created by pywang on 2016/7/27.
 */
public class ModifyPersonDataVO {
    private String userAccount;
    private String accountName;

    private String phoneAreaCode;
    private String phoneLocalNumber;
    private String phoneExtNumber;

    private String mobileAreaCode;
    private String mobileLocalNumber;

    private String email;
    private String orgName;

    private String accountLoginNum;
    private String accountLoginIP;
    private String accountLastTime;


    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getPhoneAreaCode() {
        return phoneAreaCode;
    }

    public void setPhoneAreaCode(String phoneAreaCode) {
        this.phoneAreaCode = phoneAreaCode;
    }

    public String getPhoneLocalNumber() {
        return phoneLocalNumber;
    }

    public void setPhoneLocalNumber(String phoneLocalNumber) {
        this.phoneLocalNumber = phoneLocalNumber;
    }

    public String getPhoneExtNumber() {
        return phoneExtNumber;
    }

    public void setPhoneExtNumber(String phoneExtNumber) {
        this.phoneExtNumber = phoneExtNumber;
    }

    public String getMobileAreaCode() {
        return mobileAreaCode;
    }

    public void setMobileAreaCode(String mobileAreaCode) {
        this.mobileAreaCode = mobileAreaCode;
    }

    public String getMobileLocalNumber() {
        return mobileLocalNumber;
    }

    public void setMobileLocalNumber(String mobileLocalNumber) {
        this.mobileLocalNumber = mobileLocalNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getAccountLoginNum() {
        return accountLoginNum;
    }

    public void setAccountLoginNum(String accountLoginNum) {
        this.accountLoginNum = accountLoginNum;
    }

    public String getAccountLoginIP() {
        return accountLoginIP;
    }

    public void setAccountLoginIP(String accountLoginIP) {
        this.accountLoginIP = accountLoginIP;
    }

    public String getAccountLastTime() {
        return accountLastTime;
    }

    public void setAccountLastTime(String accountLastTime) {
        this.accountLastTime = accountLastTime;
    }
}
