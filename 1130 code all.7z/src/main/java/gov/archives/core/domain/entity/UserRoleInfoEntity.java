package gov.archives.core.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by tristan on 2016/8/2.
 */
@Alias("UserRoleInfo")
public class UserRoleInfoEntity extends UserInfoEntity{
    private String roleName;

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
