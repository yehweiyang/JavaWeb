package gov.archives.core.domain.vo;

public class SystemAnnounceVO {
    private static final long serialVersionUID = -6060395151401693976L;

    private String announceMessage;

    public String getAnnounceMessage() {
        return announceMessage;
    }

    public void setAnnounceMessage(String announceMessage) {
        this.announceMessage = announceMessage;
    }
}
