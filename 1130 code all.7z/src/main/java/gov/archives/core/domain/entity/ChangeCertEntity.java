package gov.archives.core.domain.entity;

import java.io.Serializable;

/**
 * ChangeCertEntity
 * <p>
 * Created by WeiYang on 2016/10/17.
 */
public class ChangeCertEntity extends BaseEntity implements Serializable {
    private String serialNumber;
    private String certb64;
    private String account;
    private String certHash;

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getCertb64() {
        return certb64;
    }

    public void setCertb64(String certb64) {
        this.certb64 = certb64;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getCertHash() {
        return certHash;
    }

    public void setCertHash(String certHash) {
        this.certHash = certHash;
    }
}
