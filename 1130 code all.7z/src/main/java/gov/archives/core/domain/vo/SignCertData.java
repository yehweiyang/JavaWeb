package gov.archives.core.domain.vo;

import java.io.Serializable;

public class SignCertData implements Serializable{
	private static final long serialVersionUID = -4774826177817351273L;

	private String token;
	
	private String b64Signature;

	public String getToken() {
		return token;
	}

	public void setToken(String tbs) {
		this.token = tbs;
	}

	public String getB64Signature() {
		return b64Signature;
	}

	public void setB64Signature(String b64Signature) {
		this.b64Signature = b64Signature;
	}
}
