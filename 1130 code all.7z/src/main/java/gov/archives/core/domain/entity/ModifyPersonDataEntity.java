package gov.archives.core.domain.entity;

import org.apache.ibatis.type.Alias;
/**
 * Created by pywang on 2016/8/9.
 */
@Alias("PersonData")
public class ModifyPersonDataEntity extends UserInfoEntity {
    private String loginCount;
    private String loginIP;
    private String loginTime;

    public String getLoginCount() {
        return loginCount;
    }

    public void setLoginCount(String loginCount) {
        this.loginCount = loginCount;
    }

    public String getLoginIP() {
        return loginIP;
    }

    public void setLoginIP(String loginIP) {
        this.loginIP = loginIP;
    }

    public String getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(String loginTime) {
        this.loginTime = loginTime;
    }
}


