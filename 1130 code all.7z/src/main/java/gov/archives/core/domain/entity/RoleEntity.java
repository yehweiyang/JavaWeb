package gov.archives.core.domain.entity;

import java.util.UUID;

import org.apache.ibatis.type.Alias;

/**
 * RoleEntity
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@Alias("Role")
public class RoleEntity extends BaseEntity {

    private String roleName;
    private Integer activeStatus;

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Integer getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }


}
