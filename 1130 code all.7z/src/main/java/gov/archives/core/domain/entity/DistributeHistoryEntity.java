package gov.archives.core.domain.entity;

import java.sql.Timestamp;
import java.util.UUID;

import org.apache.ibatis.type.Alias;

/**
 * Created by tristan on 2016/9/7.
 */
@Alias("DistHistory")
public class DistributeHistoryEntity {
    private UUID sysId;
    private Timestamp distTimestamp;
    private String processId;
    private String fromOrgUnitName;
    private String toOrgUnitName;
    private String clientId;
    private int flowSeq;
    private String memo;
    private String creatorApp;
    private Timestamp createdTime;
    private String modifierApp;
    private Timestamp modifiedTime;

    public UUID getSysId() {
        return sysId;
    }

    public void setSysId(UUID sysId) {
        this.sysId = sysId;
    }

    public Timestamp getDistTimestamp() {
        return distTimestamp;
    }

    public void setDistTimestamp(Timestamp distTimestamp) {
        this.distTimestamp = distTimestamp;
    }

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getFromOrgUnitName() {
        return fromOrgUnitName;
    }

    public void setFromOrgUnitName(String fromOrgUnitName) {
        this.fromOrgUnitName = fromOrgUnitName;
    }

    public String getToOrgUnitName() {
        return toOrgUnitName;
    }

    public void setToOrgUnitName(String toOrgUnitName) {
        this.toOrgUnitName = toOrgUnitName;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public int getFlowSeq() {
        return flowSeq;
    }

    public void setFlowSeq(int flowSeq) {
        this.flowSeq = flowSeq;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getCreatorApp() {
        return creatorApp;
    }

    public void setCreatorApp(String creatorApp) {
        this.creatorApp = creatorApp;
    }

    public Timestamp getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Timestamp createdTime) {
        this.createdTime = createdTime;
    }

    public String getModifierApp() {
        return modifierApp;
    }

    public void setModifierApp(String modifierApp) {
        this.modifierApp = modifierApp;
    }

    public Timestamp getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Timestamp modifiedTime) {
        this.modifiedTime = modifiedTime;
    }
}
