package gov.archives.core.security.encrypt;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.util.Properties;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import org.iii.common.util.IOUtils;

import gov.archives.core.conf.SecKeyInitializer;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.util.EncryptUtils;

/**
 * Created by kshsu on 2016/10/4.
 */
public class CipherConf {

    public enum Mode {
        ENCRYPT, DECRYPT
    }

    public enum Method {
        AES256, TRIPLE_DES
    }

    // config file
    public static final String CONFIGFILE_NAME = "encryptUtils.properties";

    // sk
    private static final String PROPERTY_SECRET_KEY = "sk";
    public static final String SECRET_KEY;
    private static final String DEFAULT_SECRET_KEY = "Coda PALL MALL";
    // iv (8 word) Triple DES
    private static final String PROPERTY_IV = "iv";
    public static final String IV;
    private static final String DEFAULT_IV = "01234567";

    // iv256 (16 word) AES256
    private static final String PROPERTY_IV256 = "iv256";
    public static final String IV256;
    private static final String DEFAULT_IV256 = "1234567812345678";

    public static final String ENCRYPT_METHOD;
    private static final String PROPERTY_ENCRYPT_METHOD = "encryptMethod";

    // Common Configuration
    protected static final String BOUNCYCASTLE_PROVIDER = "BC";
    protected static final String ALGORITHM_3DES_KEY = "DESede";
    protected static final String ALGORITHM_AES_CIPHER = "AES/GCM/NoPadding";
    protected static final String ALGORITHM_3DES_CIPHER = "DESede/CBC/PKCS5Padding";

    // encoding format
    public static final String ENCODING;
    private static final String DEFAULT_ENCODING = "utf-8";
    private static final String PROPERTY_ENCODING = "encoding";

    static {
        Properties properties = new Properties();

        try {
            properties.load(
                    IOUtils.loadResourceInClasspath(CONFIGFILE_NAME));
        } catch (IOException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        } finally {
            ENCRYPT_METHOD = properties.getProperty(PROPERTY_ENCRYPT_METHOD, "");
            SECRET_KEY = properties.getProperty(PROPERTY_SECRET_KEY, DEFAULT_SECRET_KEY);
            IV = properties.getProperty(PROPERTY_IV, DEFAULT_IV);
            IV256 = properties.getProperty(PROPERTY_IV256, DEFAULT_IV256);
            ENCODING = properties.getProperty(PROPERTY_ENCODING, DEFAULT_ENCODING);
        }
    }

    CipherConf() {
        Security.addProvider(new BouncyCastleProvider());
    }

    private Cipher cipher;

    private Mode mode;

    public Cipher getCipher() {
        return cipher;
    }

    public void setCipher(Cipher cipher) {
        this.cipher = cipher;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public int getMode() {
        return (Mode.ENCRYPT.equals(this.mode) ?
                Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE);
    }

    public String getIV() {
        return propertyConvert(SecKeyInitializer.getRandomIv(Method.TRIPLE_DES));
    }

    public String getIV256() {
        return propertyConvert(SecKeyInitializer.getRandomIv(Method.AES256));
    }

    protected String getSecretKey() {
        try {
            return propertyConvert(SecKeyInitializer.getRandomSecKey());
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ENCRYPT_OR_DECRYPT_ERROR, e);
        }
    }

    private String propertyConvert(String source) {
        try {
            return EncryptUtils.base64ToText(source);
        } catch (CoreException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ENCRYPT_OR_DECRYPT_ERROR, e);
        }
    }
}
