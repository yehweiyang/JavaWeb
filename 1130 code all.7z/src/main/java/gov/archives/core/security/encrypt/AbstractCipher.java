package gov.archives.core.security.encrypt;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;

import gov.archives.core.exception.CoreException;

/**
 * Created by kshsu on 2016/10/3.
 */
public abstract class AbstractCipher extends CipherConf {

    public abstract Cipher getInstance(CipherConf.Mode mode) throws CoreException;

    public abstract SecretKey getCustSecretKey();
}