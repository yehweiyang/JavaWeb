package gov.archives.core.security.encrypt;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import org.iii.security.exception.SecurityException;
import org.iii.security.util.SecretKeyUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;

/**
 * Created by kshsu on 2016/10/3.
 */
public class Aes256Cipher extends AbstractCipher {

    public static final String ALIAS_NAME = "PALL";

    @Override
    synchronized public Cipher getInstance(CipherConf.Mode mode) throws CoreException {
        setMode(mode);

        IvParameterSpec ips = new IvParameterSpec(getIV256().getBytes());
        try {
            setCipher(Cipher.getInstance(CipherConf.ALGORITHM_AES_CIPHER, CipherConf.BOUNCYCASTLE_PROVIDER));
            getCipher().init(getMode(), getCustSecretKey(), ips);
        } catch (Exception e) {
            throw new CoreException(e, CoreErrorCode.ENCRYPT_OR_DECRYPT_ERROR);
        }

        return getCipher();
    }

    @Override
    public SecretKey getCustSecretKey() {
        try {
            return SecretKeyUtils.getAESKeyFromCustData(getSecretKey().getBytes());
        } catch (SecurityException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ENCRYPT_OR_DECRYPT_ERROR, e);
        }
    }
}
