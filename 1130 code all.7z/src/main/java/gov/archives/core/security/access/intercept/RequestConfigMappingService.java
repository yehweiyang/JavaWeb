package gov.archives.core.security.access.intercept;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;

import gov.archives.core.domain.entity.UserInfoEntity;

/**
 * Created by yflin on 9/26/16.
 */
public interface RequestConfigMappingService {
    String ROLE_PREFIX = "ROLE_";
    String CONTROLLER_JS = "Controller.js";
    String VIEW_SUFFIX = ".html";
    String CONTROLLER_PREFIX_URL = "/archivesapps/controllers/";
    String VIEW_PREFIX_URL = "/archivesapps/views/";
    String ARCH_ASSETS_ALL = "/archivesapps/assets/**";
    String ARCH_TEMPLATES_ALL = "/archivesapps/templates/**";
    String HOME_CONTROLLER_JS = "/archivesapps/controllers/HomeController.js";
    String HOME_HTML = "//archivesapps/views/home.html";
    String REST_PREFIX_URL = "/v1/";
    String REST_SESSION_ALL = "/v1/session/**";
    String REST_CORE_MENU = "/v1/core/menu";
    String REST_CORE_MENU_ALL = "/v1/core/menu/all";
    String REST_MENU_URL_MAP = "/v1/core/rest/urlMap";
    String REST_AGENCY_DOWNLOAD_URL_MAP = "/v1/changeRecord/agencyCert/downloadLogFile?**";
    String REST_TOKEN_ALL = "/v1/token/**";
    String LOGOUT_URL_ALL = "/logout/**";
    String CHECK_CERT_HASH = "/cert/check";
    String HOME_PAGE = "/v1/home";
    String ERROR_PREFIX = "/errors/*";
    String INDEX_JSP = "/index.jsp";
    String CAPTCHA_JPG = "/captcha.jpg";
    String NEW_ACCOUNT = "/newAccount";
    String RESOURCES_PREFIX = "/resources/**";
    String PERMIT_ALL = "permitAll";
    String ARCH_ASSETS_JS = "/archivesapps/assets/js";
    String ARCH_ASSETS_CSS = "/archivesapps/assets/css";
    String ERROR_CODE_JS = "/errorcode.js";
    String LOGIN_JS = "/login.js";
    String LOGIN_CSS = "/login.css";
    String HIPKI_JS = "/hipki.js";
    String READCERT_JS = "/readcert.js";
    String NEW_ACCOUNT_JS = "/newaccount.js";
    String EDIT_ANNOUNCEMENT_HTML_URL = "/v1/systemTool/editAnnouncement/download/announcement";

    List<RequestConfigMapping> getRequestConfigMappings();

    Collection<? extends GrantedAuthority> createAuthorities(UserInfoEntity user);
}
