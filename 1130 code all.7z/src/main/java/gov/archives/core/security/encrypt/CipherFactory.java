package gov.archives.core.security.encrypt;

import javax.crypto.Cipher;

import org.iii.common.util.PreconditionUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;

/**
 * Created by kshsu on 2016/10/3.
 */
public class CipherFactory extends AbstractCipherFactory {

    @Override
    public Cipher getInstance(CipherConf.Method method, CipherConf.Mode mode)
            throws CoreException {
        PreconditionUtils.checkArguments(method, mode);

        try {
            if (method.equals(CipherConf.Method.AES256)) {
                return new Aes256Cipher().getInstance(mode);
            } else if (method.equals(CipherConf.Method.TRIPLE_DES)) {
                return new TripleDesCipher().getInstance(mode);
            } else {
                throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR);
            }
        } catch (Exception ex) {
            throw new CoreException(ex, CoreErrorCode.ENCRYPT_OR_DECRYPT_ERROR);
        }
    }
}
