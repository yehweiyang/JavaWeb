package gov.archives.core.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.security.access.intercept.RequestConfigMappingService;
import gov.archives.core.service.UserInfoService;

@Component
public class RestAuthenticationProvider implements AuthenticationProvider {
    @Autowired
    private UserInfoService userService;

    @Autowired
    private RequestConfigMappingService requestConfigMappingService;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) authentication;
        String principal = (String) auth.getPrincipal();
        String credential = (String) auth.getCredentials();
        UserInfoEntity user = userService.getByAccount(principal);
        if (null == user || !user.getCertCardNum().equals(credential)) {
            throw new UsernameNotFoundException("Invalid username/password.");
        }
        return new UsernamePasswordAuthenticationToken(principal, credential, requestConfigMappingService.createAuthorities(user));
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.getSimpleName().equals(UsernamePasswordAuthenticationToken.class.getSimpleName());
    }
}
