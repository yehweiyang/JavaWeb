package gov.archives.core.security;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.security.access.intercept.RequestConfigMappingService;

@Component
public class DocumentUserAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	private RequestConfigMappingService requestConfigMappingService;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		CaptchaPKIAuthenticationToken token = (CaptchaPKIAuthenticationToken) authentication;
		UserInfoEntity user = token.getUser();
		String cardNo = user.getCertCardNum();
		Collection<? extends GrantedAuthority> authorityList = requestConfigMappingService.createAuthorities(user);
		if (null == authorityList)
			throw new AuthenticationServiceException(CoreErrorMessage.findByCode(CoreErrorCode.AUTHORITY_ROLE_ERROR));
		return new CaptchaPKIAuthenticationToken(user, user.getCertCardNum(), authorityList);
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.getSimpleName().equals(CaptchaPKIAuthenticationToken.class.getSimpleName());
	}
}
