package gov.archives.core.security;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import org.iii.security.hash.HashGenerator;
import org.iii.security.hash.HashGenerators;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.SignCertData;
import gov.archives.core.domain.vo.VerifyResult;
import gov.archives.core.message.CoreErrorCode;

//TODO: refactor this class exception block
@Component
@Scope("prototype")
public class DigitalSignHandle {
    private X509Certificate signCert;
    private VerifyResult verifyResult;
    private Decoder decoder = Base64.getDecoder();
    private HashGenerator fileHashGenerator;

    public DigitalSignHandle() {
        verifyResult = new VerifyResult();
        verifyResult.setIsVerify(true);
        verifyResult.setErrorCode("0");
        verifyResult.setErrorMessage("Success");

        fileHashGenerator = HashGenerators.getInstanceByAlgorithm(CoreConf.FILE_HASH_ALGORITHM);
    }

    public String transBase64CertIntoX509Cert(String b64Cert) throws AuthenticationException {
        try {
            CertificateFactory cf = CertificateFactory.getInstance(CoreConf.CERT_FORMAT);

            signCert = (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(decoder.decode(b64Cert)));

            checkKeyUsage(signCert);

            String derASN1 = new String(signCert.getEncoded(), StandardCharsets.UTF_8);

            return fileHashGenerator.getHashByString(derASN1);
        } catch (CertificateException e) {
            throw new AuthenticationServiceException(CoreErrorCode.SIGNATURE_ERROR);
        }
    }

    private void checkKeyUsage(X509Certificate signCert) throws CertificateException {
        boolean[] usage = signCert.getKeyUsage();

        if (!usage[0]) { throw new CertificateException(); }
    }

    public String readCertFile(File file) throws AuthenticationException {
        try {
            byte[] data = FileUtils.readFileToByteArray(file);

            if (data == null) { throw new CertificateException(CoreErrorCode.CARD_NOT_AVAILABLE); }

            CertificateFactory cf = CertificateFactory.getInstance(CoreConf.CERT_FORMAT);

            signCert = (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(data));

            checkKeyUsage(signCert);

            return new String(signCert.getEncoded(), StandardCharsets.UTF_8);
        } catch (CertificateException | IOException e) {
            throw new AuthenticationServiceException(CoreErrorCode.CARD_NOT_AVAILABLE);
        }
    }

    public void saveCertFile(File saveCertFile) throws AuthenticationException {
        try {
            FileUtils.writeByteArrayToFile(saveCertFile, signCert.getEncoded());
        } catch (CertificateEncodingException | IOException e) {
            throw new AuthenticationServiceException(CoreErrorCode.SIGNATURE_ERROR);
        }
    }

    public VerifyResult getVerifyResult() {
        return verifyResult;
    }

    public boolean isCredentialsExpired(Date lastTime) {
        return lastTime.toInstant()
                       .isAfter(signCert.getNotAfter().toInstant()) |
                lastTime.toInstant()
                        .isBefore(signCert.getNotBefore().toInstant());
    }

    public boolean verifySignature(SignCertData certData) {
        boolean verify;
        String tbs = certData.getToken();
        byte[] signature = decoder.decode(certData.getB64Signature());
        try {
            Signature sign = Signature.getInstance(CoreConf.SIGN_ALGORITHM);
            sign.initVerify(signCert);
            sign.update(tbs.getBytes());
            verify = sign.verify(signature);
        } catch (SignatureException | InvalidKeyException | NoSuchAlgorithmException e) {
            verify = false;
        }
        return verify;
    }
}

