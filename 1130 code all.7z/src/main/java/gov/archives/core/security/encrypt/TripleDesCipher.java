package gov.archives.core.security.encrypt;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;

/**
 * Created by kshsu on 2016/10/3.
 */
public class TripleDesCipher extends AbstractCipher {

    public static final String ALIAS_NAME = "MALL";

    @Override
    synchronized public Cipher getInstance(CipherConf.Mode mode) throws CoreException {
        setMode(mode);

        IvParameterSpec ips = new IvParameterSpec(getIV().getBytes());
        try {
            setCipher(Cipher.getInstance(CipherConf.ALGORITHM_3DES_CIPHER, CipherConf.BOUNCYCASTLE_PROVIDER));
            getCipher().init(getMode(), getCustSecretKey(), ips);
        } catch (Exception e) {
            throw new CoreException(e, CoreErrorCode.ENCRYPT_OR_DECRYPT_ERROR);
        }

        return getCipher();
    }

    @Override
    public SecretKey getCustSecretKey() {

        DESedeKeySpec spec;
        SecretKeyFactory secretKeyFactory;
        try {
            spec = new DESedeKeySpec(getSecretKey().getBytes());
            secretKeyFactory = SecretKeyFactory.getInstance(CipherConf.ALGORITHM_3DES_KEY);
            return secretKeyFactory.generateSecret(spec);
        } catch (InvalidKeyException | InvalidKeySpecException | NoSuchAlgorithmException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ENCRYPT_OR_DECRYPT_ERROR, e);
        }
    }
}
