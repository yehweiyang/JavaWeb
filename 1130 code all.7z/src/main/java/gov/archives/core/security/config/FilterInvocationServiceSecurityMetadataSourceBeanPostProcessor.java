package gov.archives.core.security.config;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.stereotype.Component;

import gov.archives.core.security.access.intercept.FilterInvocationServiceSecurityMetadataSource;

/**
 * Created by yflin on 9/26/16.
 */
@Component
public class FilterInvocationServiceSecurityMetadataSourceBeanPostProcessor implements BeanPostProcessor {
    @Autowired
    private FilterInvocationServiceSecurityMetadataSource metadataSource;

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        if(bean instanceof FilterInvocationSecurityMetadataSource) {
            return metadataSource;
        }
        return bean;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if(bean instanceof FilterInvocationSecurityMetadataSource) {
            metadataSource.createSecurityMetadataSource();
            return metadataSource;
        }
        return bean;
    }
}
