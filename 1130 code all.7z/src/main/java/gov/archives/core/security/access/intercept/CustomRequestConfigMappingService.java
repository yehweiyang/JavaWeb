package gov.archives.core.security.access.intercept;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Repository;

import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.RoleMenuMapping;
import gov.archives.core.service.MenuService;
import gov.archives.core.service.RoleService;

import static gov.archives.core.conf.CoreConf.INDEX_URL;
import static gov.archives.core.conf.CoreConf.LOGIN_URL;

/**
 * Created by yflin on 9/26/16.
 */
@Repository("requestConfigMappingService")
public class CustomRequestConfigMappingService implements RequestConfigMappingService {
    private List<RequestConfigMapping> requestConfigMappingList;

    private RoleService roleService;

    private MenuService menuService;

    private Map<String, String> roleTypeMap;

    @Autowired
    public CustomRequestConfigMappingService(RoleService roleService, MenuService menuService) {
        this.roleService = roleService;
        this.menuService = menuService;
        this.roleTypeMap = new HashMap<>();
        this.requestConfigMappingList = new ArrayList<>();
    }

    @Override
    public List<RequestConfigMapping> getRequestConfigMappings() {
        if (!requestConfigMappingList.isEmpty()) {
            requestConfigMappingList.clear();
            roleTypeMap.clear();
        }
        genRoleTypeMap();
        DefaultRequestUrlMap();
        CustomRequestUrlMap();
        return requestConfigMappingList;
    }

    @Override
    public Collection<? extends GrantedAuthority> createAuthorities(UserInfoEntity user) {
        genRoleTypeMap();
        RoleEntity roleEntity = roleService.getBySysId(user.getRoleSysId());
        if (null != roleEntity) {
            return AuthorityUtils.createAuthorityList(roleTypeMap.get(roleEntity.getRoleName()));
        }
        return null;
    }

    private void DefaultRequestUrlMap() {
        List<String> roleList = new ArrayList<>();
        for (RoleEntity entity : roleService.getRoleList()) {
            roleList.add(entity.getRoleName());
        }
        SecurityConfig allRoleConfig = createSecurityConfig(roleList);
        SecurityConfig permitAllConfig = new SecurityConfig(PERMIT_ALL);
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(ERROR_PREFIX), permitAllConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(INDEX_JSP), permitAllConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(LOGIN_URL), permitAllConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(CAPTCHA_JPG), permitAllConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(NEW_ACCOUNT), permitAllConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(RESOURCES_PREFIX),
                permitAllConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(ARCH_ASSETS_JS + ERROR_CODE_JS),
                permitAllConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(ARCH_ASSETS_JS + LOGIN_JS),
                permitAllConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(ARCH_ASSETS_JS + HIPKI_JS),
                permitAllConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(ARCH_ASSETS_JS + READCERT_JS),
                permitAllConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(ARCH_ASSETS_JS + NEW_ACCOUNT_JS),
                        permitAllConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(ARCH_ASSETS_CSS + LOGIN_CSS),
                permitAllConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(REST_CORE_MENU),
                permitAllConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(REST_AGENCY_DOWNLOAD_URL_MAP),
                permitAllConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(EDIT_ANNOUNCEMENT_HTML_URL),
                permitAllConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(INDEX_URL), allRoleConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(REST_CORE_MENU_ALL),
                        allRoleConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(REST_MENU_URL_MAP),
                        allRoleConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(REST_TOKEN_ALL), allRoleConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(LOGOUT_URL_ALL), allRoleConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(CHECK_CERT_HASH), allRoleConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(HOME_PAGE), allRoleConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(ARCH_ASSETS_ALL), allRoleConfig));
        requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(REST_SESSION_ALL),
                allRoleConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(ARCH_TEMPLATES_ALL), allRoleConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(HOME_CONTROLLER_JS),
                        allRoleConfig));
        requestConfigMappingList
                .add(new RequestConfigMapping(new AntPathRequestMatcher(HOME_HTML),
                        allRoleConfig));
    }

    private void CustomRequestUrlMap() {
        List<String> urlType = Arrays.asList(CONTROLLER_PREFIX_URL, VIEW_PREFIX_URL, REST_PREFIX_URL);
        urlType.forEach(this::genRequestConfigMapping);
    }

    private String toLowerCamelCase(String menuCode) {
        return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
    }

    private String buildRequestUrl(String urlType, MenuEntity topMenu, MenuEntity subMenu) {
        StringBuilder requestURL = new StringBuilder().append(urlType);
        if (urlType.equals(CONTROLLER_PREFIX_URL)) {
            requestURL.append(topMenu.getMenuCode()).append("/").append(subMenu.getMenuCode()).append(CONTROLLER_JS);
        } else if (urlType.equals(VIEW_PREFIX_URL)) {
            requestURL.append(topMenu.getMenuCode()).append("/").append(toLowerCamelCase(subMenu.getMenuCode()))
                      .append(VIEW_SUFFIX);
        } else if (urlType.equals(REST_PREFIX_URL)) {
            requestURL.append(toLowerCamelCase(topMenu.getMenuCode())).append("/")
                      .append(toLowerCamelCase(subMenu.getMenuCode())).append("/**");
        }
        return requestURL.toString();
    }

    private void genRequestUrlMap(RoleMenuMapping roleMenuMapping, Map<String, List<String>> requestUrlMapping,
            String urlType) {
        RoleEntity roleEntity = roleMenuMapping.getRole();
        if (null != roleEntity && 1 == roleEntity.getActiveStatus()) {
            String roleName = roleEntity.getRoleName();
            for (MenuEntity entity : roleMenuMapping.getMenus()) {
                MenuEntity topMenu = menuService.getBySysId(entity.getTopMenuId());
                String requestUrl = buildRequestUrl(urlType, topMenu, entity);
                if (null != requestUrl) {
                    List<String> roleList = requestUrlMapping.get(requestUrl);
                    if (null == roleList) {
                        roleList = new ArrayList<>();
                    }
                    roleList.add(roleName);
                    requestUrlMapping.put(requestUrl, roleList);
                }
            }
        }
    }

    private SecurityConfig createSecurityConfig(List<String> roleList) {
        StringBuilder builder = new StringBuilder().append("hasAnyRole(");
        for (int i = 0; i < roleList.size(); i += 1) {
            String roleName = roleTypeMap.get(roleList.get(i));
            if (i < (roleList.size() - 1)) { builder.append("'").append(roleName).append("'").append(","); } else {
                builder.append("'").append(roleName).append("'");
            }
        }
        builder.append(")");
        return new SecurityConfig(builder.toString());
    }

    private void genRequestConfigMapping(String urlType) {
        List<RoleEntity> roleEntityList = roleService.getRoleList();
        Map<String, List<String>> requestUrlMapping = new TreeMap<>();
        for (RoleEntity entity : roleEntityList) {
            RoleMenuMapping roleMenuMapping = roleService.getMenuMappingByRoleName(entity.getRoleName());
            genRequestUrlMap(roleMenuMapping, requestUrlMapping, urlType);
        }
        addRequestConfigMappingList(requestUrlMapping);
    }

    private void addRequestConfigMappingList(Map<String, List<String>> requestUrlMapping) {
        for (String url : requestUrlMapping.keySet()) {
            requestConfigMappingList.add(new RequestConfigMapping(new AntPathRequestMatcher(url),
                    createSecurityConfig(requestUrlMapping.get(url))));
        }
    }

    private void genRoleTypeMap() {
        if (roleTypeMap.isEmpty()) {
            for (RoleEntity roleEntity : roleService.getRoleList()) {
                addRoleTypeMap(roleEntity.getRoleName());
            }
        }
    }

    private void addRoleTypeMap(String roleName) {
        roleTypeMap.put(roleName, ROLE_PREFIX + roleName);
    }
}
