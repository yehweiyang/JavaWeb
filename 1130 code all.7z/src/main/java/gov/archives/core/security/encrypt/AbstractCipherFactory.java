package gov.archives.core.security.encrypt;

import javax.crypto.Cipher;

import gov.archives.core.exception.CoreException;

/**
 * Created by kshsu on 2016/10/3.
 */
public abstract class AbstractCipherFactory {

    public abstract Cipher getInstance(CipherConf.Method method, CipherConf.Mode mode)
            throws CoreException;
}
