package gov.archives.core.security.access.intercept;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.web.util.matcher.RequestMatcher;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;

/**
 * Created by yflin on 9/26/16.
 */
public class RequestConfigMapping {
    private final RequestMatcher matcher;
    private final Collection<ConfigAttribute> attributes;

    public RequestConfigMapping(RequestMatcher matcher, ConfigAttribute attribute) {
        this(matcher, Collections.singleton(attribute));
    }

    public RequestConfigMapping(RequestMatcher matcher, Collection<ConfigAttribute> attributes) {
        if (matcher == null) {

            throw new ArchivesException(CoreErrorMessage.findByCode(CoreErrorCode.REQUEST_MATCHER_NULL_ERROR));
        }

        this.matcher = matcher;
        this.attributes = attributes;
    }

    public RequestMatcher getMatcher() {
        return matcher;
    }

    public Collection<ConfigAttribute> getAttributes() {
        return attributes;
    }
}
