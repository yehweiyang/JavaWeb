package gov.archives.core.exception;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.context.support.StaticApplicationContext;

import org.iii.common.util.PreconditionUtils;

import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.util.LogUtils;
import gov.archives.exchange.event.ArchivesExceptionEvent;
import gov.archives.exchange.event.handler.GlobalEventHandler;

/**
 * Created by 140631 on 2016/8/12.
 */
public class ArchivesException extends RuntimeException implements ApplicationEventPublisherAware {

    public static ArchivesException getInstanceByErrorCode(String errorCode, Object... objects) {
        String errorMessage = CoreErrorMessage.findByCode(errorCode);

        return new ArchivesException(errorMessage, errorCode, objects);
    }

    private ApplicationEventPublisher publisher;

    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        this.publisher = applicationEventPublisher;
    }

    private void publish(String errorMessage, String errorCode, Object... objects) {
        ArchivesExceptionEvent archivesExceptionEvent =
                new ArchivesExceptionEvent(this, errorMessage, errorCode, objects);
        publishEventInner(archivesExceptionEvent);
    }

    private void publish(String errorCode, Object... objects) {
        ArchivesExceptionEvent archivesExceptionEvent = new ArchivesExceptionEvent(this, errorCode, objects);
        publishEventInner(archivesExceptionEvent);
    }

    private String errorCode;

    private String errorMessage;

    public ArchivesException() {
        super();
    }

    public ArchivesException(String message) {
        super(message);
        this.errorCode = LogUtils.getErrorCodeIfExist(message);
        this.errorMessage = LogUtils.getErrorMessage(message);
        publish(errorMessage, errorCode);
    }

    public ArchivesException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = LogUtils.getErrorCodeIfExist(message);
        this.errorMessage = LogUtils.getErrorMessage(message);
        publish(errorMessage, errorCode, cause);
    }

    public ArchivesException(Throwable cause) {
        super(cause);
        this.errorCode = CoreErrorCode.SYSTEM_ERROR;
        this.errorMessage = LogUtils.getErrorMessage(CoreErrorCode.SYSTEM_ERROR);
        publish(errorMessage, errorCode, cause);
    }

    protected ArchivesException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.errorCode = CoreErrorCode.SYSTEM_ERROR;
        this.errorMessage = LogUtils.getErrorMessage(CoreErrorCode.SYSTEM_ERROR);
        publish(errorMessage, errorCode, cause);
    }

    public ArchivesException(String message, String errorCode, Object... objects) {
        super(message);
        this.errorCode = errorCode;
        this.errorMessage = message;


        publish(message, errorCode, objects);
    }




    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    private <T extends ApplicationEvent> void publishEventInner(T applicationEvent) {
        PreconditionUtils.checkArguments(applicationEvent);
        if (null != publisher) {
            publisher.publishEvent(applicationEvent);
        } else {
            StaticApplicationContext context = new StaticApplicationContext();
            context.addApplicationListener(new GlobalEventHandler());
            context.refresh();
            context.publishEvent(applicationEvent);
        }
    }
}
