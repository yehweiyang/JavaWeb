package gov.archives.core.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.validator.routines.RegexValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import gov.archives.core.conf.ActionLogConf;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.UserInfo;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.UserInfoService;

/**
 * Created by tristan on 2016/7/25.
 */
@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.SYSTEM_TOOL_URL + CoreConf.USER_MANAGE_URL)
public class UserInfoController extends RestControllerBase {


    @Autowired
    private UserInfoService userInfoService;

    @RequestMapping(value = "/list",
            method = RequestMethod.GET)
    public Collection<UserInfo> getFilterAccount(@RequestParam Map<String, Object> requestMap, HttpServletRequest request) {
        try {
            Map<String, Object> nameSearchMap = new HashMap<String, Object>();
            nameSearchMap.put("keyWord", MapUtils.getObject(requestMap, "keyWord"));
            nameSearchMap.put("verification", Boolean.parseBoolean(MapUtils.getString(requestMap, "verification")));
            nameSearchMap.put("active", Boolean.parseBoolean(MapUtils.getString(requestMap, "active")));
            nameSearchMap.put("inactive", Boolean.parseBoolean(MapUtils.getString(requestMap, "inactive")));

            List<UserInfo> userInfoList = userInfoService.listByKeyWord(nameSearchMap);
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_ACCOUNT_KEYWORD, ActionLogConf.SUCCESS_MSG,
                    ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);

            return userInfoList;
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_ACCOUNT_KEYWORD,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR),
                    CoreErrorCode.SEARCH_ERROR, ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR, e);
        }
    }

    @RequestMapping(value = "/saveUser",
            method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.OK)
    public void saveUser(@RequestBody UserInfo user, HttpServletRequest request) {
        try {
            if (null == user) {
                throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
            }
            verifyUserInfo(user);
            userInfoService.updateUserByAccount(user);
            insertActionLogAndRsysLog(request, ActionLogConf.UPDATE_ACCOUNT_DATA, ActionLogConf.SUCCESS_MSG,
                    ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.UPDATE_PERSON_DATA,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR),
                    CoreErrorCode.SEARCH_ERROR, ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(e.getErrorCode());
        }
    }

    private void verifyUserInfo(UserInfo user) {
        RegexValidator digitValidator = new RegexValidator(CoreConf.DIGIT_PATTERN);
        RegexValidator digitOrEmptyValidator = new RegexValidator(CoreConf.DIGIT_EMPTY_PATTERN);
        RegexValidator alphaNumericValidator = new RegexValidator(CoreConf.ALPHANUMERIC_PATTERN);
        RegexValidator alphaNumericNlsValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);

        String account = user.getAccount();
        if (null == account || !alphaNumericValidator.isValid(account)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.USER_ACCOUNT_FORMAT_INCORRECT);
        }
        String roleName = user.getRoleName();
        if (roleName == null || (!roleName.isEmpty() && !alphaNumericNlsValidator.isValid(roleName))) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_INCORRECT);
        }
        String userName = user.getUserName();
        if (null == userName || !alphaNumericNlsValidator.isValid(userName)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.USER_NAME_FORMAT_INCORRECT);
        }
        String email = user.getEmail();
        if (null == email || !EmailValidator.getInstance().isValid(email)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.EMAIL_FORMAT_INCORRECT);
        }
        if (!alphaNumericNlsValidator.isValid(user.getOrgInfo())) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ORG_INFO_FORMAT_INCORRECT);
        }
        int activeStatus = user.getActiveStatus();
        if (!(activeStatus == CoreConf.STATUS_APPLYING || activeStatus == CoreConf.STATUS_DISABLED
                || activeStatus == CoreConf.STATUS_ENABLED)) {
            throw new RestApplicationException("Invalid ActiveStatus");
        }
        String deputyAccount = user.getDeputyAccount();
        if (null == deputyAccount || (!deputyAccount.isEmpty() && !alphaNumericValidator.isValid(deputyAccount))) {
            throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
        }
        String phoneAreaCode = user.getPhoneAreaCode();
        if (null == phoneAreaCode || !digitValidator.isValid(phoneAreaCode)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_TYPE_INCORRECT);
        }
        if (phoneAreaCode.length() < 2 || phoneAreaCode.length() > 4) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
        String phoneLocalNumber = user.getPhoneLocalNumber();
        if (null == phoneLocalNumber || !digitValidator.isValid(phoneLocalNumber)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_TYPE_INCORRECT);
        }
        if (phoneLocalNumber.length() > 10) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
        String phoneExtNumber = user.getPhoneExtNumber();
        if (null == phoneExtNumber || !digitOrEmptyValidator.isValid(phoneExtNumber)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_TYPE_INCORRECT);
        }
        if (phoneExtNumber.length() > 6) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
        String mobileAreaCode = user.getMobileAreaCode();
        if (null == mobileAreaCode || !digitOrEmptyValidator.isValid(mobileAreaCode)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_TYPE_INCORRECT);
        }
        if (mobileAreaCode.length() > 4) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
        String mobileLocalNumber = user.getMobileLocalNumber();
        if (null == mobileLocalNumber || !digitOrEmptyValidator.isValid(mobileLocalNumber)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_TYPE_INCORRECT);
        }
        if (mobileLocalNumber.length() > 10) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
    }
}
