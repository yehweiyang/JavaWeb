package gov.archives.core.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.validator.routines.RegexValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.PreconditionUtils;

import gov.archives.common.json.JsonUtils;
import gov.archives.core.conf.ActionLogConf;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.DistributeMappingEntity;
import gov.archives.core.domain.entity.DistributeUnitEntity;
import gov.archives.core.domain.vo.DistributeDoc;
import gov.archives.core.domain.vo.DistributeHistory;
import gov.archives.core.domain.vo.DistributeMapping;
import gov.archives.core.domain.vo.DistributeUnit;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.mapper.query.DistributionQueryMapper;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.DistributionService;
import gov.archives.core.util.BeanUtils;

/**
 * Created by tristan on 2016/8/25.
 */
@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.DOCUMENT_SYSTEM_URL)
public class DistributionController extends RestControllerBase {
    private static final Logger log = LoggerFactory.getLogger(DistributionController.class);

    @Autowired
    private DistributionService distributionService;

    @RequestMapping(value = CoreConf.DIST_DOC_UNIT_URL + "/listSenderUnit", method = RequestMethod.GET)
    public Collection<DistributeUnit> getSenderUnitList(
            @RequestParam(value = "orgId", required = false, defaultValue = "") String orgId,
            @RequestParam(value = "unitId", required = false, defaultValue = "") String unitId,
            @RequestParam(value = "orgUnitName", required = false, defaultValue = "") String orgUnitName,
            @RequestParam(value = "exactMatch") boolean exactMatch,
            HttpServletRequest request) {
        try {
            RegexValidator stringValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);
            if (!orgId.isEmpty()) { if (!stringValidator.isValid(orgId)) { throw new RestApplicationException(); } }
            if (!unitId.isEmpty()) { if (!stringValidator.isValid(unitId)) { throw new RestApplicationException(); } }
            if (!orgUnitName.isEmpty()) {
                if (!stringValidator.isValid(orgUnitName)) { throw new RestApplicationException(); }
            }
            String centerId = "9905"; //temp

            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);

            return distributionService.listSenderUnit(centerId, orgId, unitId, orgUnitName, exactMatch);
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_DOCUMENT_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR), CoreErrorCode.SEARCH_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR, e);
        }

    }

    @RequestMapping(value = CoreConf.DIST_DOC_RCV_URL + "/listReceiverUnit", method = RequestMethod.GET)
    public Collection<DistributeUnit> getReceiverUnitList(
            @RequestParam(value = "orgId", required = false, defaultValue = "") String orgId,
            @RequestParam(value = "unitId", required = false, defaultValue = "") String unitId,
            @RequestParam(value = "orgUnitName", required = false, defaultValue = "") String orgUnitName,
            @RequestParam(value = "exactMatch") boolean exactMatch,
            HttpServletRequest request) {
        try {
            RegexValidator stringValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);
            if (!orgId.isEmpty()) { if (!stringValidator.isValid(orgId)) { throw new RestApplicationException(); } }
            if (!unitId.isEmpty()) { if (!stringValidator.isValid(unitId)) { throw new RestApplicationException(); } }
            if (!orgUnitName.isEmpty()) {
                if (!stringValidator.isValid(orgUnitName)) { throw new RestApplicationException(); }
            }
            String centerId = "9905"; //temp
            List<DistributeUnit> distributeUnitList =
                    distributionService.listReceiverUnit(centerId, orgId, unitId, orgUnitName, exactMatch);
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_RECEIVER_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);
            return distributeUnitList;
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_RECEIVER_DOCUMENT_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR), CoreErrorCode.SEARCH_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR, e);
        }
    }

    @RequestMapping(value = CoreConf.DIST_DOC_UNIT_URL + "/listCenterSenderUnit", method = RequestMethod.GET)
    public Collection<DistributeUnit> getCenterSenderUnitList(@RequestParam Map<String, Object> requestParams,
                                                              HttpServletRequest request) {
        try {
            List<DistributeUnit> distributeUnitList =
                    distributionService.listCenterSenderUnit(addCenterIdToMap(requestParams));
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);
            return distributeUnitList;
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_DOCUMENT_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR), CoreErrorCode.SEARCH_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR, e);
        }

    }

    @RequestMapping(value = CoreConf.DIST_DOC_RCV_URL + "/listCenterReceiverUnit", method = RequestMethod.GET)
    public Collection<DistributeUnit> getCenterReceiverUnitList(@RequestParam Map<String, Object> requestParams,
                                        HttpServletRequest request) {
        try {
            List<DistributeUnit> distributeUnitList =
                    distributionService.listCenterReceiverUnit(addCenterIdToMap(requestParams));
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_RECEIVER_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
            return distributeUnitList;
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_RECEIVER_DOCUMENT_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR), CoreErrorCode.SEARCH_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR, e);
        }
    }

    @RequestMapping(value = CoreConf.DIST_DOC_UNIT_URL + "/listUnitMappingBySender", method = RequestMethod.GET)
    public Collection<DistributeUnit> listUnitMappingBySender(@RequestParam Map<String, Object> requestParams,
                                        HttpServletRequest request) {
        try {
            List<DistributeUnit> distributeUnitList =
                    distributionService.listReceiverUnitBySenderId(addCenterIdToMap(requestParams));
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
            return distributeUnitList;
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_DOCUMENT_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR), CoreErrorCode.SEARCH_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR, e);
        }
    }

    @RequestMapping(value = CoreConf.DIST_DOC_UNIT_URL + "/deleteSenderUnit", method = RequestMethod.DELETE)
    public void deleteSenderUnit(@RequestParam Map<String, Object> senderUnit, HttpServletRequest request) {
        try {
            PreconditionUtils.checkArguments(senderUnit);

            DistributeUnit distributeUnit = new ObjectMapper().convertValue(senderUnit, DistributeUnit.class);

            distributionService.deleteSenderUnitByOrgUnitId(distributeUnit);
            insertActionLogAndRsysLog(request, ActionLogConf.DELETE_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.DELETE_DOCUMENT_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.DELETE_ERROR), CoreErrorCode.DELETE_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.UPDATE_ERROR, e);
        }
    }

    @RequestMapping(value = CoreConf.DIST_DOC_RCV_URL + "/deleteReceiverUnit", method = RequestMethod.DELETE)
    public void deleteReceiverUnit(@RequestParam Map<String, Object> receiverUnit, HttpServletRequest request) {
        try {
            PreconditionUtils.checkArguments(receiverUnit);

            DistributeUnit distributeUnit = new ObjectMapper().convertValue(receiverUnit, DistributeUnit.class);
            insertActionLogAndRsysLog(request, ActionLogConf.DELETE_RECEIVER_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.DELETE_RECEIVER_DOCUMENT_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.DELETE_ERROR), CoreErrorCode.DELETE_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.UPDATE_ERROR, e);
        }
    }

    @RequestMapping(value = CoreConf.DIST_DOC_UNIT_URL + "/setSenderUnit", method = RequestMethod.PUT)
    public void setSenderUnit(@RequestBody Collection<DistributeUnit> senderList, HttpServletRequest request) {
        try {
            PreconditionUtils.checkArguments(senderList);
            String currentUser =
                    request.getRemoteUser() == null ? "unknown" : request.getRemoteUser();
            Collection<DistributeUnit> originalList = this.getSenderUnitList("", "", "", false, request);

            List<DistributeUnit> addedUnitList = new ArrayList<>(senderList);
            addedUnitList.removeAll(originalList);
            log.info("add senderUnit: " + JsonUtils.getJsonTextByObject(addedUnitList));
            List<DistributeUnit> removedUnitList = new ArrayList<>(originalList);
            removedUnitList.removeAll(senderList);
            log.info("remove senderUnit: " + JsonUtils.getJsonTextByObject(removedUnitList));
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
            for (DistributeUnit unit : addedUnitList) {
                DistributeUnitEntity unitEntity = new DistributeUnitEntity();
                BeanUtils.copyProperties(unitEntity, unit);
                unitEntity.initSave(currentUser);
                distributionService.insertSenderUnit(unitEntity);
            }
            for (DistributeUnit unit : removedUnitList) {
                distributionService.deleteSenderUnitByOrgUnitId(unit);
            }
            insertActionLogAndRsysLog(request, ActionLogConf.UPDATE_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.UPDATE_DOCUMENT_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.UPDATE_ERROR), CoreErrorCode.UPDATE_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.UPDATE_ERROR, e);
        }
    }

    @RequestMapping(value = CoreConf.DIST_DOC_RCV_URL  + "/setReceiverUnit", method = RequestMethod.PUT)
    public void setReceiverUnit(@RequestBody Collection<DistributeUnit> receiverList, HttpServletRequest request) {
        try {
            PreconditionUtils.checkArguments(receiverList);
            Collection<DistributeUnit> originalList = this.getReceiverUnitList("", "", "", false, request);

            List<DistributeUnit> addedUnitList = new ArrayList<>(receiverList);
            addedUnitList.removeAll(originalList);
            List<DistributeUnit> removedUnitList = new ArrayList<>(originalList);
            removedUnitList.removeAll(receiverList);

            String currentUser =
                    request.getRemoteUser() == null ? "unknown" : request.getRemoteUser();
            for (DistributeUnit unit : addedUnitList) {
                DistributeUnitEntity unitEntity = new DistributeUnitEntity();
                BeanUtils.copyProperties(unitEntity, unit);
                unitEntity.initSave(currentUser);
                distributionService.insertReceiverUnit(unitEntity);
            }

            for (DistributeUnit unit : removedUnitList) {
                distributionService.deleteReceiverUnitByOrgUnitId(unit);
            }
            insertActionLogAndRsysLog(request, ActionLogConf.UPDATE_RECEIVER_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);

        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.UPDATE_RECEIVER_DOCUMENT_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.UPDATE_ERROR), CoreErrorCode.UPDATE_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ADD_ERROR, e);
        }
    }

    @RequestMapping(value = CoreConf.DIST_DOC_UNIT_URL + "/setDistributeMapping", method = RequestMethod.PUT)
    public void setDistributeMapping(@RequestBody JsonNode jsonNode, HttpServletRequest request)
            throws JsonProcessingException {
        try {
            PreconditionUtils.checkArguments(jsonNode);
            String senderOrgId = jsonNode.get("senderOrgId").textValue();
            String senderUnitId = jsonNode.get("senderUnitId").textValue();
            JsonNode mappingListNode = jsonNode.get("mappingList");
            List<DistributeMapping> newList = new ArrayList<>();
            ObjectMapper objectMapper = new ObjectMapper();
            for (JsonNode node : mappingListNode) {
                DistributeMapping mapping = objectMapper.treeToValue(node, DistributeMapping.class);
                newList.add(mapping);
            }
            List<DistributeMapping> originalMappingList =
                    distributionService.listMappingBySenderId(senderOrgId, senderUnitId);
            List<DistributeMapping> addedMappingList = (new ArrayList<>(newList));
            List<DistributeMapping> removedMappingList = new ArrayList<>(originalMappingList);
            addedMappingList.removeAll(originalMappingList);
            removedMappingList.removeAll(newList);

            String currentUser =
                    request.getRemoteUser() == null ? "unknown" : request.getRemoteUser();
            for (DistributeMapping mapping : addedMappingList) {
                DistributeMappingEntity mappingEntity = new DistributeMappingEntity();
                BeanUtils.copyProperties(mappingEntity, mapping);
                mappingEntity.initSave(currentUser);
                distributionService.insertDistributeMapping(mappingEntity);
            }
            for (DistributeMapping mapping : removedMappingList) {
                distributionService.deleteMappingByOrgUnitId(mapping);
            }
            insertActionLogAndRsysLog(request, ActionLogConf.ADD_DOCUMENT_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.ADD_DOCUMENT_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.ADD_ERROR), CoreErrorCode.ADD_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ADD_ERROR, e);
        }
    }

    @RequestMapping(value = CoreConf.DIST_DOC_STATUS_URL + "/listDistDoc", method = RequestMethod.GET)
    public Collection<DistributeDoc> getDistributeDocList(
            @RequestParam(value = "processId", required = false, defaultValue = "") String processId,
            @RequestParam(value = "status") int status,
            @RequestParam(value = "fromOrgId", required = false, defaultValue = "") String fromOrgId,
            @RequestParam(value = "fromUnitId", required = false, defaultValue = "") String fromUnitId,
            @RequestParam(value = "fromOrgUnitName", required = false, defaultValue = "") String fromOrgUnitName,
            @RequestParam(value = "toOrgId", required = false, defaultValue = "") String toOrgId,
            @RequestParam(value = "toUnitId", required = false, defaultValue = "") String toUnitId,
            @RequestParam(value = "toOrgUnitName", required = false, defaultValue = "") String toOrgUnitName,
            @RequestParam(value = "fromTime", required = false, defaultValue = "") String fromTime,
            @RequestParam(value = "toTime", required = false, defaultValue = "") String toTime,
            @RequestParam(value = "exactMatch") boolean exactMatch,
            HttpServletRequest request) {
        try {
            RegexValidator stringValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);
            if (!processId.isEmpty()) {
                if (!stringValidator.isValid(processId)) { throw new RestApplicationException(); }
            }
            if (!fromOrgId.isEmpty()) {
                if (!stringValidator.isValid(fromOrgId)) { throw new RestApplicationException(); }
            }
            if (!fromUnitId.isEmpty()) {
                if (!stringValidator.isValid(fromUnitId)) { throw new RestApplicationException(); }
            }
            if (!fromOrgUnitName.isEmpty()) {
                if (!stringValidator.isValid(fromOrgUnitName)) { throw new RestApplicationException(); }
            }
            if (!toOrgId.isEmpty()) { if (!stringValidator.isValid(toOrgId)) { throw new RestApplicationException(); } }
            if (!toUnitId.isEmpty()) {
                if (!stringValidator.isValid(toUnitId)) { throw new RestApplicationException(); }
            }
            if (!toOrgUnitName.isEmpty()) {
                if (!stringValidator.isValid(toOrgUnitName)) { throw new RestApplicationException(); }
            }
            List<DistributeDoc> distributeDocList =
                    distributionService.listDistributeDoc(processId, status, fromOrgId, fromUnitId, fromOrgUnitName,
                            toOrgId, toUnitId, toOrgUnitName, fromTime, toTime, exactMatch);
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_DOCUMENT_STATUS_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
            return distributeDocList;

        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_DOCUMENT_STATUS_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR), CoreErrorCode.SEARCH_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR, e);
        }
    }

    @RequestMapping(value = CoreConf.DIST_DOC_STATUS_URL + "/listFlowHistory", method = RequestMethod.GET)
    public Collection<DistributeHistory> getDistributeHistory(@RequestParam(value = "processId") String processId,
            HttpServletRequest request) {
        try {
            PreconditionUtils.checkArguments(processId);
            List<DistributeHistory> distributeHistoryList =
                    distributionService.listDistributeHistoryByProcessId(processId);
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_HISTORY_DOCUMENT_STATUS_UNIT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
            return distributeHistoryList;
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_HISTORY_DOCUMENT_STATUS_UNIT,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR), CoreErrorCode.SEARCH_ERROR,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR, e);
        }

    }

    private Map<String, Object> addCenterIdToMap(Map<String, Object> requestMap){
        requestMap.put(DistributionQueryMapper.CENTER_ID, "9905");
        return requestMap;
    }
}
