package gov.archives.core.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.ActionLogConf;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.vo.RoleMenuMapping;
import gov.archives.core.domain.vo.RoleName;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.security.access.intercept.FilterInvocationServiceSecurityMetadataSource;
import gov.archives.core.service.RoleService;
import gov.archives.core.service.UserInfoService;

/**
 * Created by tristan on 2016/8/2.
 */
@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.SYSTEM_TOOL_URL + CoreConf.ROLE_MANAGE_URL)
public class RoleController extends RestControllerBase {
    @Autowired
    private RoleService roleService;

    @Autowired
    private UserInfoService userService;

    @Autowired
    FilterInvocationServiceSecurityMetadataSource filterInvocationService;

    @RequestMapping(value = "/listRoleName",
            method = RequestMethod.GET)
    public Collection<RoleName> listRoleName(HttpServletRequest request) {

        try {
            Collection<RoleName> roleNameCollection = roleService.listRoleName();

            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_ROLE,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
            return roleNameCollection;
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_ROLE,
                    CoreErrorMessage.findByCode(CoreErrorCode.ROLE_VALUE_UPDATE),
                    CoreErrorCode.ROLE_VALUE_UPDATE, ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_UPDATE, e);
        }

    }

    @RequestMapping(value = "/roleList",
            method = RequestMethod.GET)
    public List<RoleEntity> roleList(HttpServletRequest request) {
        try {
            List<RoleEntity> roleNameList = roleService.getRoleList();
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_ROLE,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
            return roleNameList;
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_ROLE, CoreErrorMessage.findByCode(ActionLogConf.FAIL_MSG),
                    CoreErrorCode.ROLE_VALUE_UPDATE, ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_UPDATE, e);
        }
    }

    @RequestMapping(value = "/newRoleType",
            method = RequestMethod.POST)
    public void addRole(@RequestParam("status") Boolean status,
            @RequestParam("roleName") String roleName, HttpServletRequest request) {
        int activeStatus = (status) ? 1 : 0;
        RoleEntity roleEntity = new RoleEntity();

        try {
            if (roleService.getByRoleName(roleName) == null) {
                roleEntity.setSysId(UUID.randomUUID());
                roleEntity.setActiveStatus(activeStatus);
                roleEntity.setRoleName(roleName);
                roleEntity.initSave(userService.getCurrentAccount());
                roleService.insert(roleEntity);
                insertActionLogAndRsysLog(request, ActionLogConf.ADD_ROLE,
                        ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE
                        , ActionLogConf.EVENT_LEVEL_MEDIUM);
            }
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.ADD_ROLE,
                    CoreErrorMessage.findByCode(CoreErrorCode.ROLE_VALUE_UPDATE), CoreErrorCode.ROLE_VALUE_UPDATE,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_UPDATE, e);
        }
    }

    @RequestMapping(value = "/fixRoleType",
            method = RequestMethod.PUT)
    public void fixRole(@RequestParam("oldRoleName") String oldRoleName,
            @RequestParam("fixStatus") int fixStatus,
            @RequestParam("fixRoleName") String fixRoleName,
            HttpServletRequest request) {
        List<RoleEntity> sameList;
        RoleEntity roleList = roleService.getByRoleName(oldRoleName);
        RoleEntity roleEntity = new RoleEntity();
        try {
            roleEntity.setRoleName(fixRoleName);
            roleEntity.setSysId(roleList.getSysId());
            roleEntity.setActiveStatus(fixStatus);
            roleEntity.initUpdate(oldRoleName);
            sameList = roleService.getOtherList(roleEntity);
            if (roleList != null && sameList.isEmpty()) {
                roleService.update(roleEntity);
                filterInvocationService.createSecurityMetadataSource();
                insertActionLogAndRsysLog(request, ActionLogConf.UPDATE_ROLE,
                        ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);
            }
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.UPDATE_ROLE,
                    CoreErrorMessage.findByCode(CoreErrorCode.ROLE_VALUE_UPDATE), CoreErrorCode.ROLE_VALUE_UPDATE,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_UPDATE, e);
        }
    }

    @RequestMapping(value = "/choiceRole",
            method = RequestMethod.GET)
    public List<RoleMenuMapping> choiceRole(@RequestParam("SysId") UUID roleSysId,
            HttpServletRequest request) {
        List<RoleMenuMapping> roleMenuList = new ArrayList<RoleMenuMapping>();
        try {
            if (roleSysId != null) {
                roleMenuList.add(roleService.getMenuMappingByRoleSysId(roleSysId));
            }
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_ROLE,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
            return roleMenuList;
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_ROLE,
                    CoreErrorMessage.findByCode(CoreErrorCode.ROLE_VALUE_SEARCH),
                    CoreErrorCode.ROLE_VALUE_SEARCH, ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_SEARCH, e);
        }
    }

    @RequestMapping(value = "/menuConfig",
            method = RequestMethod.PUT)
    public void menuConfig(@RequestParam("roleSysId") UUID roleSysId,
            @RequestParam("menu") List<UUID> menu, HttpServletRequest request) {
        RoleMenuMapping roleMenuMapping = new RoleMenuMapping();
        try {
            roleMenuMapping = getRoleMenuMapping(roleSysId, menu);
            roleService.updateRoleMenuMapping(roleMenuMapping);
            filterInvocationService.createSecurityMetadataSource();
            insertActionLogAndRsysLog(request, ActionLogConf.UPDATE_MENU_CONFIG,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.UPDATE_MENU_CONFIG,
                    CoreErrorMessage.findByCode(CoreErrorCode.ROLE_VALUE_MENUMODIFY),
                    CoreErrorCode.ROLE_VALUE_MENUMODIFY,
                    ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_MENUMODIFY, e);
        }
    }

    private RoleMenuMapping getRoleMenuMapping(UUID roleSysId, List<UUID> menu) {

        RoleMenuMapping roleMenu = new RoleMenuMapping();
        List<MenuEntity> menuList = new ArrayList<MenuEntity>();
        RoleEntity role = new RoleEntity();

        role.setSysId(roleSysId);

        menu.stream()
            .forEach(sysId -> {
                MenuEntity menuEntity = new MenuEntity();
                menuEntity.setSysId(sysId);
                menuList.add(menuEntity);
            });
        roleMenu.setRole(role);
        roleMenu.setMenus(menuList);
        roleMenu.setCreatorAccount(userService.getCurrentAccount());

        return roleMenu;
    }
}
