package gov.archives.core.controller;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import com.google.common.collect.ImmutableMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.facade.RoleMenuMappingFacade;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.MenuService;

/**
 * MenuQueryMapper <br> (尚未描述類別目的與用途) <br> wtjiang, 2016/7/21.
 */
@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.CORE_BASE_URL)
public class MenuController extends RestControllerBase {
    public static final String GET_MENUS = "/menu";

    @Autowired
    private RoleMenuMappingFacade roleMenuMappingFacade;

    @Autowired
    MenuService menuService;

    @RequestMapping(value = GET_MENUS,
            method = RequestMethod.GET)
    public Map getRoleMenu(HttpServletRequest request) {
        try {
            String currentAccount =
                    convertBase64AuthToString(request.getSession().getAttribute("authorization").toString());

            Map roleMappingMenuMap = roleMenuMappingFacade.getRoleMappingMenu(currentAccount);
            return roleMappingMenuMap;
        } catch (Exception ex) {
            throw (ex instanceof ArchivesException) ? (ArchivesException) ex
                    : ArchivesException.getInstanceByErrorCode(CoreErrorCode.ACCOUNT_ERROR, ex);
        }
    }

    @RequestMapping(value = GET_MENUS + "/all",
            method = RequestMethod.GET)
    public Map getAllMenu() {
        try {
            Map allMenuMap = ImmutableMap.of("menu", menuService.getMenuTree());
            return allMenuMap;
        } catch (ArchivesException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_MENU_ERROR, e);

        }

    }

    @RequestMapping(value = "/rest/urlMap",
            method = RequestMethod.GET)
    public Map<String, String> getRestUrlMap() {
        return menuService.getMenuUrlMap();
    }

    private String convertBase64AuthToString(String authStr) throws UnsupportedEncodingException {
        return new String(Base64.getDecoder().decode(authStr.replace("Basic ", "")), "UTF-8").split(":")[0];
    }
}
