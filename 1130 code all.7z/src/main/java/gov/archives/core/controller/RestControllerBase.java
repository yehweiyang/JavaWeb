package gov.archives.core.controller;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.LogUtils;

public class RestControllerBase {
    protected static final String CACHE_DATE = "cacheData";
    private static final String UNKNOWN_ACCOUNT = "unknown";

    @Autowired
    protected ActionLogService actionLogService;

    @Autowired
    private UserInfoService userInfoService;

    protected ActionLogEntity initializeLogEntity(HttpServletRequest httpServletRequest, String actionModule,
            String resultMessage, String errorCode, String eventLevel) {
        return ActionLogEntity.Builder.create()
                                      .setActionItem(actionModule)
                                      .setActionResult(LogUtils.getErrorMessage(resultMessage))
                                      .setErrorCode(errorCode)
                                      .setEventLevel(eventLevel)
                                      .setActorAccount(getCurrentAccount(httpServletRequest))
                                      .setRemoteIp(httpServletRequest.getRemoteAddr())
                                      .setActionTime(new Timestamp(System.currentTimeMillis()))
                                      .build();
    }

    protected void insertActionLogAndRsysLog(HttpServletRequest httpServletRequest, String actionModule,
            String resultMessage, String errorCode, String eventLevel) {
        actionLogService.insertsAndRsysLog(
                initializeLogEntity(
                        httpServletRequest,
                        actionModule,
                        resultMessage,
                        errorCode,
                        eventLevel)
        );
    }

    protected void insertActionLog(HttpServletRequest httpServletRequest, String actionModule, String resultMessage,
            String errorCode, String eventLevel) {
        actionLogService.insert(
                initializeLogEntity(
                        httpServletRequest,
                        actionModule,
                        resultMessage,
                        errorCode,
                        eventLevel)
        );
    }


    protected boolean validateFiled(final String filed, String regex) {
        if (null != filed && 0 < filed.length()) {
            return Pattern.compile(regex).matcher(filed).matches();
        }
        return true;
    }

    protected boolean validateNotEmptyFiled(final String filed, String regex) {
        if (null != filed && 0 < filed.length()) {
            return Pattern.compile(regex).matcher(filed).matches();
        }
        return false;
    }

    protected String getCurrentAccount(HttpServletRequest request) {

        String currentAccount = userInfoService.getCurrentAccount();

        return null == request.getSession().getAttribute("authorization") ? "" :
                (currentAccount.equals(UNKNOWN_ACCOUNT) ?
                        getCurrentAccountNameBySession(request) : currentAccount);
    }

    private String getCurrentAccountNameBySession(HttpServletRequest request) {
        String rtnStr;
        try {
            String encodeStr = request.getSession().getAttribute("authorization").toString();
            rtnStr = new String(Base64.getDecoder().decode(encodeStr.replace("Basic ", "")), "UTF-8").split(":")[0];
        } catch (UnsupportedEncodingException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR, e);
        }
        return rtnStr;
    }

}
