package gov.archives.core.controller;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.PreconditionUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ChangeCertEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.security.DigitalSignHandle;
import gov.archives.core.service.ChangeCertService;
import gov.archives.core.service.UserInfoService;

import static gov.archives.core.conf.CoreConf.REST_API_VERSION;
import static gov.archives.core.conf.CoreConf.SYSTEM_TOOL_URL;

/**
 * ChangeCertController
 * <p>
 * Created by WeiYang on 2016/10/17.
 */
@RestController
@RequestMapping(path = REST_API_VERSION + SYSTEM_TOOL_URL + CoreConf.USER_MANAGE_URL)
public class ChangeCertController extends RestControllerBase {

    @Autowired
    private ChangeCertService changeCertService;
    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private DigitalSignHandle pkcs1Handle;

    @RequestMapping(value = "/modifyCert",
            method = RequestMethod.PUT)
    public void updateCert(@RequestBody ChangeCertEntity changeCertEntity, HttpServletRequest httpServletRequest) {
        try {
            PreconditionUtils.checkArguments(changeCertEntity);

            changeCertEntity.setModifierAccount(httpServletRequest.getRemoteUser());
            changeCertEntity.setModifiedTime(getTodayTimeStamp());
            changeCertEntity.setCertHash(getX509CertHash(changeCertEntity.getCertb64()));
            changeCertService.update(changeCertEntity);
        } catch (ArchivesException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.CARD_NOT_AVAILABLE, ex);
        }
    }

    @RequestMapping(value = "/queryCert",
            method = RequestMethod.GET)
    public Map<String, Object> queryCert(@RequestParam Map<String, Object> changeCertEntity) {
        Map<String, Object> map = new HashMap<>();
        try {
            UserInfoEntity user = userInfoService.getByAccount(MapUtils.getString(changeCertEntity, "account"));
            map.put("withOldCard",
                    getX509CertHash(MapUtils.getString(changeCertEntity, "certb64")).equals(user.getCertHash()));
        } catch (ArchivesException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.CARD_NOT_AVAILABLE, ex);
        }
        return map;
    }

    private Timestamp getTodayTimeStamp() {
        return Timestamp.valueOf(LocalDateTime.now().format(DateTimeFormatter.ofPattern(CoreConf.DATE_TIME_FORMAT)));
    }

    private String getX509CertHash(String cert64) {
        return pkcs1Handle.transBase64CertIntoX509Cert(cert64);
    }

}
