package gov.archives.core.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.AccountDetail;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.service.SessionManageService;

/**
 * Created by yflin on 10/3/16.
 */
@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.SESSION_URL)
public class SessionController {
    public static final String REST_SESSION_DETAIL = "/detail";

    @Autowired
    private SessionManageService sessionManageService;

    @RequestMapping(value = REST_SESSION_DETAIL)
    public ResponseEntity<AccountDetail> getAccountDetail(HttpServletRequest request) throws RestApplicationException {
        AccountDetail accountDetail = sessionManageService.getAccountDetail();
        if (null != accountDetail) {
            return new ResponseEntity<>(accountDetail, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(accountDetail, HttpStatus.NOT_FOUND);
        }
    }

    @RequestMapping(value = "/checkSessionId",
            method = RequestMethod.POST)
    public ResponseEntity checkAccountSessionId() {
        HttpStatus status = sessionManageService.checkAccountSessionId() ? HttpStatus.OK : HttpStatus.CONFLICT;
        return new ResponseEntity(status);
    }
}
