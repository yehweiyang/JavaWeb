package gov.archives.core.controller;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.validator.routines.RegexValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.ActionLogConf;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ModifyPersonDataEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.ModifyPersonDataVO;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.UserInfoService;

import static gov.archives.core.message.CoreErrorMessage.findByCode;

/**
 * Created by pywang on 2016/8/9.
 */

@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.SYSTEM_TOOL_URL + CoreConf.MODIFY_PERSON_DATA_URL)
public class ModifyPersonDataController extends RestControllerBase {

    @Autowired
    private UserInfoService userInfoService;



    @RequestMapping(value = "/getUser", method = RequestMethod.GET)
    public ModifyPersonDataVO getUser(HttpServletRequest request) {
        try {
            String account = userInfoService.getCurrentAccount();
            ModifyPersonDataEntity modifyPersonDataEntity = userInfoService.getAccountInfo(account);



            if (modifyPersonDataEntity.getLoginCount().isEmpty() || modifyPersonDataEntity.getLoginIP().isEmpty() ||
                    modifyPersonDataEntity.getLoginTime().isEmpty()) {
                insertActionLog(request, ActionLogConf.SEARCH_PERSON_DATA, CoreErrorCode.SEARCH_ERROR,
                        CoreErrorCode.SEARCH_ERROR, ActionLogConf.EVENT_LEVEL_HIGH);
                throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR);
            }

            ModifyPersonDataVO modifyPersonDataVO = getModifyPersonDataVo(modifyPersonDataEntity);

            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_PERSON_DATA,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);


            return modifyPersonDataVO;
        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_PERSON_DATA,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR),
                    CoreErrorCode.SEARCH_ERROR, ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR, e);
        }

    }

    @RequestMapping(value = "/modifyUser", method = RequestMethod.PUT)
    public Map<String, String> saveUser(@RequestBody ModifyPersonDataEntity user, HttpServletRequest request) {
        try {
            Map<String, String> saveResult = new HashMap<String, String>();
            if (null == user) {
                throw new RestApplicationException(HttpStatus.BAD_REQUEST);
            }
            String regexResult = verifySingleUserInfo(user);
            if (!regexResult.isEmpty()) {
                saveResult.put("result", regexResult);
                return saveResult;
            }

            userInfoService.update(getUserInfo(user));

            insertActionLogAndRsysLog(request, ActionLogConf.UPDATE_PERSON_DATA,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_MEDIUM);
            saveResult.put("result", "");
            return saveResult;

        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.UPDATE_PERSON_DATA,
                    CoreErrorMessage.findByCode(CoreErrorCode.UPDATE_ERROR),
                    CoreErrorCode.UPDATE_ERROR, ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.UPDATE_ERROR, e);
        }
    }

    private String verifySingleUserInfo(ModifyPersonDataEntity user) {
        RegexValidator alphaNumericNlsValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);


        String email = user.getEmail();
        if (null == email || !EmailValidator.getInstance().isValid(email)) {
            return findByCode(CoreErrorCode.EMAIL_FORMAT_INCORRECT);
        }
        if (!alphaNumericNlsValidator.isValid(user.getOrgInfo())) {
            return findByCode(CoreErrorCode.ORG_INFO_FORMAT_INCORRECT);
        }
        if (regexValidator(user.getPhoneAreaCode(), CoreConf.DIGIT_PATTERN)) {
            return findByCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }

        if (regexValidator(user.getPhoneLocalNumber(), CoreConf.DIGIT_PATTERN)) {
            return findByCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }

        if (regexValidator(user.getPhoneExtNumber(), CoreConf.DIGIT_EMPTY_PATTERN)) {
            return findByCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }

        if (regexValidator(user.getMobileAreaCode(), CoreConf.DIGIT_EMPTY_PATTERN)) {
            return findByCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }

        if (regexValidator(user.getMobileLocalNumber(), CoreConf.DIGIT_EMPTY_PATTERN)) {
            return findByCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }

        return "";
    }

    private Boolean regexValidator(String stringValue, String regexPattern) {
        RegexValidator regexValidator = new RegexValidator(regexPattern);
        if (null == stringValue || !regexValidator.isValid(stringValue)) {
            return true;
        }
        return false;
    }

    private UserInfoEntity getUserInfo(ModifyPersonDataEntity modifyPersonDataEntity) {
        UserInfoEntity userInfoEntity = userInfoService.getByAccount(userInfoService.getCurrentAccount());
        if (null == userInfoEntity) {
            throw new RestApplicationException(HttpStatus.BAD_REQUEST);
        }
        userInfoEntity.setPhoneAreaCode(modifyPersonDataEntity.getPhoneAreaCode());
        userInfoEntity.setPhoneExtNumber(modifyPersonDataEntity.getPhoneExtNumber());
        userInfoEntity.setPhoneLocalNumber(modifyPersonDataEntity.getPhoneLocalNumber());
        userInfoEntity.setMobileAreaCode(modifyPersonDataEntity.getMobileAreaCode());
        userInfoEntity.setMobileLocalNumber(modifyPersonDataEntity.getMobileLocalNumber());
        userInfoEntity.setEmail(modifyPersonDataEntity.getEmail());
        userInfoEntity.setOrgInfo(modifyPersonDataEntity.getOrgInfo());
        userInfoEntity.rebuildPhoneNumbers();
        userInfoEntity.initUpdate(userInfoService.getCurrentAccount());

        return userInfoEntity;
    }

    private ModifyPersonDataVO getModifyPersonDataVo(ModifyPersonDataEntity modifyPersonDataEntity) {
        ModifyPersonDataVO modifyPersonDataVO = new ModifyPersonDataVO();
        modifyPersonDataVO.setUserAccount(modifyPersonDataEntity.getAccount());
        modifyPersonDataVO.setAccountName(modifyPersonDataEntity.getUserName());
        modifyPersonDataVO.setPhoneAreaCode(modifyPersonDataEntity.getPhoneAreaCode());
        modifyPersonDataVO.setPhoneExtNumber(modifyPersonDataEntity.getPhoneExtNumber());
        modifyPersonDataVO.setPhoneLocalNumber(modifyPersonDataEntity.getPhoneLocalNumber());
        modifyPersonDataVO.setMobileAreaCode(modifyPersonDataEntity.getMobileAreaCode());
        modifyPersonDataVO.setMobileLocalNumber(modifyPersonDataEntity.getMobileLocalNumber());
        modifyPersonDataVO.setEmail(modifyPersonDataEntity.getEmail());
        modifyPersonDataVO.setOrgName(modifyPersonDataEntity.getOrgInfo());
        modifyPersonDataVO.setAccountLoginNum(modifyPersonDataEntity.getLoginCount());
        modifyPersonDataVO.setAccountLoginIP(modifyPersonDataEntity.getLoginIP());
        modifyPersonDataVO.setAccountLastTime(modifyPersonDataEntity.getLoginTime());

        return modifyPersonDataVO;
    }
}
