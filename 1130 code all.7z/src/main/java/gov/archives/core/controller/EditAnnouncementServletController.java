package gov.archives.core.controller;

import gov.archives.core.conf.ActionLogConf;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.accessor.ClientLogAccessor;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.ServletContextAware;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;

/**
 * Created by wtjiang on 2016/11/18.
 */
@Controller
@RequestMapping(path = CoreConf.SYSTEM_TOOL_URL + CoreConf.EDIT_ANNOUNCEMENT_URL)
public class EditAnnouncementServletController extends RestControllerBase implements ServletContextAware {

    private static final String DOWNLOAD = "/downLoad";
    private static final String HTML_FILE_NAME = "announcement";
    private static final String HTML_FILE_SUFFIX = ".html";
    private ServletContext servletContext;

    @Autowired
    private ClientLogAccessor clientLogAccessor;


    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @RequestMapping(value = {DOWNLOAD + "/" + HTML_FILE_NAME},
            method = {RequestMethod.GET, RequestMethod.POST})
    public void downLoadAnnouncementFile(HttpServletRequest request, HttpServletResponse response) {
        try {
            InputStream inputStream = clientLogAccessor.getProjectLocalFile(
                    getProjectLocalPath(), HTML_FILE_NAME, HTML_FILE_SUFFIX);

            response.setContentType("application/html");
            response.setHeader("Content-Disposition", "attachment; filename=" + HTML_FILE_NAME + HTML_FILE_SUFFIX);
            IOUtils.copy(inputStream, response.getOutputStream());
            response.flushBuffer();
            inputStream.close();
        } catch (Exception e) {
            initializeLogEntity(request, ActionLogConf.UPDATE_EDITANNOUNCEMENT,
                    CoreErrorCode.UPDATE_ERROR, CoreErrorCode.UPDATE_ERROR, ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.LOG_FILE_ERROR);
        }
    }

    private String getProjectLocalPath() {
        return servletContext.getRealPath("") + HTML_FILE_NAME + "/";
    }
}
