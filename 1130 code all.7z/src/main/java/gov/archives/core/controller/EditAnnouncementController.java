package gov.archives.core.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import gov.archives.exchange.accessor.ClientLogAccessor;
import gov.archives.exchange.conf.ReportConf;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.FileSystemUtils;

import gov.archives.core.conf.ActionLogConf;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.SystemAnnounceVO;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.SmartCardIdentityService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.EscapeUtils;
import org.springframework.web.context.ServletContextAware;

import static org.springframework.http.HttpStatus.CREATED;

@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + "/{systemTool}/{editAnnouncement}")
public class EditAnnouncementController extends RestControllerBase {
    private static final String HTML_TOP =
            "<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">"
                    + "<title></title></head><body><div>";
    private static final String HTML_BOTTOM = "</div></body></html>";
    private static final String HTML_FILE_NAME = "announcement";
    private static final String HTML_FILE_SUFFIX = ".html";
    private static final String REST_ANNOUNCE = "/announce";
    private static final String READ = "/read";


    private void transHtmlFile(File htmlFile, String notifyMessage) {
        try {
            String html = new String("".getBytes(), Charset.forName("UTF-8"));
            html += HTML_TOP;
            html += notifyMessage;
            html += HTML_BOTTOM;
            FileUtils.writeStringToFile(htmlFile, html, Charset.forName("UTF-8"));
        } catch (IOException e) {
            throw new ArchivesException(CoreErrorCode.FILE_SAVE_ERROR, e);
        }
    }

    public String readHtmlFile(File file) {
        String htmlString = null;
        try {
            if (FileSystemUtils.isExists(file)) {
                htmlString = FileUtils.readFileToString(file);
                int beginIndex = htmlString.indexOf("<div>") + "<div>".length();
                htmlString = htmlString.substring(beginIndex, htmlString.indexOf("</div>"));
                htmlString = StringEscapeUtils.unescapeHtml4(htmlString);
            }
        } catch (IOException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.DATA_NOT_FOUND, e);

        }
        return htmlString;
    }

    @RequestMapping(value = READ + REST_ANNOUNCE,
            method = RequestMethod.GET)
    public ResponseEntity<SystemAnnounceVO> readAnnouncement(HttpServletRequest request) {
        SystemAnnounceVO systemAnnounce = new SystemAnnounceVO();
        try {
            String realPath = request.getServletContext().getRealPath("") + HTML_FILE_NAME;
            String fileName = HTML_FILE_NAME + HTML_FILE_SUFFIX;
            systemAnnounce.setAnnounceMessage(readHtmlFile(new File(realPath, fileName)));
            insertActionLogAndRsysLog(request, ActionLogConf.SEARCH_EDITANNOUNCEMENT,
                    ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);

        } catch (ArchivesException e) {
            insertActionLog(request, ActionLogConf.SEARCH_EDITANNOUNCEMENT,
                    CoreErrorMessage.findByCode(CoreErrorCode.SEARCH_ERROR),
                    CoreErrorCode.SEARCH_ERROR, ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_ERROR, e);
        }
        return new ResponseEntity<>(systemAnnounce, CREATED);
    }

    @RequestMapping(value = REST_ANNOUNCE,
            method = RequestMethod.PUT)
    public ResponseEntity<Void> postAnnouncement(HttpServletRequest request, @RequestBody SystemAnnounceVO announce) {
        try {
            if (null == announce.getAnnounceMessage()) {
                throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR);
            } else {
                announce.setAnnounceMessage(EscapeUtils.escapeHtml(announce.getAnnounceMessage()));
                String realPath = request.getServletContext().getRealPath("") + HTML_FILE_NAME;
                FileSystemUtils.checkFolder(new File(realPath));
                String fileName = HTML_FILE_NAME + HTML_FILE_SUFFIX;
                transHtmlFile(new File(realPath, fileName), announce.getAnnounceMessage());
                initializeLogEntity(request, ActionLogConf.UPDATE_EDITANNOUNCEMENT,
                        ActionLogConf.SUCCESS_MSG, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
                return new ResponseEntity<>(CREATED);
            }
        } catch (ArchivesException e) {
            initializeLogEntity(request, ActionLogConf.UPDATE_EDITANNOUNCEMENT,
                    CoreErrorCode.UPDATE_ERROR, CoreErrorCode.UPDATE_ERROR, ActionLogConf.EVENT_LEVEL_HIGH);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.UPDATE_ERROR, e);
        }
    }
}
