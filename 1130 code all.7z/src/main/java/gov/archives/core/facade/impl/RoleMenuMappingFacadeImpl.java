package gov.archives.core.facade.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.common.collect.ImmutableMap;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.entity.RoleMenuMappingEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.TopMenuVo;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.facade.RoleMenuMappingFacade;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.MenuService;
import gov.archives.core.service.RoleMenuService;
import gov.archives.core.service.UserInfoService;

/**
 * Created by wtjiang on 2016/9/10.
 */
@Service
public class RoleMenuMappingFacadeImpl implements RoleMenuMappingFacade {

    @Autowired
    private MenuService menuService;

    @Autowired
    private RoleMenuService roleMenuService;

    @Autowired
    private UserInfoService userInfoService;

    @Override
    public List<MenuEntity> getRoleMenuFacade(String account) {

        UserInfoEntity userInfoEntity = userInfoService.getByAccount(account);

        if (userInfoEntity.getRoleSysId().equals(CoreConf.DEFAULT_ID)) {
            return new ArrayList();
        }

        List<RoleMenuMappingEntity> subMenuSysid = roleMenuService.getRoleMenuMappingListByRoleSysId(userInfoEntity.getRoleSysId());
        List<MenuEntity> subRoleMenu = new ArrayList<MenuEntity>();

        menuService.getAllMenu().stream().forEach(menu -> {
            subMenuSysid.forEach(subMenuByRoleId -> {
                if (menu.getSysId().equals(subMenuByRoleId.getMenuSysId())) {
                    subRoleMenu.add(menu);
                }
            });
        });

        return subRoleMenu;
    }

    @Override
    public Map getRoleMappingMenu(String account) {
        Map<Integer, TopMenuVo> resultMenu = menuService.getMenuTree(getRoleMenuFacade(account));

        if (MapUtils.isEmpty(resultMenu)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.DATA_NOT_FOUND);
        }

        return ImmutableMap.of("menu", resultMenu);
    }


}
