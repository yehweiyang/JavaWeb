package gov.archives.core.facade.impl;

import java.io.File;
import java.sql.Timestamp;
import java.util.Map;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import gov.archives.core.conf.ActionLogConf;
import gov.archives.core.controller.RestControllerBase;
import gov.archives.core.util.LogUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.AccountForm;
import gov.archives.core.domain.vo.VerifyResult;
import gov.archives.core.exception.BadCaptchaException;
import gov.archives.core.facade.DocumentExchangeServiceFacade;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.service.SmartCardIdentityService;
import gov.archives.core.service.UserInfoService;
// TODO: refactor this
@Transactional
@Service
public class DocumentExchangeServiceFacadeImpl extends RestControllerBase implements DocumentExchangeServiceFacade {
    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private SmartCardIdentityService smartCardIdentityService;

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            isolation = Isolation.REPEATABLE_READ,
            propagation = Propagation.REQUIRED,
            rollbackFor = AuthenticationException.class)
    public void accountRegister(AccountForm account, HttpServletRequest request, Map<String, Object> model)
            throws AuthenticationException {
        HttpSession session = request.getSession();
        UUID roleSysId = UUID.fromString("00000000-0000-0000-0000-000000000000");
        try {

            String captcha = request.getParameter("captcha");
            String CAPTCHA = (String) session.getAttribute("CAPTCHA");

            if (!CAPTCHA.equals(captcha)) {
                throw new BadCaptchaException(CoreErrorCode.CAPTCHA_ERROR);
            }
            UserInfoEntity user = userInfoService.getByAccount(account.getUserName());

            if ((null != user && user.getAccount().equals(account.getUserName()))) {
                throw new UsernameNotFoundException(CoreErrorCode.DUPLICATE_ACCOUNT);
            }
            File realFile = new File(request.getServletContext().getRealPath(""));
            String certSHA256Hash = smartCardIdentityService.saveRequestCertificate(account.getCertb64(),
                    realFile,
                    account.getCardNo(),
                    session.getLastAccessedTime());

            user = new UserInfoEntity();
            // save to database
            user.setAccount(account.getUserName());
            user.setUserName(account.getFullName());
            String userPhoneLocal = account.getPhonExt();
            if (userPhoneLocal.equals("null") || userPhoneLocal.equals("")) {
                user.setPhoneNumber(account.getPhoneLocal() + "-" + account.getPhoneNum());
            } else {
                user.setPhoneNumber(account.getPhoneLocal() + "-" + account.getPhoneNum() + "#" + account.getPhonExt());
            }
            user.setMobileNumber(account.getMobileLocal() + "-" + account.getMobileNum());
            user.setEmail(account.geteMailAddr());
            user.setCertCardNum(account.getCardNo());
            user.setCertHash(certSHA256Hash);
            user.setOrgInfo(" ");
            user.setActiveStatus(-1);
            user.setRoleSysId(roleSysId);
            user.setDeputyAccount("");
            user.initSave(account.getUserName());
            userInfoService.insert(user);

            documentExchangeActionLog(request, ActionLogConf.SUCCESS_MSG);
        } catch (AuthenticationException e) {
            VerifyResult verifyResult = smartCardIdentityService.userIdentityException(e);
            documentExchangeActionLog(request, CoreErrorCode.REGISTER_ACCOUNT_ERROR);
            model.put("errorMessage", verifyResult.getErrorMessage());
            throw new AuthenticationServiceException(verifyResult.getErrorMessage());
        }
        model.put("errorMessage", "申請流程處理中!!");
    }

    private void documentExchangeActionLog(HttpServletRequest request, String actionResult) {
        if (actionResult.equals(ActionLogConf.SUCCESS_MSG)) {
            insertActionLogAndRsysLog(request, ActionLogConf.REGISTER_ACCOUNT,
                    actionResult, ActionLogConf.SUCCESS_CODE, ActionLogConf.EVENT_LEVEL_LOW);
        } else {
            insertActionLog(request, ActionLogConf.REGISTER_ACCOUNT, actionResult,
                    actionResult, ActionLogConf.EVENT_LEVEL_HIGH);
        }
    }

}