package gov.archives.core.facade;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.AuthenticationException;

import gov.archives.core.domain.vo.AccountForm;

public interface DocumentExchangeServiceFacade {
	void accountRegister(AccountForm account, HttpServletRequest request, Map<String, Object> model) throws AuthenticationException;
}
