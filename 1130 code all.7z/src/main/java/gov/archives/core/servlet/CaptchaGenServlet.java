package gov.archives.core.servlet;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.archives.core.util.CaptchaUtils;
import gov.archives.core.util.LogUtils;

public class CaptchaGenServlet extends HttpServlet {
    private static final Logger log = LoggerFactory.getLogger(CaptchaGenServlet.class);
    private static final long serialVersionUID = 6410300413039495351L;
    private static final String FILE_TYPE = "jpeg";
    private static final int MIN_LENGTH = 4;
    private static final int MAX_LENGTH = 6;
    private static final String SALT_CHARS = "abcdefghijklmnopqrstuvwxyz";
    private static final int EXPIRE_TIME = 0;
    private static final int MAX_AGE = 0;
    private static final int WIDTH = 140;
    private static final int HEIGHT = 50;
    private static final Color BG_COLOR = new Color(238, 241, 245);
    private static final Color FG_COLOR = new Color(15, 15, 15);
    private static final Font FONT = new Font(Font.SANS_SERIF, 0, 30);
    private static final int INIT_X = 0;
    private static final int INIT_Y = 0;
    private static final int DRAW_X = 16;
    private static final int DRAW_Y = 30;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            processCaptcha(request, response);
        } catch (Exception e) {
            LogUtils.logException(e);
        }
    }

    private void processCaptcha(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        initResponse(response);

        String captchaStr = CaptchaUtils.generateCaptcha(MIN_LENGTH, MAX_LENGTH, SALT_CHARS);

        BufferedImage captcha = drawCaptcha(captchaStr);

        setCaptcha(request, captchaStr);

        responseCaptcha(response, captcha);

    }

    private void initResponse(HttpServletResponse response) {
        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expires", EXPIRE_TIME);
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Max-Age", MAX_AGE);
    }

    private BufferedImage drawCaptcha(String captchaStr) {

        BufferedImage cpimg = new BufferedImage(WIDTH, HEIGHT, BufferedImage.OPAQUE);

        Graphics g = cpimg.createGraphics();
        g.setFont(FONT);
        g.setColor(BG_COLOR);
        g.fillRect(INIT_X, INIT_Y, WIDTH, HEIGHT);
        g.setColor(FG_COLOR);
        g.drawString(captchaStr, DRAW_X, DRAW_Y);

        return cpimg;
    }

    private void setCaptcha(HttpServletRequest request, String captchaStr) {
        request.getSession(true).setAttribute("CAPTCHA", captchaStr);
    }

    private void responseCaptcha(HttpServletResponse response, BufferedImage captcha) throws IOException {
        OutputStream outputStream = response.getOutputStream();
        response.setContentType("image/jpeg");
        ImageIO.write(captcha, FILE_TYPE, outputStream);

        outputStream.close();
    }
}
