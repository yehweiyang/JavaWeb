package gov.archives.core.util;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import org.iii.common.util.StringUtils;

/**
 * Created by tristan on 2016/9/8.
 */
public class DateTimeUtils {
    public static String convertLocalFromUtcTime(String time) {
        return !StringUtils.isEmpty(time) ? DateTime.parse(time)
                                                    .withZone(DateTimeZone.forID("Asia/Taipei"))
                                                    .toString("yyyy-MM-dd HH:mm:ss") : "";
    }
}
