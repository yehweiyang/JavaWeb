package gov.archives.core.util;

import java.io.UnsupportedEncodingException;
import javax.crypto.Cipher;
import javax.xml.bind.DatatypeConverter;

import org.iii.common.util.PreconditionUtils;
import org.iii.security.conf.SecurityConfig;
import org.iii.security.hash.HashGenerator;
import org.iii.security.hash.HashGenerators;

import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.security.encrypt.CipherConf;
import gov.archives.core.security.encrypt.CipherFactory;

/**
 * Created by kshsu on 2016/9/22.
 */
public abstract class EncryptUtils {

    private EncryptUtils() {}

    public static String enCryptOrDeCrypt(String plainText, CipherConf.Method method, CipherConf.Mode mode)
            throws CoreException {

        PreconditionUtils.checkArguments(plainText, method, mode);
        Cipher cipher;
        String rtnStr;
        byte[] decryptedTextBytes;
        byte[] encryptedTextBytes;

        try {
            cipher = new CipherFactory().getInstance(method, mode);
            if (mode.equals(CipherConf.Mode.ENCRYPT)) {
                encryptedTextBytes = cipher.doFinal(plainText.getBytes(CipherConf.ENCODING));
                rtnStr = (null != encryptedTextBytes ? DatatypeConverter.printBase64Binary(encryptedTextBytes) : "");
            } else {
                decryptedTextBytes = cipher.doFinal(DatatypeConverter.parseBase64Binary(plainText));
                rtnStr = (null != decryptedTextBytes ? new String(decryptedTextBytes, CipherConf.ENCODING) : "");
            }
        } catch (Exception ex) {
            throw new CoreException(ex, CoreErrorCode.ENCRYPT_OR_DECRYPT_ERROR);
        }
        return rtnStr;
    }

    public static String txtToHash(String plainText) throws CoreException {

        PreconditionUtils.checkArguments(plainText);

        HashGenerator hashGenerator = HashGenerators.getInstanceByAlgorithm(SecurityConfig.ALGORITHM_SHA1);

        return hashGenerator.getHashByString(plainText);
    }

    public static String txtToBase64(String plainText) throws CoreException {
        PreconditionUtils.checkArguments(plainText);
        String rtnStr;
        byte[] outputBytes;
        try {
            outputBytes = plainText.getBytes(CipherConf.ENCODING);
            rtnStr = DatatypeConverter.printBase64Binary(outputBytes);
        } catch (UnsupportedEncodingException ex) {
            throw new CoreException(ex, CoreErrorCode.SYSTEM_ERROR);
        }

        return rtnStr;
    }

    public static String base64ToText(String plainText) throws CoreException {
        PreconditionUtils.checkArguments(plainText);
        String rtnStr;
        byte[] outputBytes;
        try {
            outputBytes = DatatypeConverter.parseBase64Binary(plainText);
            rtnStr = (null != outputBytes ? new String(outputBytes, CipherConf.ENCODING) : "");
        } catch (UnsupportedEncodingException ex) {
            throw new CoreException(ex, CoreErrorCode.SYSTEM_ERROR);
        }

        return rtnStr;
    }
}