package gov.archives.exchange.exception;

import java.io.File;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.conf.CommonConfig;

import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;


import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.MenuService;
import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.facade.ReportOutputFacade;
import gov.archives.core.service.MenuService;
import gov.archives.exchange.service.ReportServiceTest;

/**
 * Created by kshsu on 2016/8/15.
 * 測試報表底層的錯誤處理 (by Exception)
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class ReportExceptionTest {

    private static final Logger log = LoggerFactory.getLogger(ReportExceptionTest.class);

    /* 報表輸出格式 => 開始日 => 可變 */
    private static String PARAM_DATA_FROM = "2015/05/01";

    /* 報表輸出格式 => 結束日 => 可變 */
    private static String PARAM_DATA_TO = "2016/06/01";

    /* 報表輸出格式 => 可變 */
    private static final String REPORT_OUTPUT_TYPE = "pdf";

    /* 報表抬頭 => 可變*/
    private static String REPORT_TITLE = "報表抬頭";

    private static final String REPORT_TEMPLATE = "menuReport.jasper";
    private static final String REPORT_FOLDER = "reportTemplate";
    private static final String TEST_RESOURCES_FOLDER = "test-resources";
    private static final String REPORT_OUTPUT_FOLDER = "reportOutput";
    private static final String REPORT_OUTPUT_FILE_IS_NULL = "";

    @Autowired
    private MenuService menuService;

    @Autowired
    private ReportOutputFacade outputFacade;

    /* 報表參數 */
    private Map<String, Object> paramsMap;

    @Before
    public void setUp() throws Exception {

        Path outputFolder = CommonConfig.getRuntimeRoot(ReportServiceTest.class)
                                        .resolve(TEST_RESOURCES_FOLDER)
                                        .resolve(REPORT_OUTPUT_FOLDER);

        FileSystemUtils.checkFolder(outputFolder);

        /* 初始化 paramsMap 報表參數 */
        paramsMap = new HashMap<>();
        paramsMap.put("title", REPORT_TITLE);
        paramsMap.put("dateFrom", PARAM_DATA_FROM);
        paramsMap.put("dateTo", PARAM_DATA_TO);
    }

    @Test
    public void mainTest() {
        /* Exception Test */
        try {
            // errorMessage: 無法判斷的錯誤
            testReportException();
        } catch (CoreException e) {
            Assert.assertNotNull(e);
        }

        // errorMessage: ReportCommandProcessor Method 內部發生錯誤
        exportReport(REPORT_OUTPUT_FILE_IS_NULL, REPORT_OUTPUT_TYPE);
    }

    private void testReportException() throws CoreException {
        try {
            Class<?> clazz = Class.forName("");
        } catch (Exception ex) {
            Assert.assertNotNull(ex);
            throw new CoreException(ex, CoreErrorCode.REPORT_EXCEPTION_UNKNOWN);
        }
    }

    public void exportReport(String fileName, String exportType) {
        List<MenuEntity> menuEntities = menuService.getAllMenu();
        try {
            File reportTemplate =
                    Paths.get(IOUtils.loadResourceURLInClasspath(REPORT_FOLDER + "/" + REPORT_TEMPLATE).toURI())
                         .toFile();

            File reportOutput = CommonConfig.getRuntimeRoot(ReportServiceTest.class)
                                            .resolve(TEST_RESOURCES_FOLDER)
                                            .resolve(REPORT_OUTPUT_FOLDER)
                                            .resolve(fileName)
                                            .toFile();

            outputFacade.genReportToFile(
                    new ReportInputModel(reportTemplate.getAbsolutePath(), reportOutput.getAbsolutePath(), menuEntities,
                            paramsMap, exportType));

        } catch (Exception e) {
            log.error(StringUtils.stackTraceFromException(e));

            Assert.assertNotNull(e);
        }
    }
}
