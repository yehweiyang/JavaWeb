package gov.archives.exchange.facade;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.conf.CommonConfig;
import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.exchange.domain.entity.ReportSendRankResult;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.service.ReportDataGenService;

/**
 * Created by kshsu on 2016/8/15.
 * 測試報表底層的輸出功能 (by Facade)
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class ReportOutputFacadeTest {
    private static final Logger log = LoggerFactory.getLogger(ReportOutputFacadeTest.class);

    /* 報表輸出格式 => 開始日 => 可變 */
    private static String PARAM_DATA_FROM = "2015/05/01";

    /* 報表輸出格式 => 結束日 => 可變 */
    private static String PARAM_DATA_TO = "2016/06/01";

    /* 報表輸出格式 => 可變 */
    private static final String REPORT_OUTPUT_TYPE = "pdf";

    /* 報表樣板檔名 => 可變 */
    private static final String REPORT_TEMPLATE = "reportSendRank";

    /* 報表抬頭 => 可變*/
    private static String REPORT_TITLE = "報表抬頭XXX";

    @Autowired
    ReportOutputFacade reportOutputFacade;

    @Autowired
    private ReportDataGenService reportDataGenService;

    private ReportBaseFilter globalFilter;

    /* 報表樣板目錄 */
    private File reportTemplateFile;

    /* 報表參數 */
    private Map<String, Object> paramsMap;

    /* 報表輸出目錄 */
    private Path outputFolder;

    /* 報表輸出檔案 */
    private File reportOutput;

    /* 報表輸出串流 */
    private FileOutputStream fos;

    private List<ReportSendRankResult> reportSendRankResults;

    private static final String REPORT_FOLDER = "reportTemplate";
    private static final String TEST_RESOURCES_FOLDER = "test-resources";
    private static final String REPORT_OUTPUT_FOLDER = "reportOutput";

    @Before
    public void setUp() throws Exception {
        /* 初始化 globalFilter 資料 */
        globalFilter = new ReportBaseFilter();
        globalFilter.setDateFrom(PARAM_DATA_FROM);
        globalFilter.setDateTo(PARAM_DATA_TO);
        globalFilter.setSortColumnName("rowIndex");

        /* 初始化 paramsMap 報表參數 */
        paramsMap = new HashMap<>();
        paramsMap.put("title", REPORT_TITLE);
        paramsMap.put("dateFrom", PARAM_DATA_FROM);
        paramsMap.put("dateTo", PARAM_DATA_TO);

        /* 初始化輸出目錄 */
        Path outputFolder = CommonConfig.getRuntimeRoot(ReportOutputFacadeTest.class)
                                        .resolve(TEST_RESOURCES_FOLDER)
                                        .resolve(REPORT_OUTPUT_FOLDER);
        FileSystemUtils.checkFolder(outputFolder);

        Assert.assertNotNull(outputFolder);

        /* 初始化報表樣板目錄 .jasper */
        reportTemplateFile =
                Paths.get(IOUtils.loadResourceURLInClasspath(
                        REPORT_FOLDER + "/" + REPORT_TEMPLATE + CoreConf.SUFFIX_JASPER).toURI())
                     .toFile();

        Assert.assertNotNull(reportTemplateFile);

        /* 報表輸出檔案 */
        reportOutput = CommonConfig.getRuntimeRoot(ReportOutputFacadeTest.class)
                                   .resolve(TEST_RESOURCES_FOLDER)
                                   .resolve(REPORT_OUTPUT_FOLDER)
                                   .resolve(REPORT_TEMPLATE + ("pdf".equals(REPORT_OUTPUT_TYPE) ? CoreConf.SUFFIX_PDF :
                                           CoreConf.SUFFIX_ODS))
                                   .toFile();

        Assert.assertNotNull(reportOutput);

        fos = new FileOutputStream(reportOutput);
        Assert.assertNotNull(fos);
    }

    @Test
    public void mainTest() {
        try {
            reportSendRankResults = reportDataGenService.getReportSendRankByFilter(globalFilter);
            Assert.assertNotNull(reportSendRankResults);

            reportOutputFacade.genReportToFile(
                    new ReportInputModel(reportTemplateFile.getAbsolutePath(), reportOutput.getAbsolutePath(),
                            reportSendRankResults,
                            paramsMap, REPORT_OUTPUT_TYPE));
            exportReport(reportSendRankResults, REPORT_OUTPUT_TYPE, false);
            exportReport(reportSendRankResults, REPORT_OUTPUT_TYPE, true);
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));
            Assert.assertNull(ex);
        }
    }

    /* Export Report */
    private void exportReport(Object javaBean, String exportType, boolean testToStream) {
        try {
            if (!testToStream) {
                reportOutputFacade.genReportToFile(
                        new ReportInputModel(reportTemplateFile.getAbsolutePath(), reportOutput.getAbsolutePath(),
                                javaBean,
                                paramsMap, exportType));
            } else {
                reportOutputFacade.genReportToByteArray(
                        new ReportInputModel(reportTemplateFile.getAbsolutePath(), reportOutput.getAbsolutePath(),
                                javaBean,
                                paramsMap, fos, exportType));
                reportOutputFacade.genReportToStream(
                        new ReportInputModel(reportTemplateFile.getAbsolutePath(), reportOutput.getAbsolutePath(),
                                javaBean,
                                paramsMap, fos, exportType));
            }
        } catch (Exception e) {
            log.error(StringUtils.stackTraceFromException(e));
            Assert.assertNull(e);
        }
    }
}
