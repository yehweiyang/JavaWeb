package gov.archives.exchange.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import org.iii.common.util.DebugUtils;

import gov.archives.exchange.domain.vo.ReportBaseFilter;

/**
 * Created by jslee on 2016/11/24.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml",
        "classpath:spring-mvc.xml"})
@WebAppConfiguration
public class OtakuTest {

    @Autowired
    private ReportDataGenService reportDataGenService;

    @Test
    public void mainTest() {
        DebugUtils.dumpCollection(reportDataGenService.getReportSendRankByFilter(initReportBaseFilter()));
    }


    private ReportBaseFilter initReportBaseFilter() {
        ReportBaseFilter reportBaseFilter = new ReportBaseFilter();

        reportBaseFilter.setDateFrom("2016-04-01");
        reportBaseFilter.setDateTo("2016-06-01");
        reportBaseFilter.setSortColumnName("senderName");

        return reportBaseFilter;
    }

}
