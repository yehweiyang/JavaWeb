package gov.archives.exchange.service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.DebugUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;

/**
 * Created by jslee on 2016/9/30.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class RedundantSwitchTest {
    private static final Logger log = LoggerFactory.getLogger(RedundantSwitchTest.class);
    private static final String DEFAULT_CENTER_ID = "9905";
    private static final String DEFAULT_ACCOUNT = "Otaku";
    private static final UUID UPDATE_SYS_ID = CoreConf.DEFAULT_ID;
    private static final int activeStatus = 1;

    @Autowired
    private RedundantSwitchService redundantSwitchService;

    @Test
    public void fullTest() {
        try {
            deleteTest();
            createTest();
            updateTest();
            readTest();
        } catch (Exception e) {
            log.error(StringUtils.stackTraceFromException(e));
            Assert.assertNull(e);
        }
    }

    @Test
    public void createTest() {
        redundantSwitchService.addRedundantSwitchListByCurrentCenterId(prepareCreateMap());
    }

    @Test
    public void readTest() {
        DebugUtils.dumpCollection(redundantSwitchService.getRedundantSwitchByCurrentCenterId(DEFAULT_CENTER_ID));
    }

    @Test
    public void updateTest() {
        Map<String, Object> map = new HashMap<>();
        map.put("activeStatus", activeStatus);
        map.put("sysId", UPDATE_SYS_ID);
        redundantSwitchService.updateRedundantSwitchStatusById(map);
    }

    @Test
    public void deleteTest() {
        redundantSwitchService.clearEmptyRedundantSwitchByCurrentCenterId(DEFAULT_CENTER_ID);
    }

    private Map<String, Object> prepareCreateMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("curAccount", DEFAULT_ACCOUNT);
        map.put("curCenterId", DEFAULT_CENTER_ID);
        return map;
    }

}
