package gov.archives.exchange.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.exchange.domain.entity.TransmitDetailEntity;

import static gov.archives.exchange.service.DetailInfoService.*;
import static gov.archives.exchange.service.MainInfoService.*;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper.xml"})
public class DetailInfoServiceTest {
    private static final String TEST_EXCHANGE_SERIAL = "8927debc7059c25382093e11b313136e";

    @Autowired
    private DetailInfoService service;

    @Before
    public void setUp() throws Exception {}

    //@Test
    public void testGetTransmitDetailByMap() throws Exception {
        Map<String, Object> queryMap = new HashMap<>();
        queryMap.put(EXCHANGE_TYPE, INNER_TYPE);
        queryMap.put(EXCHANGE_SERIAL, TEST_EXCHANGE_SERIAL);
        List<TransmitDetailEntity> entityList = service.getTransmitDetailByMap(queryMap);
        Assert.assertNotNull(entityList);
    }
}
