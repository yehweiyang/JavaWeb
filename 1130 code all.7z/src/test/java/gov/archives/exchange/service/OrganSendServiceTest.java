package gov.archives.exchange.service;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.DebugUtils;

import gov.archives.exchange.mapper.query.OrganSendQueryMapper;

/**
 * Created by pywang on 2016/10/24.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class OrganSendServiceTest {

    @Autowired
    private OrganSendQueryMapper sendQueryMapper;

    @Autowired
    private OrganSendQueryMapper docSendMapper;

    private Map<String, Object> params;
    private Boolean isExactMatch;

    @Autowired
    private OrganSendService organSendService;

    @Test
    public void mainTest() {
        DebugUtils.dumpCollection(organSendService.getOrganSendByMap(new HashMap<>(), false));
        DebugUtils.dumpCollection(organSendService.getDocSendByMap(new HashMap<>()));
    }

}