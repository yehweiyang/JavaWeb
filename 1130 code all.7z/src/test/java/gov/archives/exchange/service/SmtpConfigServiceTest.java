package gov.archives.exchange.service;

import gov.archives.exchange.conf.ExchangeConf;
import org.iii.common.conf.CommonConfig;
import org.iii.common.util.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

/**
 * Created by wtjiang on 2016/9/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class SmtpConfigServiceTest {

    private static final String MAILSERVER_PROPERTIES = "mailServer.properties";

    private Properties prop;

    @Test
    public void smtpTest() {

        File testFile = CommonConfig.getRuntimeRoot(SmtpConfigServiceTest.class)
                .resolve("src/main/resources")
                .resolve(MAILSERVER_PROPERTIES).toFile();

            try {
                if (IOUtils.isFileExist(testFile)) {
                    prop = new Properties();
//                    testFile.createNewFile();
    //                prop.load(IOUtils.loadResourceInClasspath(MAILSERVER_PROPERTIES));
                    OutputStream fos = new FileOutputStream(testFile);
                    prop.setProperty(ExchangeConf.SMTP_SERVER_IP, "123");
                    prop.setProperty(ExchangeConf.SMTP_SERVER_PORT, "123");
                    prop.setProperty(ExchangeConf.SMTP_LOGIN_ACCOUNT, "123");
                    prop.setProperty(ExchangeConf.SMTP_ACCESS_NUMBER, "123");
                    prop.setProperty(ExchangeConf.SMTP_LAST_UPDATE, "123");
                    prop.setProperty(ExchangeConf.IS_USE_SSL, "123");
                    prop.setProperty(ExchangeConf.IS_NEED_CERTIFICATION, "123");
                    prop.store(fos, "SMTP Config 設定");
                    fos.flush();
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
                Assert.assertNull(e);
            }

//        System.out.println(testFile);
    }
}
