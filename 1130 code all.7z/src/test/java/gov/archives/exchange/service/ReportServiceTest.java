package gov.archives.exchange.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.conf.CommonConfig;
import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.exchange.domain.entity.ReportErrRankResult;
import gov.archives.exchange.domain.entity.ReportODFSendRateResult;
import gov.archives.exchange.domain.entity.ReportReceiveStatisticResult;
import gov.archives.exchange.domain.entity.ReportRecvErrListResult;
import gov.archives.exchange.domain.entity.ReportRecvListResult;
import gov.archives.exchange.domain.entity.ReportRecvStateResult;
import gov.archives.exchange.domain.entity.ReportSendErrListResult;
import gov.archives.exchange.domain.entity.ReportSendErrResult;
import gov.archives.exchange.domain.entity.ReportSendListResult;
import gov.archives.exchange.domain.entity.ReportSendRankResult;
import gov.archives.exchange.domain.entity.ReportSendStateResult;
import gov.archives.exchange.domain.entity.ReportSendStatisticResult;
import gov.archives.exchange.domain.entity.ReportSendUnConfmResult;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.domain.vo.ReportODFSendRateFilter;
import gov.archives.exchange.domain.vo.ReportRSStateFilter;
import gov.archives.exchange.domain.vo.ReportRecvErrListFilter;
import gov.archives.exchange.domain.vo.ReportRecvListFilter;
import gov.archives.exchange.domain.vo.ReportSendErrFilter;
import gov.archives.exchange.domain.vo.ReportSendErrListFilter;
import gov.archives.exchange.domain.vo.ReportSendListFilter;
import gov.archives.exchange.domain.vo.ReportSendUnConfmFilter;
import gov.archives.exchange.facade.ReportOutputFacade;

/**
 * Created by jslee on 2016/7/25. 測試各個報表的輸出資料 (by Report) 有真實產出檔案
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class ReportServiceTest {

    private static final Logger log = LoggerFactory.getLogger(ReportServiceTest.class);

    private static final String REPORT_FOLDER = "reportTemplate";
    private static final String TEST_RESOURCES_FOLDER = "test-resources";
    private static final String REPORT_OUTPUT_FOLDER = "reportOutput";

    /* 報表輸出格式 => 開始日 => 可變 */
    private static String PARAM_DATA_FROM = "2016-05-01";

    /* 報表輸出格式 => 結束日 => 可變 */
    private static String PARAM_DATA_TO = "2016-05-07";

    /* 報表輸出格式 => 起始時間 => 可變 */
    private static String PARAM_TIME_FROM = "00";

    /* 報表輸出格式 => 結束時間 => 可變 */
    private static String PARAM_TIME_TO = "12";

    /* 測試輸出到資料流(false => 產生測試檔案) => 可變 */
    private static boolean IS_EXPORT_REPORT_TO_STREAM = false;

    /* 報表抬頭 => 可變 */
    private static String REPORT_TITLE = "報表抬頭";

    /* 報表輸出型態 */
    private static String REPORT_OUTPUT_TYPE = "ods";

    private static String DEAULT_ORDER_COLUMN = "rowIndex";

    private static boolean DEAULT_ORDER_DESC = false;

    @Autowired
    private ReportDataGenService reportDataGenService;

    @Autowired
    private ReportOutputFacade outputFacade;

    /* Global ReportBaseFilter(查詢條件) */
    private ReportBaseFilter globalFilter;

    /* 報表參數 */
    private Map<String, Object> paramsMap;

    @Before
    public void setUp() throws Exception {
        Path outputFolder = CommonConfig.getRuntimeRoot(ReportServiceTest.class)
                                        .resolve(TEST_RESOURCES_FOLDER)
                                        .resolve(REPORT_OUTPUT_FOLDER);
        FileSystemUtils.checkFolder(outputFolder);

        globalFilter = new ReportBaseFilter();
        globalFilter.setDateFrom(PARAM_DATA_FROM);
        globalFilter.setDateTo(PARAM_DATA_TO);
        globalFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        globalFilter.setSortDescending(DEAULT_ORDER_DESC);

        paramsMap = new HashMap<>();
        paramsMap.put("title", REPORT_TITLE);
        paramsMap.put("dateFrom", PARAM_DATA_FROM);
        paramsMap.put("dateTo", PARAM_DATA_TO);
        paramsMap.put("createDate",
                new SimpleDateFormat(CoreConf.DATE_FORMAT).format(new Date()));
    }

    @Test
    public void mainTest() throws IOException, ClassNotFoundException, URISyntaxException {
        /* PRN001 Test */
        testPRN001();

        /* PRN002 Test */
        testPRN002();

        /* PRN003 Test */
        /* Receive Part */
        testPRN003Receive();

        /* Send Part */
        testPRN003Send();

        /* PRN004 Test */
        testPRN004();

        /* PRN005 Test*/
        testPRN005();

        /* PRN006 Test */
        testPRN006();

        /* PRN007 Test */
        testPRN007();

        /* PRN008 Test */
        testPRN008();

        /* PRN009 Test */
        testPRN009();

        /* PRN010 Test */
        testPRN010();

        /* PRN011 Test */
        testPRN011();

        /* PRN013 Test */
        testPRN013();

    }

    private void testPRN001() {
        List<ReportSendRankResult> sendRankResults = reportDataGenService.getReportSendRankByFilter(globalFilter);
        exportReport(sendRankResults, ReportEnum.REPORT_SEND_RANK.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN002() {
        List<ReportErrRankResult> errRankResults = reportDataGenService.getReportErrRankByFilter(globalFilter);
        exportReport(errRankResults, ReportEnum.REPORT_ERR_RANK.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN003Receive() {
        List<ReportReceiveStatisticResult> receiveStatisticResults =
                reportDataGenService.getReportReceiveStatisticByRSStateFilter(initReportRSStateFilter());
        exportReport(receiveStatisticResults, ReportEnum.REPORT_R_STATE_STATIC.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN003Send() {
        List<ReportSendStatisticResult> sendStatisticResults =
                reportDataGenService.getReportSendStatisticByRSStateFilter(initReportRSStateFilter());
        exportReport(sendStatisticResults, ReportEnum.REPORT_S_STATE_STATIC.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN004() {
        List<ReportSendErrResult> sendErrResults =
                reportDataGenService.getReportSendErrBySendErrFilter(initReportSendErrFilter());
        exportReport(sendErrResults, ReportEnum.REPORT_SEND_ERR.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN005() {
        List<ReportSendStateResult> sendStateResults = reportDataGenService.getReportSendStateByFilter(globalFilter);
        exportReport(sendStateResults, ReportEnum.REPORT_SEND_STATE.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN006() {
        List<ReportSendListResult> sendListResults =
                reportDataGenService.getReportSendListBySendListFilter(initReportSendListFilter());
        exportReport(sendListResults, ReportEnum.REPORT_SEND_LIST.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);

    }

    private void testPRN007() {
        List<ReportSendUnConfmResult> sendUnConfmResults =
                reportDataGenService.getReportSendUnConfmBySendUnConfomFilter(initReportSendUnConfmFilter());
        exportReport(sendUnConfmResults, ReportEnum.REPORT_SEND_UNCONFIRM.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN008() {
        List<ReportSendErrListResult> sendErrListResults =
                reportDataGenService.getReportSendErrListBySendErrListFilter(initReportSendErrListFilter());
        exportReport(sendErrListResults, ReportEnum.REPORT_SEND_ERR_LIST.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN009() {
        List<ReportRecvStateResult> recvStateResults = reportDataGenService.getReportRecvStateByFilter(globalFilter);
        exportReport(recvStateResults, ReportEnum.REPORT_RECEIVE_STATE.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN010() {
        List<ReportRecvListResult> recvListResults =
                reportDataGenService.getReportRecvListByRecvListFilter(initReportRecvListFilter());
        exportReport(recvListResults, ReportEnum.REPORT_RECEIVE_LIST.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN011() {
        List<ReportRecvErrListResult> recvErrListResults =
                reportDataGenService.getReportRecvErrListByRecvErrListFilter(initReportRecvErrListFilter());
        exportReport(recvErrListResults, ReportEnum.REPORT_RECEIVE_ERR_LIST.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    private void testPRN013() {
        List<ReportODFSendRateResult> odfSendRateResultList =
                reportDataGenService.getReportODFSendRateByODFSendRateFilter(initReportODFSendRateFilter());
        exportReport(odfSendRateResultList, ReportEnum.REPORT_ODF_SEND_RATE.toString(), REPORT_OUTPUT_TYPE,
                IS_EXPORT_REPORT_TO_STREAM);
    }

    /* PRN003 Filter */
    private ReportRSStateFilter initReportRSStateFilter() {
        ReportRSStateFilter rsStateFilter = new ReportRSStateFilter();
        rsStateFilter.setDateFrom(PARAM_DATA_FROM);
        rsStateFilter.setDateTo(PARAM_DATA_TO);
        rsStateFilter.setTimeFrom(PARAM_TIME_FROM);
        rsStateFilter.setTimeTo(PARAM_TIME_TO);
        rsStateFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        rsStateFilter.setSortDescending(DEAULT_ORDER_DESC);
        return rsStateFilter;
    }

    /* PRN004 Filter */
    private ReportSendErrFilter initReportSendErrFilter() {
        ReportSendErrFilter sendErrFilter = new ReportSendErrFilter();
        sendErrFilter.setDateFrom(PARAM_DATA_FROM);
        sendErrFilter.setDateTo(PARAM_DATA_TO);
        sendErrFilter.setTimeFrom(PARAM_TIME_FROM);
        sendErrFilter.setTimeTo(PARAM_TIME_TO);
        sendErrFilter.setContentFullCmp(false);
        sendErrFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        sendErrFilter.setSortDescending(DEAULT_ORDER_DESC);
        return sendErrFilter;
    }

    /* PRN006 Filter */
    private ReportSendListFilter initReportSendListFilter() {
        ReportSendListFilter sendListFilter = new ReportSendListFilter();
        sendListFilter.setDateFrom(PARAM_DATA_FROM);
        sendListFilter.setDateTo(PARAM_DATA_TO);
        sendListFilter.setTimeFrom(PARAM_TIME_FROM);
        sendListFilter.setTimeTo(PARAM_TIME_TO);
        sendListFilter.setContentFullCmp(false);
        sendListFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        sendListFilter.setSortDescending(DEAULT_ORDER_DESC);
        return sendListFilter;
    }

    /* PRN007 Filter */
    private ReportSendUnConfmFilter initReportSendUnConfmFilter() {
        ReportSendUnConfmFilter sendUnConfmFilter = new ReportSendUnConfmFilter();
        sendUnConfmFilter.setDateFrom(PARAM_DATA_FROM);
        sendUnConfmFilter.setDateTo(PARAM_DATA_TO);
        sendUnConfmFilter.setTimeFrom(PARAM_TIME_FROM);
        sendUnConfmFilter.setTimeTo(PARAM_TIME_TO);
        sendUnConfmFilter.setContentFullCmp(false);
        sendUnConfmFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        sendUnConfmFilter.setSortDescending(DEAULT_ORDER_DESC);
        return sendUnConfmFilter;
    }

    /* PRN008 Filter */
    private ReportSendErrListFilter initReportSendErrListFilter() {
        ReportSendErrListFilter sendErrListFilter = new ReportSendErrListFilter();
        sendErrListFilter.setDateFrom(PARAM_DATA_FROM);
        sendErrListFilter.setDateTo(PARAM_DATA_TO);
        sendErrListFilter.setTimeFrom(PARAM_TIME_FROM);
        sendErrListFilter.setTimeTo(PARAM_TIME_TO);
        sendErrListFilter.setContentFullCmp(false);
        sendErrListFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        sendErrListFilter.setSortDescending(DEAULT_ORDER_DESC);
        return sendErrListFilter;

    }

    /* PRN010 Filter */
    private ReportRecvListFilter initReportRecvListFilter() {
        ReportRecvListFilter recvListFilter = new ReportRecvListFilter();
        recvListFilter.setDateFrom(PARAM_DATA_FROM);
        recvListFilter.setDateTo(PARAM_DATA_TO);
        recvListFilter.setTimeFrom(PARAM_TIME_FROM);
        recvListFilter.setTimeTo(PARAM_TIME_TO);
        recvListFilter.setContentFullCmp(false);
        recvListFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        recvListFilter.setSortDescending(DEAULT_ORDER_DESC);
        return recvListFilter;
    }

    /* PRN011 Filter */
    private ReportRecvErrListFilter initReportRecvErrListFilter() {
        ReportRecvErrListFilter recvListFilter = new ReportRecvErrListFilter();
        recvListFilter.setDateFrom(PARAM_DATA_FROM);
        recvListFilter.setDateTo(PARAM_DATA_TO);
        recvListFilter.setTimeFrom(PARAM_TIME_FROM);
        recvListFilter.setTimeTo(PARAM_TIME_TO);
        recvListFilter.setContentFullCmp(false);
        recvListFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        recvListFilter.setSortDescending(DEAULT_ORDER_DESC);
        return recvListFilter;
    }

    /* PRN013 Filter */
    private ReportODFSendRateFilter initReportODFSendRateFilter() {
        ReportODFSendRateFilter odfSendRateFilter = new ReportODFSendRateFilter();
        odfSendRateFilter.setDateFrom(PARAM_DATA_FROM);
        odfSendRateFilter.setDateTo(PARAM_DATA_TO);
        odfSendRateFilter.setContentFullCmp(false);
        odfSendRateFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        odfSendRateFilter.setSortDescending(DEAULT_ORDER_DESC);
        return odfSendRateFilter;
    }

    /* Export Report */
    private void exportReport(Object javaBean, String reportTemplate, String exportType, boolean testToStream) {
        try {
            File reportTemplateFile =
                    Paths.get(IOUtils.loadResourceURLInClasspath(
                            REPORT_FOLDER + "/" + reportTemplate + CoreConf.SUFFIX_JASPER).toURI())
                         .toFile();
            File reportOutput = CommonConfig.getRuntimeRoot(ReportServiceTest.class)
                                            .resolve(TEST_RESOURCES_FOLDER)
                                            .resolve(REPORT_OUTPUT_FOLDER)
                                            .resolve(reportTemplate + ("pdf".equals(exportType) ? CoreConf.SUFFIX_PDF :
                                                    CoreConf.SUFFIX_ODS))
                                            .toFile();
            if (!testToStream) {
                outputFacade.genReportToFile(
                        new ReportInputModel(reportTemplateFile.getAbsolutePath(), reportOutput.getAbsolutePath(),
                                javaBean,
                                paramsMap, exportType));
            } else {
                FileOutputStream fos = new FileOutputStream(reportOutput);
                outputFacade.genReportToByteArray(
                        new ReportInputModel(reportTemplateFile.getAbsolutePath(), reportOutput.getAbsolutePath(),
                                javaBean,
                                paramsMap, fos, exportType));
                outputFacade.genReportToStream(
                        new ReportInputModel(reportTemplateFile.getAbsolutePath(), reportOutput.getAbsolutePath(),
                                javaBean,
                                paramsMap, fos, exportType));
            }
        } catch (Exception e) {
            log.error(StringUtils.stackTraceFromException(e));
            Assert.assertNull(e);
        }
    }

}
