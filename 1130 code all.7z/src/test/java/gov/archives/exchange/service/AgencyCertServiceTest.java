package gov.archives.exchange.service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.conf.CommonConfig;
import org.iii.common.util.IOUtils;

import gov.archives.core.TestConf;
import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.exchange.accessor.ClientLogAccessor;
import gov.archives.exchange.conf.ExchangeConf;
import gov.archives.exchange.mapper.query.AgencyCertQueryMapper;

/**
 * AgencyCertServiceTest
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * wtjiang, 2016/8/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class AgencyCertServiceTest {
    private static final Logger log = LoggerFactory.getLogger(AgencyCertServiceTest.class);

    private static final String TEST_CLIENT_LOG_FOLDER = "clientLog";
    private static final String TEST_LOG_FILE = "eClient.ini";

    private static final String MANAGE_WEB_PROPERTIES = "manageWeb.properties";
    private static final String PROP_CLIENT_LOG = "client.log.location";

    @Autowired
    private AgencyCertQueryMapper accessorQueryMapper;

    private Properties prop;
    private List<File> files;

    @Autowired
    private ClientLogAccessor clientLogAccessor;

    @Before
    public void setUp() throws Exception {
        prop = new Properties();

        prop.load(IOUtils.loadResourceInClasspath(MANAGE_WEB_PROPERTIES));

        files = Arrays.asList(CommonConfig.getRuntimeRoot(AgencyCertServiceTest.class)
                                          .resolve(TestConf.TEST_RESOURCES_FOLDER)
                                          .resolve(TEST_CLIENT_LOG_FOLDER).toFile().listFiles());
    }

    @Test
    public void testGetClientLog() throws Exception {
        Path testFile =
                CommonConfig.getRuntimeRoot(AgencyCertServiceTest.class)
                            .resolve(TestConf.TEST_RESOURCES_FOLDER)
                            .resolve(TEST_CLIENT_LOG_FOLDER)
                            .resolve(TEST_LOG_FILE);

        File logFile = testFile.toFile();

        files = Arrays.asList(CommonConfig.getRuntimeRoot(AgencyCertServiceTest.class)
                                          .resolve(TestConf.TEST_RESOURCES_FOLDER)
                                          .resolve(TEST_CLIENT_LOG_FOLDER).toFile().listFiles());

        File propertiesFile = new File(IOUtils.loadResourceURLInClasspath(MANAGE_WEB_PROPERTIES).toURI());



        log.info("client log: " + prop.getProperty(PROP_CLIENT_LOG));
    }

    @Test
    public void testGetLinuxFile() throws Exception {
        File propertiesFile = new File(IOUtils.loadResourceURLInClasspath(MANAGE_WEB_PROPERTIES).toURI());

        for (int i = 0; i < files.size(); i++) {
            System.out.println(files.get(i));
        }
    }
}
