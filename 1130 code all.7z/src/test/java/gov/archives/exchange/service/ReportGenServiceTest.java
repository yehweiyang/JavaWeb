package gov.archives.exchange.service;

import java.util.Collection;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import org.iii.common.util.DebugUtils;

import gov.archives.exchange.domain.entity.ReportConFirmedDataResult;
import gov.archives.exchange.domain.entity.ReportErrRankResult;
import gov.archives.exchange.domain.entity.ReportODFSendRateResult;
import gov.archives.exchange.domain.entity.ReportReceiveStatisticResult;
import gov.archives.exchange.domain.entity.ReportRecvErrListResult;
import gov.archives.exchange.domain.entity.ReportRecvListResult;
import gov.archives.exchange.domain.entity.ReportRecvStateResult;
import gov.archives.exchange.domain.entity.ReportSendErrListResult;
import gov.archives.exchange.domain.entity.ReportSendErrResult;
import gov.archives.exchange.domain.entity.ReportSendListResult;
import gov.archives.exchange.domain.entity.ReportSendRankResult;
import gov.archives.exchange.domain.entity.ReportSendStateResult;
import gov.archives.exchange.domain.entity.ReportSendStatisticResult;
import gov.archives.exchange.domain.entity.ReportSendUnConfmResult;
import gov.archives.exchange.domain.vo.ReportConFirmedDataFilter;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportODFSendRateFilter;
import gov.archives.exchange.domain.vo.ReportRSStateFilter;
import gov.archives.exchange.domain.vo.ReportRecvErrListFilter;
import gov.archives.exchange.domain.vo.ReportRecvListFilter;
import gov.archives.exchange.domain.vo.ReportSendErrFilter;
import gov.archives.exchange.domain.vo.ReportSendErrListFilter;
import gov.archives.exchange.domain.vo.ReportSendListFilter;
import gov.archives.exchange.domain.vo.ReportSendUnConfmFilter;

/**
 * Created by kshsu on 2016/8/15. 測試各個報表的輸出資料 (by Report) 無真實產出檔案
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml",
        "classpath:spring-mvc.xml"})
@WebAppConfiguration
public class ReportGenServiceTest {
    private static final Logger log = LoggerFactory.getLogger(ReportGenServiceTest.class);

    /* 報表輸出格式 => 開始日 => 可變 */
    private static String PARAM_DATA_FROM = "2015-05-01";

    /* 報表輸出格式 => 結束日 => 可變 */
    private static String PARAM_DATA_TO = "2016-06-01";

    /* 報表輸出格式 => 起始時間 => 可變 */
    private static String PARAM_TIME_FROM = "00";

    /* 報表輸出格式 => 結束時間 => 可變 */
    private static String PARAM_TIME_TO = "12";

    /* 完全比對 => 可變 */
    private static boolean CONTENT_FULL_COMPARE = true;

    /* 發文機關名稱 => 可變 */
    private static String SENDER_NAME = "eclient教育訓練四五";

    /* 列印出結果資料 => 可變 */
    private static boolean IS_DUMP_RESULT = false;

    private static String DEAULT_ORDER_COLUMN = "rowIndex";

    private static boolean DEAULT_ORDER_DESC = false;

    @Autowired
    private ReportDataGenService reportDataGenService;

    /* Golbal ReportBaseFilter(查詢條件) */
    private ReportBaseFilter globalFilter;

    /* Filters */
    /* PRN003 */
    private ReportRSStateFilter reportRSStateFilter;

    /* PRN004 */
    private ReportSendErrFilter reportSendErrFilter;

    /* PRN006 */
    private ReportSendListFilter reportSendListFilter;

    /* PRN007 */
    private ReportSendUnConfmFilter reportSendUnConfmFilter;

    /* PRN008 */
    private ReportSendErrListFilter reportSendErrListFilter;

    /* PRN010 */
    private ReportRecvListFilter reportRecvListFilter;

    /* PRN011 */
    private ReportRecvErrListFilter reportRecvErrListFilter;

    /* PRN012 */
    private ReportConFirmedDataFilter reportConFirmedDataFilter;

    /* PRN013 */
    private ReportODFSendRateFilter reportODFSendRateFilter;


    /* 報表產出的資料 */
    private List<ReportSendRankResult> reportSendRankResults;
    private List<ReportErrRankResult> reportErrRankResults;
    private List<ReportReceiveStatisticResult> reportReceiveStatisticResults;
    private List<ReportSendStatisticResult> reportSendStatisticResults;
    private List<ReportSendErrResult> reportSendErrResults;
    private List<ReportSendStateResult> reportSendStateResults;
    private List<ReportSendListResult> reportSendListResults;
    private List<ReportSendUnConfmResult> reportSendUnConfmResults;
    private List<ReportSendErrListResult> reportSendErrListResults;
    private List<ReportRecvStateResult> reportRecvStateResults;
    private List<ReportRecvListResult> reportRecvListResults;
    private List<ReportRecvErrListResult> reportRecvErrListResults;
    private List<ReportConFirmedDataResult> reportConFirmedDataResults;
    private List<ReportODFSendRateResult> reportODFSendRateResults;

    @Before
    public void setUp() throws Exception {
        setUpGlobalData();
        setUpPrn003Data();
        setUpPrn004Data();
        setUpPrn006Data();
        setUpPrn007Data();
        setUpPrn008Data();
        setUpPrn010Data();
        setUpPrn011Data();
        setUpPrn012Data();
        setUpPrn013Data();
    }

    @Test
    public void mainTest() {
        prn001Test();
        prn002Test();
        prn003ReceiveTest();
        prn003SendTest();
        prn004Test();
        prn005Test();
        prn006Test();
        prn007Test();
        prn008Test();
        prn009Test();
        prn010Test();
        prn011Test();
        prn012Test();
        prn013Test();
    }

    private void prn001Test() {
        reportSendRankResults = reportDataGenService.getReportSendRankByFilter(globalFilter);
        dumpCollection(reportErrRankResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportSendRankResults);
    }

    private void prn002Test() {
        reportErrRankResults = reportDataGenService.getReportErrRankByFilter(globalFilter);
        dumpCollection(reportErrRankResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportErrRankResults);
    }

    private void prn003ReceiveTest() {
        reportReceiveStatisticResults =
                reportDataGenService.getReportReceiveStatisticByRSStateFilter(reportRSStateFilter);
        dumpCollection(reportReceiveStatisticResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportReceiveStatisticResults);
    }

    private void prn003SendTest() {
        reportSendStatisticResults = reportDataGenService.getReportSendStatisticByRSStateFilter(reportRSStateFilter);
        dumpCollection(reportSendStatisticResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportSendStatisticResults);
    }

    private void prn004Test() {
        reportSendErrResults = reportDataGenService.getReportSendErrBySendErrFilter(reportSendErrFilter);
        dumpCollection(reportSendErrResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportSendErrResults);
    }

    private void prn005Test() {
        reportSendStateResults = reportDataGenService.getReportSendStateByFilter(globalFilter);
        dumpCollection(reportSendStateResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportSendStateResults);
    }

    private void prn006Test() {
        reportSendListResults = reportDataGenService.getReportSendListBySendListFilter(reportSendListFilter);
        dumpCollection(reportSendListResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportSendListResults);
    }

    private void prn007Test() {
        reportSendUnConfmResults =
                reportDataGenService.getReportSendUnConfmBySendUnConfomFilter(reportSendUnConfmFilter);
        dumpCollection(reportSendUnConfmResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportSendUnConfmResults);
    }

    private void prn008Test() {
        reportSendErrListResults =
                reportDataGenService.getReportSendErrListBySendErrListFilter(reportSendErrListFilter);
        dumpCollection(reportSendErrListResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportSendErrListResults);
    }

    private void prn009Test() {
        reportRecvStateResults = reportDataGenService.getReportRecvStateByFilter(globalFilter);
        dumpCollection(reportRecvStateResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportRecvStateResults);
    }

    private void prn010Test() {
        reportRecvListResults = reportDataGenService.getReportRecvListByRecvListFilter(reportRecvListFilter);
        dumpCollection(reportRecvListResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportRecvListResults);
    }

    private void prn011Test() {
        reportRecvErrListResults =
                reportDataGenService.getReportRecvErrListByRecvErrListFilter(reportRecvErrListFilter);
        dumpCollection(reportRecvErrListResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportRecvErrListResults);
    }

    private void prn012Test() {
        reportConFirmedDataResults =
                reportDataGenService.getReportConFirmedDataResultByConFirmedDataFilter(reportConFirmedDataFilter);
        dumpCollection(reportConFirmedDataResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportConFirmedDataResults);
    }

    private void prn013Test() {
        reportODFSendRateResults =
                reportDataGenService.getReportODFSendRateByODFSendRateFilter(reportODFSendRateFilter);
        dumpCollection(reportODFSendRateResults, IS_DUMP_RESULT);
        Assert.assertNotNull(reportODFSendRateResults);
    }


    //init Data
    private void setUpGlobalData() {
        globalFilter = new ReportBaseFilter();
        globalFilter.setDateFrom(PARAM_DATA_FROM);
        globalFilter.setDateTo(PARAM_DATA_TO);
        globalFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        globalFilter.setSortDescending(DEAULT_ORDER_DESC);
    }

    private void setUpPrn003Data() {
        reportRSStateFilter = new ReportRSStateFilter();
        reportRSStateFilter.setDateFrom(PARAM_DATA_FROM);
        reportRSStateFilter.setDateTo(PARAM_DATA_TO);
        reportRSStateFilter.setTimeFrom(PARAM_TIME_FROM);
        reportRSStateFilter.setTimeTo(PARAM_TIME_TO);
        reportRSStateFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        reportRSStateFilter.setSortDescending(DEAULT_ORDER_DESC);
    }

    private void setUpPrn004Data() {
        reportSendErrFilter = new ReportSendErrFilter();
        reportSendErrFilter.setDateFrom(PARAM_DATA_FROM);
        reportSendErrFilter.setDateTo(PARAM_DATA_TO);
        reportSendErrFilter.setTimeFrom(PARAM_TIME_FROM);
        reportSendErrFilter.setTimeTo(PARAM_TIME_TO);
        reportSendErrFilter.setContentFullCmp(CONTENT_FULL_COMPARE);
        reportSendErrFilter.setSenderName(SENDER_NAME);
        reportSendErrFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        reportSendErrFilter.setSortDescending(DEAULT_ORDER_DESC);
    }

    private void setUpPrn006Data() {
        reportSendListFilter = new ReportSendListFilter();
        reportSendListFilter.setDateFrom(PARAM_DATA_FROM);
        reportSendListFilter.setDateTo(PARAM_DATA_TO);
        reportSendListFilter.setTimeFrom(PARAM_TIME_FROM);
        reportSendListFilter.setTimeTo(PARAM_TIME_TO);
        reportSendListFilter.setContentFullCmp(CONTENT_FULL_COMPARE);
        reportSendListFilter.setSenderName(SENDER_NAME);
        reportSendListFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        reportSendListFilter.setSortDescending(DEAULT_ORDER_DESC);
    }

    private void setUpPrn007Data() {
        reportSendUnConfmFilter = new ReportSendUnConfmFilter();
        reportSendUnConfmFilter.setDateFrom(PARAM_DATA_FROM);
        reportSendUnConfmFilter.setDateTo(PARAM_DATA_TO);
        reportSendUnConfmFilter.setTimeFrom(PARAM_TIME_FROM);
        reportSendUnConfmFilter.setTimeTo(PARAM_TIME_TO);
        reportSendUnConfmFilter.setContentFullCmp(CONTENT_FULL_COMPARE);
        reportSendUnConfmFilter.setSenderName(SENDER_NAME);
        reportSendUnConfmFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        reportSendUnConfmFilter.setSortDescending(DEAULT_ORDER_DESC);
    }

    private void setUpPrn008Data() {
        reportSendErrListFilter = new ReportSendErrListFilter();
        reportSendErrListFilter.setDateFrom(PARAM_DATA_FROM);
        reportSendErrListFilter.setDateTo(PARAM_DATA_TO);
        reportSendErrListFilter.setTimeFrom(PARAM_TIME_FROM);
        reportSendErrListFilter.setTimeTo(PARAM_TIME_TO);
        reportSendErrListFilter.setContentFullCmp(CONTENT_FULL_COMPARE);
        reportSendErrListFilter.setSenderName(SENDER_NAME);
        reportSendErrListFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        reportSendErrListFilter.setSortDescending(DEAULT_ORDER_DESC);
    }

    private void setUpPrn010Data() {
        reportRecvListFilter = new ReportRecvListFilter();
        reportRecvListFilter.setDateFrom(PARAM_DATA_FROM);
        reportRecvListFilter.setDateTo(PARAM_DATA_TO);
        reportRecvListFilter.setTimeFrom(PARAM_TIME_FROM);
        reportRecvListFilter.setTimeTo(PARAM_TIME_TO);
        reportRecvListFilter.setContentFullCmp(CONTENT_FULL_COMPARE);
        reportRecvListFilter.setReceiverName(SENDER_NAME);
        reportRecvListFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        reportRecvListFilter.setSortDescending(DEAULT_ORDER_DESC);
    }

    private void setUpPrn011Data() {
        reportRecvErrListFilter = new ReportRecvErrListFilter();
        reportRecvErrListFilter.setDateFrom(PARAM_DATA_FROM);
        reportRecvErrListFilter.setDateTo(PARAM_DATA_TO);
        reportRecvErrListFilter.setTimeFrom(PARAM_TIME_FROM);
        reportRecvErrListFilter.setTimeTo(PARAM_TIME_TO);
        reportRecvErrListFilter.setContentFullCmp(CONTENT_FULL_COMPARE);
        reportRecvErrListFilter.setReceiverName(SENDER_NAME);
        reportRecvErrListFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        reportRecvErrListFilter.setSortDescending(DEAULT_ORDER_DESC);
    }

    private void setUpPrn012Data() {
        reportConFirmedDataFilter = new ReportConFirmedDataFilter();
        reportConFirmedDataFilter.setDateFrom(PARAM_DATA_FROM);
        reportConFirmedDataFilter.setDateTo(PARAM_DATA_TO);
        reportConFirmedDataFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        reportConFirmedDataFilter.setSortDescending(DEAULT_ORDER_DESC);
    }

    private void setUpPrn013Data() {
        reportODFSendRateFilter = new ReportODFSendRateFilter();
        reportODFSendRateFilter.setDateFrom(PARAM_DATA_FROM);
        reportODFSendRateFilter.setDateTo(PARAM_DATA_TO);
        reportODFSendRateFilter.setContentFullCmp(CONTENT_FULL_COMPARE);
        reportODFSendRateFilter.setSortColumnName(DEAULT_ORDER_COLUMN);
        reportODFSendRateFilter.setSortDescending(DEAULT_ORDER_DESC);
    }

    private void dumpCollection(Collection resultCollection, boolean isDumpCollection) {
        if (isDumpCollection) {
            DebugUtils.dumpCollection(resultCollection);
        }
    }
}
