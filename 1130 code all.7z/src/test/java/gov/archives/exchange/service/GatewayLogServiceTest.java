package gov.archives.exchange.service;

import java.io.File;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.DebugUtils;

import gov.archives.core.exception.CoreException;
import gov.archives.exchange.util.ReportUtils;

/**
 * GatewayLogServiceTest
 * <p>
 * Created by WeiYang on 2016/10/25.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class GatewayLogServiceTest {

    Logger log = Logger.getLogger(GatewayLogServiceTest.class);

    @Autowired
    GatewayLogService gatewayLogService;

    Map<String, Object> map = new HashMap<String, Object>();


    @Before
    public void prepare() {
        map.put("dateFromOut", Timestamp.valueOf("2016-01-01 01:01:01"));
        map.put("dateToOut", Timestamp.valueOf("2016-12-31 01:01:01"));
        map.put("dateFromIn", Timestamp.valueOf("2016-01-01 01:01:01"));
        map.put("dateToIn", Timestamp.valueOf("2016-12-31 01:01:01"));
        map.put("sendOrgId", "TEST00181");
        map.put("startNo", "1040525885");
        map.put("endNo", "1040525886");
        map.put("isFullCmp", "false");
    }

    @Test
    public void query() {
        DebugUtils.dumpCollection(gatewayLogService.queryAll(map));
    }

    @Test
    public void testWrite() {
        try {
            ReportUtils.saveAsJsonFile("testName", "testFile............");
            DebugUtils.dumpObject(ReportUtils.readJsonFileAsString("testName"));
        } catch (CoreException e) {
            e.printStackTrace();
        } finally {
            File file = new File("testName");
            file.delete();
        }
    }

}
