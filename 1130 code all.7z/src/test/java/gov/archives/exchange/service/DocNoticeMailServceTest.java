package gov.archives.exchange.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.PreconditionUtils;

import gov.archives.exchange.domain.entity.DocNoticeMailEntity;
import gov.archives.exchange.domain.vo.DocNoticeMailVO;

/**
 * Created by jslee on 2016/9/14.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class DocNoticeMailServceTest {

    private static final String DEFAULT_CREATOR = "Admin";
    private static final String DEFAULT_NOTICE_EMAILS = "aaaa@aa.aa.ww;ww@ee2.com;";
    private static final String DEFAULT_ORG_ID = "TEST0011225";
    private static final String DEFAULT_UNIT_ID = "U0001235";
    private static final String DEFAULT_ORG_UNIT_NAME = "Builder Company";

    private static final Boolean UPDATE_ACTIVE_STATUS = false;

    private UUID sysId;
    private List<DocNoticeMailVO> docNoticeMailVOs;

    @Autowired
    private DocNoticeMailService docNoticeMailService;

    @Before
    public void prepare() {
        docNoticeMailVOs = docNoticeMailService.getDocNoticeMailByFilterMap(initFilterMap());
        if (docNoticeMailVOs.size() != 0) {
            docNoticeMailService.removeDocNoticeMail(docNoticeMailVOs.get(0).getDocNoticeId());
        }
    }

    @Test
    public void fullTest() {
        createTest();
        updateTest();
        queryTest();
        deleteTest();
    }


    public void createTest() {
        docNoticeMailService.addDocNoticeMail(prepareCreateBean());
    }

    public void updateTest() {
        docNoticeMailService.updateDocNoticeMail(prepareUpdateBean());
    }

    public void queryTest() {
        docNoticeMailVOs = docNoticeMailService.getDocNoticeMailByFilterMap(initFilterMap());
        Assert.assertNotNull(docNoticeMailVOs);
    }

    public void deleteTest() {
        docNoticeMailService.removeDocNoticeMail(sysId);
    }

    private DocNoticeMailVO prepareCreateBean() {
        DocNoticeMailEntity docNoticeMailEntity = new DocNoticeMailEntity();
        docNoticeMailEntity.setSysId(sysId);
        docNoticeMailEntity.initSave(DEFAULT_CREATOR);
        docNoticeMailEntity.setNoticeEmail(DEFAULT_NOTICE_EMAILS);
        docNoticeMailEntity.setOrgId(DEFAULT_ORG_ID);
        docNoticeMailEntity.setOrgUnitName(DEFAULT_UNIT_ID);
        docNoticeMailEntity.setUnitId(DEFAULT_ORG_UNIT_NAME);
        sysId = docNoticeMailEntity.getSysId();
        return convertDocNoticeMailEntityToVo(docNoticeMailEntity);
    }

    private DocNoticeMailVO prepareUpdateBean() {
        DocNoticeMailEntity docNoticeMailEntity = new DocNoticeMailEntity();
        docNoticeMailEntity.setSysId(sysId);
        docNoticeMailEntity.initUpdate(DEFAULT_CREATOR);
        docNoticeMailEntity.setActiveStatus(UPDATE_ACTIVE_STATUS);
        return convertDocNoticeMailEntityToVo(docNoticeMailEntity);
    }

    private Map<String, Object> initFilterMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("orgId", DEFAULT_ORG_ID);
        return map;
    }

    private DocNoticeMailVO convertDocNoticeMailEntityToVo(DocNoticeMailEntity docNoticeMailEntity) {
        PreconditionUtils.checkArguments(docNoticeMailEntity);
        DocNoticeMailVO docNoticeMailVO = new DocNoticeMailVO();
        docNoticeMailVO.setDocNoticeId(docNoticeMailEntity.getSysId());
        docNoticeMailVO.setDocNoticeOrgId(docNoticeMailEntity.getOrgId());
        docNoticeMailVO.setDocNoticeUnitId(docNoticeMailEntity.getUnitId());
        docNoticeMailVO.setDocNoticeOrgUnitName(docNoticeMailEntity.getOrgUnitName());
        docNoticeMailVO.setDocNoticeStatus(docNoticeMailEntity.getActiveStatus());
        docNoticeMailVO.setDocNoticeEmails(docNoticeMailEntity.getNoticeEmail());
        docNoticeMailVO.setDocNoticeCreator(docNoticeMailEntity.getCreatorAccount());
        docNoticeMailVO.setDocNoticeCreatedTime(docNoticeMailEntity.getCreatedTime());
        docNoticeMailVO.setDocNoticeModifier(docNoticeMailEntity.getModifierAccount());
        docNoticeMailVO.setDocNoticeModifiedTime(docNoticeMailEntity.getModifiedTime());
        return docNoticeMailVO;
    }
}
