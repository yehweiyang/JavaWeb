package gov.archives.exchange.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.exchange.domain.entity.ExchangeInnerRecordEntity;

import static gov.archives.exchange.service.MainInfoService.*;
import static gov.archives.exchange.service.DetailInfoService.*;

/**
 * MainInfoServiceTest <br> (尚未描述類別目的與用途) <br> gemhuang, 2016/8/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class MainInfoServiceTest {

    @Autowired
    private MainInfoService service;

    @Before
    public void setUp() throws Exception {}

    @Test
    public void testGetMainInfoByMap() throws Exception {
        Map<String, Object> queryMap = new HashMap<>();
        queryMap.put(SENDER_TYPE_SCHEMA, INNER_TYPE);

        List<ExchangeInnerRecordEntity> entityList = service.getMainInfoByMap(queryMap);

        Assert.assertNotNull(entityList);
    }
}
