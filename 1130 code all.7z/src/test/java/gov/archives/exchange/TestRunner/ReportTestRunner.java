package gov.archives.exchange.TestRunner;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.archives.exchange.exception.ReportExceptionTest;
import gov.archives.exchange.facade.ReportOutputFacadeTest;
import gov.archives.exchange.service.ReportGenServiceTest;
import gov.archives.exchange.service.ReportServiceTest;

/**
 * Created by kshsu on 2016/8/16.
 * 直接執行 main method 搜尋 log 結果 是否有 occur error 產生
 * 即可判斷個單元測試是否有錯
 */
public class ReportTestRunner {
    private static final Logger log = LoggerFactory.getLogger(ReportTestRunner.class);

    public static void main(String[] args) {
        /* 將相關的測試 CLASS 納入即可*/
        Result result =
                JUnitCore.runClasses(ReportServiceTest.class, ReportGenServiceTest.class, ReportOutputFacadeTest.class,
                        ReportExceptionTest.class);

        for (Failure failure : result.getFailures()) {
            log.info("========= ReportTestRunner Occur Error: " + failure.toString());
        }

        log.info("========= ReportTestRunner Excute Result: " + result.wasSuccessful());
    }
}
