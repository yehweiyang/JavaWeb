package gov.archives.exchange.mapper.query;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.exchange.domain.entity.OrganReceiveEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class OrganReceiveQueryMapperTest {

    @Autowired
    OrganReceiveQueryMapper queryMapper;

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testFindByExchangeId() throws Exception {
        Map<String, Object> testParams = new HashMap<>();
        testParams.put("exchangeType", "INNER");
        testParams.put("startUpDateTime", "2016-04-01");
        testParams.put("endUpDateTime", "2016-10-21");
        List<OrganReceiveEntity> entityList = queryMapper.findByExactMatchMap(testParams);
        Assert.assertNotNull(entityList);
    }

    @Test
    public void testExchangeType() throws Exception{
        Map<String, Object> testParams2 = new HashMap<>();
        testParams2.put("exchangeType", "OUTTER");
        Assert.assertNotNull(testParams2);
    }
}
