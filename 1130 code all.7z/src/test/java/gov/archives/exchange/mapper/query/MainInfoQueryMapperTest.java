package gov.archives.exchange.mapper.query;

import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.exchange.domain.entity.MainInfoEntity;

/**
 * MainInfoQueryMapperTest
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class MainInfoQueryMapperTest {

    private static final String TEST_EXCHANGE_ID = "aaaaaaa";

    @Autowired
    private MainInfoQueryMapper queryMapper;

    @Autowired
    private AgencyCertQueryMapper accessorQueryMapper;

    @Before
    public void setUp() throws Exception {}

    @Test
    public void testFindByMap() throws Exception {
        Map<String, Object> queryMap = new HashedMap();
        queryMap.put("", TEST_EXCHANGE_ID);
        queryMapper.findByMap(queryMap);
    }
}
 