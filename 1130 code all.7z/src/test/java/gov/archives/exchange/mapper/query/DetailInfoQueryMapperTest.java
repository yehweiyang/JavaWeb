package gov.archives.exchange.mapper.query;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.exchange.domain.entity.TransmitDetailEntity;

import static gov.archives.exchange.service.DetailInfoService.*;
import static gov.archives.exchange.service.MainInfoService.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class DetailInfoQueryMapperTest {
    private static final String TEST_EXCHANGE_SERIAL = "8927debc7059c25382093e11b313136e";

    @Autowired
    private DetailInfoQueryMapper queryMapper;

    @Before
    public void setUp() throws Exception {}

    @Test
    public void testFindByMap() throws Exception {
        Map<String, Object> queryMap = new HashMap<>();
        queryMap.put(EXCHANGE_TYPE, INNER_TYPE);
        queryMap.put(EXCHANGE_SERIAL, TEST_EXCHANGE_SERIAL);

        List<TransmitDetailEntity> entityList = queryMapper.findByMap(queryMap);

        Assert.assertNotNull(entityList);
    }
}
