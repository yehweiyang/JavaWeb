
package gov.archives.exchange.mapper.query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.DebugUtils;

/**
 * Created by wtjiang on 2016/8/26.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class AccessorQueryMapperTest {

    @Autowired
    private AgencyCertQueryMapper accessorQueryMapper;

    @Test
    public void getListByOrgId(){
        DebugUtils.dumpCollection(accessorQueryMapper.findCertHashByOrgId("A101P0000U"));
    }
}

