package gov.archives.exchange.mapper.query;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.databind.JsonNode;
import net.sf.jasperreports.engine.util.JsonUtil;
import org.dom4j.Node;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import org.iii.common.conf.CommonConfig;
import org.iii.common.util.DebugUtils;

import gov.archives.exchange.conf.ExchangeConf;
import gov.archives.exchange.domain.vo.ExchangeAbnormalQueryVo;
import gov.archives.exchange.service.ExchangeAbnormalQueryService;
import gov.archives.xmldoc.domain.BaseDocument;
import gov.archives.xmldoc.processor.XmlDocumentReader;
import gov.archives.xmldoc.processor.XmlDocumentReaders;
import gov.archives.xmldoc.util.XMLUtils;

/**
 * ExchangeAbnormalQueryTest
 * <p>
 * Created by WeiYang on 2016/9/9.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:spring-service.xml",
        "classpath:spring-mapper-test.xml",
        "classpath:spring-mvc.xml"})
@WebAppConfiguration
public class ExchangeAbnormalQueryTest {
    private static final Logger log = LoggerFactory.getLogger(ExchangeAbnormalQueryTest.class);
    private static final String PROCESS_ID = "fdd3d645ba610d7ecb94a5252687aff2";
    private static final String TEST_RESOURCES_FOLDER = "test-resources";
    private static final String TEST_FOLDER = "TestFileParsing";
    private static final String TEST_AMOUNT_CONFIG_FILE = "center.9108.xml";
    private XmlDocumentReader<BaseDocument> testReader;

    @Autowired
    HttpServletRequest request;
    @Autowired
    ExchangeAbnormalQueryService service;

    @Before
    public void setUp() throws Exception {
        testReader = XmlDocumentReaders.getDocumentReaderByDocumentType(BaseDocument.class);
    }


    @Test
    public void testGetServerConfigPath() throws Exception{
        String xmlPath = ExchangeConf.getServerConfigLocation();
        Assert.assertNotNull(xmlPath);
        DebugUtils.dumpObject(xmlPath);
    }

    @Test
    public void testQuery() throws Exception {

        ExchangeAbnormalQueryVo vo = prepareVo();
        Assert.assertNotNull(service.getErrorQueryID(PROCESS_ID));
        Assert.assertNotNull(service.getErrorQueryList(vo));

        String processId1 = service.getErrorQueryList(vo).get(0).getProcessId();
        String processId2 = service.getErrorQueryID(PROCESS_ID).getProcessId();

        Assert.assertEquals(processId1, processId2);

    }

    @Test
    public void testReadXml() throws Exception {
        Path root = CommonConfig.getRuntimeRoot(ExchangeAbnormalQueryTest.class);
        File testFile = root.resolve(TEST_RESOURCES_FOLDER)
                            .resolve(TEST_FOLDER)
                            .resolve(TEST_AMOUNT_CONFIG_FILE).toFile();
        File testFile1 = root.resolve(TEST_RESOURCES_FOLDER)
                            .resolve(TEST_FOLDER).toFile();
        System.out.println(testFile1.listFiles());
        BaseDocument testDoc = testReader.readDocumentFromFile(testFile);

        java.util.List<Node> nodes = XMLUtils.getNodesByPathLevel(testDoc.getContent(), "//eHub");

        List<String> ehubList = new ArrayList<String>();
        nodes.stream().forEach(node -> {
            List<String> ehubString = XMLUtils.getValuesByTags(node, "id");
            int i = 0;
            ehubList.add(ehubString.get(i));
            i++;
        });
        Collection<String> ehubCollection = new ArrayList<String>(ehubList);
        Assert.assertNotNull(ehubList);
        DebugUtils.dumpCollection(ehubCollection);
    }
    @Test
    public void testReadJson() throws Exception {
        Path root = CommonConfig.getRuntimeRoot(ExchangeAbnormalQueryTest.class);
        File testFile = root.resolve(TEST_RESOURCES_FOLDER)
                            .resolve(TEST_FOLDER)
                            .resolve("account_error_query.json").toFile();

        JsonNode jsonNode =JsonUtil.parseJson(testFile);
        Assert.assertNotNull(jsonNode);
        DebugUtils.dumpObject(jsonNode.toString());
    }


    private ExchangeAbnormalQueryVo prepareVo() {
        ExchangeAbnormalQueryVo queryVo = new ExchangeAbnormalQueryVo();
        queryVo.setIsCheck("false");
        queryVo.setDateFrom("2016-01-01");
        queryVo.setTimeFrom("00");
        queryVo.setDateTo("2016-12-31");
        queryVo.setTimeTo("23");
        queryVo.seteHub("");
        queryVo.setStartNo("");
        queryVo.setEndNo("");
        queryVo.setExchangeId("");
        queryVo.setProcessId("");
        queryVo.setSenderUnitName("");
        queryVo.setSenderOrgId("");
        queryVo.setReceiverOrgId("");
        queryVo.setReceiverUnitName("");
        return queryVo;
    }
}
