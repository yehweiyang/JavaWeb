package gov.archives.exchange.mapper.query;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.DebugUtils;

import gov.archives.exchange.domain.vo.LoginHistory;
import gov.archives.exchange.service.LoginHistoryService;

/**
 * LoginHistoryTest
 * <p>
 * Created by WeiYang on 2016/9/14.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class LoginHistoryTest {


    @Autowired
    private LoginHistoryService service;


    @Test
    public void loginQuery() {
        LoginHistory vo = prepareVo();
        Assert.assertNotNull(service.getQueryList(vo));
        DebugUtils.dumpObject(service.getQueryList(vo));
    }


    private LoginHistory prepareVo() {
        LoginHistory queryVo = new LoginHistory();
        queryVo.setAccount("admin");
        queryVo.setDateFrom("2016-01-01");
        queryVo.setTimeFrom("00");
        queryVo.setDateTo("2016-12-31");
        queryVo.setTimeTo("23");
        return queryVo;
    }

}
