package gov.archives.exchange.mapper.query;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.DebugUtils;

import gov.archives.exchange.domain.entity.OrganSendDocSendEntity;
import gov.archives.exchange.domain.entity.OrganSendEntity;
import gov.archives.exchange.service.OrganSendService;

/**
 * Created by pywang on 2016/9/20.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class OrganSendQueryMapperTest {

    @Autowired
    private OrganSendQueryMapper queryMapper;

    @Autowired
    private OrganSendService organSendService;

    @Test
    public void setUp() throws Exception{

    }

    @Test
    public void testQueryType() throws Exception{
        Map<String, Object> testMap = new HashMap<>();
        testMap.put("queryType", 1);
        List<OrganSendEntity> entityList = queryMapper.findByExactMatchMap(testMap);
        Assert.assertNotNull(entityList);
    }
    @Test
    public void testQueryType2() throws Exception{
        Map<String, Object> testMap = new HashMap<>();
        testMap.put("queryType", 1);
        List<OrganSendEntity> entityList = queryMapper.findByLikeMap(testMap);
        Assert.assertNotNull(entityList);
    }

    @Test
    public void testOrgSendDocSend() throws Exception{
        Map<String, Object> testDocSend = new HashMap<>();
        testDocSend.put("queryType", 1);
        List<OrganSendDocSendEntity> testDocSendList = queryMapper.findByMap(testDocSend);
        Assert.assertNotNull(testDocSendList );


    }

    @Test
    public void mainTest() {
        DebugUtils.dumpCollection(organSendService.getOrganSendByMap(new HashMap<>(), false));
    }
}
