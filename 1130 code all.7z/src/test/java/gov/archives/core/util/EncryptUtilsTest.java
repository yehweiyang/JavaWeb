package gov.archives.core.util;

import java.io.IOException;
import java.util.Properties;

import org.apache.commons.codec.digest.DigestUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.DebugUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;
import org.iii.security.conf.SecurityConfig;
import org.iii.security.hash.HashGenerator;
import org.iii.security.hash.HashGenerators;

import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.security.encrypt.CipherConf;

/**
 * Created by kshsu on 2016/9/14.
 */
public class EncryptUtilsTest {

    private static final Logger log = LoggerFactory.getLogger(EncryptUtilsTest.class);

    private static final String SOURCETXT = "測試本文能不能被加解密";

    private static final String SOURCETXT_ENCRYPT_BY_3DES =
            "7FrO2A/tpLaXlPDqw7oVexx2IhG8sOL4wu+wQXqZYatz24k5N23Mtg==";

    private static final String SOURCETXT_ENCRYPTED_BY_AES256 =
            "gpC7flAD3EpIAZ1J2tk75wpM4S3k37nJGbvkkXpYyRZkXPABR+ksJE/k+QHC5N6L5A==";

    private static final String BASE64_TEST_IV = "28825252";
    private static final String BASE64_TEST_IV256 = "2882525228825252";

    private String CONFIGFILE_NAME = "ds-development.properties";
    private String PROPERTY_DB_COMMANDER = "db.g2b2c.commander";
    private String PROPERTY_DB_COMMANDER_PWD = "db.g2b2c.commanderPwd";
    private String PROPERTY_DB_QUERIER = "db.g2b2c.querier";
    private String PROPERTY_DB_QUERIER_PWD = "db.g2b2c.querierPwd";
    private String DB_COMMANDER;
    private String DB_COMMANDER_PWD;
    private String DB_QUERIER;
    private String DB_QUERIER_PWD;

    @Before
    public void setUp() throws CoreException {
        Properties propDs = new Properties();
        Properties propEn = new Properties();
        try {
            propDs.load(
                    IOUtils.loadResourceInClasspath(CONFIGFILE_NAME));
        } catch (IOException ex) {
            throw new CoreException(ex, CoreErrorCode.PROPERTY_SETTING_ERROR);
        } finally {
            DB_COMMANDER = propDs.getProperty(PROPERTY_DB_COMMANDER, "");
            DB_COMMANDER_PWD = propDs.getProperty(PROPERTY_DB_COMMANDER_PWD, "");
            DB_QUERIER = propDs.getProperty(PROPERTY_DB_QUERIER, "");
            DB_QUERIER_PWD = propDs.getProperty(PROPERTY_DB_QUERIER_PWD, "");
        }
    }

    @Test
    public void mainTest() throws Exception {

        if (StringUtils.isEmpty(CipherConf.ENCRYPT_METHOD)) {
            Assert.assertTrue(
                    EncryptUtils.enCryptOrDeCrypt(SOURCETXT,
                            CipherConf.Method.AES256,
                            CipherConf.Mode.ENCRYPT)
                                .equals(SOURCETXT_ENCRYPTED_BY_AES256));

            Assert.assertEquals(true,
                    SOURCETXT.equals(EncryptUtils.enCryptOrDeCrypt(SOURCETXT_ENCRYPTED_BY_AES256,
                            CipherConf.Method.AES256,
                            CipherConf.Mode.DECRYPT)));

            Assert.assertEquals(true,
                    SOURCETXT.equals(EncryptUtils.enCryptOrDeCrypt(SOURCETXT_ENCRYPT_BY_3DES,
                            CipherConf.Method.TRIPLE_DES,
                            CipherConf.Mode.DECRYPT)));

            //            DebugUtils.dumpObject("======== SOURCETEXT AES256 Encrypt ========");
            //            DebugUtils.dumpObject(
            //                    EncryptUtils.enCryptOrDeCrypt(SOURCETXT, CipherConf.Method.AES256, CipherConf.Mode.ENCRYPT));
            //
            //            DebugUtils.dumpObject("======== DB AES256 Encrypt ========");
            //            DebugUtils.dumpObject(
            //                    EncryptUtils.enCryptOrDeCrypt(DB_COMMANDER, CipherConf.Method.AES256, CipherConf.Mode.ENCRYPT));
            //            DebugUtils.dumpObject(
            //                    EncryptUtils.enCryptOrDeCrypt(DB_COMMANDER_PWD, CipherConf.Method.AES256, CipherConf.Mode.ENCRYPT));
            //            DebugUtils.dumpObject(
            //                    EncryptUtils.enCryptOrDeCrypt(DB_QUERIER, CipherConf.Method.AES256, CipherConf.Mode.ENCRYPT));
            //            DebugUtils.dumpObject(
            //                    EncryptUtils.enCryptOrDeCrypt(DB_QUERIER_PWD, CipherConf.Method.AES256, CipherConf.Mode.ENCRYPT));
            //
            //            DebugUtils.dumpObject("======== SOURCETEXT 3DES Encrypt ========");
            //            DebugUtils.dumpObject(
            //                    EncryptUtils.enCryptOrDeCrypt(SOURCETXT, CipherConf.Method.TRIPLE_DES, CipherConf.Mode.ENCRYPT));
            //
            //            DebugUtils.dumpObject("======== DB 3DES Encrypt ========");
            //            DebugUtils.dumpObject(
            //                    EncryptUtils.enCryptOrDeCrypt(DB_COMMANDER, CipherConf.Method.TRIPLE_DES, CipherConf.Mode.ENCRYPT));
            //            DebugUtils.dumpObject(
            //                    EncryptUtils
            //                            .enCryptOrDeCrypt(DB_COMMANDER_PWD, CipherConf.Method.TRIPLE_DES, CipherConf.Mode.ENCRYPT));
            //            DebugUtils.dumpObject(
            //                    EncryptUtils.enCryptOrDeCrypt(DB_QUERIER, CipherConf.Method.TRIPLE_DES, CipherConf.Mode.ENCRYPT));
            //            DebugUtils.dumpObject(
            //                    EncryptUtils
            //                            .enCryptOrDeCrypt(DB_QUERIER_PWD, CipherConf.Method.TRIPLE_DES, CipherConf.Mode.ENCRYPT));

            //        DebugUtils.dumpObject("======== DB TripleDES Decrypt ========");
            //        DebugUtils.dumpObject(EncryptUtils.enCryptOrDeCrypt("cjUXA28iS+jUK3+WpZBISQ==", CipherConf.Method.TRIPLE_DES,
            //                CipherConf.Mode.DECRYPT));
            //        DebugUtils.dumpObject(EncryptUtils.enCryptOrDeCrypt("9EYPDEag69GS0QsfjzxAZA==", CipherConf.Method.TRIPLE_DES,
            //                CipherConf.Mode.DECRYPT));
            //        DebugUtils.dumpObject(EncryptUtils.enCryptOrDeCrypt("qmxFRLy1tZ4Hm0vI7BI2pg==", CipherConf.Method.TRIPLE_DES,
            //                CipherConf.Mode.DECRYPT));
            //        DebugUtils.dumpObject(EncryptUtils.enCryptOrDeCrypt("vU4p9XJKGowYLJDfu9wKoQ==", CipherConf.Method.TRIPLE_DES,
            //                CipherConf.Mode.DECRYPT));
        }

        HashGenerator hashGenerator = HashGenerators.getInstanceByAlgorithm(SecurityConfig.ALGORITHM_SHA1);

        String hashByGenerator = EncryptUtils.txtToHash(BASE64_TEST_IV);
        String hashByDigest = hashByDigest(BASE64_TEST_IV);

        Assert.assertEquals(hashByDigest, hashByGenerator);

        //        DebugUtils.dumpObject("iv to base64= " + EncryptUtils.txtToBase64(BASE64_TEST_IV));
        //
        //        DebugUtils.dumpObject("iv128 to base64= " + EncryptUtils.txtToBase64(BASE64_TEST_IV256));

        Assert.assertEquals(BASE64_TEST_IV, EncryptUtils.base64ToText(EncryptUtils.txtToBase64(BASE64_TEST_IV)));
    }

    private String hashByDigest(String text) {
        return DigestUtils.sha1Hex(text);
    }
}