package gov.archives.core.util;

import java.sql.Timestamp;
import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.junit.Test;

import org.iii.common.util.DateTimeUtils;

/**
 * Created by 140631 on 2016/7/25.
 */
public class DateTimeTest {

    @Test
    public void testNewDateTime() {
        DateTime dateTime = LocalDateTime.parse("2016-07-25T15:00:00.000").toDateTime();

        Date date = dateTime.toDate();

        Timestamp time = new Timestamp(dateTime.getMillis());

        System.out.println(dateTime.toString());

        DateTime dateTime2 = DateTimeUtils.parseDateTime("2016-07-25 15:00:00", "yyyy-MM-dd HH:mm:ss");

        System.out.println(dateTime2.toString("yyyy-MM-dd"));
    }
}
