package gov.archives.core.util;

import org.joda.time.DateTime;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by tristan on 2016/9/8.
 */
public class DateTimeUtilsTest {
    @Test
    public void convertUtcTimeToLocal() throws Exception {
        String local = DateTimeUtils.convertLocalFromUtcTime("2016-09-07T01:00:00.000Z");

        System.out.printf(local);
    }

}