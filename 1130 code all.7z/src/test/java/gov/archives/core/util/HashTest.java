package gov.archives.core.util;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.StringUtils;

import gov.archives.core.exception.CoreException;

/**
 * Created by kshsu on 2016/9/20.
 */
public class HashTest {

    private static final Logger log = LoggerFactory.getLogger(HashTest.class);

    // f5853cbbd74d634196a240a681803a3da80e348dd30771acd7bebd8453e37347
    private static final String SOURCETEXT_1 = "我是中國人";

    // 91e7f4f8251dc8b2b9779923d94eda5487ddda8bbcd97ec23567db775aac382c
    private static final String SOURCETEXT_2 = "我是中國人2";

    @Test
    public void mainTest() {
        stringHashCodeSameTest();

        stringHashCodeNotSameTest();
    }

    private void stringHashCodeSameTest() {
        try {
            log.debug("sourceText1 hashCode = " + EncryptUtils.txtToHash(SOURCETEXT_1));
            Assert.assertEquals(EncryptUtils.txtToHash(SOURCETEXT_1), EncryptUtils.txtToHash(SOURCETEXT_1));
        } catch (CoreException e) {
            StringUtils.stackTraceFromException(e);
            Assert.assertNull(e);
        } finally {
            log.debug("Test for one string's HashCode is the same!");
        }
    }

    private void stringHashCodeNotSameTest() {
        try {
            log.debug("sourceText2 hashCode = " + EncryptUtils.txtToHash(SOURCETEXT_2));
            Assert.assertNotEquals(EncryptUtils.txtToHash(SOURCETEXT_1), EncryptUtils.txtToHash(SOURCETEXT_2));
        } catch (CoreException e) {
            StringUtils.stackTraceFromException(e);
            Assert.assertNull(e);
        } finally {
            log.debug("Test for two string's HashCode is not the same!");
        }
    }
}
