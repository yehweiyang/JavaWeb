package gov.archives.core;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.Date;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.StaticApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.exchange.event.ScheduleEvent;
import gov.archives.exchange.event.handler.GlobalEventHandler;

/**
 * Created by kshsu on 2016/9/13.
 * 測試各項 log 方式
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class LogTest {
    private static final Logger log = LoggerFactory.getLogger(LogTest.class);

    private static final String ERROR_CODE = HttpStatus.OK.getReasonPhrase();
    private static final String ERROR_CODE_ERROR =
            ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR).getErrorCode();
    private String EVENT_LEVEL_LOW = CoreConf.EVENT_LEVEL_LOW;
    private String EVENT_LEVEL_MEDIUM = CoreConf.EVENT_LEVEL_MEDIUM;
    private String EVENT_LEVEL_HIGH = CoreConf.EVENT_LEVEL_HIGH;
    private String IP;
    private static final String ACTION_RESULT = "成功";
    private static final String ACTION_RESULT_ERROR =
            ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR).getErrorMessage();
    private static final Timestamp ACTION_TIME = new Timestamp(System.currentTimeMillis());
    private static final String ACTOR_ACCOUNT = "admin";
    private static final String ACTION_ITEM = "Function-01";
    private ActionLogEntity actionLog;

    private StaticApplicationContext context;

    // 初始化事件
    private ScheduleEvent scheduleEvent;

    @Autowired
    private ActionLogService service;

    @Before
    public void init() {
        try {
            IP = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        context = new StaticApplicationContext();
        // 加入監聽器
        context.addApplicationListener(new GlobalEventHandler());
        context.refresh();
    }

    @Test
    public void testInsertLog() throws Exception {

        /* 測試 rsyslog of Level Low */
        rsyslogTestSuccess();

        /* 測試 rsyslog of Level Medium */
        rsyslogTestNormal();

        /* 測試 rsyslog of Level High */
        rsyslogTestErr();

        /* 測試事件監聽器 log */
        eventlogTest();

        /* 測試一般 Runtime log */
        normallogTest();
    }

    private void rsyslogTestSuccess() {
        try {
            ActionLogEntity actionLog = prepareLogSuccess();
            service.insertsAndRsysLog(actionLog);
            service.delete(actionLog);
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));
            Assert.assertNull(ex);
        }
    }

    private void rsyslogTestNormal() {
        try {
            ActionLogEntity actionLog = prepareLogNormal();
            service.insertsAndRsysLog(actionLog);
            service.delete(actionLog);
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));
            Assert.assertNull(ex);
        }
    }

    private void rsyslogTestErr() {
        try {
            ActionLogEntity actionLog = prepareLogErr();
            service.insertsAndRsysLog(actionLog);
            service.delete(actionLog);
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));
            Assert.assertNull(ex);
        }
    }

    private void eventlogTest() {
        try {
            scheduleEvent = new ScheduleEvent(this);
            context.publishEvent(scheduleEvent);
            Assert.assertNotNull(scheduleEvent);

            scheduleEvent = new ScheduleEvent(this, true);
            context.publishEvent(scheduleEvent);
            Assert.assertNotNull(scheduleEvent);
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));
            Assert.assertNull(ex);
        }
    }

    private ActionLogEntity prepareLogSuccess() {
        ActionLogEntity actionLog =
                ActionLogEntity.Builder.create()
                                       .setActionItem(ACTION_ITEM)
                                       .setActionResult(ACTION_RESULT)
                                       .setActionTime(ACTION_TIME)
                                       .setActorAccount(ACTOR_ACCOUNT)
                                       .setErrorCode(ERROR_CODE)
                                       .setEventLevel(EVENT_LEVEL_LOW)
                                       .setRemoteIp(IP)
                                       .build();

        return actionLog;
    }

    private ActionLogEntity prepareLogNormal() {
        ActionLogEntity actionLog =
                ActionLogEntity.Builder.create()
                                       .setActionItem(ACTION_ITEM)
                                       .setActionResult(ACTION_RESULT)
                                       .setActionTime(ACTION_TIME)
                                       .setActorAccount(ACTOR_ACCOUNT)
                                       .setErrorCode(ERROR_CODE)
                                       .setEventLevel(EVENT_LEVEL_MEDIUM)
                                       .setRemoteIp(IP)
                                       .build();

        return actionLog;
    }

    private ActionLogEntity prepareLogErr() {
        ActionLogEntity actionLog =
                ActionLogEntity.Builder.create()
                                       .setActionItem(ACTION_ITEM)
                                       .setActionResult(ACTION_RESULT_ERROR)
                                       .setActionTime(ACTION_TIME)
                                       .setActorAccount(ACTOR_ACCOUNT)
                                       .setErrorCode(ERROR_CODE_ERROR)
                                       .setEventLevel(EVENT_LEVEL_HIGH)
                                       .setRemoteIp(IP)
                                       .build();

        return actionLog;
    }

    private void normallogTest() {

        /* Customer Message */
        log.debug("DEBUG on " + new Date());
        log.info("INFO on " + new Date());
        log.warn("WARN on " + new Date());
        log.error("ERROR on " + new Date());

        /* System Message */
        try {
            Class<?> clazz = Class.forName("");
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));
            Assert.assertNotNull(ex);
        }
    }
}
