package gov.archives.core.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gov.archives.core.domain.vo.DistributeUnit;
import org.apache.commons.collections.map.HashedMap;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.core.domain.entity.DistributeMappingEntity;
import gov.archives.core.domain.entity.DistributeUnitEntity;
import gov.archives.core.domain.vo.DistributeDoc;
import gov.archives.core.domain.vo.DistributeMapping;
import gov.archives.core.mapper.query.DistributionQueryMapper;
import gov.archives.core.util.BeanUtils;

/**
 * Created by tristan on 2016/8/26.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class DistributeServiceTest {
    private static final Logger log = LoggerFactory.getLogger(DistributeServiceTest.class);

    private static final String TEST_CENTER_ID = "0000";
    private static final String TEST_ORG_ID = "ORG000001";
    private static final String TEST_UNIT_ID = "UNIT00001";
    private static final String TEST_ORG_UNIT_NAME = "TEST UNIT";
    private static final String TEST_CREATOR = "admin";
    private static final String TEST_SENDER_ORG_ID = "ORG111111";
    private static final String TEST_SENDER_UNIT_ID = "UNIT11111";
    private static final String TEST_RECEIVER_ORG_ID = "ORG222222";
    private static final String TEST_RECEIVER_UNIT_ID = "UNIT22222";

    @Autowired
    DistributionService distributionService;

    public DistributeUnitEntity prepareDistributeUnit() {
        DistributeUnitEntity unit = new DistributeUnitEntity();
        unit.setCenterId(TEST_CENTER_ID);
        unit.setOrgId(TEST_ORG_ID);
        unit.setUnitId(TEST_UNIT_ID);
        unit.setOrgUnitName(TEST_ORG_UNIT_NAME);
        unit.initSave(TEST_CREATOR);
        return unit;
    }

    public DistributeMappingEntity prepareDistributeMapping() {
        DistributeMappingEntity mapping = new DistributeMappingEntity();
        mapping.setSenderOrgId(TEST_SENDER_ORG_ID);
        mapping.setSenderUnitId(TEST_SENDER_UNIT_ID);
        mapping.setReceiverOrgId(TEST_RECEIVER_ORG_ID);
        mapping.setReceiverUnitId(TEST_RECEIVER_UNIT_ID);
        mapping.initSave(TEST_CREATOR);
        return mapping;
    }

    @Test
    public void testRemoveSenderUnit() throws Exception {
        DistributeUnitEntity senderUnit = prepareDistributeUnit();
        distributionService.insertSenderUnit(senderUnit);
        distributionService.deleteSenderUnit(senderUnit);
    }

    @Test
    public void testRemoveReceiverUnit() throws Exception {
        DistributeUnitEntity receiverUnit = prepareDistributeUnit();
        distributionService.insertReceiverUnit(receiverUnit);
        distributionService.deleteReceiverUnit(receiverUnit);
    }

    @Test
    public void testGetSenderUnitByOrgUnitId() throws Exception {
        DistributeUnitEntity senderUnit = prepareDistributeUnit();
        distributionService.insertSenderUnit(senderUnit);
        Map<String, String> queryData = new HashMap<>();
        queryData.put(DistributionQueryMapper.KEY_ORG_ID, TEST_ORG_ID);
        queryData.put(DistributionQueryMapper.KEY_UNIT_ID, TEST_UNIT_ID);
        DistributeUnitEntity unit = distributionService.getSenderUnitByOrgUnitId(queryData);
        Assert.assertNotNull(unit);
        Assert.assertEquals(unit.getOrgId(), TEST_ORG_ID);
        Assert.assertEquals(unit.getUnitId(), TEST_UNIT_ID);
        distributionService.deleteSenderUnit(senderUnit);
    }

    @Test
    public void testGetReceiverUnitByOrgUnitId() throws Exception {
        DistributeUnitEntity senderUnit = prepareDistributeUnit();
        distributionService.insertReceiverUnit(senderUnit);
        Map<String, String> queryData = new HashMap<>();
        queryData.put(DistributionQueryMapper.KEY_ORG_ID, TEST_ORG_ID);
        queryData.put(DistributionQueryMapper.KEY_UNIT_ID, TEST_UNIT_ID);
        DistributeUnitEntity unit = distributionService.getReceiverUnitByOrgUnitId(queryData);
        Assert.assertNotNull(unit);
        Assert.assertEquals(unit.getOrgId(), TEST_ORG_ID);
        Assert.assertEquals(unit.getUnitId(), TEST_UNIT_ID);
        distributionService.deleteReceiverUnit(senderUnit);
    }

    @Test
    public void testListCenterSenderUnit() throws Exception {
        List<DistributeMapping> mappingList = distributionService.listMappingBySenderId(TEST_SENDER_ORG_ID, TEST_SENDER_UNIT_ID);
        Assert.assertNotNull(mappingList);
    }

    @Test
    public void testDeleteMappingByOrgUnitId() throws Exception {
        DistributeMappingEntity mappingEntity = prepareDistributeMapping();
        distributionService.insertDistributeMapping(mappingEntity);
        DistributeMapping mapping = new DistributeMapping();
        BeanUtils.copyProperties(mapping, mappingEntity);
        DistributeMappingEntity insertResult = distributionService.getMappingByOrgUnitId(mapping);
        Assert.assertNotNull(insertResult);
        distributionService.deleteDistributeMapping(mappingEntity);
        DistributeMappingEntity result = distributionService.getMappingByOrgUnitId(mapping);
        Assert.assertNull(result);
    }

    @Test
    public void testDeleteMappingBySenderUnitId() throws Exception {
        DistributeMappingEntity mappingEntity = prepareDistributeMapping();
        distributionService.insertDistributeMapping(mappingEntity);
        DistributeMapping mapping = new DistributeMapping();
        BeanUtils.copyProperties(mapping, mappingEntity);
        DistributeMappingEntity insertResult = distributionService.getMappingByOrgUnitId(mapping);
        Assert.assertNotNull(insertResult);
        distributionService.deleteMappingBySenderUnitId(TEST_SENDER_ORG_ID, TEST_SENDER_UNIT_ID);
        DistributeMappingEntity result = distributionService.getMappingByOrgUnitId(mapping);
        Assert.assertNull(result);
    }

    @Test
    public void testDeleteMappingByReceiverUnitId() throws Exception {
        DistributeMappingEntity mappingEntity = prepareDistributeMapping();
        distributionService.insertDistributeMapping(mappingEntity);
        distributionService.deleteMappingByReceiverUnitId(TEST_RECEIVER_ORG_ID, TEST_RECEIVER_UNIT_ID);
        DistributeMapping mapping = new DistributeMapping();
        BeanUtils.copyProperties(mapping, mappingEntity);
        DistributeMappingEntity result = distributionService.getMappingByOrgUnitId(mapping);
        Assert.assertNull(result);
    }

    @Test
    public void testListDistributeDoc() throws Exception {
        List<DistributeDoc> distDocList = distributionService.listDistributeDoc("", 0, "", "", "", "", "", "", "", "", false);
        Assert.assertNotNull(distDocList);
    }
}
