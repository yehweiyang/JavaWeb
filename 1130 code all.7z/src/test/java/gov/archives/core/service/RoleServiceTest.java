package gov.archives.core.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.vo.RoleMenuMapping;

/**
 * RoleServiceTest
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class RoleServiceTest {

    private static final String TEST_ROLE_NAME = "ADMIN";
    private static final String TEST_CREATOR = "admin";
    private static final String TEST_MENU_CODE = "ADMIN";
    private static final String TEST_MENU_NAME = "TEST_MANU";

    @Autowired
    private RoleService roleService;

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private MenuService menuService;

    @Before
    public void setUp() throws Exception {
        RoleEntity role = roleService.getByRoleName(TEST_ROLE_NAME);

        if (null != role) {
            roleService.delete(role);
            roleService.deleteMenuMapping(role);
        }

        MenuEntity menu = menuService.getByMenuCode(TEST_MENU_CODE);

        if (null != menu) {
            menuService.delete(menu);
        }
    }

    @Test
    public void testInsert() throws Exception {
        try {
            RoleEntity role = prepareRole();

            roleService.insert(role);

            RoleEntity role1 = roleService.getByRoleName(role.getRoleName());
            RoleEntity role2 = roleService.getBySysId(role.getSysId());

            Assert.assertNotNull(role1);
            Assert.assertNotNull(role2);

            Assert.assertEquals(TEST_ROLE_NAME, role1.getRoleName());
            Assert.assertEquals(TEST_ROLE_NAME, role2.getRoleName());

            roleService.delete(role1);
        } catch (Exception ex) {
            Assert.assertNull(ex);
        }
    }

    private RoleEntity prepareRole() {
        RoleEntity role = new RoleEntity();

        role.setRoleName(TEST_ROLE_NAME);
        role.setActiveStatus(CoreConf.STATUS_ENABLED);
        role.initSave(TEST_CREATOR);

        return role;
    }

    @Test
    public void testUpdate() throws Exception {
        try {
            RoleEntity role = prepareExistsRole();

            role.setActiveStatus(CoreConf.STATUS_DISABLED);
            role.initUpdate(TEST_CREATOR);

            roleService.update(role);

            RoleEntity role1 = roleService.getByRoleName(role.getRoleName());
            RoleEntity role2 = roleService.getBySysId(role.getSysId());

            Assert.assertNotNull(role1);
            Assert.assertNotNull(role2);

            // Assert.assertNotEquals(role1.getCreatedTime(), role1.getModifiedTime());

            Assert.assertEquals(CoreConf.STATUS_DISABLED, role1.getActiveStatus());
            Assert.assertEquals(CoreConf.STATUS_DISABLED, role2.getActiveStatus());
        } catch (Exception ex) {
            Assert.assertNull(ex);
        }
    }

    private RoleEntity prepareExistsRole() {
        RoleEntity role = prepareRole();

        roleService.insert(role);

        role = roleService.getByRoleName(role.getRoleName());

        return role;
    }

    @Test
    public void testSetMenuToRole() throws Exception {
        RoleEntity role = prepareExistsRole();
        MenuEntity menu = prepareExistsMenu();

        RoleMenuMapping mapping = new RoleMenuMapping();

        mapping.setRole(role);
        mapping.setCreatorAccount(TEST_CREATOR);
        mapping.addMenu(menu);

        roleService.updateRoleMenuMapping(mapping);

        RoleMenuMapping mapping1 = roleService.getMenuMappingByRoleName(role.getRoleName());
        RoleMenuMapping mapping2 = roleService.getMenuMappingByRoleSysId(role.getSysId());

        Assert.assertEquals(mapping1.getMenus().get(0).getSysId(), mapping2.getMenus().get(0).getSysId());

        roleService.deleteMenuMapping(mapping.getRole());
        menuService.delete(menu);
    }

    private MenuEntity prepareExistsMenu() {
        MenuEntity menu = prepareMenu();

        menuService.insert(menu);

        menu = menuService.getByMenuCode(TEST_MENU_CODE);

        return menu;
    }

    private MenuEntity prepareMenu() {
        MenuEntity menu = new MenuEntity();

        menu.setMenuCode(TEST_MENU_CODE);
        menu.setMenuName(TEST_MENU_NAME);
        menu.setMenuSeq(1);
        menu.setActiveStatus(CoreConf.STATUS_ENABLED);
        menu.setModifiedMemo("");
        menu.setTopMenuId(CoreConf.DEFAULT_ID);
        menu.initSysId();

        return menu;
    }
}
