package gov.archives.core.service;

import java.sql.Timestamp;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.DebugUtils;

import gov.archives.core.domain.entity.ChangeCertEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.security.DigitalSignHandle;

/**
 * ChangeCertServiceTest
 * <p>
 * Created by WeiYang on 2016/10/17.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class ChangeCertServiceTest {
    private static final String beforeB64Cert3 =
            "MIIFADCCA+igAwIBAgIRAI5bPsoaUKooHFfTK/EI1dQwDQYJKoZIhvcNAQELBQAwRzELMAkGA1UEBhMCVFcxEjAQBgNVBAoMCeihjOaUv+mZojEkMCIGA1UECwwb5YWn5pS/6YOo5oaR6K2J566h55CG5Lit5b+DMB4XDTE2MTAwMzAwNDUyOFoXDTIxMTAwMzE1NTk1OVowPDELMAkGA1UEBhMCVFcxEjAQBgNVBAMMCeiRieWogeaPmjEZMBcGA1UEBRMQMDAwMDAwMDExNDkwNzAyMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANM4SM0KZEn39ATJtO3YfMCsYsn8LmIgrz/X+MYW834F9CWI+lvdVCNQAT7Z2YFw0fm6WNFef/5mbIeX1n1Wiw2ZQcWEfuA7pAtIcqKrM5MySQULVDAp2DoHq18BLiuutUt01WwlyMF4GdNeYRSsX6CrHacBNcvbC2zsIM2x7nrNxE67g/LAdHJab/8QGFgNN47MXmU+jNIsZjTUypslK+O67LneKrjAGzZ5RJy1yMIgz/0KPFIWlM5Yr2oSs6mAhFVhzniw+3zGYvgKLQZuc+0TAfZFD1qJSJBPxm34wN6+26mm8rhhe1GPRQsOgQLa9a/hyoX2bioVcbbiHm91kcECAwEAAaOCAfAwggHsMB8GA1UdIwQYMBaAFPqbNGcJCpgi92JIi4ImpkXFwyKkMB0GA1UdDgQWBBR5EbSGagV3gBKvnmayBNHXxW7UHzCBnAYIKwYBBQUHAQEEgY8wgYwwRwYIKwYBBQUHMAKGO2h0dHA6Ly9tb2ljYS5uYXQuZ292LnR3L3JlcG9zaXRvcnkvQ2VydHMvSXNzdWVkVG9UaGlzQ0EucDdiMEEGCCsGAQUFBzABhjVodHRwOi8vbW9pY2EubmF0Lmdvdi50dy9jZ2ktYmluL09DU1AyL29jc3Bfc2VydmVyLmV4ZTAOBgNVHQ8BAf8EBAMCB4AwFAYDVR0gBA0wCzAJBgdghnZlAAMDMB4GA1UdEQQXMBWBE3R3MDAxODI2OUBnbWFpbC5jb20wMwYDVR0JBCwwKjAVBgdghnYBZAIBMQoGCGCGdgFkAwEBMBEGB2CGdgFkAjMxBgwENDU0NjCBjwYDVR0fBIGHMIGEMECgPqA8hjpodHRwOi8vbW9pY2EubmF0Lmdvdi50dy9yZXBvc2l0b3J5L01PSUNBL0NSTDIvQ1JMXzAwMTEuY3JsMECgPqA8hjpodHRwOi8vbW9pY2EubmF0Lmdvdi50dy9yZXBvc2l0b3J5L01PSUNBL0NSTDIvY29tcGxldGUuY3JsMA0GCSqGSIb3DQEBCwUAA4IBAQAxaWGx9irwX0AL4DOxp2Awncm9UfyNb8Lgco2Ovd5GIQ4jgELhTJ4Mv2ji/YOaPSo+wEhJ8mxi8zsar/oQpkqM7Dx9FCmye7V5/8/OJe30QzDFOuNa3YYsFVuD6BAtyc2d4jqhStIDC9Sd+xHr6CV6I9iM8qTpOhtLIHGq0yCjn6joagcXhc3SbPmutDtVaZvy0PLJtt2yKAOwiBFk/vdbBYrZd0AxpwjlYCLMepG3vI9OdKcNHeLf6eoNZHOSV6sgcW083hF8ZCOzROAgYfhaQ9TkIhQSKPYwE4Eb0aV4lzyGEPCvTKfFFyM7OU5iKYfNteNyoDW9rozfBsFA7mLx";
    private static final String afterB64Cert3 =
            "MIIEuTCCA6GgAwIBAgIQamllWKQzu/FSLxxCgNzdMjANBgkqhkiG9w0BAQsFADBWMQswCQYDVQQGEwJUVzESMBAGA1UECgwJ6KGM5pS/6ZmiMTMwMQYDVQQLDCoo5ris6Kmm55SoKSDmlL/lupzmuKzoqabmhpHorYnnrqHnkIbkuK3lv4MwHhcNMTYwNjIyMDU0MTIyWhcNMTYxMjIyMDU0MTIyWjA5MQswCQYDVQQGEwJUVzESMBAGA1UEBwwJ6Ie65YyX5biCMRYwFAYDVQQKDA3muKzoqabmqZ/pl5wxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4ZmwtA+Mxq0c8Qq/fOKXtxNG+3GRrxhgb0U8jKbjXGQTv5nQcW6UX/tODFDQZXAM6QNwjczB7TIGVeipHBVJpWY4jb/KRaNOtwQSnLrTuKDY8a7YLXp81BEeUTB6a+lqeVEbo+w24Jyhb0T6/jK+mQWLtKOtd6uilxHD2pET/zcIHlEa16j/ZbhXiPlFAYOqrON92V8dIhsiXboq7IMxjbsY0qKSXNr3Nbu9XuOpUdoarue9arDQvQIZp2bBWQqERhX8gypqGDwTahGSXBNwQMqnl6ovmXdJXyRJ4+16UHGhguomcfMCrMQDys+6MCgIVqeMySoMBgSYQsNHkBe74QIDAQABo4IBnjCCAZowdwYIKwYBBQUHAQEEazBpMDoGCCsGAQUFBzAChi5odHRwOi8vMjEwLjI0MS42OS4xODEvY2VydHMvSXNzdWVkVG9UaGlzQ0EucDdiMCsGCCsGAQUFBzABhh9odHRwOi8vMjEwLjI0MS42OS4xODEvT0NTUC9vY3NwMBQGA1UdIAQNMAswCQYHYIZ2ZQADADBRBgNVHQkESjBIMBYGB2CGdgFkAgExCwYJYIZ2AWQDAgEBMBQGB2CGdgFkAgIxCRMHcHJpbWFyeTAYBgdghnYBZAJmMQ0GC2CGdgFlhb8TgZwhMBoGA1UdEQQTMBGBD3Rlc3RAY2h0LmNvbS50dzAOBgNVHQ8BAf8EBAMCB4AwHwYDVR0jBBgwFoAUd6/QZYfuHcip9pegJUcOyZXacaswHQYDVR0OBBYEFO6MGigyfYUcQGYF66K45GH6jT9gMEoGA1UdHwRDMEEwP6A9oDuGOWh0dHA6Ly8yMTAuMjQxLjY5LjE4MS9zaGEyL2NybC9HVGVzdENBMi9jb21wbGV0ZWRlbHRhLmNybDANBgkqhkiG9w0BAQsFAAOCAQEAWq52xYNsOMOiKYeeVuaGiJxna4z8TyX2Xs6LfgjEBa9rPY/AEljdxfqOlfRdfHMFhVnJ3IyXe1iGqYAyGYwjM7oCe1Ft6jjLAt8Tmb6xmAF6hH7UkeiWKr/G5aZe2fLAF4Q4obC5uagBjxOAH8pgKU6aNd3ESL2TMhTAmSDcdvtrOwaIw3H+G1bLf150QNJw82S0mkNUAOUhpDg+VqQD5BixOKHpaFxrIWNIRZUp92ZfGKOIxf5uUZ72wFkCQ68ldtt87WXLSsIcWFRLH2dCaIVCzPnA5MbFsDeCKWjn4UV+AmMcKof14NzpXN6WTag2CrNAo64ne63hGLZZaKEqfQ==";
    private static final String TEST_ACCOUNT = "JAWAELANPALA";
    private static final String TEST_CARD_NUM = "TP03160201361696";
    private static final String TEST_CERT_HASH = "e72450582b6fa5516a510bf256308421f820fed4cbe35d0a036e69667597a00e";
    private static final String TEST_NAME = "小康妮的轉音經常練習";
    private static final UUID TEST_ROLE = UUID.fromString("00000000-0000-0000-0000-000000000000");
    private static final String TEST_EMAIL = "";
    private static final String TEST_PHONE = "";
    private static final String TEST_MOBILE = "";
    private static final String TEST_ORG_INFO = "";
    private static final Integer TEST_STATUS = 1;
    private static final String TEST_DEPUTY = "";


    ChangeCertEntity certEntity = new ChangeCertEntity();

    @Autowired
    private ChangeCertService changeCertService;
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private DigitalSignHandle pkcs1Handle;

    private UserInfoEntity prepareUser() {
        UserInfoEntity user = new UserInfoEntity();

        user.setAccount(TEST_ACCOUNT);
        user.setRoleSysId(TEST_ROLE);
        user.setUserName(TEST_NAME);
        user.setEmail(TEST_EMAIL);
        user.setPhoneNumber(TEST_PHONE);
        user.setMobileNumber(TEST_MOBILE);
        user.setOrgInfo(TEST_ORG_INFO);
        user.setActiveStatus(TEST_STATUS);
        user.setDeputyAccount(TEST_DEPUTY);
        user.setCertCardNum(TEST_CARD_NUM);
        user.setCertHash(TEST_CERT_HASH);

        user.initSave(TEST_ACCOUNT);

        return user;
    }

    private UserInfoEntity prepareExistsUser() {
        UserInfoEntity user = prepareUser();

        userInfoService.insert(user);

        return user = userInfoService.getByAccount(user.getAccount());
    }


    @Before
    public void setUp() throws Exception {
        DebugUtils.dumpObject("do this before");
        UserInfoEntity user = userInfoService.getByAccount(TEST_ACCOUNT);

        if (null != user) {
            userInfoService.delete(user);
        }
    }

    @Test
    public void testUpdate() {
        UserInfoEntity user = prepareExistsUser();
        DebugUtils.dumpObject(user);
        Assert.assertNotNull(user);
        certEntity.setCertHash(pkcs1Handle.transBase64CertIntoX509Cert(beforeB64Cert3));
        certEntity.setModifiedTime(new Timestamp(System.currentTimeMillis()));
        certEntity.setModifierAccount("CHANGEACCOUNT");
        certEntity.setAccount(user.getAccount());
        certEntity.setSerialNumber("TTA0000000001839");

        changeCertService.update(certEntity);
        UserInfoEntity infoEntity = userInfoService.getByAccount(user.getAccount());
        DebugUtils.dumpObject(infoEntity);
        userInfoService.delete(user);
    }
}
