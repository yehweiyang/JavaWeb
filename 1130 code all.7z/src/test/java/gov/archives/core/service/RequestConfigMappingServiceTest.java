package gov.archives.core.service;

import java.util.Collection;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.DebugUtils;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.security.access.intercept.CustomRequestConfigMappingService;
import gov.archives.core.security.access.intercept.RequestConfigMapping;
import gov.archives.core.security.access.intercept.RequestConfigMappingService;

import static gov.archives.core.security.access.intercept.RequestConfigMappingService.ERROR_PREFIX;

/**
 * Created by yflin on 10/14/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class RequestConfigMappingServiceTest {
    public static final String TEST_ACCOUNT = "LoginTest";
    private RequestConfigMappingService requestConfigMappingService;

    @Autowired
    private RoleService roleService;

    @Autowired
    private MenuService menuService;

    @Autowired
    private UserInfoService userInfoService;

    @Before
    public void setUp() throws Exception {
        requestConfigMappingService = new CustomRequestConfigMappingService(roleService, menuService);
    }

    @Test
    public void getRequestConfigMappings() throws Exception {

        List<RequestConfigMapping> list = requestConfigMappingService.getRequestConfigMappings();

        Assert.assertNotNull(list);

        RequestConfigMapping testRequestConfig = list.get(0);

        Assert.assertNotEquals(ERROR_PREFIX, testRequestConfig.getMatcher().toString());
    }

    @Test
    public void getCreateAuthorities() throws Exception {
        UserInfoEntity user = userInfoService.getByAccount(TEST_ACCOUNT);

        Collection<? extends GrantedAuthority> authorities = requestConfigMappingService.createAuthorities(user);

        Assert.assertNotNull(authorities);
    }
}
