package gov.archives.core.service;

import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.DebugUtils;

import gov.archives.core.domain.vo.TopMenuVo;

/**
 * RouterServiceTest
 * <p>
 * Created by WeiYang on 2016/8/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class RouterServiceTest {

    private static final Logger log = LoggerFactory.getLogger(RouterServiceTest.class);
    @Autowired
    private MenuService service;


    @Test
    public void testGetRouter() throws Exception {

        Map<Integer, TopMenuVo> routerMenuTree = service.getMenuTree();

        Assert.assertNotNull(routerMenuTree);

        DebugUtils.dumpMap(routerMenuTree);
    }

}
