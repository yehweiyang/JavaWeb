package gov.archives.core.service;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.UserInfo;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.util.BeanUtils;

/**
 * UserInfoServiceTest
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/15.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class UserInfoServiceTest {
    private static final Logger log = LoggerFactory.getLogger(UserInfoServiceTest.class);

    private static final String TEST_ACCOUNT = "admin";
    private static final String TEST_NAME = "Admin";
    private static final String TEST_NAME_2 = "TEST-2";
    private static final UUID TEST_ROLE = UUID.fromString("00000000-0000-0000-0000-000000000000");
    private static final String TEST_EMAIL = "";
    private static final String TEST_PHONE = "";
    private static final String TEST_MOBILE = "";
    private static final String TEST_ORG_INFO = "";
    private static final Integer TEST_STATUS = 1;
    private static final String TEST_DEPUTY = "";
    private static final String TEST_CARD_NUM = "123456789";
    private static final String TEST_CERT_HASH = "";
    private static final String TEST_CREATOR = "admin";
    private static final String TEST_ROLE_NAME = "ADMIN";

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private RoleService roleService;

    @Before
    public void setUp() throws Exception {
        UserInfoEntity user = userInfoService.getByAccount(TEST_ACCOUNT);

        if (null != user) {
            userInfoService.delete(user);
        }

        RoleEntity role = roleService.getByRoleName(TEST_ROLE_NAME);

        if (null != role) {
            roleService.delete(role);
        }
    }

    @Test
    public void testInsert() throws Exception {
        UserInfoEntity user = prepareUser();

        userInfoService.insert(user);


        user = userInfoService.getByAccount(user.getAccount());

        Assert.assertNotNull(user);

        userInfoService.delete(user);
    }

    private UserInfoEntity prepareUser() {
        UserInfoEntity user = new UserInfoEntity();

        user.setAccount(TEST_ACCOUNT);
        user.setRoleSysId(TEST_ROLE);
        user.setUserName(TEST_NAME);
        user.setEmail(TEST_EMAIL);
        user.setPhoneNumber(TEST_PHONE);
        user.setMobileNumber(TEST_MOBILE);
        user.setOrgInfo(TEST_ORG_INFO);
        user.setActiveStatus(TEST_STATUS);
        user.setDeputyAccount(TEST_DEPUTY);
        user.setCertCardNum(TEST_CARD_NUM);
        user.setCertHash(TEST_CERT_HASH);

        user.initSave(TEST_CREATOR);

        return user;
    }

    @Test
    public void testUpdate() throws Exception {
        UserInfoEntity user = prepareExistsUser();

        user.setUserName(TEST_NAME_2);
        user.initUpdate(TEST_CREATOR);

        userInfoService.update(user);

        user = userInfoService.getByAccount(user.getAccount());

        // Assert.assertNotEquals(user.getCreatedTime(), user.getModifiedTime());
        // Assert.assertEquals(TEST_NAME_2, user.getUserName());

        userInfoService.delete(user);
    }

    private UserInfoEntity prepareExistsUser() {
        UserInfoEntity user = prepareUser();

        userInfoService.insert(user);

        return user = userInfoService.getByAccount(user.getAccount());
    }

    @Test
    public void testSetUserToRoleId() throws Exception {
        UserInfoEntity user = prepareExistsUser();
        RoleEntity role = prepareExistsRole();

        user.setRoleSysId(role.getSysId());
        user.initUpdate(TEST_CREATOR);
        userInfoService.update(user);

        user = userInfoService.getByAccount(user.getAccount());

        // Assert.assertNotEquals(user.getCreatedTime(), user.getModifiedTime());
        Assert.assertEquals(role.getSysId(), user.getRoleSysId());

        userInfoService.delete(user);
        roleService.delete(role);
    }

    @Test
    public void testPersonData() throws Exception {
        String account = "jplee";
        UserInfoEntity userInfoEntity = new UserInfoEntity();
        userInfoEntity.setOrgInfo("asdasf");
        userInfoEntity.setAccount(account);
        userInfoEntity.setMobileAreaCode("22222");
        UserInfoEntity userInfoEntity2 = userInfoService.getByAccount(userInfoEntity.getAccount());

        if (null == userInfoEntity2) {
            throw new RestApplicationException(HttpStatus.BAD_REQUEST);
        }

        BeanUtils.copyProperties(userInfoEntity, userInfoEntity2);

        userInfoEntity2.initUpdate(userInfoService.getCurrentAccount());

        userInfoService.update(userInfoEntity2);
        //ModifyPersonDataEntity modifyPersonDataEntity = userInfoService.getAccountInfo(account);
        //System.out.println(modifyPersonDataEntity);

    }


    @Test
    public void testSetUserToRoleName() throws Exception {
        UserInfoEntity user = prepareExistsUser();
        RoleEntity role = prepareExistsRole();

        user.initUpdate(TEST_CREATOR);
        userInfoService.updateUserByRoleName(user, role.getRoleName());

        user = userInfoService.getByAccount(user.getAccount());

        // Assert.assertNotEquals(user.getCreatedTime(), user.getModifiedTime());
        Assert.assertEquals(role.getSysId(), user.getRoleSysId());

        userInfoService.delete(user);
        roleService.delete(role);
    }

    private RoleEntity prepareExistsRole() {
        RoleEntity role = prepareRole();

        roleService.insert(role);

        role = roleService.getByRoleName(role.getRoleName());

        return role;
    }

    private RoleEntity prepareRole() {
        RoleEntity role = new RoleEntity();

        role.setRoleName(TEST_ROLE_NAME);
        role.setActiveStatus(CoreConf.STATUS_ENABLED);
        role.initSave(TEST_CREATOR);

        return role;
    }

    @Test
    public void testList() throws JsonProcessingException {
        List<UserInfo> userInfoList = userInfoService.list();

        Assert.assertNotNull(userInfoList);

        ObjectMapper mapper = new ObjectMapper();

        for (UserInfo userInfo : userInfoList) {
            log.info("ToString: " + ToStringBuilder.reflectionToString(userInfo));
            String json = mapper.writeValueAsString(userInfo);
            log.info("JSON: " + json);
        }
    }


    @Test
    public void testListByKeyWord() throws JsonProcessingException {
        Map<String, Object> map = new HashedMap();
        map.put("keyWord", "");
        map.put("verification", true);
        map.put("active", true);
        map.put("inactive", true);
        List<UserInfo> userInfoList = userInfoService.listByKeyWord(map);
        Assert.assertNotNull(userInfoList);
    }

    @Test
    public void testUpdateUserByAccount() {
        UserInfoEntity userInfoEntity= prepareUser();
        userInfoService.insert(userInfoEntity);

        UserInfoEntity testUser = userInfoService.getByAccount(TEST_ACCOUNT);
        Assert.assertNotNull(testUser);
        UserInfo userInfo = new UserInfo();
        BeanUtils.copyProperties(userInfo, testUser);

        userInfo.setActiveStatus(1);
        userInfo.setOrgInfo("TEST123");
        userInfo.setEmail("test@archives.gov.tw");
        userInfo.setPhoneAreaCode("02");
        userInfo.setMobileLocalNumber("22222222");

        userInfoService.updateUserByAccount(userInfo);

        userInfoService.delete(userInfoEntity);
    }
}
