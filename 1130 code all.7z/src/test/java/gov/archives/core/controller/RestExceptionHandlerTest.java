package gov.archives.core.controller;

import com.fasterxml.jackson.databind.JsonNode;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.WebApplicationContext;

import gov.archives.common.json.JsonUtils;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;

/**
 * Created by tristan on 2016/8/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:spring-service.xml",
        "classpath:spring-mapper-test.xml",
        "classpath:spring-mvc.xml"})
@WebAppConfiguration
public class RestExceptionHandlerTest {
    private static final Logger log = LoggerFactory.getLogger(RestExceptionHandlerTest.class);

    @Autowired
    private WebApplicationContext wac;

    @Autowired
    @InjectMocks
    private RestExceptionHandler restExceptionHandler;

    private MockMvc mockMvc;

    @Before
    public void setup() {

        mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    @Controller
    @RequestMapping(value = CoreConf.REST_API_VERSION+CoreConf.CORE_BASE_URL)
    public static class ExceptionController {
        @RequestMapping(value = "/archivesException", method = RequestMethod.GET)
        public void testApplicationException() {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ACCOUNT_ERROR);
        }

        @RequestMapping(value = "/illegalArgumentException", method = RequestMethod.POST)
        public void testIllegalArgumentException() {
            throw new IllegalArgumentException();
        }

        @RequestMapping(value = "/sueccessRequest", method = RequestMethod.GET)
        @ResponseStatus(HttpStatus.OK)
        public void testSuccessRequest() {

        }
    }

    @Test
    public void testArchivesException() throws Exception {
        Assert.assertNotNull(restExceptionHandler);
        mockMvc.perform(
                MockMvcRequestBuilders.get(CoreConf.REST_API_VERSION+CoreConf.CORE_BASE_URL+"/archivesException"))
                .andDo(result->{
                    Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), result.getResponse().getStatus());
                    String response = result.getResponse().getContentAsString();
                    Assert.assertNotNull(response);
                    JsonNode node = JsonUtils.getJsonTreeByJsonText(response);
                    log.info("ResponseContent: "+response);
                    Assert.assertEquals(node.get("errorCode").asText(), CoreErrorCode.ACCOUNT_ERROR);
                });
    }

    @Test
    public void testIllegalArgumentException() throws Exception {
        Assert.assertNotNull(restExceptionHandler);
        mockMvc.perform(
                MockMvcRequestBuilders.post(CoreConf.REST_API_VERSION+CoreConf.CORE_BASE_URL+"/illegalArgumentException"))
                .andDo(result -> {
                    Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), result.getResponse().getStatus());
                    String response = result.getResponse().getContentAsString();
                    Assert.assertNotNull(response);
                    JsonNode node = JsonUtils.getJsonTreeByJsonText(response);
                    log.info("ResponseContent: "+response);
                    Assert.assertEquals(node.get("errorCode").asText(), CoreErrorCode.SYSTEM_ERROR);
                });
    }

    @Test
    public void testSuccestRequest() throws Exception{
        Assert.assertNotNull(restExceptionHandler);
        mockMvc.perform(
                MockMvcRequestBuilders.get(CoreConf.REST_API_VERSION+CoreConf.CORE_BASE_URL+"/sueccessRequest"))
                .andDo( result -> {
                    Assert.assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
                });
    }
}
