package gov.archives.core.controller;

import java.util.HashMap;

import com.fasterxml.jackson.databind.JsonNode;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import org.iii.common.util.StringUtils;

import gov.archives.common.json.JsonUtils;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.service.MenuService;

import static org.mockito.Mockito.when;

/**
 * Created by 140631 on 2016/8/12.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:spring-security.xml",
        "classpath:spring-service.xml",
        "classpath:spring-mapper-test.xml",
        "classpath:spring-mvc.xml"})
@WebAppConfiguration
public class MenuControllerTest {
    private static final Logger log = LoggerFactory.getLogger(MenuControllerTest.class);

    @Autowired
    private WebApplicationContext wctx;

    @InjectMocks
    @Autowired
    private MenuController controller;

    @Mock
    private MenuService menuService;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.webAppContextSetup(wctx)
                                 .apply(SecurityMockMvcConfigurers.springSecurity())
                                 .build();
    }

    @Test
    @WithMockUser(roles = {""})
    public void testHomeForbidden() throws Exception {
        mockMvc.perform(
                MockMvcRequestBuilders
                        .get(CoreConf.REST_API_VERSION + "/home")
                        .accept(MediaType.APPLICATION_JSON))
               .andDo(result -> Assert.assertEquals(HttpStatus.FORBIDDEN.value(), result.getResponse().getStatus()));
    }

    @Test
    @WithMockUser(roles = {"管理員"})
    public void testMenuNotFound() throws Exception {
        when(menuService.getMenuTree()).thenReturn(new HashMap<>());

        mockMvc.perform(
                MockMvcRequestBuilders
                        .get(CoreConf.REST_API_VERSION + CoreConf.CORE_BASE_URL + MenuController.GET_MENUS + "/all")
                        .accept(MediaType.APPLICATION_JSON))
               .andDo(result -> {
                   Assert.assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
                   verifyExceptionMessage(result.getResponse().getContentAsString());
               });
    }

    private void verifyExceptionMessage(String contentJson) {
        Assert.assertFalse(StringUtils.isEmpty(contentJson));
        Assert.assertEquals("{\"menu\":{}}", contentJson);
    }

    private void verifyMenuJson(String menuJson) {
        Assert.assertFalse(StringUtils.isEmpty(menuJson));

        JsonNode jsonTree = JsonUtils.getJsonTreeByJsonText(menuJson);

        Assert.assertNotNull(jsonTree);

        // TopMenuVo topMenu = jsonTree.get("menu")
    }

}
