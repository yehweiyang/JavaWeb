package gov.archives.core;

/**
 * Created by 140631 on 2016/7/26.
 */
public class TestConf {
    public static final String TEST_RESOURCES_FOLDER = "test-resources";
}
