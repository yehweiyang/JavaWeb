# domain.entity

## 目的

測試 domain model 之 entitiy 物件用