package gov.archives.core.conf;

import java.io.File;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import org.iii.common.util.DebugUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.util.EncryptUtils;

/**
 * Created by kshsu on 2016/10/11.
 */
public class SecKeyInitializerTest {

    private static final String PROPERTY_SECRETKEY_SEGMENT = "1,5,7";
    private static final String PROPERTY_SECRETKEY_PART1 = "sk01";
    private static final String PROPERTY_SECRETKEY_PART2 = "sk02";
    private static final String PROPERTY_SECRETKEY_PART3 = "sk03";
    private static final String PROPERTY_SECRETKEY_PART4 = "sk04";
    private static final String PROPERTY_SECRETKEY_PART5 = "sk05";
    private static final String PROPERTY_SECRETKEY_PART6 = "sk06";
    private static final String PROPERTY_SECRETKEY_PART7 = "sk07";
    private static final String PROPERTY_SECRETKEY_PART8 = "sk08";
    private static final String PROPERTY_SECRETKEY_PART9 = "sk09";
    private static final String PROPERTY_SECRETKEY_PART10 = "sk10";
    private static final String[] PROPERTY_SECRETKEY_PART = new String[]{
            PROPERTY_SECRETKEY_PART1, PROPERTY_SECRETKEY_PART2, PROPERTY_SECRETKEY_PART3,
            PROPERTY_SECRETKEY_PART4, PROPERTY_SECRETKEY_PART5, PROPERTY_SECRETKEY_PART6,
            PROPERTY_SECRETKEY_PART7, PROPERTY_SECRETKEY_PART8, PROPERTY_SECRETKEY_PART9,
            PROPERTY_SECRETKEY_PART10
    };
    private static final String ENCRYPT_CONFIG_FILE_NAME = "encryptUtils.properties";
    private static File ENCRYPT_CONFIG_FILE;

    @Before
    public void setUp() {
        try {
            ENCRYPT_CONFIG_FILE =
                    Paths.get(IOUtils.loadResourceURLInClasspath(ENCRYPT_CONFIG_FILE_NAME).toURI()).toFile();
        } catch (Exception e) {
            Assert.assertNull(e);
        }
    }

    @Test
    public void mainTest() throws Exception {

        List<String> sk_list = Arrays.asList(PROPERTY_SECRETKEY_SEGMENT.split(","));
        Map<Integer, String> sk_list_data = new HashMap<>();
        String SECRETKEY = EncryptUtils.txtToBase64(RandomStringUtils.random(24, true, true));

        DebugUtils.dumpObject("SECRETKEY= " + SECRETKEY);

        // 要添加的資料
        String appendData = getRandomBase64Text(SECRETKEY.length() % sk_list.size());

        for (Integer j = 0; j < sk_list.size(); j++) {
            // 分段資料長度 = sercrtkey 長度 / 分幾段
            int segmentSecretDataLength = SECRETKEY.length() / sk_list.size();

            if (!StringUtils.isEmpty(sk_list.get(j))) {
                if (j == 0) {
                    sk_list_data.put(Integer.valueOf(sk_list.get(j)), SECRETKEY.substring(j, segmentSecretDataLength) +
                            (!j.equals(sk_list.size() - 1) ? appendData : ""));
                } else if (j == (sk_list.size() - 1)) {
                    sk_list_data.put(Integer.valueOf(sk_list.get(j)),
                            SECRETKEY.substring(j * segmentSecretDataLength, SECRETKEY.length()));
                } else {
                    sk_list_data.put(Integer.valueOf(sk_list.get(j)),
                            SECRETKEY.substring(j * segmentSecretDataLength, (j + 1) * segmentSecretDataLength) +
                                    (!j.equals(sk_list.size() - 1) ? appendData : ""));
                }
            } else {
                throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR);
            }
        }

        DebugUtils.dumpObject("SECRETKEY map data= " + sk_list_data);

        Properties propEn = new Properties();

        propEn.load(
                IOUtils.loadResourceInClasspath(ENCRYPT_CONFIG_FILE_NAME));

        for (Integer i = 0; i < PROPERTY_SECRETKEY_PART.length; i++) {
            // 分段資料長度 = sercrtkey 長度 / 分幾段 + 添加資料長度
            int segmentSecretDataLength = SECRETKEY.length() / sk_list.size() + appendData.length();

            propEn.setProperty(PROPERTY_SECRETKEY_PART[i], getRandomBase64Text(segmentSecretDataLength));

            for (Integer sk_list_data_key : sk_list_data.keySet()) {
                if ((i + 1) == sk_list_data_key) {
                    propEn.setProperty(PROPERTY_SECRETKEY_PART[i], sk_list_data.get(sk_list_data_key));
                }
            }
        }

        DebugUtils.dumpObject("encryptUtils.properties= " + propEn);

        DebugUtils.dumpObject("decrypt seckey= " + getRandomSecKey(propEn));

        Assert.assertEquals(SECRETKEY, getRandomSecKey(propEn));
    }

    private String getRandomBase64Text(int size) throws CoreException {
        return EncryptUtils.txtToBase64(RandomStringUtils.random(24, true, true)).substring(0, size);
    }

    private String getRandomSecKey(Properties properties) {
        List<String> sk_list;
        Map<Integer, String> sk_list_data = new HashMap<>();
        String rtnSecKey = "";
        try {
            String SECRETKEY = EncryptUtils.txtToBase64(RandomStringUtils.random(24, true, true));

            sk_list = Arrays.asList(PROPERTY_SECRETKEY_SEGMENT.split(","));

            // 要添加的資料
            String appendData = getRandomBase64Text(SECRETKEY.length() % sk_list.size());

            for (Integer j = 0; j < sk_list.size(); j++) {
                sk_list_data
                        .put(j, properties.getProperty(PROPERTY_SECRETKEY_PART[Integer.parseInt(sk_list.get(j)) - 1]));
            }

            for (Integer i = 0; i < sk_list_data.size(); i++) {
                if (i == sk_list_data.size() - 1) {
                    rtnSecKey += sk_list_data.get(i);
                } else {
                    rtnSecKey +=
                            sk_list_data.get(i).substring(0, sk_list_data.get(i).length() - appendData.length());
                }
            }
        } catch (CoreException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PROPERTY_SETTING_ERROR, ex);
        }
        return rtnSecKey;
    }
}
