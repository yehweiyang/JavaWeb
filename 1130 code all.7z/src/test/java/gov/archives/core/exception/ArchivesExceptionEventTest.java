package gov.archives.core.exception;

import java.io.IOException;

import com.fasterxml.jackson.databind.JsonNode;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.StaticApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.WebApplicationContext;

import org.iii.common.util.StringUtils;

import gov.archives.common.json.JsonUtils;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.controller.RestExceptionHandler;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.util.LogUtils;
import gov.archives.exchange.event.ArchivesExceptionEvent;
import gov.archives.exchange.event.handler.GlobalEventHandler;

/**
 * Created by kshsu on 2016/9/21.
 * UnitTest for ArchivesExceptionEvent
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:spring-service.xml",
        "classpath:spring-mapper-test.xml",
        "classpath:spring-mvc.xml"})
@WebAppConfiguration
public class ArchivesExceptionEventTest {

    private static final String ERROR_CODE = CoreErrorCode.SYSTEM_ERROR;
    private static final String ERROR_MESSAGE = CoreErrorMessage.findByCode(CoreErrorCode.SYSTEM_ERROR);
    private static final Level ROOT_LOGGER_LEVEL = Level.INFO;

    private static String RESPONSE_CONTENT = "ResponseContent";
    private static String JSON_NODE_ERRORCODE = "errorCode";
    private static final String MOCKTTO_TEST_URL = "archivesExceptionTest";

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    @InjectMocks
    private RestExceptionHandler restExceptionHandler;

    private MockMvc mockMvc;

    /* 錯誤訊息
        127.0.0.1,gov.archives.core.exception.ArchivesException,archives,系統錯誤,SYS0000,高
        127.0.0.1,gov.archives.core.exception.ArchivesExceptionEventTest,archives,系統錯誤,SYS0000,高
     */

    private StaticApplicationContext context;

    // 初始化事件
    private ArchivesExceptionEvent archivesExceptionEvent;

    @Before
    public void setUp() {
        // RootLogger 等級
        LogManager.getRootLogger().setLevel(ROOT_LOGGER_LEVEL);

        context = new StaticApplicationContext();
        // 加入監聽器
        context.addApplicationListener(new GlobalEventHandler());
        context.refresh();

        // 初始化事件
        archivesExceptionEvent =
                new ArchivesExceptionEvent(this, ERROR_MESSAGE,
                        ERROR_CODE);

        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    public void mainTest() {
        try {
            // 測試 ArchivesException 呼叫方式 使用 ArchivesException.getInstanceByErrorCode
            ArchivesException.getInstanceByErrorCode(ERROR_CODE);

            // 測試 ArchivesException 呼叫方式 使用 ArchivesException.getInstanceByErrorCode
            // 未定義的 errorCode
            ArchivesException.getInstanceByErrorCode("SYS8888");

            // 測試 ArchivesException 呼叫方式 使用 ArchivesException.getInstanceByErrorCode
            // 拋出系統錯誤訊息
            ArchivesException.getInstanceByErrorCode(ERROR_CODE, new Exception());

            // 測試 ArchivesException 呼叫方式 new ArchivesException()
            new ArchivesException(ERROR_MESSAGE);

            // 測試 ArchivesException 呼叫方式 new ArchivesException()
            // 拋出系統錯誤訊息
            new ArchivesException(ERROR_MESSAGE, new IOException());

            // 測試 ArchivesException 呼叫方式 使用 Listener 觸發
            context.publishEvent(archivesExceptionEvent);
        } catch (Exception ex) {
            LogUtils.logException(ex);
            Assert.assertNull(ex);
        }
    }

    @Controller
    @RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.CORE_BASE_URL)
    public static class ExceptionController {
        @RequestMapping(value = "/" + MOCKTTO_TEST_URL,
                method = RequestMethod.GET)
        public void testApplicationException() {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ACCOUNT_ERROR);
        }
    }

    @Test
    public void testArchivesException() throws Exception {
        Assert.assertNotNull(restExceptionHandler);
        mockMvc.perform(
                MockMvcRequestBuilders
                        .get(CoreConf.REST_API_VERSION + CoreConf.CORE_BASE_URL + "/" + MOCKTTO_TEST_URL))
               .andDo(result -> {
                   Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), result.getResponse().getStatus());
                   String response = result.getResponse().getContentAsString();
                   Assert.assertNotNull(response);
                   JsonNode node = JsonUtils.getJsonTreeByJsonText(response);
                   LogUtils.info(RESPONSE_CONTENT + ": " + response);
                   Assert.assertEquals(node.get(JSON_NODE_ERRORCODE).asText(), CoreErrorCode.ACCOUNT_ERROR);
               });
    }
}
