package gov.archives.dox.mapper.query;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.dox.domain.entity.SubrogationEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class SubrogationQueryMapperTest {


    @Autowired
    private SubrogationQueryMapper queryMapper;

    @Before
    public void setUp() throws Exception {}


    @Test
    public void testFindByMap() throws Exception {
        Map<String, Object> queryMap = new HashMap<>();
        queryMap.put("agencyId", "301000000A");
        queryMap.put("authAgencyId", "376470000A");

        List<SubrogationEntity> entityList = queryMapper.findByMap(queryMap);

        Assert.assertNotNull(entityList);
    }
}
