//package gov.archives.dox.mapper.query;
//
//import java.util.UUID;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import gov.archives.dox.domain.entity.entity.UserInfoEntity;
//import gov.archives.dox.service.UserInfoService;
//
///**
// * UserInfoQueryTest
// * <p>
// * Created by WeiYang on 2016/11/29.
// */
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
//public class UserInfoQueryTest {
//
//    private UUID sysId;
//    @Autowired
//    private UserInfoService infoServiceBack;
//    UserInfoEntity entity = new UserInfoEntity();
//
//    @Test
//    public void findAll() {
//        System.out.println("test...................");
//        System.out.println(infoServiceBack.findAll());
//    }
//
//    @Test
//    public void findValueById(){
//        System.out.println(infoServiceBack.findById("tw00182691"));
//
//    }
//    @Test
//    public void add(){
//        entity.setSysId(UUID.randomUUID());
//        entity.setAccount("tw00182691");
//        entity.setActiveStatus(1);
//        entity.setEmail("tw00182691@gmail.com");
//        entity.setMobileNumber("0927851981");
//        entity.setOrgInfo("衛生福利部社會救助及社工司");
//        entity.setPhoneNumber("02-85906614");
//        entity.setUserName("葉威揚");
//        infoServiceBack.add(entity);
//    }
//
//    @Test
//    public void update(){
//        entity.setActiveStatus(-1);
//        entity.setAccount("tw00182691");
//        entity.setActiveStatus(-47);
//        entity.setEmail("tw00182691@gmail.com");
//        entity.setMobileNumber("0927851981");
//        entity.setOrgInfo("衛生福利部社會救助及社工司");
//        entity.setPhoneNumber("02-85906614");
//        entity.setUserName("葉威揚");
//        infoServiceBack.update(entity);
//    }
//
//    @Test
//    public void delete(){
//        infoServiceBack.delete("tw00182691");
//    }
//
//}
