package gov.archives.dox.service;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.joda.time.LocalDateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.conf.CommonConfig;
import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.TestConf;
import gov.archives.core.conf.CoreConf;
import gov.archives.dox.domain.entity.OrgCertExpiredEntity;
import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.facade.ReportOutputFacade;
import gov.archives.exchange.service.ReportServiceTest;

import static gov.archives.dox.service.OrgCertService.DAY_PARAMETER;
import static gov.archives.dox.service.OrgCertService.MONTH_PARAMETER;
import static gov.archives.dox.service.OrgCertService.TITLE_NAME;
import static gov.archives.dox.service.OrgCertService.TITLE_PARAMETER;
import static gov.archives.dox.service.OrgCertService.YEAR_PARAMETER;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class OrgCertServiceTest {
    private static final Logger log = LoggerFactory.getLogger(OrgCertServiceTest.class);
    private static final String REPORT_FOLDER = "reportTemplate";
    private static final String TEST_RESOURCES_FOLDER = "test-resources";
    private static final String REPORT_OUTPUT_FOLDER = "reportOutput";
    private static final String JASPER_REPORT_TEMPLATE = "certExpired";

    @Autowired
    private ReportOutputFacade outputFacade;

    @Autowired
    OrgCertService orgCertService;

    @Before
    public void setUp() throws Exception {
        Path outputFolder = CommonConfig.getRuntimeRoot(ReportServiceTest.class)
                                        .resolve(TEST_RESOURCES_FOLDER)
                                        .resolve(REPORT_OUTPUT_FOLDER);
        FileSystemUtils.checkFolder(outputFolder);
    }

    @Test
    public void test1GetCertExpired() {
        List<OrgCertExpiredEntity> entityList = orgCertService.getCertExpired();

        Assert.assertNotNull(entityList);
    }

    //@Test
    public void test2CertExpiredReport() {
        List<OrgCertExpiredEntity> entityList = orgCertService.getCertExpired();
        try {
            exportReport(entityList, JASPER_REPORT_TEMPLATE, "pdf");
            exportReport(entityList, JASPER_REPORT_TEMPLATE, "ods");
        } catch (Exception ex) {
            Assert.assertNull(ex);
        }
    }

    private File getTestFileSaveDir() {
        return CommonConfig.getRuntimeRoot(OrgCertServiceTest.class)
                           .resolve(TestConf.TEST_RESOURCES_FOLDER)
                           .resolve(REPORT_OUTPUT_FOLDER)
                           .toFile();
    }

    //@Test
    public void test3CleanReport() {
        try {
            File directory = getTestFileSaveDir();
            FileUtils.deleteDirectory(directory);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }

    private Map<String, Object> initParamsMap() {
        Map<String, Object> paramsMap = new HashMap<>();
        paramsMap.put(TITLE_PARAMETER, TITLE_NAME);
        LocalDateTime dateTime = LocalDateTime.now();
        paramsMap.put(YEAR_PARAMETER, dateTime.getYear() - 1911);
        paramsMap.put(MONTH_PARAMETER, dateTime.getMonthOfYear());
        paramsMap.put(DAY_PARAMETER, dateTime.getDayOfMonth());
        return paramsMap;
    }

    private void exportReport(Object javaBean, String reportTemplate, String exportType) {
        try {
            File reportTemplateFile =
                    Paths.get(IOUtils.loadResourceURLInClasspath(
                            REPORT_FOLDER + "/" + reportTemplate + CoreConf.SUFFIX_JASPER).toURI())
                         .toFile();

            File reportOutput = CommonConfig.getRuntimeRoot(ReportServiceTest.class)
                                            .resolve(TEST_RESOURCES_FOLDER)
                                            .resolve(REPORT_OUTPUT_FOLDER)
                                            .resolve(reportTemplate + ("pdf".equals(exportType) ? CoreConf.SUFFIX_PDF :
                                                    CoreConf.SUFFIX_ODS))
                                            .toFile();

            outputFacade.genReportToFile(
                    new ReportInputModel(reportTemplateFile.getAbsolutePath(), reportOutput.getAbsolutePath(), javaBean,
                            initParamsMap(), exportType));

        } catch (Exception e) {
            log.error(StringUtils.stackTraceFromException(e));
            Assert.assertNull(e);
        }
    }
}
