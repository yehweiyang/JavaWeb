package gov.archives.dox.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.dox.domain.entity.SubrogationEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class SubrogationServiceTest {

    @Autowired
    SubrogationService subrogationService;

    @Before
    public void setUp() throws Exception {}

    @Test
    public void testGetByQueryMap() throws Exception {
        Map<String, Object> queryMap = new HashMap<>();

        queryMap.put("agencyId", "A01060000A");
        queryMap.put("authAgencyId", "301000000A");
        queryMap.put("exactMatch", "true");

        List<SubrogationEntity> entityList = subrogationService.getByQueryMap(queryMap);

        Assert.assertNotNull(entityList);
    }
}
