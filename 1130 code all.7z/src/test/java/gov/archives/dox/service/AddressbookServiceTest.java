package gov.archives.dox.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.dox.domain.entity.AddressBookBase;
import gov.archives.dox.domain.entity.AddressbookEntity;
import gov.archives.dox.mapper.query.AddressbookQueryMapper;

/**
 * AddressbookServiceTest
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper-test.xml"})
public class AddressbookServiceTest {

    private static final String TEST_ORG_ID = "A07090300D";
    private static final String TEST_UNIT_ID = "U300000";

    @Autowired
    private AddressbookService service;

    @Before
    public void setUp() throws Exception {}

    private Map<String, Object> prepareQueryMap() {
        Map<String, Object> queryMap = new HashMap<>();

        queryMap.put(AddressbookQueryMapper.KEY_ORG_ID, TEST_ORG_ID);
        queryMap.put(AddressbookQueryMapper.KEY_UNIT_ID, TEST_UNIT_ID);

        return queryMap;
    }

    @Test
    public void testGetByOrgUnitId() throws Exception {
        AddressbookEntity entity = service.getByOrgUnitId(prepareQueryMap());

        Assert.assertNotNull(entity);
    }

    @Test
    public void testGetAllAddressBook() throws Exception {
        List<AddressBookBase> entityList = service.getAllAddressBook(new HashMap<String, Object>());

        Assert.assertNotNull(entityList);
    }
}
