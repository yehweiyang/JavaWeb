angular.module('ArchivesApp').controller('UserVerificationController', function($scope, $http, $uibModal, archivesConstant, archivesService) {
    $scope.$on('$viewContentLoaded', function() {
        $scope.queryUsers();
    });

    $scope.archivesService = archivesService;
    $scope.userList = [];
    $scope.isQueried = false;

    $scope.queryUsers = function() {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH
                + archivesConstant.SYSTEM_TOOL_PATH + "/user/list";

        return $http.get(url).then(function successCallback(response) {
            $scope.userList = response.data;
            $scope.isQueried = true;
        }, function errorCallback(response) {
            $scope.isQueried = true;
        });
    };

    $scope.selected = {
        user: $scope.userList[0]
    };

    $scope.openUserDetail = function() {
        var uibModalInstance = $uibModal.open({
            templateUrl: archivesConstant.APP_PATH + "/views/SystemTool/userAccountModification.html",
            controller: "UserAccountModificationController",
            size: 'lg',
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            $rootScope.settings.appPath + '/controllers/SystemTool/UserAccountModificationController.js',
                        ]
                    });
                }],
                userList: function() {
                    return $scope.userList;
                },
                user: function () {
                    return $scope.selected.user;
                }
            }
        });
    };
});