angular.module("ArchivesApp").constant('reportScheduleConstant', {
    DOMAIN_PATH: "/reportScheduleManage",
    INIT_PATH: "/init",
    RUN_SCHEDULE_PATH: "/runSchedule",
    RUN_SUCCESS_MSG: "排程執行成功"
}).controller('ReportScheduleManageController', function($scope, $http, reportScheduleConstant, archivesService, archivesConstant) {
    var actionAddress;
    $scope.archivesService = archivesService;

    $scope.$on('$viewContentLoaded', function() {
        actionAddress = genActionPath(reportScheduleConstant.INIT_PATH);

        return $http.get(actionAddress)
            .success(function(data) {
                $scope.dateRange = data.dateRange;
                $scope.reportScheduleList = data.scheduleList;
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    });

    $scope.runScheduleAction = function(reportScheduleName) {
        actionAddress = genActionPath(reportScheduleConstant.RUN_SCHEDULE_PATH + "/" + reportScheduleName);
        return $http.get(actionAddress)
            .success(function() {
                successViewer(reportScheduleConstant.RUN_SUCCESS_MSG);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    var genActionPath = function(actionUrl) {
        return archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + archivesConstant.SYSTEM_TOOL_PATH +
                reportScheduleConstant.DOMAIN_PATH + actionUrl;
    };

});
