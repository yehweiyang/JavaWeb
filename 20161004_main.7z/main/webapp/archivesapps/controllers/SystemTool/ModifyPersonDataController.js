angular.module('ArchivesApp').controller('ModifyPersonDataController',
    function($rootScope, $scope, $timeout, $http, pkiService, archivesConstant) {

    $scope.$on('$viewContentLoaded', function() {
        queryUser();
    });

    $scope.slot = pkiService.querySlot();
    $scope.cardStatus = false;
    var errorCode = "";
    $scope.errorMessage = "";
    $scope.errorCode = "";
    $scope.showErrorMessage = false;

    $scope.user = {};

    var queryUser = function() {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH
                + archivesConstant.SYSTEM_TOOL_PATH + "/user/getUser";
        return $http.get(url).then(function(response) {
            $scope.user = response.data;

        });
    };

    $rootScope.$on('slot:find', function() {
        $scope.slot = true;
        $scope.cardStatus = true;
    });

    $rootScope.$on('slot:empty', function() {
        $scope.slot = false;
        $scope.cardStatus = false;
    });


    $scope.save = function() {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + archivesConstant.SYSTEM_TOOL_PATH + "/user/modifyUser";
        var userJson = angular.toJson($scope.user);
        $http.post(url, userJson).then(function successCallback(response) {
            successViewer(archivesConstant.UPDATE_SUCCESS_MSG);
        },
        function errorCallback(response) {
        //angular.copy(userCopy, $scope.user);
        console.log(response);
        $scope.errorCode = response.data.errorCode;
        $scope.errorMessage = response.data.errorMessage;
        if($scope.errorCode=="SYS0000" || $scope.errorCode=="SYS0001") {
            console.log("ErrorCode= "+$scope.errorCode);
            handleSysErrorMessage();
        }
        else
        handleErrorMessage()
        console.log("ErrorCode= "+$scope.errorCode);
        console.log("ErrorMsg= "+$scope.errorMessage);
    });
    };

        var handleErrorMessage = function () {
            $scope.showErrorMessage = true;
            $timeout(function() {
                $scope.showErrorMessage = false;
            }, 3000);
        };

        var handleSysErrorMessage = function() {
            $scope.errorMessage+="，即將導回首頁";
            $scope.showErrorMessage = true;
            $timeout(function() {
                $scope.showErrorMessage = false;
            }, 3000);
            $window.location.href = archivesConstant.WEB_ROOT_PATH + "/index";
        };
});