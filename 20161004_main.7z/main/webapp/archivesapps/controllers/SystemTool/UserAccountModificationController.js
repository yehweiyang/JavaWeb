angular.module('ArchivesApp').controller('UserAccountModificationController',
    function ($rootScope, $scope, $http, $uibModalInstance, $timeout, $location, $window, pkiService, userList, user, archivesConstant) {


        setTimeout(function () {
            $('.archives-checkbox').checkboxpicker();
            $('.selectpicker').selectpicker();
        }, 500);

        $uibModalInstance.opened.then(function () {
            queryRoles();
        });

        $rootScope.$on('slot:find', function () {
            $scope.cardStatus = true;
        });
        $rootScope.$on('slot:empty', function () {
            $scope.cardStatus = false;
        });

        $scope.userList = userList;
        $scope.user = user;
        $scope.shadowUser = angular.copy(user);
        var userCopy = angular.copy(user);
        $scope.roleList = [];
        $scope.cardStatus = false;
        $scope.slot = pkiService.querySlot();
        $scope.errorMessage = "";
        $scope.showErrorMessage = false;


        queryRoles = function () {
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH
                + archivesConstant.SYSTEM_TOOL_PATH + "/role/listRoleName";
            return $http.get(url)
                .then(function (response) {
                    $scope.roleList = response.data;
                });
        };

        $scope.searchRoleName = function (keyword) {
            angular.forEach($scope.roleList, function (role) {
                if (role.roleName.match(keyword))
                    $scope.shadowUser.roleName = role.roleName;
            });
        };

        $scope.save = function () {
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH
                + archivesConstant.SYSTEM_TOOL_PATH + "/user/saveUser";
            if ($scope.userDetailForm.$pristine) {
                $uibModalInstance.close();
                return;
            }
            $scope.shadowUser.phoneNumber = $scope.shadowUser.phoneAreaCode + "-" + $scope.shadowUser.phoneLocalNumber
                + ($scope.shadowUser.phoneExtNumber ? ("#" + $scope.shadowUser.phoneExtNumber) : "");
            angular.copy($scope.shadowUser, $scope.user);
            var userJson = angular.toJson($scope.user);
            $http.post(url, userJson).then(function successCallback(response) {
                successViewer(archivesConstant.UPDATE_SUCCESS_MSG);
                setTimeout(function () {
                    $uibModalInstance.close($scope.user);
                }, 1000);
            }, function errorCallback(response) {
                handleErrorMessage(response);
            });
        };

        $scope.rollback = function () {
            angular.copy(userCopy, $scope.shadowUser);
            angular.copy(userCopy, $scope.user);
            $scope.userDetailForm.$setPristine();
        };

        function handleErrorMessage(response) {
            angular.copy(userCopy, $scope.user);
            if (response.data.errorCode == "SYS0000" || response.data.errorCode == "SYS0001") {
                exceptionViewer(response, true);
            } else {
                $scope.showErrorMessage = true;
                $scope.errorMessage = response.data.errorMessage;
                $timeout(function () {
                    $scope.showErrorMessage = false;
                }, 3000);
            }
        }


        $scope.cancel = function () {
            angular.copy(userCopy, $scope.shadowUser);
            angular.copy(userCopy, $scope.user);
            $scope.userDetailForm.$setPristine();
            $uibModalInstance.dismiss('cancel');
        };

    });