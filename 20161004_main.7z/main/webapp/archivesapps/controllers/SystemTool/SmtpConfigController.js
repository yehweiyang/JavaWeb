angular.module('ArchivesApp').controller('SmtpConfigController', function ($scope, $http, archivesConstant) {
    $('.archives-checkbox').checkboxpicker();

    $scope.errorMessage = false;

    $http.get(archivesConstant.SYSTEMTOOL_AJAX_PATH + '/searchConfig')
        .then(function (response) {
            console.log(response);
            $scope.account = isNull(response.data.loginAccount);
            $scope.smtpIP = isNull(response.data.smtpServerIp);
            $scope.smtpPassword = isNull(response.data.loginPassword);
            $scope.portNumber = (isNull(response.data.smtpServerPort) != '') ? parseInt(response.data.smtpServerPort) : '';
            $scope.lastUpdateTime = isNull(response.data.lastUpdateTime);
            $('#ssl').prop('checked', (response.data.useSsl == 'false')? false : true);
            $('#certification').prop('checked',(response.data.certification == 'false')? false : true);
        }), function errorCallback(response) {
                exceptionViewer(response, false);
    };

    $scope.updateInfo = function () {

        if ($scope.account == '' || $scope.smtpIP == '' || $scope.portNumber == '') {
            errorMessage(true, '請確實填寫欄位');
            return;
        }

        if ($scope.smtpPassword == '' && $scope.firstPassword == '') {
            errorMessage(true, '第一次輸入請設定密碼');
            return;
        }

        if ($scope.firstPassword != $scope.secPassword) {
            errorMessage(true, '密碼與第一次不符');
            return;
        }

        var infoValue = {
            account: $scope.account,
            firstPassword: $scope.firstPassword,
            smtpIP: $scope.smtpIP,
            portNumber: $scope.portNumber,
            sslValue: $('#ssl').prop('checked'),
            authenticateValue: $('#certification').prop('checked')
        };

        $http.get(archivesConstant.SYSTEMTOOL_AJAX_PATH + '/updateConfig', {params: infoValue})
            .then(function (response) {
                errorMessage(false, '');
                successViewer(archivesConstant.UPDATE_SUCCESS_MSG);
            }), function errorCallback(response) {
                exceptionViewer(response, false);
        };
    };

    function isNull(infoValue){
        (infoValue == 'null') ? infoValue = '' : infoValue = infoValue;
        return infoValue;
    }

    function errorMessage(errorStatus, errorMessage) {
        $scope.errorMessage = errorStatus;
        $scope.error = errorMessage;
    }
});