angular.module("ArchivesApp").controller('LoginHistoryController', function($scope, $http, archivesConstant, archivesService) {
    $('.selectpicker').selectpicker();
    $('.archives-checkbox').checkboxpicker();
    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = 'account'
    $scope.$on('$viewContentLoaded', function() {
        $scope.resetBt();
    });

    $scope.queryBt = function() {
        $http({
            url: archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                '/exchange/querLoginHistory',
            method: "GET",
            params: $scope.login
        }).success(function(response) {
            $scope.result = !(response.length === 0)
            $scope.noResult = (response.length === 0)
            $scope.queryData = $scope.result ? response : [];

        }).error(function(response) {
            exceptionViewer(response, false);
        });
    };



    $scope.resetBt = function() {
        $scope.noResult = false;
        $scope.result = false;
        $scope.login.account = "";
        $scope.login.dateFrom = new Date();
        $scope.login.timeFrom = '00';
        $scope.login.dateTo = new Date();
        $scope.login.timeTo = 23;
    }

    $scope.archivesService.pager.itemsPerPage = 100;

    $scope.hourList = function () {
        var array = [];
        for (var i = 0; i < 24; i++) {
            var hour = i.toString().length < 2 ? "0" + i : i;
            array.push(hour);
        }
        return array;
    };



    $scope.openDateFromCalendar = function() {
        $scope.dateFromCalendar.opened = true;
    };


    $scope.openDateToCalendar = function() {
        $scope.dateToCalendar.opened = true;
    };
    $scope.dateFromCalendar = {
        opened: false
    };

    $scope.dateToCalendar = {
        opened: false
    };

});