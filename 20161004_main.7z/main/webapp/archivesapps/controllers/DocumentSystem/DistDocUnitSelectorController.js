angular.module('ArchivesApp').controller('DistDocUnitSelectorController',
        function($rootScope, $scope, $http, $timeout, $uibModalInstance, archivesService, pkiService, target, selected) {

    var switchEnum = {"SET_SENDER":1, "SET_RECEIVER":2, "SET_MAPPING":3}

    $uibModalInstance.opened.then(function(){
        $scope.queryUnit();
        $scope.isQueried = true;
    });

    $scope.isQueried = false;
    $scope.functionSwitch = switchEnum[target];
    $scope.unitList = [];
    var checkedUnitList = [];
    $scope.currentPage = 1;
    $scope.maxSize = 10;
    $scope.unitPerPage = 10;
    $scope.senderUnit = {};
    $scope.archivesService = archivesService;
    $scope.slot = pkiService.querySlot();
    $scope.cardStatus = false;

    $rootScope.$on('slot:find', function() {
        $scope.cardStatus = true;
    });
    $rootScope.$on('slot:empty', function() {
        $scope.cardStatus = false;
    });

    $scope.queryUnit = function () {
        switch($scope.functionSwitch) {
            case switchEnum.SET_SENDER:
                queryCenterSenderUnit();
                break;
            case switchEnum.SET_RECEIVER:
                queryCenterReceiverUnit();
                break;
            case switchEnum.SET_MAPPING:
                $scope.senderUnit = selected;
                queryMappingBySender();
                break;
        }
    };

    $scope.reset = function() {
        $scope.search.orgId = "";
        $scope.search.unitId = "";
        $scope.search.orgUnitName = "";
    };

    var queryCenterSenderUnit = function() {
        var url = "/manageWeb/v1/DocumentSystem/listCenterSenderUnit";
        return $http.get(url).then(function(response) {
            $scope.unitList = response.data;
        });
    };

    var queryCenterReceiverUnit = function() {
        var url = "/manageWeb/v1/DocumentSystem/listCenterReceiverUnit";
        return $http.get(url).then(function(response) {
            $scope.unitList = response.data;
        });
    };

    var queryMappingBySender = function() {
        var url = "/manageWeb/v1/DocumentSystem/listUnitMappingBySender";
        return $http.get(url, {
            params: {
                orgId: $scope.senderUnit.orgId,
                unitId: $scope.senderUnit.unitId
            }
        }).then(function(response) {
            $scope.unitList = response.data;
        });
    };

    $scope.confirm = function() {
        switch($scope.functionSwitch) {
            case switchEnum.SET_SENDER:
                setSender();
                break;
            case switchEnum.SET_RECEIVER:
                setReceiver();
                break;
            case switchEnum.SET_MAPPING:
                serMapping();
                break;
        }
    };

    $scope.cancel = function() {
        $uibModalInstance.close("Cancel");
    };

    var setSender = function() {
        checkedUnitList = $scope.unitList.filter(function(unit) { return unit.exist });
        var url = "/manageWeb/v1/DocumentSystem/setSenderUnit";
        $http.post(url, checkedUnitList).then(function successCallback(response) {
            $uibModalInstance.close();
        }, function errorCallback(response) {
            exceptionViewer(response, false);
        });
    };

    var setReceiver = function() {
        checkedUnitList = $scope.unitList.filter(function(unit) { return unit.exist });
        var url = "/manageWeb/v1/DocumentSystem/setReceiverUnit";
        $http.post(url, checkedUnitList).then(function successCallback(response) {
            $uibModalInstance.close();
        }, function errorCallback(response) {
            exceptionViewer(response, false);
        });
    };

    var serMapping = function() {
        checkedUnitList = $scope.unitList.filter(function(unit) { return unit.exist });
        var mappingMap = {
            senderOrgId: $scope.senderUnit.orgId,
            senderUnitId: $scope.senderUnit.unitId,
            mappingList: []
        };
        checkedUnitList.forEach(function(unit) {
            var mapping = {
                senderOrgId: $scope.senderUnit.orgId,
                senderUnitId: $scope.senderUnit.unitId,
                receiverOrgId: unit.orgId,
                receiverUnitId: unit.unitId
            };
            mappingMap.mappingList.push(mapping);
        });
        var url = "/manageWeb/v1/DocumentSystem/setDistributeMapping";
        $http.post(url, mappingMap).then(function successCallback() {
            $uibModalInstance.close();
        }, function errorCallback(response) {
            exceptionViewer(response, false);
        });
    };
});