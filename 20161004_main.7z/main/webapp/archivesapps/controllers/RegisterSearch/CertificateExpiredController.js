includeOtherScript("reportService");
angular.module("ArchivesApp").controller('CertificateExpiredController', function($scope, $http, registerService, reportService, archivesConstant) {
	$scope.uibPageBase = 10;
	$scope.queryCert = null;
	$scope.start = 0;
	$scope.end = $scope.uibPageBase;
	$scope.maxSize = 5;
    $scope.certList = [];
    $scope.showLoad = true;
    $scope.reportService = reportService;
	$scope.certExpire = function() {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/certExpired/list";
	    $http.get(url).then(function(response) {
	        $scope.showLoad = false;
    		$scope.certList = response.data;
    		$scope.totalItems = $scope.certList.length;
    		$scope.currentPage = registerService.getExpireIndexPage();
    		$scope.start = 0;
    		$scope.end = $scope.uibPageBase;
    		$scope.showTable = true;
    	}, function(errResponse) {
    		$scope.showLoad = false;
    	    $scope.showTable = false;
    	});
	};
	$scope.outputFile = function(exportType) {
        if (exportType == 'ods')
       	    $scope.showODS = true;
       	else if (exportType == 'pdf')
       	    $scope.showPDF = true;
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/certExpired/download/" + exportType;
    	$http.get(url).then(function(response) {
    	    $scope.reportService.exportReportFile(url, exportType);
     	    $scope.showODS = false;
     	    $scope.showPDF = false;
        }, function(errResponse) {
            $scope.showODS = false;
            $scope.showPDF = false;
       	});
    };
	$scope.pageChanged = function() {
        $scope.end = $scope.currentPage * $scope.uibPageBase;
	    $scope.start = $scope.end - $scope.uibPageBase;
        registerService.setExpireIndexPage($scope.currentPage);
    };

	registerService.setExpireIndexPage(1)
    $scope.certExpire();
});