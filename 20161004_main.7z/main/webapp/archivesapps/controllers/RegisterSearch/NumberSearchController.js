angular.module("ArchivesApp").controller('NumberSearchController', function($scope, $http, registerService, archivesConstant) {
	$scope.uibPageBase = 10;
	$scope.checkCompare = false;
	$scope.start = 0;
	$scope.end = $scope.uibPageBase;
	$scope.maxSize = 5;
	$scope.queryDocWord = {};
    $scope.docWordList = [];
	$scope.bigPageChanged = function() {
		$scope.end = $scope.currentPage * $scope.uibPageBase;
		$scope.start = $scope.end - $scope.uibPageBase;
        registerService.setNumberCurrentPage($scope.currentPage);
	};
    $scope.toggleModal = function(){
    	$scope.showModal = false;
    };
    $scope.toggleForbidden = function(){
    	$scope.forbiddenModal = false;
    };
	$scope.open1 = function() {
    	$scope.popup1.opened = true;
    };

    $scope.open2 = function() {
        $scope.popup2.opened = true;
    };

	$scope.open3 = function() {
    	$scope.popup3.opened = true;
    };

    $scope.open4 = function() {
        $scope.popup4.opened = true;
    };
    
    
    $scope.popup1 = {
    	opened: false
    };

    $scope.popup2 = {
    	opened: false
    };
    
    $scope.popup3 = {
    	opened: false
    };

    $scope.popup4 = {
    	opened: false
    };

    $scope.restNumber = function(cacheData) {
        var queryData = $scope.queryDocWord;
        queryData.cacheData = cacheData;
        queryData.exactMatch = $scope.checkCompare;
        if ($scope.dt1 != null)
            queryData.effectDateStart = $scope.dt1.toISOString().substring(0, 10);
        else
            queryData.effectDateStart = null;
        if ($scope.dt2 != null)
            queryData.effectDateEnd = $scope.dt2.toISOString().substring(0, 10);
        else
            queryData.effectDateEnd = null;
        if ($scope.dt3 != null)
            queryData.validDateStart = $scope.dt3.toISOString().substring(0, 10);
        else
            queryData.validDateStart = null;
        if ($scope.dt4 != null)
            queryData.validDateEnd = $scope.dt4.toISOString().substring(0, 10);
        else
            queryData.validDateEnd = null;
        var config = {
            params: queryData
        };
        registerService.setNumberQueryData(queryData);
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/numberSearch/list";
    	$http.get(url, config).then(function(response) {
    	    $scope.docWordList = response.data;
    		$scope.totalItems = $scope.docWordList.length;
            $scope.currentPage = registerService.getNumberCurrentPage();
    		$scope.start = 0;
    		$scope.end = $scope.uibPageBase;
    		$scope.showError = false;
    		$scope.showTable = true;
            $scope.showLoad = false;
        }, function(errResponse) {
            $scope.errorMessage = errResponse.data.errorMessage;
            $scope.showError = true;
            $scope.showTable = false;
            $scope.showLoad = false;
    	});
    }
    
    $scope.queryBt = function(form) {
        if (form.$valid) {
        	$scope.showLoad = true;
            $scope.restNumber(false);
        } else {
            $scope.errorMessage = archivesConstant.FORM_INVALID_MSG;
            $scope.showError = true;
        }
    }
    
    $scope.resetBt = function() {
    	$scope.showError = false;
    	$scope.showTable = false;
    	$scope.queryDocWord.authAgencyId = null;
    	$scope.queryDocWord.agencyId = null;
    	$scope.queryDocWord.subRoGate = null;
    	$scope.checkCompare = false;
       	$scope.dt1 = null;
       	$scope.dt2 = null;
       	$scope.dt3 = null;
       	$scope.dt4 = null;
       	registerService.setNumberQueryData(null);
    };

    $scope.queryDocWord = registerService.getNumberQueryData();
    if ($scope.queryDocWord != null) {
        $scope.checkCompare = $scope.queryDocWord.exactMatch;
        if ($scope.queryDocWord.effectDateStart != null)
            $scope.dt1 = new Date($scope.queryDocWord.effectDateStart);
        if ($scope.queryDocWord.effectDateEnd != null)
            $scope.dt2 = new Date($scope.queryDocWord.effectDateEnd);
        if ($scope.queryDocWord.validDateStart != null)
            $scope.dt3 = new Date($scope.queryDocWord.validDateStart);
        if ($scope.queryDocWord.validDateEnd != null)
            $scope.dt4 = new Date($scope.queryDocWord.validDateEnd);
        $scope.restNumber(true);
    } else {
        $scope.queryDocWord = {};
        registerService.setNumberCurrentPage(1);
    }
});
