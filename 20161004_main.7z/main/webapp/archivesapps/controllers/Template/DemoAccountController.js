angular.module("ArchivesApp").controller('DemoAccountController', function($scope, $http) {
    $('.selectpicker').selectpicker();
    $('.archives-checkbox').checkboxpicker();
});
