includeOtherScript("reportService");

angular.module("ArchivesApp").controller('ReportSendErrController', function($scope, $http, reportService, reportConstant) {
    var actionAddress;
    var reportName = reportConstant.REPORT_SEND_ERROR;
    $scope.reportService = reportService;
    $scope.reportService.setHoursRangeFromDomId("timeTo");
    $scope.reportService.setHoursRangeFromDomId("timeFrom");
    $(".selectpicker").selectpicker("refresh");

    $scope.$on('$viewContentLoaded', function() {
        actionAddress = $scope.reportService.getInitActionUrl(reportName);

        return $http.get(actionAddress)
            .success(function(data) {
                var filter = data.filterContent;
                var result = data.resultContent;
                $scope.dateFrom = new Date(filter.dateFrom);
                $scope.dateTo = new Date(filter.dateTo);
                $scope.receiverId = filter.receiverId;
                $scope.receiverName = filter.receiverName;
                $scope.senderId = filter.senderId;
                $scope.senderName = filter.senderName;
                $scope.contentFullCmp = filter.contentFullCmp;
                $scope.reportListFromMonth = filter.reportListFromMonth;
                $scope.selectedReportFromMonth = null != filter.reportListFromMonth ? $scope.reportListFromMonth[0] : null;
                $scope.reportService.sorter.columnName = filter.sortColumnName;
                $scope.reportService.sorter.descending = filter.sortDescending;
                $scope.reportService.currentFilter = filter;
                $('#timeFrom').selectpicker("val", filter.timeFrom);
                $('#timeTo').selectpicker("val", filter.timeTo);

                setDataTable(result, false);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    });

    $scope.queryAction = function() {
        actionAddress = $scope.reportService.getQueryActionUrl(reportName);

        $scope.reportService.currentFilter = {
            dateFrom: $('#dateFrom').val(),
            dateTo: $('#dateTo').val(),
            timeFrom: $('#timeFrom').selectpicker("val"),
            timeTo: $('#timeTo').selectpicker("val"),
            receiverId: $scope.receiverId,
            receiverName: $scope.receiverName,
            senderId: $scope.senderId,
            senderName: $scope.senderName,
            contentFullCmp: $scope.contentFullCmp,
            sortColumnName: escape($scope.reportService.sorter.columnName),
            sortDescending: escape($scope.reportService.sorter.descending)
        };

        return $http.get(actionAddress, { params: $scope.reportService.currentFilter })
            .success(function(data) {
                setDataTable(data);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.exportAction = function(exportType) {
        actionAddress = $scope.reportService.getDownloadActionUrl(reportName, exportType);
        return $http.get(actionAddress)
            .success(function(data) {
                $scope.reportService.exportReportFile(actionAddress, exportType);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.queryMonthActionReport = function() {
        actionAddress = $scope.reportService.getQueryMonthActionUrl(reportName, $scope.selectedReportFromMonth);
        return $http.get(actionAddress)
            .success(function(data) {
                var filter = data.filterContent;
                var result = data.resultContent;
                $scope.dateFrom = new Date(filter.dateFrom);
                $scope.dateTo = new Date(filter.dateTo);

                setDataTable(result);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.toggleCalendar = function (datePickerId) {
        $scope[datePickerId] = $scope.reportService.toggleCalendar($scope[datePickerId]);
    };

    $scope.resetAction = function () {
        $scope.toggleResult = false;
        $scope.toggleAlert = false;
        $scope.dateFrom = $scope.reportService.getToday();
        $scope.dateTo = $scope.reportService.getToday();
        $scope.receiverId = "";
        $scope.receiverName = "";
        $scope.senderId = "";
        $scope.senderName = "";
        $scope.contentFullCmp = false;
        $('#timeFrom').selectpicker("val", "00");
        $('#timeTo').selectpicker("val", "23");
    };

    function setDataTable(viewData, isInit) {
        var hasAnyViewData = $.trim(viewData) !== '';
        $scope.toggleResult = hasAnyViewData;
        angular.forEach(viewData, function(currentView) {
            currentView.rowIndex = parseInt(currentView.rowIndex);
        });
        $scope.queryResult = hasAnyViewData ? viewData : "";
        $scope.toggleAlert = typeof isInit === "undefined" ?
            !hasAnyViewData : false;
    }

});
