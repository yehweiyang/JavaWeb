angular.module('ArchivesApp').controller('ExchangeAbnormalQueryController',
    function($scope, $http, $rootScope, $uibModal, archivesConstant, archivesService) {

        $scope.$on('$viewContentLoaded', function() {
            $scope.reset();
            init();
        });

        $scope.archivesService = archivesService;
        $scope.archivesService.sorter.columnName = "account";
        $scope.archivesService.pager.itemsPerPage = 100;

        $scope.saveHtmlBt = function(id) {
            var queryProcessId = {
                processId: id.processId
            };
            var url = archivesConstant.CHANGERECORD_AJAX_PATH  +
                '/exchangeAbnormalQueryID';
            $http.get(url, {
                params: queryProcessId
            }).success(function(data, status, headers, config) {
                $scope.detail = data;
                return $scope.detail;
            })
            var modal = $uibModal.open({
                templateUrl: archivesConstant.APP_PATH + "/views/ChangeRecord/detailInfo.html",
                scope: $scope,
                size: 'modal-dialog modal-lg'
            })

        }


        $scope.$watch('hideOrShow', function() {
            $scope.toggleText = $scope.hideOrShow ? '開啟異常訊息' : '隱藏異常訊息';
        })

        $scope.query = function() {
            var url = archivesConstant.CHANGERECORD_AJAX_PATH  + '/exchangeAbnormalQuery';
            $http.get(url, {
                    params: $scope.error
                }).success(function(data) {
                    if (data.length > 0) {
                        $scope.userList = data;
                        $scope.noResult = false;
                        $scope.myVar = true;
                        $scope.hideOrShow = true;
                        var url = archivesConstant.CHANGERECORD_AJAX_PATH + '/exchangeAbnormalQueryWriteTemp';
                        $http.get(url, {
                            params: {
                                query_value: $scope.error
                            }
                        })
                    } else {
                        $scope.noResult = true;
                        $scope.myVar = false;
                    }
                })
                .error(function(data, status) {
                    $scope.noResult = true;
                    $scope.myVar = false;
                }).finally(function() {
                    var url = archivesConstant.CHANGERECORD_AJAX_PATH  +
                        '/exchangeAbnormalQueryLog';
                    $http.get(url);
                })
        }

        $scope.master = {
            sendOrgName: "",
            sendOrganId: "",
            receiverOrgName: "",
            receiverOrgId: "",
            processId: "",
            exchangeId: "",
            startNo: "",
            endNo: "",
            dateFrom: new Date(),
            timeFrom: "00",
            dateTo: new Date(),
            timeTo: "23",
            isCheck: 'false'
        };
        $scope.reset = function() {
            $scope.myVar = false;
            $scope.error = angular.copy($scope.master);
        };

        $scope.prop = {
            "type": "select",
            "value00": "00",
            "value23": "23",
            "values": ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
                "22", "23"
            ]
        };

        var init = function() {
            //讀取xml檔
            var url = archivesConstant.CHANGERECORD_AJAX_PATH  + '/exchangeAbnormalQueryReadXML';
            $http.get(url)
                .success(function(data) {
                    if (data.length > 0) {
                        $scope.ehubName = {
                            "values": data
                        };
                    } else {
                        $scope.eHubSource = 'none';
                    }
                })

            //讀取暫存檔
            var url = archivesConstant.CHANGERECORD_AJAX_PATH  + '/exchangeAbnormalQueryReadTemp';
            $http.get(url)
                .success(function(data) {
                    if (data != "") {
                        var url = archivesConstant.CHANGERECORD_AJAX_PATH  +
                            '/exchangeAbnormalQuery';
                        $http.get(url, {
                            params: data
                        }).success(function(dataInside) {
                            //如果暫存檔查詢有值則將form表單填上
                            $scope.userList = dataInside;
                            $scope.noResult = false;
                            $scope.myVar = true;
                            $scope.hideOrShow = true;

                            $scope.error.sendOrgName = data.sendOrgName
                            $scope.error.sendOrganId = data.sendOrganId
                            $scope.error.receiverOrgName = data.receiverOrgName
                            $scope.error.receiverOrgId = data.receiverOrgId
                            $scope.error.processId = data.processId
                            $scope.error.exchangeId = data.exchangeId
                            $scope.error.startNo = data.startNo
                            $scope.error.endNo = data.endNo
                            $scope.error.eHub = data.eHub
                            $scope.error.dateFrom = new Date(data.dateFrom)
                            $scope.error.timeFrom = data.timeFrom
                            $scope.error.dateTo = new Date(data.dateTo)
                            $scope.error.timeTo = data.timeTo
                            $scope.error.isCheck = data.isCheck
                        })
                    }
                })
        }

        $scope.openDateFromCalendar = function() {
            $scope.dateFromCalendar.opened = true;
        };

        $scope.openDateToCalendar = function() {
            $scope.dateToCalendar.opened = true;
        };
        $scope.dateFromCalendar = {
            opened: false
        };

        $scope.dateToCalendar = {
            opened: false
        };

    });