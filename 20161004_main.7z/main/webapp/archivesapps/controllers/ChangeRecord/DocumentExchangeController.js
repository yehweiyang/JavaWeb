angular.module('ArchivesApp').controller('DocumentExchangeController', function($scope, $http, $state, exchangeService,
archivesConstant) {
	var self = this;
	$scope.uibPageBase = 10;
	$scope.start = 0;
	$scope.end = $scope.uibPageBase;
	$scope.maxSize = 5;
	$scope.pageChanged = function() {
    	$scope.end = $scope.currentPage * $scope.uibPageBase;
    	$scope.start = $scope.end - $scope.uibPageBase;
	};
	$scope.exchange = exchangeService.getExchange();
	if ($scope.exchange == null) {
	    $state.go("InsideSend_Change");
	} else {
	    var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH
	    if ($scope.exchange.transmitType == archivesConstant.INNER_TRANSMIT_TYPE) {
	        $scope.titleMsg = archivesConstant.SENDER_TITLE_MSG
	        url += "/exchange/inside/detail/";
	    } else if ($scope.exchange.transmitType == archivesConstant.OUT_TRANSMIT_TYPE) {
	        $scope.titleMsg = archivesConstant.RECEIVE_TITLE_MSG
            url += "/exchange/outside/detail/";
        }
        url += $scope.exchange.exchangeSerial;
        $http.get(url).then(function(response) {
            $scope.docTransmitMsgList = response.data;
            $scope.totalItems = $scope.docTransmitMsgList.length;
            $scope.currentPage = 1;
    	    $scope.start = 0;
    	    $scope.end = $scope.uibPageBase;
    	    $scope.showError = false;
    	    $scope.showTable = true;
        }, function(errResponse) {
            $scope.errorMessage = errResponse.data.errorMessage;
            $scope.showError = true;
            $scope.showTable = false;
        });
	}
	
	$scope.detailBt = function(transmitMsg) {
        exchangeService.setTransmitDetail(transmitMsg);
        $state.go("DocumentExchangeDetail");
	}

	$scope.returnBt = function(transmitMsg) {
	    exchangeService.setExchange(null);
        if ($scope.exchange.transmitType == archivesConstant.INNER_TRANSMIT_TYPE)
            $state.go("InsideSend_Change");
        else if ($scope.exchange.transmitType == archivesConstant.OUT_TRANSMIT_TYPE)
            $state.go("OutsideReceive_Change");
    }
});