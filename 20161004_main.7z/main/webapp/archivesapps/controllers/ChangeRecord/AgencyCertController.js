angular.module('ArchivesApp').controller('AgencyCertController', function ($rootScope, $scope, $http, archivesConstant) {
    //取得certHash能-開始
    $scope.getCertHash = function () {
        if (!$scope.orgId) {
            errorMessage(true, '機關代碼不可為空');
            return;
        }

        $http.get(archivesConstant.CHANGERECORD_AJAX_PATH + "/certHash/" + $scope.orgId)
            .success(function (response) {
                if (response.length != 0) {
                    errorMessage(false, '');
                    selectOption(response);
                } else {
                    errorMessage(true, '機關代碼錯誤');
                }
            }).error(function (response) {
            exceptionViewer(response, false);
        });
    }
    //取得certHash能-結束

    function selectOption(allOrgCert) {
        for (var i = 0; i < allOrgCert.length; i++) {
            $('#changeCerHash').append('<option value="' + allOrgCert[i].signCertHash + '">' + allOrgCert[i].signCertHash + '</option>');
        }
        $('#changeCerHash').css('display', 'block');
        $('.selectpicker').selectpicker();
    }

    //查詢檔案功能-開始
    $scope.searchLog = function () {

        if (!$scope.certHash || !$scope.orgId) {
            errorMessage(true, '請選擇CertHash');
            return false;
        }

        var orgValue = {
            orgId: $scope.orgId,
            certHash: $scope.certHash
        };

        $http.get(archivesConstant.CHANGERECORD_AJAX_PATH + "/searchLogFile", {params: orgValue})
            .success(function (response) {
                errorMessage(false, '');
                $scope.file = "";
                $scope.file = response;
                if ($scope.file.length == 0) {
                    errorMessage(true, '查無資料');
                }
                $('#logFile').css('display', 'block');
            }).error(function (response) {
            exceptionViewer(response, false);
        });
    };
    //查詢檔案功能-結束

    //下載檔案功能-開始
    $scope.downloadLogFile = function (fileName) {

        var logValue = {
            orgId: $scope.orgId,
            certHash: $scope.certHash,
            fileName: fileName
        };

        $http.get(archivesConstant.CHANGERECORD_AJAX_PATH + "/downloadLogFile", {params: logValue})
            .success(function (response) {
                errorMessage(false, '');
                window.location.href = archivesConstant.CHANGERECORD_AJAX_PATH + "/downloadLogFile?orgId=" + $scope.orgId + "&certHash=" + $scope.certHash + "&fileName=" + fileName;
            }).error(function (response) {
            exceptionViewer(response, false);
        });
    };
    //下載檔案功能-結束

    //清空功能-開始
    $scope.giveUp = function () {
        $("#selectCertHash").empty();
        $("#selectCertHash").append('<select class="selectpicker show-tick form-control" data-live-search="true" ng-model="certHash" id="changeCerHash" style="display:none;"><option class="get-class" value="" disabled selected>請選擇</option></select>');
        $('#logFile').css('display', 'none');
        $scope.file = "";
        $scope.orgId = '';
        errorMessage(false, '');
    };
    //清空功能-結束

    function errorMessage(errorStatus, errorMessage) {
        $scope.errorMessage = errorStatus;
        $scope.error = errorMessage;
    }
});