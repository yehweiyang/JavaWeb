var postTarget;
var timeoutId;
function postData(target,data)
{
	if(!http.sendRequest)
	{
		return null;
	}
	http.url=target;
	http.actionMethod="POST";
	var code=http.sendRequest(data);
	if(code!=0) return null;
	return http.responseText;

}
function checkFinish(){
	if(postTarget){
		postTarget.close();
		alert("尚未安裝元件");
	}
}
function makeSignature()
{
    var ua = window.navigator.userAgent;
	if(ua.indexOf("MSIE")!=-1 || ua.indexOf("Trident")!=-1) //is IE, use ActiveX
	{
		postTarget=window.open("http://localhost:61161/waiting.gif", "Signing","height=200, width=200, left=100, top=20");
		var tbsPackage=getTbsPackage();
		document.getElementById("httpObject").innerHTML='<OBJECT id="http" width=1 height=1 style="LEFT: 1px; TOP: 1px" type="application/x-httpcomponent" VIEWASTEXT></OBJECT>';
		var data=postData("http://localhost:61161/sign","tbsPackage="+tbsPackage);
		postTarget.close();
		postTarget=null;
		if(!data) alert("尚未安裝元件");
		else setSignature(data);
	}
	else
	{
		postTarget=window.open("http://localhost:61161/popupForm", "處理中","height=200, width=200, left=100, top=20");
		timeoutId=setTimeout(checkFinish,3500);
	}
}

function getTbsPackage(){
	var tbsData = {};
	tbsData["tbs"]=document.getElementById("tbs").value;
	tbsData["tbsEncoding"]=document.getElementById("tbsEncoding").value;
	tbsData["hashAlgorithm"]=document.getElementById("hashAlgorithm").value;
	tbsData["pin"]=document.getElementById("pin").value;
	tbsData["func"]="MakeSignature";
	tbsData["signatureType"]="PKCS1";
	var json = JSON.stringify(tbsData ).replace(/\+/g,"%2B");;
	return json;
}
function setSignature(signature)
{
	var ret=JSON.parse(signature);
	document.getElementById("b64Signature").value=ret.signature;
	document.getElementById("returnCode").value=ret.ret_code;
	if(ret.ret_code!=0){
		alert(MajorErrorReason(ret.ret_code));
		if(ret.last_error)
			alert(MinorErrorReason(ret.last_error));
	}
	else
	{
		document.getElementById('loginForm').submit()
	}
}

function receiveMessage(event)
{
	if(console) console.debug(event);
	
	//安全起見，這邊應填入網站位址檢查
	if(event.origin!="http://localhost:61161")
		return;
	try{
		var ret = JSON.parse(event.data);
		if(ret.func){
			if(ret.func=="getTbs"){
				clearTimeout(timeoutId);
				var json=getTbsPackage()
				postTarget.postMessage(json,"*");
			}else if(ret.func=="sign"){
				setSignature(event.data);
			}
		}else{
			if(console) console.error("no func");
		}
	}catch(e){
		//errorhandle
		if(console) console.error(e);
	}
}
if (window.addEventListener) {
	window.addEventListener("message", receiveMessage, false);
}else {
	//for IE8
	window.attachEvent("onmessage", receiveMessage);
}
//for IE8
var console=console||{"log":function(){}, "debug":function(){}, "error":function(){}};

function setOutput(output)
{
	var ret=JSON.parse(output);
	if(ret.ret_code==0x76000031)
	{
		alert(window.location.hostname+"非信任網站，請先加入信任網站");
		return;
	}
	var slots = ret.slots;
	if(slots[0].token instanceof Object)
	{
		document.getElementById('cardNo').value = slots[0].token.serialNumber;
		document.getElementById('slotDescription').value = "卡片存在";
		document.getElementById('slotDescription').style = "color:blue";
		document.getElementById('SubmitBt').disabled = false;
	}
	else
	{
		document.getElementById('cardNo').value = "";
		document.getElementById('slotDescription').value = "卡片不存在";
	}
}

function getImageInfo(ctx)
{
	var output="";
	for(i=0;i<2000;i++)
	{
		var data=ctx.getImageData(i,0,1,1).data;
		if(data[2]==0) break;
		output=output+String.fromCharCode(data[2],data[1],data[0]);
	}
	if(output=="") output='{"ret_code": 1979711501,"message": "執行檔錯誤或逾時"}';
	return output;
}

function myLoad(){
	var img = null;
	var ctx;
	var output="";
	var ua = window.navigator.userAgent;
	if(ua.indexOf("MSIE")==-1 && ua.indexOf("Trident")==-1) //not IE
	{
		img=document.createElement("img");
		img.crossOrigin = "Anonymous";
		img.src = 'http://localhost:61161/p11Image.bmp';
		var canvas = document.createElement("canvas");
		canvas.width=2000;canvas.height=1;
		ctx = canvas.getContext('2d');
		
		img.onload = function() {
			ctx.drawImage(img, 0, 0);
			output=getImageInfo(ctx);
			setOutput(output);
		};
		img.onerror = function()
		{
			document.getElementById('info').value= "未安裝客戶端程式或未啟動服務";
		};
	}else{
		document.getElementById("httpObject").innerHTML='<OBJECT id="http" width=1 height=1 style="LEFT: 1px; TOP: 1px" type="application/x-httpcomponent" VIEWASTEXT></OBJECT>';
		output=postData("http://localhost:61161/pkcs11info","");
		if(output==null){
			document.getElementById('info').value= "未安裝客戶端程式或未啟動服務";
			return;
		}
		else
			setOutput(output);
	}
}