
ArchivesApp.factory('accountFactory', function($http, $window, archivesConstant) {
    var self = this;
	self.accountDetail;

	var factory = {
		getAccountDetail: function() {
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + archivesConstant.SYSTEM_TOOL_PATH + '/user/accountDetail';
            $http.get(url).then(function(response) {
			    self.accountDetail = response.data;
	        });
	        return self.accountDetail;
	    }, setAccountDetail: function(detail) {
    		self.accountDetail = detail;
    	}, checkSessionId: function() {
            $http.post(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +
                    archivesConstant.SYSTEM_TOOL_PATH + '/user/checkSessionId')
            .error(function(response) {
                $window.location.href = archivesConstant.WEB_ROOT_PATH + "/conflictSession";
            });
        }, sessionExpired: function() {
            $window.location.href = archivesConstant.WEB_ROOT_PATH + "/sessionExpired";
        }
	};
    return factory;
});