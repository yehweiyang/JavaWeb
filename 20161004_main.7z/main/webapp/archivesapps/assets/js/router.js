ArchivesApp.config(['$stateProvider', '$urlRouterProvider', 'archivesConstant', function($stateProvider, $urlRouterProvider, archivesConstant) {
    $urlRouterProvider.otherwise("/home");

    //html名稱改小寫駝峰

    var toLowerCamelCase = function(menuCode) {
        return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
    };
    //project名
    $.ajaxSetup({
        async: false
    });
    // 使用get解決csrf保護
    $.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/core/menu').then(function(response) {
        angular.forEach(response.menu, function(topMenuValue, topMenuKey) {
            angular.forEach(topMenuValue.subMenus, function(subMenuValue, subMenuKey) {
                if (typeof(subMenuValue.menuName) != 'undefined') {
                    $stateProvider
                        .state(subMenuValue.menuCode, {
                            url: '/' + topMenuValue.menuCode + '/' + subMenuValue.menuCode,
                            views: {
                                "content": {
                                    templateUrl: archivesConstant.APP_PATH + '/views/' + topMenuValue.menuCode + '/' +
                                        toLowerCamelCase(subMenuValue.menuCode) + '.html',
                                    controller: subMenuValue.menuCode + "Controller"
                                }
                            },
                            data: {
                                pageTitle: subMenuValue.menuName
                            },
                            resolve: {
                                deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                                    return $ocLazyLoad.load({
                                        name: 'ArchivesApp',
                                        insertBefore: '#ng_load_plugins_before',
                                        files: [
                                            archivesConstant.APP_PATH + '/controllers/' + topMenuValue.menuCode +'/' + subMenuValue.menuCode + 'Controller.js',
                                        ]
                                    });
                                }]
                            }
                        })
                }
            });
        });
    })
    $stateProvider
        .state('home', {
            url: '/home',
            views: {
                "content": {
                    templateUrl: archivesConstant.APP_PATH + '/views/home.html',
                    controller: "HomeController"
                }
            },
            data: {
                pageTitle: ''
            },
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            archivesConstant.APP_PATH + '/controllers/HomeController.js',
                        ]
                    });
                }]
            }
        })
        .state('DocumentExchange', {
            url: "/ChangeRecord/DocumentExchange",
            views: {
                "content": {
                    templateUrl: archivesConstant.APP_PATH + "/views/ChangeRecord/documentExchange.html",
                    controller: "DocumentExchangeController"
                }
            },
            data: {pageTitle: '交換記錄彙整'},
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            archivesConstant.APP_PATH + '/controllers/ChangeRecord/DocumentExchangeController.js',
                        ]
                    });
                }]
            }
        })
        .state('DocumentExchangeDetail', {
            url: "/ChangeRecord/DocumentExchangeDetail",
            views: {
                "content": {
                    templateUrl: archivesConstant.APP_PATH + "/views/ChangeRecord/documentExchangeDetail.html",
                    controller: "DocumentExchangeDetailController"
                }
            },
            data: {pageTitle: '交換記錄彙整'},
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            archivesConstant.APP_PATH + '/controllers/ChangeRecord/DocumentExchangeDetailController.js',
                        ]
                    });
                }]
            }
        })
}]);