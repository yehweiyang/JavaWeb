ArchivesApp.constant('reportConstant', {
    REPORT_TOOL_PATH: "/reportTool",
    INIT_PATH: "/init",
    LIST_PATH: "/list",
    DOWNLOAD_PATH: "/download",
    MONTH_PATH: "/month",
    PDF_FILE: "pdf",
    ODS_FILE: "ods",
    //-- report name setting
    REPORT_SEND_RANK: "rptSendRank",
    REPORT_ERROR_RANK: "rptErrRk",
    REPORT_RS_STATE_STATIC: "rptRSState",
    REPORT_R_STATE_STATIC: "rptRss",
    REPORT_S_STATE_STATIC: "rptSss",
    REPORT_SEND_ERROR: "rptSendErr",
    REPORT_SEND_STATE: "rptSendSt",
    REPORT_SEND_LIST: "rptSendList",
    REPORT_SEND_UNCONFIRM: "rptSendUnConfm",
    REPORT_SEND_ERROR_LIST: "rptSendErrList",
    REPORT_RECEIVE_STATE: "rptRecvState",
    REPORT_RECEIVE_LIST: "rptRecvList",
    REPORT_RECEIVE_ERR_LIST: "rptRecvErrList",
    REPORT_CONFIRMED_QUERY: "rptConfirmed",
    REPORT_ODF_SEND_RATE: "rptOdfSendRate"
}).service('reportService', function($http, $filter, archivesConstant, reportConstant) {

    this.currentReportName = "";

    this.checkEmptyValue = function(checkValue, initValue) {
        return (typeof checkValue === 'undefined') || 'null' === checkValue || null === checkValue ?
                           ((typeof initValue === 'undefined') ? "" : initValue)
                           : checkValue;
    };

    this.exportReportFile = function (actionAddress, exportType) {
        if (reportConstant.PDF_FILE === exportType) {
            window.open(actionAddress, "window", "toolbar=no, menubar=no, resizable=yes");
        } else if (reportConstant.ODS_FILE === exportType) {
            window.location.href = actionAddress;
        }
    };

    this.getAverageFromCollection = function (collection, column) {
        var totalCount = this.getTotalCountFromCollection(collection, column);
        return typeof collection !== 'undefined' ? totalCount / collection.length : totalCount;
    };

    this.getDownloadActionUrl = function (reportName, exportType) {
        return archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + reportConstant.REPORT_TOOL_PATH + "/" +
                reportName + reportConstant.DOWNLOAD_PATH + "/" + exportType;
    };


    this.getInitActionUrl = function (reportName) {
        this.currentReportName = reportName;
        return archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + reportConstant.REPORT_TOOL_PATH + "/" +
                reportName + reportConstant.INIT_PATH;
    };

    this.getQueryActionUrl = function (reportName) {
        this.currentReportName = reportName;
        return archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + reportConstant.REPORT_TOOL_PATH + "/" +
                reportName + reportConstant.LIST_PATH;
    };

    this.getQueryMonthActionUrl = function (reportName, selectedMonth) {
        return archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + reportConstant.REPORT_TOOL_PATH + "/" +
                reportName + reportConstant.MONTH_PATH + "/" + selectedMonth;
    };

    this.getToday = function() {
        return new Date();
    };

    this.getTotalCountFromCollection = function (collection, column) {
        var totalCount = 0;
        if (typeof collection !== 'undefined') {
            angular.forEach(collection, function(item) {
                totalCount += parseInt(item[column]);
            });
        }
        return totalCount;
    };

    this.setHoursRangeFromDomId = function(domId) {
        domId = '#' + domId;
        var formatTime = function(timeValue) {
            return timeValue.toString().length < 2 ? "0" + timeValue : timeValue;
        };
        for (var i = 0 ; i < 24 ; i++) {
            $(domId).append($('<option>', {
                value:  formatTime(i),
                text:   formatTime(i)
            }));
        }
    };

    this.sorter = {
        columnName : null,
        descending : false
    };

    this.currentFilter = { };

    this.sortByColumnName = function(columnName) {
        this.sorter.descending = columnName === this.sorter.columnName ? !this.sorter.descending : false;
        this.sorter.columnName = columnName;
        this.asyncReportResult();
    };

    this.toggleCalendar = function(datePicker) {
        return datePicker = { opened : typeof datePicker === 'undefined' ? true : !datePicker.opened  };
    };

    this.asyncReportResult = function () {
        this.currentFilter.sortColumnName = this.sorter.columnName;
        this.currentFilter.sortDescending = this.sorter.descending;

        $http.get(this.getQueryActionUrl(this.currentReportName), { params: this.currentFilter })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };
});