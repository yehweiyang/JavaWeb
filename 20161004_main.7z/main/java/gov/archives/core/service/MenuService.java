package gov.archives.core.service;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.vo.TopMenuVo;

/**
 * MenuService <br> (尚未描述類別目的與用途) <br> gemhuang, 2016/7/18.
 */
public interface MenuService {
    MenuEntity getByMenuCode(String menuCode);

    void insert(MenuEntity menu);

    void update(MenuEntity menu);

    void delete(MenuEntity menu);

    MenuEntity getBySysId(UUID sysId);

    List<MenuEntity> getAllMenu();

    Map<Integer, TopMenuVo> getMenuTree();

    Map<Integer, TopMenuVo> getMenuTree(List<MenuEntity> menuEntities);

}
