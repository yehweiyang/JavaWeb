package gov.archives.core.service;

import java.util.List;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.UserInfo;

/**
 * UserInfoService
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/15.
 */
public interface UserInfoService {

    UserInfoEntity getByAccount(String account);

    void insert(UserInfoEntity user);

    void update(UserInfoEntity user);

    void delete(UserInfoEntity user);

    void updateUserByAccount(UserInfo userInfo);

    void updateUserByRoleName(UserInfoEntity user, String roleName);

    List<UserInfo> list();

    String getCurrentAccount();
}
