package gov.archives.core.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.servlet.ServletContext;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.context.ServletContextAware;

import org.iii.common.util.StringUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.HomeService;

/**
 * Created by jslee on 2016/9/11.
 */
@Service
public class HomeServiceImpl implements HomeService, ServletContextAware {

    private static final Logger log = LoggerFactory.getLogger(HomeServiceImpl.class);

    private static final String WEB_INFO_PATH = "/WEB-INF";
    private static final String VIEWS_PATH = "/views";
    private static final String OUT_PATH = "/homeout";
    private static final String HOME_OUTPUT = "home_description";
    private static final String DEFAULT_OUTPUT_CONTENT = "無公告內容";


    private ServletContext servletContext;
    private String homeOutPutPath = "";

    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @Override
    public String readHomePageTextASString() {
        FileReader fr = null;
        BufferedReader br = null;
        String outputString = DEFAULT_OUTPUT_CONTENT;
        try {
            fr = new FileReader(getHomePageTextPath());
            br = new BufferedReader(fr);
            outputString = IOUtils.toString(br);

        } catch (IOException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR);
        } finally {
            try {
                if (null != br) {
                    br.close();
                    if (null != fr) {
                        fr.close();
                    }
                }
            } catch (IOException e) {
                log.error(e.getClass().getName() +
                        StringUtils.stackTraceFromException(e));
            }
        }
        return outputString;
    }

    private String getHomePageTextPath() {
        homeOutPutPath = servletContext.getRealPath("") +
                WEB_INFO_PATH +
                VIEWS_PATH +
                OUT_PATH;

        initHomeOuptFolder();

        return homeOutPutPath + "/" + HOME_OUTPUT;
    }

    private void initHomeOuptFolder() {
        if (!org.iii.common.util.IOUtils.isFolderExist(homeOutPutPath)) {
            boolean isSuccess = new File(homeOutPutPath).mkdirs();
            if (isSuccess) {
                log.info(homeOutPutPath + " 建立成功");
            } else {
                throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR);
            }
        }
    }

}
