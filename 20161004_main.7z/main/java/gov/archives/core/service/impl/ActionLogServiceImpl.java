package gov.archives.core.service.impl;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.mapper.command.ActionLogCommandMapper;
import gov.archives.core.mapper.query.ActionLogQueryMapper;
import gov.archives.core.service.ActionLogService;

/**
 * ActionLogServiceImpl
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@Service
@Transactional
public class ActionLogServiceImpl implements ActionLogService {

    private static final Logger log = LoggerFactory.getLogger(ActionLogServiceImpl.class);

    @Autowired
    private ActionLogCommandMapper commandMapper;

    @Autowired
    private ActionLogQueryMapper queryMapper;

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void insert(ActionLogEntity actionLog) {
        PreconditionUtils.checkArguments(actionLog);

        commandMapper.save(actionLog);

        logEvent(actionLog);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void delete(ActionLogEntity actionLog) {
        PreconditionUtils.checkArguments(actionLog);

        commandMapper.remove(actionLog);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public ActionLogEntity getLastLogInByAccount(String actorAccount) {
        PreconditionUtils.checkArguments(actorAccount);

        return queryMapper.lastLogInByAccount(actorAccount);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public ActionLogEntity getLogInCountByAccount(String actorAccount) {
        PreconditionUtils.checkArguments(actorAccount);

        return queryMapper.logInCountByAccount(actorAccount);
    }

    @Override
    public void logEvent(ActionLogEntity actionLog) {
        String errorCode = actionLog.getErrorCode();
        if (HttpStatus.OK.getReasonPhrase().equals(errorCode) || StringUtils.isEmpty(errorCode)) {
            insertInfoActionLog(actionLog);
        } else {
            insertErrorActionLog(actionLog);
        }
    }

    private void insertInfoActionLog(ActionLogEntity actionLog) {
        log.info(prepareLogMessage(actionLog));
    }

    private void insertErrorActionLog(ActionLogEntity actionLog) {
        log.error(prepareLogMessage(actionLog));
    }

    private String prepareLogMessage(ActionLogEntity actionLog) {
        Timestamp actionTime = actionLog.getActionTime();
        String remoteIp = actionLog.getRemoteIp();
        String actionItem = actionLog.getActionItem();
        String actorAccount = actionLog.getActorAccount();
        String actionResult = actionLog.getActionResult();
        String errorCode = actionLog.getErrorCode();
        String eventLevel = actionLog.getEventLevel();

        // TODO: 之後訊息要加密或 Hash 可以從此下手
        return actionTime + "," +
                remoteIp + "," +
                actionItem + "," +
                actorAccount + "," +
                actionResult + "," +
                errorCode + "," +
                eventLevel;
    }
}
