package gov.archives.core.service;

/**
 * Created by jslee on 2016/9/11.
 */
public interface HomeService {


    String readHomePageTextASString();

}
