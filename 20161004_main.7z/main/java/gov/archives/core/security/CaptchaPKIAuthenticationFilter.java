package gov.archives.core.security;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.domain.entity.LogInControlEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.AccountDetail;
import gov.archives.core.domain.vo.SignCertData;
import gov.archives.core.domain.vo.VerifyResult;
import gov.archives.core.exception.BadCaptchaException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.service.LogInControlService;
import gov.archives.core.service.SessionManageService;
import gov.archives.core.service.SmartCardIdentityService;
import gov.archives.core.service.UserInfoService;

import static gov.archives.core.conf.AuthenticationConf.PARAM_CARD_NUM;
import static gov.archives.core.conf.AuthenticationConf.PARAM_USER_NAME;

public final class CaptchaPKIAuthenticationFilter extends UsernamePasswordAuthenticationFilter {
    private static final Logger log = LoggerFactory.getLogger(CaptchaPKIAuthenticationFilter.class);

    private Encoder encoder = Base64.getEncoder();

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private ActionLogService actionLogService;

    @Autowired
    private LogInControlService logInControlService;

    @Autowired
    private SmartCardIdentityService smartCardIdentityService;

    @Autowired
    private SessionManageService sessionManageService;

    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
            throws AuthenticationException {
        if (!request.getMethod().equals("POST")) {
            throw new AuthenticationServiceException("Authentication method not supported: " + request.getMethod());
        }

        HttpSession session = request.getSession();
        String account = null;
        String cardNo;
        UserInfoEntity user;
        session.getLastAccessedTime();
        request.getRemoteAddr();
        ActionLogEntity actLogEntity = new ActionLogEntity();
        LogInControlEntity logInCtl = new LogInControlEntity();
        LogInControlEntity logInCtl1 = new LogInControlEntity();
        String logInSession = request.getRequestedSessionId();
        UUID logInSysId = UUID.randomUUID();

        try {
            account = request.getParameter(PARAM_USER_NAME);
            cardNo = request.getParameter(PARAM_CARD_NUM);

            //  log.info("mytest " + account);
            logInCtl =
                    logInSession == null ? null :
                            logInControlService.getBySessionIdAndAccountMaxlimitTime(logInSession, account);
            log.info(" check loginIn before " + ToStringBuilder.reflectionToString(logInCtl));
            if (null == logInCtl) {
                logInCtl1.setSysId(logInSysId);
                logInCtl1.setSessionId(logInSession);
                logInCtl1.setLoginAccount(account);
                logInCtl1.setCertCardNum(cardNo);
                logInCtl1.setLoginTime(new Timestamp(session.getLastAccessedTime()));
                logInCtl1.setRemoteIp(request.getRemoteAddr());
                logInCtl1.setLoginCount(1);
                logInControlService.insert(logInCtl1);
            } else {
                Integer logInCnt = logInCtl.getLoginCount();
                logInCtl.getLoginTime();
                logInCtl.getLogInControlSysId();
                log.info("login_count " + logInCnt + " " + logInSession + " sysid " + logInCtl.getLogInControlSysId());

                if (logInCnt < 3) {
                    logInCnt = logInCnt + 1;
                    logInCtl1.setLoginCount(logInCnt);
                    logInCtl1.setSessionId(logInSession);
                    logInCtl1.setLoginAccount(account);
                    logInCtl1.setLoginTime(logInCtl.getLoginTime());
                    log.info("login_count cnt+1 update " + ToStringBuilder.reflectionToString(logInCtl1));

                    logInControlService.update(logInCtl1);
                } else {
                    if (new Timestamp(session.getLastAccessedTime()).before(logInCtl.getMaxLimitLoginTime())) {
                        throw new AuthenticationServiceException(CoreErrorCode.LOGIN_EXPIRED);
                    } else {
                        logInCtl1.setLoginCount(1);
                        logInCtl1.setSessionId(request.getRequestedSessionId());
                        logInCtl1.setLoginAccount(account);
                        logInCtl1.setLoginTime(new Timestamp(session.getLastAccessedTime()));
                        logInControlService.update(logInCtl1);
                    }
                }
            }
            String captcha = request.getParameter("captcha");
            String CAPTCHA = (String) session.getAttribute("CAPTCHA");
            log.info("Check CAPCHA " + CAPTCHA + " : captcha " + captcha);
            if (!CAPTCHA.equals(captcha)) {
                throw new BadCaptchaException(CoreErrorCode.CAPTCHA_ERROR);
            }

            account = request.getParameter(PARAM_USER_NAME);
            user = account == null ? null : userInfoService.getByAccount(account);

            //   log.info("login user check : " + ToStringBuilder.reflectionToString(account));

            if (null == user) {
                throw new UsernameNotFoundException(CoreErrorCode.ACCOUNT_ERROR);
            }

            if (user.getActiveStatus().equals(-1)) {
                AuthenticationException exception = new BadCaptchaException(CoreErrorCode.ACCOUNT_PROCESSING);
                throw exception;
            } else if (user.getActiveStatus().equals(0)) {
                AuthenticationException exception = new BadCaptchaException(CoreErrorCode.ACCOUNT_SUSPENDED);
                throw exception;
            }

            SignCertData signCert = new SignCertData();
            signCert.setToken(request.getParameter("tbs"));
            signCert.setB64Signature(request.getParameter("b64Signature"));

            File file = new File(request.getServletContext()
                                        .getRealPath("") + CoreConf.CERT_FOLDER, user.getCertCardNum() + ".cer");

            UUID uuid = (UUID) session.getAttribute("login_uuid");

            smartCardIdentityService
                    .smartCarVerifyHandler(signCert, file, user.getCertHash(), uuid, session.getLastAccessedTime());

                UUID sysId = UUID.randomUUID();
                log.info("sysid " + sysId);
                actLogEntity.setSysId(sysId);
                actLogEntity.setActionTime(new Timestamp(session.getLastAccessedTime()));
                actLogEntity.setRemoteIp(request.getRemoteAddr());
                actLogEntity.setActorAccount(account);
                actLogEntity.setActionItem("webapp_001");
                actLogEntity.setActionResult("success");
                actLogEntity.setErrorCode("");
                actLogEntity.setEventLevel("A");
                actionLogService.insert(actLogEntity);
                UUID logInSysId1 = logInCtl1.getLogInControlSysId();
                log.info("login_delete " + ToStringBuilder.reflectionToString(logInCtl1));
                logInControlService.delete(logInCtl1);

        } catch (AuthenticationException e) {
            VerifyResult verifyResult = smartCardIdentityService.userIdentityException(e);
            UUID sysId = UUID.randomUUID();
            log.info("sysid " + sysId + "error " + e);
            actLogEntity.setSysId(sysId);
            actLogEntity.setActionTime(new Timestamp(session.getLastAccessedTime()));
            actLogEntity.setRemoteIp(request.getRemoteAddr());
            actLogEntity.setActorAccount(account);
            actLogEntity.setActionItem("webapp_001");
            actLogEntity.setActionResult(verifyResult.getErrorMessage());
            actLogEntity.setErrorCode(verifyResult.getErrorCode());
            actLogEntity.setEventLevel("A");
            actionLogService.insert(actLogEntity);
            throw new AuthenticationServiceException(verifyResult.getErrorMessage());
        }
        String authorization = account + ":" + cardNo;
        session.setAttribute("authorization",
                "Basic " + new String(encoder.encode(authorization.getBytes()), StandardCharsets.UTF_8));
        AccountDetail detail = new AccountDetail();
        detail.setAccount(account);
        detail.setSessionId(session.getId());
        detail.setRemoteAddress(request.getRemoteAddr());
        detail.setTimeOut(session.getMaxInactiveInterval());
        sessionManageService.setAccountDetail(detail);
        CaptchaPKIAuthenticationToken authRequest = new CaptchaPKIAuthenticationToken(account, cardNo, user);
        setDetails(request, authRequest);
        return getAuthenticationManager().authenticate(authRequest);
    }
}