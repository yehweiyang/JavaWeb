package gov.archives.core.domain.entity;

import java.io.Serializable;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.ibatis.type.Alias;

/**
 * UserInfoEntity
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/15.
 */
@Alias("UserInfo")
public class UserInfoEntity extends BaseEntity implements Serializable {
    private String account;
    private UUID roleSysId;
    private String userName;
    private String email;
    private String phoneNumber;
    private String mobileNumber;
    private String orgInfo;
    private Integer activeStatus;
    private String deputyAccount;
    private String certCardNum;
    private String certHash;

    private String phoneAreaCode;
    private String phoneLocalNumber;
    private String phoneExtNumber;
    private String mobileAreaCode;
    private String mobileLocalNumber;

    public void splitPhoneNumber() {
        if (phoneNumber.isEmpty()) {
            phoneAreaCode = "";
            phoneExtNumber = "";
            phoneLocalNumber = "";
        }

        String regex = "^(\\d+)-(\\d+)#?(\\d*)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(phoneNumber);

        if (matcher.matches()) {
            setPhoneAreaCode(matcher.group(1));
            setPhoneLocalNumber(matcher.group(2));
            setPhoneExtNumber(matcher.group(3));
        }
    }

    public void splitMobileNumber() {
        if (mobileNumber.isEmpty()) {
            mobileAreaCode = "";
            mobileLocalNumber = "";
        }

        String regex = "^(\\d*)-(\\d*)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(mobileNumber);

        if (matcher.matches()) {
            setMobileAreaCode(matcher.group(1));
            setMobileLocalNumber(matcher.group(2));
        }
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public UUID getRoleSysId() {
        return roleSysId;
    }

    public void setRoleSysId(UUID roleSysId) {
        this.roleSysId = roleSysId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        splitPhoneNumber();
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
        splitMobileNumber();
    }

    public String getOrgInfo() {
        return orgInfo;
    }

    public void setOrgInfo(String orgInfo) {
        this.orgInfo = orgInfo;
    }

    public Integer getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getDeputyAccount() {
        return deputyAccount;
    }

    public void setDeputyAccount(String deputyAccount) {
        this.deputyAccount = deputyAccount;
    }

    public String getCertCardNum() {
        return certCardNum;
    }

    public void setCertCardNum(String certCardNum) {
        this.certCardNum = certCardNum;
    }

    public String getCertHash() {
        return certHash;
    }

    public void setCertHash(String certHash) {
        this.certHash = certHash;
    }

    public String getPhoneAreaCode() {
        return phoneAreaCode;
    }

    public void setPhoneAreaCode(String phoneAreaCode) {
        this.phoneAreaCode = phoneAreaCode;
    }

    public String getPhoneLocalNumber() {
        return phoneLocalNumber;
    }

    public void setPhoneLocalNumber(String phoneLocalNumber) {
        this.phoneLocalNumber = phoneLocalNumber;
    }

    public String getPhoneExtNumber() {
        return phoneExtNumber;
    }

    public void setPhoneExtNumber(String phoneExtNumber) {
        this.phoneExtNumber = phoneExtNumber;
    }

    public String getMobileAreaCode() {
        return mobileAreaCode;
    }

    public void setMobileAreaCode(String mobileAreaCode) {
        this.mobileAreaCode = mobileAreaCode;
    }

    public String getMobileLocalNumber() {
        return mobileLocalNumber;
    }

    public void setMobileLocalNumber(String mobileLocalNumber) {
        this.mobileLocalNumber = mobileLocalNumber;
    }
}
