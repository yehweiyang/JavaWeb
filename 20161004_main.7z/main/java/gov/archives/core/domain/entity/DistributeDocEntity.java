package gov.archives.core.domain.entity;

import java.sql.Timestamp;
import java.util.UUID;

import org.apache.ibatis.type.Alias;

/**
 * Created by tristan on 2016/9/6.
 */
@Alias("DistDoc")
public class DistributeDocEntity{
    private UUID sysId;
    private String processId;
    private String fromOrgUnitName;
    private String toOrgUnitName;
    private Timestamp clientTime;
    private Timestamp insertTime;
    private Timestamp downloadTime;
    private Timestamp withdrawTime;
    private Timestamp rejectTime;
    private Timestamp resendTime;
    private Timestamp confirmTime;
    private int flowStatus;
    private int status;
    private int errorType;
    private String errorMsg;
    private String extraNote;
    private String sendDocMemo;
    private String receiveMemo;
    private char repeat;
    private Timestamp completeTime;
    private String serviceId;
    private String subject;
    private String clientId;
    private String fromOrgId;
    private String fromUnitId;
    private String toOrgId;
    private String toUnitId;
    private Timestamp createdTime;
    private Timestamp modifiedTime;
    private String creatorApp;
    private String modifierApp;

    public UUID getSysId() {
        return sysId;
    }

    public void setSysId(UUID sysId) {
        this.sysId = sysId;
    }

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getFromOrgUnitName() {
        return fromOrgUnitName;
    }

    public void setFromOrgUnitName(String fromOrgUnitName) {
        this.fromOrgUnitName = fromOrgUnitName;
    }

    public String getToOrgUnitName() {
        return toOrgUnitName;
    }

    public void setToOrgUnitName(String toOrgUnitName) {
        this.toOrgUnitName = toOrgUnitName;
    }

    public Timestamp getClientTime() {
        return clientTime;
    }

    public void setClientTime(Timestamp clientTime) {
        this.clientTime = clientTime;
    }

    public Timestamp getInsertTime() {
        return insertTime;
    }

    public void setInsertTime(Timestamp insertTime) {
        this.insertTime = insertTime;
    }

    public Timestamp getDownloadTime() {
        return downloadTime;
    }

    public void setDownloadTime(Timestamp downloadTime) {
        this.downloadTime = downloadTime;
    }

    public Timestamp getWithdrawTime() {
        return withdrawTime;
    }

    public void setWithdrawTime(Timestamp withdrawTime) {
        this.withdrawTime = withdrawTime;
    }

    public Timestamp getRejectTime() {
        return rejectTime;
    }

    public void setRejectTime(Timestamp rejectTime) {
        this.rejectTime = rejectTime;
    }

    public Timestamp getResendTime() {
        return resendTime;
    }

    public void setResendTime(Timestamp resendTime) {
        this.resendTime = resendTime;
    }

    public Timestamp getConfirmTime() {
        return confirmTime;
    }

    public void setConfirmTime(Timestamp confirmTime) {
        this.confirmTime = confirmTime;
    }

    public int getFlowStatus() {
        return flowStatus;
    }

    public void setFlowStatus(int flowStatus) {
        this.flowStatus = flowStatus;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getErrorType() {
        return errorType;
    }

    public void setErrorType(int errorType) {
        this.errorType = errorType;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getExtraNote() {
        return extraNote;
    }

    public void setExtraNote(String extraNote) {
        this.extraNote = extraNote;
    }

    public String getSendDocMemo() {
        return sendDocMemo;
    }

    public void setSendDocMemo(String sendDocMemo) {
        this.sendDocMemo = sendDocMemo;
    }

    public String getReceiveMemo() {
        return receiveMemo;
    }

    public void setReceiveMemo(String receiveMemo) {
        this.receiveMemo = receiveMemo;
    }

    public char getRepeat() {
        return repeat;
    }

    public void setRepeat(char repeat) {
        this.repeat = repeat;
    }

    public Timestamp getCompleteTime() {
        return completeTime;
    }

    public void setCompleteTime(Timestamp completeTime) {
        this.completeTime = completeTime;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getFromOrgId() {
        return fromOrgId;
    }

    public void setFromOrgId(String fromOrgId) {
        this.fromOrgId = fromOrgId;
    }

    public String getFromUnitId() {
        return fromUnitId;
    }

    public void setFromUnitId(String fromUnitId) {
        this.fromUnitId = fromUnitId;
    }

    public String getToOrgId() {
        return toOrgId;
    }

    public void setToOrgId(String toOrgId) {
        this.toOrgId = toOrgId;
    }

    public String getToUnitId() {
        return toUnitId;
    }

    public void setToUnitId(String toUnitId) {
        this.toUnitId = toUnitId;
    }

    public Timestamp getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Timestamp createdTime) {
        this.createdTime = createdTime;
    }

    public Timestamp getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Timestamp modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public String getCreatorApp() {
        return creatorApp;
    }

    public void setCreatorApp(String creatorApp) {
        this.creatorApp = creatorApp;
    }

    public String getModifierApp() {
        return modifierApp;
    }

    public void setModifierApp(String modifierApp) {
        this.modifierApp = modifierApp;
    }
}
