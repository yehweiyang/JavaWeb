package gov.archives.core.domain.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

import org.apache.ibatis.type.Alias;

/**
 * Created by i00047 on 2016/6/7.
 */
@Alias("ActionLog")
public class ActionLogEntity extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 3647233284813657927L;
    private Timestamp actionTime;
    private String remoteIp;
    private String actionItem;
    private String actorAccount;
    private String actionResult;
    private String errorCode;
    private String eventLevel;

    public Timestamp getActionTime() {
        return actionTime;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getRemoteIp() {
        return remoteIp;
    }

    public String getActionItem() {
        return actionItem;
    }

    public String getActorAccount() {
        return actorAccount;
    }

    public String getActionResult() { return actionResult; }

    public String getErrorCode() {
        return errorCode;
    }

    public String getEventLevel() {
        return eventLevel;
    }

    public void setActionTime(Timestamp actionTime) {
        this.actionTime = actionTime;
    }

    public void setRemoteIp(String remoteIp) {
        this.remoteIp = remoteIp;
    }

    public void setActionItem(String actionItem) {
        this.actionItem = actionItem;
    }

    public void setActorAccount(String actorAccount) {
        this.actorAccount = actorAccount;
    }

    public void setActionResult(String actionResult) {
        this.actionResult = actionResult;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public void setEventLevel(String eventLevel) {
        this.eventLevel = eventLevel;
    }

    public static class Builder {

        public static Builder create() {
            return new Builder();
        }

        private ActionLogEntity entity;
        private Builder self;

        private Builder() {
            entity = new ActionLogEntity();
            self = this;
        }

        public Builder setActionTime(Timestamp actionTime) {
            this.entity.actionTime = actionTime;

            return self;
        }

        public Builder setRemoteIp(String remoteIp) {
            this.entity.remoteIp = remoteIp;

            return self;
        }

        public Builder setActionItem(String actionItem) {
            this.entity.actionItem = actionItem;

            return self;
        }

        public Builder setActorAccount(String actorAccount) {
            this.entity.actorAccount = actorAccount;

            return self;
        }

        public Builder setActionResult(String actionResult) {
            this.entity.actionResult = actionResult;

            return self;
        }

        public Builder setErrorCode(String errorCode) {
            this.entity.errorCode = errorCode;

            return self;
        }

        public Builder setEventLevel(String eventLevel) {
            this.entity.eventLevel = eventLevel;

            return self;
        }

        public ActionLogEntity build() {
            this.entity.setSysId(UUID.randomUUID());

            return this.entity;
        }
    }
}
