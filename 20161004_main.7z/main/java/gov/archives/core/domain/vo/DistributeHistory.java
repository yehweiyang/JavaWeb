package gov.archives.core.domain.vo;

import java.sql.Timestamp;

/**
 * Created by tristan on 2016/9/7.
 */
public class DistributeHistory {
    private String processId;
    private String fromOrgUnitName;
    private String toOrgUnitName;
    private String clientId;
    private String distTime;
    private int flowSeq;

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getFromOrgUnitName() {
        return fromOrgUnitName;
    }

    public void setFromOrgUnitName(String fromOrgUnitName) {
        this.fromOrgUnitName = fromOrgUnitName;
    }

    public String getToOrgUnitName() {
        return toOrgUnitName;
    }

    public void setToOrgUnitName(String toOrgUnitName) {
        this.toOrgUnitName = toOrgUnitName;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getDistTime() {
        return distTime;
    }

    public void setDistTime(String distTime) {
        this.distTime = distTime;
    }

    public int getFlowSeq() {
        return flowSeq;
    }

    public void setFlowSeq(int flowSeq) {
        this.flowSeq = flowSeq;
    }
}
