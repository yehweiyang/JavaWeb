package gov.archives.core.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;

import static org.springframework.http.HttpStatus.*;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.Timestamp;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.FileSystemUtils;

import static gov.archives.core.conf.CoreConf.*;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.SystemAnnounceVO;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.service.SmartCardIdentityService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.EscapeUtils;
import gov.archives.dox.conf.DoxConf;
import gov.archives.dox.message.DoxErrorCode;
import gov.archives.dox.message.DoxErrorMessage;

@RestController
@RequestMapping(path = REST_API_VERSION + CoreConf.SYSTEM_TOOL_URL)
public class EditAnnouncementController extends RestControllerBase {
    private static final String HTML_TOP = "<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">"
            + "<title></title></head><body><div>";
    private static final String HTML_BOTTOM = "</div></body></html>";
    private static final String HTML_FILE_NAME = "announcement";
    private static final String HTML_FILE_SUFFIX = ".html";
    private static final String REST_ANNOUNCE = "/announce";
    private static final String MODULE_NAME = "編輯系統公告模組";
    public static final String REST_ANNOUNCE_SUCCESS = "/systemTool/announce: Success";

    @Autowired
    private SmartCardIdentityService smartCardIdentityService;

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private ActionLogService actionLogService;

    public EditAnnouncementController() {
        this.setModuleName(MODULE_NAME);
    }

    private void transHtmlFile(File htmlFile, String notifyMessage) {
        try {
            String html = new String("".getBytes(), Charset.forName("UTF-8"));
            html += HTML_TOP;
            html += notifyMessage;
            html += HTML_BOTTOM;
            FileUtils.writeStringToFile(htmlFile, html, Charset.forName("UTF-8"));
        } catch (IOException e) {
            throw new ArchivesException(CoreErrorCode.FILE_SAVE_FAIL);
        }
    }

    public String readHtmlFile(File file) {
        String htmlString = null;
        try {
            if (FileSystemUtils.isExists(file)) {
                htmlString = FileUtils.readFileToString(file);
                int beginIndex = htmlString.indexOf("<div>") + "<div>".length();
                htmlString = htmlString.substring(beginIndex, htmlString.indexOf("</div>"));
                htmlString = StringEscapeUtils.unescapeHtml4(htmlString);
            }
        } catch (IOException e) {
            throw new ArchivesException(CoreErrorMessage.findByCode(CoreErrorCode.DATA_NOT_FOUND),
                    CoreErrorCode.DATA_NOT_FOUND);
        }
        return htmlString;
    }

    @RequestMapping(value = "/read/announce",
                    method = RequestMethod.GET)
    public ResponseEntity<SystemAnnounceVO> readAnnouncement(HttpServletRequest request) {
        String realPath = request.getServletContext().getRealPath("") + HTML_FILE_NAME;
        String fileName = HTML_FILE_NAME + HTML_FILE_SUFFIX;
        SystemAnnounceVO systemAnnounce = new SystemAnnounceVO();
        systemAnnounce.setAnnounceMessage(readHtmlFile(new File(realPath, fileName)));
        return new ResponseEntity<>(systemAnnounce, CREATED);
    }

    @RequestMapping(value = REST_ANNOUNCE,
                    method = RequestMethod.POST)
    public ResponseEntity<Void> postAnnouncement(HttpServletRequest request, @RequestBody SystemAnnounceVO annonce) {
        try {
            if (null == annonce.getAnnounceMessage()) {
                throw new ArchivesException(CoreErrorMessage.findByCode(CoreErrorCode.SYSTEM_ERROR), CoreErrorCode.SYSTEM_ERROR);
            } else {
                UserInfoEntity userInfo = userInfoService.getByAccount(request.getRemoteUser());
                File file =
                        new File(request.getServletContext().getRealPath("") + CERT_FOLDER,
                                userInfo.getCertCardNum() + SUFFIX_CERT);
                smartCardIdentityService.smartCarVerifyHandler(annonce,
                        file,
                        userInfo.getCertHash(),
                        UUID.fromString(annonce.getToken()),
                        System.currentTimeMillis());

                annonce.setAnnounceMessage(EscapeUtils.escapeHtml(annonce.getAnnounceMessage()));
                String realPath = request.getServletContext().getRealPath("") + HTML_FILE_NAME;
                FileSystemUtils.checkFolder(new File(realPath));
                String fileName = HTML_FILE_NAME + HTML_FILE_SUFFIX;
                transHtmlFile(new File(realPath, fileName), annonce.getAnnounceMessage());
                actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                        HttpStatus.OK.getReasonPhrase(),
                        REST_ANNOUNCE_SUCCESS,
                        CoreConf.EVENT_LEVEL_LOW));
                return new ResponseEntity<>(CREATED);
            }
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                            e.getErrorCode() != null ? e.getErrorCode() : UNDEFINE_ERROR_CODE,
                            e.getErrorMessage() != null ? e.getErrorMessage() : UNDEFINE_ERROR_MESSAGE,
                            CoreConf.EVENT_LEVEL_LOW));
            throw ArchivesException.getInstanceByErrorCode(e.getMessage());
        }
    }
}
