package gov.archives.core.controller;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import com.google.common.collect.ImmutableMap;
import org.iii.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.facade.RoleMenuMappingFacade;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.MenuService;

/**
 * MenuQueryMapper <br> (尚未描述類別目的與用途) <br> wtjiang, 2016/7/21.
 */
@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.CORE_BASE_URL)
public class MenuController {
    private static final Logger log = LoggerFactory.getLogger(MenuController.class);

    public static final String GET_MENUS = "/menu";
    private Boolean develop = true;

    @Autowired
    private RoleMenuMappingFacade roleMenuMappingFacade;

    @Autowired
    MenuService menuService;

    @RequestMapping(value = "/menu",
            method = RequestMethod.GET)
    public Map getRoleMenu(HttpServletRequest request) {
        try {
            String currentAccount =
                    null == request.getSession().getAttribute("authorization") ?
                            "rootis08" :
                    convertBase64AuthToString(request.getSession().getAttribute("authorization").toString());

            if (develop) {
                currentAccount = "rootis08";
            }
            return roleMenuMappingFacade.getRoleMappingMenu(currentAccount);
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));

            throw (ex instanceof ArchivesException) ? (ArchivesException) ex
                    : ArchivesException.getInstanceByErrorCode(CoreErrorCode.ACCOUNT_ERROR);
        }
    }

    @RequestMapping(value = "/menu/all",
            method = RequestMethod.GET)
    public Map getAllMenu() {
        return ImmutableMap.of("menu", menuService.getMenuTree());
    }

    private String convertBase64AuthToString(String authStr) throws UnsupportedEncodingException {
        return new String(Base64.getDecoder().decode(authStr.replace("Basic ", "")), "UTF-8").split(":")[0];
    }
}
