package gov.archives.core.controller;

import java.sql.Timestamp;
import java.util.Collection;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.validator.routines.RegexValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.domain.vo.AccountDetail;
import gov.archives.core.domain.vo.UserInfo;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.service.SessionManageService;
import gov.archives.core.service.UserInfoService;

/**
 * Created by tristan on 2016/7/25.
 */
@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.SYSTEM_TOOL_URL + "/user")
public class UserInfoController {

    private static final Logger log = LoggerFactory.getLogger(UserInfoController.class);

    public static final String MODULE_NAME = "使用者維護資料模組";
    public static final String SUCCESS_MESSAGE = "使用者資料更新成功";

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private SessionManageService sessionManageService;

    @Autowired
    private ActionLogService actionLogService;

    @RequestMapping(value = "/list",
            method = RequestMethod.GET)
    public Collection<UserInfo> getAll() {
        try {
            return userInfoService.list();
        } catch (RuntimeException e) {
            throw new RestApplicationException(e.getMessage());
        }
    }

    @RequestMapping(value = "/saveUser",
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void saveUser(@RequestBody UserInfo user, HttpServletRequest httpServletRequest) {
        try {
            if (null == user) {
                throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
            }
            verifyUserInfo(user);
            userInfoService.updateUserByAccount(user);
            writeActionLog(httpServletRequest, HttpStatus.OK.getReasonPhrase(), SUCCESS_MESSAGE,
                    CoreConf.EVENT_LEVEL_LOW);
        } catch (ArchivesException e) {
            writeActionLog(httpServletRequest, e.getErrorCode(), e.getMessage(), CoreConf.EVENT_LEVEL_LOW);
            throw ArchivesException.getInstanceByErrorCode(e.getErrorCode());
        } catch (RuntimeException e) {
            writeActionLog(httpServletRequest, CoreErrorCode.SYSTEM_ERROR, e.getMessage(), CoreConf.EVENT_LEVEL_MEDIUM);
            throw new RuntimeException(e.getMessage());
        }
    }

    private void writeActionLog(HttpServletRequest httpServletRequest, String errorCode, String message,
            String eventLevel) {
        String currentUser = httpServletRequest.getRemoteUser();
        if (null == currentUser) { throw new RestApplicationException("Not logged in"); }
        long accessedTime = httpServletRequest.getSession().getLastAccessedTime();
        ActionLogEntity actionLogEntity = ActionLogEntity.Builder.create()
                                                                 .setActionItem(MODULE_NAME)
                                                                 .setActionResult(message)
                                                                 .setErrorCode(errorCode)
                                                                 .setEventLevel(eventLevel)
                                                                 .setActorAccount(currentUser)
                                                                 .setActionTime(new Timestamp(accessedTime))
                                                                 .setRemoteIp(httpServletRequest.getRemoteAddr())
                                                                 .build();
        actionLogEntity.initSave(currentUser);
        actionLogService.insert(actionLogEntity);
    }

    private void verifyUserInfo(UserInfo user) {
        RegexValidator digitValidator = new RegexValidator(CoreConf.DIGIT_PATTERN);
        RegexValidator digitOrEmptyValidator = new RegexValidator(CoreConf.DIGIT_EMPTY_PATTERN);
        RegexValidator alphaNumericValidator = new RegexValidator(CoreConf.ALPHANUMERIC_PATTERN);
        RegexValidator alphaNumericNlsValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);

        String account = user.getAccount();
        if (null == account || !alphaNumericValidator.isValid(account)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.USER_ACCOUNT_FORMAT_INCORRECT);
        }
        String roleName = user.getRoleName();
        if (roleName == null || (!roleName.isEmpty() && !alphaNumericNlsValidator.isValid(roleName))) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ROLE_VALUE_INCORRECT);
        }
        String userName = user.getUserName();
        if (null == userName || !alphaNumericNlsValidator.isValid(userName)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.USER_NAME_FORMAT_INCORRECT);
        }
        String email = user.getEmail();
        if (null == email || !EmailValidator.getInstance().isValid(email)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.EMAIL_FORMAT_INCORRECT);
        }
        if (!alphaNumericNlsValidator.isValid(user.getOrgInfo())) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ORG_INFO_FORMAT_INCORRECT);
        }
        int activeStatus = user.getActiveStatus();
        if (!(activeStatus == CoreConf.STATUS_APPLYING || activeStatus == CoreConf.STATUS_DISABLED
                || activeStatus == CoreConf.STATUS_ENABLED)) {
            throw new RestApplicationException("Invalid ActiveStatus");
        }
        String deputyAccount = user.getDeputyAccount();
        if (null == deputyAccount || (!deputyAccount.isEmpty() && !alphaNumericValidator.isValid(deputyAccount))) {
            throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
        }
        String phoneAreaCode = user.getPhoneAreaCode();
        if (null == phoneAreaCode || !digitValidator.isValid(phoneAreaCode)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_TYPE_INCORRECT);
        }
        if (phoneAreaCode.length() < 2 || phoneAreaCode.length() > 4) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
        String phoneLocalNumber = user.getPhoneLocalNumber();
        if (null == phoneLocalNumber || !digitValidator.isValid(phoneLocalNumber)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_TYPE_INCORRECT);
        }
        if (phoneLocalNumber.length() > 10) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
        String phoneExtNumber = user.getPhoneExtNumber();
        if (null == phoneExtNumber || !digitOrEmptyValidator.isValid(phoneExtNumber)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_TYPE_INCORRECT);
        }
        if (phoneExtNumber.length() > 6) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
        String mobileAreaCode = user.getMobileAreaCode();
        if (null == mobileAreaCode || !digitOrEmptyValidator.isValid(mobileAreaCode)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_TYPE_INCORRECT);
        }
        if (mobileAreaCode.length() > 4) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
        String mobileLocalNumber = user.getMobileLocalNumber();
        if (null == mobileLocalNumber || !digitOrEmptyValidator.isValid(mobileLocalNumber)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_TYPE_INCORRECT);
        }
        if (mobileLocalNumber.length() > 10) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
    }

    @RequestMapping(value = "/accountDetail")
    public ResponseEntity<AccountDetail> getAccountDetail(HttpServletRequest request) throws RestApplicationException {
        AccountDetail accountDetail = sessionManageService.getAccountDetail();
        if (null != accountDetail) {
            return new ResponseEntity<>(accountDetail, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(accountDetail, HttpStatus.NOT_FOUND);
        }
    }

    @RequestMapping(value = "/checkSessionId",
            method = RequestMethod.POST)
    public ResponseEntity checkAccountSessionId() {
        HttpStatus status = sessionManageService.checkAccountSessionId() ? HttpStatus.OK : HttpStatus.CONFLICT;
        return new ResponseEntity(status);
    }
}
