package gov.archives.core.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.validator.routines.RegexValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.PreconditionUtils;

import gov.archives.common.json.JsonUtils;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.domain.entity.DistributeMappingEntity;
import gov.archives.core.domain.entity.DistributeUnitEntity;
import gov.archives.core.domain.vo.DistributeDoc;
import gov.archives.core.domain.vo.DistributeHistory;
import gov.archives.core.domain.vo.DistributeMapping;
import gov.archives.core.domain.vo.DistributeUnit;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.service.DistributionService;
import gov.archives.core.util.BeanUtils;
import gov.archives.dox.service.AddressbookService;

/**
 * Created by tristan on 2016/8/25.
 */
@RestController
@RequestMapping(value = "v1/DocumentSystem/")
public class DistributionController {
    private static final Logger log = LoggerFactory.getLogger(DistributionController.class);

    private static final String MODULE_DIST_SENNDER = "可轉文單位設定";
    private static final String MODULE_DIST_MAPPING = "可轉文單位新增";
    private static final String MODULE_DIST_SENDER_SETTING = "轉文群組設定";
    private static final String MODULE_DIST_RECEIVER = "可被轉文單位設定";
    private static final String MODULE_DIST_RECEIVER_SETTING = "被轉文群組設定";
    private static final String SUCCESS_MESSAGE = "轉文設定修改成功";
    private static final String MODULE_DIST_DOC = "轉文簽收查詢";
    private static final String DOST_DOC_QUERY_SUCCESS = "轉文簽收查詢成功";

    @Autowired
    private DistributionService distributionService;

    @Autowired
    private AddressbookService addressbookService;

    @Autowired
    private ActionLogService actionLogService;

    @RequestMapping(value = "listSenderUnit", method = RequestMethod.GET)
    public Collection<DistributeUnit> getSenderUnitList(
            @RequestParam(value = "orgId", required = false, defaultValue = "") String orgId,
            @RequestParam(value = "unitId", required = false, defaultValue = "") String unitId,
            @RequestParam(value = "orgUnitName", required = false, defaultValue = "") String orgUnitName,
            @RequestParam(value = "exactMatch") boolean exactMatch) {
        log.info("OrgId: "+orgId+", UnitID: "+unitId+", OrgUnitName: "+orgUnitName+", ExactMatch: "+exactMatch);
        RegexValidator stringValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);
        if(!orgId.isEmpty())
            if(!stringValidator.isValid(orgId))
                throw new RestApplicationException();
        if(!unitId.isEmpty())
            if(!stringValidator.isValid(unitId))
                throw new RestApplicationException();
        if(!orgUnitName.isEmpty())
            if(!stringValidator.isValid(orgUnitName))
                throw new RestApplicationException();
        String centerId = "9905"; //temp
        return distributionService.listSenderUnit(centerId, orgId, unitId, orgUnitName, exactMatch);
    }

    @RequestMapping(value = "listReceiverUnit", method = RequestMethod.GET)
    public Collection<DistributeUnit> getReceiverUnitList(
            @RequestParam(value = "orgId", required = false, defaultValue = "") String orgId,
            @RequestParam(value = "unitId", required = false, defaultValue = "") String unitId,
            @RequestParam(value = "orgUnitName", required = false, defaultValue = "") String orgUnitName,
            @RequestParam(value = "exactMatch") boolean exactMatch) {
        log.info("OrgId: "+orgId+", UnitID: "+unitId+", OrgUnitName: "+orgUnitName+", ExactMatch: "+exactMatch);
        RegexValidator stringValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);
        if(!orgId.isEmpty())
            if(!stringValidator.isValid(orgId))
                throw new RestApplicationException();
        if(!unitId.isEmpty())
            if(!stringValidator.isValid(unitId))
                throw new RestApplicationException();
        if(!orgUnitName.isEmpty())
            if(!stringValidator.isValid(orgUnitName))
                throw new RestApplicationException();
        String centerId = "9905"; //temp
        return distributionService.listReceiverUnit(centerId, orgId, unitId, orgUnitName, exactMatch);
    }

    @RequestMapping(value = "listCenterSenderUnit", method = RequestMethod.GET)
    public Collection<DistributeUnit> getCenterSenderUnitList() {
        String centerId = "9905"; //temp
        return distributionService.listCenterSenderUnit(centerId);
    }

    @RequestMapping(value = "listCenterReceiverUnit", method = RequestMethod.GET)
    public Collection<DistributeUnit> getCenterReceiverUnitList() {
        String centerId = "9905"; //temp
        return distributionService.listCenterReceiverUnit(centerId);
    }

    @RequestMapping(value = "listUnitMappingBySender", method = RequestMethod.GET)
    public Collection<DistributeUnit> listUnitMappingBySender(@RequestParam("orgId") String orgId,
            @RequestParam("unitId") String unitId) {
        RegexValidator stringValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);
        if(!orgId.isEmpty())
            if(!stringValidator.isValid(orgId))
                throw new RestApplicationException();
        if(!unitId.isEmpty())
            if(!stringValidator.isValid(unitId))
                throw new RestApplicationException();
        return distributionService.listReceiverUnitBySenderId(orgId, unitId);
    }

    @RequestMapping(value = "deleteSenderUnit", method = RequestMethod.POST)
    public void deleteSenderUnit(@RequestBody DistributeUnit senderUnit, HttpServletRequest httpServletRequest) {
        try {
            PreconditionUtils.checkArguments(senderUnit);
            distributionService.deleteSenderUnitByOrgUnitId(senderUnit);
            writeActionLog(httpServletRequest, MODULE_DIST_SENNDER, CoreErrorCode.SYSTEM_ERROR, SUCCESS_MESSAGE,
                    CoreConf.EVENT_LEVEL_MEDIUM);
        } catch (RuntimeException e) {
            writeActionLog(httpServletRequest, MODULE_DIST_SENNDER, CoreErrorCode.SYSTEM_ERROR, e.getMessage(),
                    CoreConf.EVENT_LEVEL_MEDIUM);
        }
    }

    @RequestMapping(value = "deleteReceiverUnit", method = RequestMethod.POST)
    public void deleteReceiverUnit(@RequestBody DistributeUnit receiverUnit, HttpServletRequest httpServletRequest) {
        try {
            PreconditionUtils.checkArguments(receiverUnit);
            distributionService.deleteReceiverUnitByOrgUnitId(receiverUnit);
            writeActionLog(httpServletRequest, MODULE_DIST_RECEIVER, CoreErrorCode.SYSTEM_ERROR, SUCCESS_MESSAGE,
                    CoreConf.EVENT_LEVEL_MEDIUM);
        } catch (RuntimeException e) {
            writeActionLog(httpServletRequest, MODULE_DIST_RECEIVER, CoreErrorCode.SYSTEM_ERROR, e.getMessage(),
                    CoreConf.EVENT_LEVEL_MEDIUM);
        }
    }

    @RequestMapping(value = "setSenderUnit", method = RequestMethod.POST)
    public void setSenderUnit(@RequestBody Collection<DistributeUnit> senderList, HttpServletRequest httpServletRequest) {
        try {
            PreconditionUtils.checkArguments(senderList);
            String currentUser =
                    httpServletRequest.getRemoteUser() == null ? "unknown" : httpServletRequest.getRemoteUser();//
            Collection<DistributeUnit> originalList = this.getSenderUnitList("", "", "", false);

            List<DistributeUnit> addedUnitList = new ArrayList<>(senderList);
            addedUnitList.removeAll(originalList);
            log.info("add senderUnit: " + JsonUtils.getJsonTextByObject(addedUnitList));
            List<DistributeUnit> removedUnitList = new ArrayList<>(originalList);
            removedUnitList.removeAll(senderList);
            log.info("remove senderUnit: " + JsonUtils.getJsonTextByObject(removedUnitList));

            for (DistributeUnit unit : addedUnitList) {
                DistributeUnitEntity unitEntity = new DistributeUnitEntity();
                BeanUtils.copyProperties(unitEntity, unit);
                unitEntity.initSave(currentUser);
                distributionService.insertSenderUnit(unitEntity);
            }
            for (DistributeUnit unit : removedUnitList) {
                distributionService.deleteSenderUnitByOrgUnitId(unit);
            }
            writeActionLog(httpServletRequest, MODULE_DIST_SENDER_SETTING, CoreErrorCode.SYSTEM_ERROR,
                    SUCCESS_MESSAGE, CoreConf.EVENT_LEVEL_MEDIUM);
        } catch (RuntimeException e) {
            writeActionLog(httpServletRequest, MODULE_DIST_SENDER_SETTING, CoreErrorCode.SYSTEM_ERROR,
                    e.getMessage(), CoreConf.EVENT_LEVEL_MEDIUM);
        }
    }

    @RequestMapping(value = "setReceiverUnit", method = RequestMethod.POST)
    public void setReceiverUnit(@RequestBody Collection<DistributeUnit> receiverList, HttpServletRequest httpServletRequest) {
        try {
            PreconditionUtils.checkArguments(receiverList);
            Collection<DistributeUnit> originalList = this.getReceiverUnitList("", "", "", false);

            List<DistributeUnit> addedUnitList = new ArrayList<>(receiverList);
            addedUnitList.removeAll(originalList);
            log.info("add receiverUnit: " + JsonUtils.getJsonTextByObject(addedUnitList));
            List<DistributeUnit> removedUnitList = new ArrayList<>(originalList);
            removedUnitList.removeAll(receiverList);
            log.info("remove receiverUnit: " + JsonUtils.getJsonTextByObject(removedUnitList));

            String currentUser =
                    httpServletRequest.getRemoteUser() == null ? "unknown" : httpServletRequest.getRemoteUser();//
            for (DistributeUnit unit : addedUnitList) {
                DistributeUnitEntity unitEntity = new DistributeUnitEntity();
                BeanUtils.copyProperties(unitEntity, unit);
                unitEntity.initSave(currentUser);
                distributionService.insertReceiverUnit(unitEntity);
            }

            for (DistributeUnit unit : removedUnitList) {
                distributionService.deleteReceiverUnitByOrgUnitId(unit);
            }
            //
        } catch (RuntimeException e) {
            writeActionLog(httpServletRequest, MODULE_DIST_RECEIVER_SETTING, CoreErrorCode.SYSTEM_ERROR, e.getMessage(), CoreConf.EVENT_LEVEL_MEDIUM);
        }
    }

    @RequestMapping(value = "setDistributeMapping", method = RequestMethod.POST)
    public void setDistributeMapping(@RequestBody JsonNode jsonNode, HttpServletRequest httpServletRequest)
            throws JsonProcessingException {
        try {
            PreconditionUtils.checkArguments(jsonNode);
            String senderOrgId = jsonNode.get("senderOrgId").textValue();
            String senderUnitId = jsonNode.get("senderUnitId").textValue();
            JsonNode mappingListNode = jsonNode.get("mappingList");
            List<DistributeMapping> newList = new ArrayList<>();
            ObjectMapper objectMapper = new ObjectMapper();
            for (JsonNode node : mappingListNode) {
                DistributeMapping mapping = objectMapper.treeToValue(node, DistributeMapping.class);
                newList.add(mapping);
            }
            List<DistributeMapping> originalMappingList =
                    distributionService.listMappingBySenderId(senderOrgId, senderUnitId);
            List<DistributeMapping> addedMappingList = (new ArrayList<>(newList));
            List<DistributeMapping> removedMappingList = new ArrayList<>(originalMappingList);
            addedMappingList.removeAll(originalMappingList);
            log.info("add mapping: " + JsonUtils.getJsonTextByObject(addedMappingList));
            removedMappingList.removeAll(newList);
            log.info("remove mapping: " + JsonUtils.getJsonTextByObject(removedMappingList));

            String currentUser =
                    httpServletRequest.getRemoteUser() == null ? "unknown" : httpServletRequest.getRemoteUser();//
            for (DistributeMapping mapping : addedMappingList) {
                DistributeMappingEntity mappingEntity = new DistributeMappingEntity();
                BeanUtils.copyProperties(mappingEntity, mapping);
                mappingEntity.initSave(currentUser);
                distributionService.insertDistributeMapping(mappingEntity);
            }
            for (DistributeMapping mapping : removedMappingList) {
                distributionService.deleteMappingByOrgUnitId(mapping);
            }
            writeActionLog(httpServletRequest, MODULE_DIST_MAPPING, CoreErrorCode.SYSTEM_ERROR,
                    SUCCESS_MESSAGE, CoreConf.EVENT_LEVEL_MEDIUM);
        } catch (RuntimeException e) {
            writeActionLog(httpServletRequest, MODULE_DIST_MAPPING, CoreErrorCode.SYSTEM_ERROR, e.getMessage(),
                    CoreConf.EVENT_LEVEL_MEDIUM);
        }
    }

    @RequestMapping(value = "listDistDoc", method = RequestMethod.GET)
    public Collection<DistributeDoc> getDistributeDocList(
            @RequestParam(value = "processId", required = false, defaultValue = "") String processId,
            @RequestParam(value = "status") int status,
            @RequestParam(value = "fromOrgId", required = false, defaultValue = "") String fromOrgId,
            @RequestParam(value = "fromUnitId", required = false, defaultValue = "") String fromUnitId,
            @RequestParam(value = "fromOrgUnitName", required = false, defaultValue = "") String fromOrgUnitName,
            @RequestParam(value = "toOrgId", required = false, defaultValue = "") String toOrgId,
            @RequestParam(value = "toUnitId", required = false, defaultValue = "") String toUnitId,
            @RequestParam(value = "toOrgUnitName", required = false, defaultValue = "") String toOrgUnitName,
            @RequestParam(value = "fromTime", required = false, defaultValue = "") String fromTime,
            @RequestParam(value = "toTime", required = false, defaultValue = "") String toTime,
            @RequestParam(value = "exactMatch") boolean exactMatch) {
        log.info("ProcessId: "+processId+", Status: "+status+", FromTime: "+fromTime+", ToTime: "+toTime);
        RegexValidator stringValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);
        if(!processId.isEmpty())
            if(!stringValidator.isValid(processId))
                throw new RestApplicationException();
        if(!fromOrgId.isEmpty())
            if(!stringValidator.isValid(fromOrgId))
                throw new RestApplicationException();
        if(!fromUnitId.isEmpty())
            if(!stringValidator.isValid(fromUnitId))
                throw new RestApplicationException();
        if(!fromOrgUnitName.isEmpty())
            if(!stringValidator.isValid(fromOrgUnitName))
                throw new RestApplicationException();
        if(!toOrgId.isEmpty())
            if(!stringValidator.isValid(toOrgId))
                throw new RestApplicationException();
        if(!toUnitId.isEmpty())
            if(!stringValidator.isValid(toUnitId))
                throw new RestApplicationException();
        if(!toOrgUnitName.isEmpty())
            if(!stringValidator.isValid(toOrgUnitName))
                throw new RestApplicationException();
        return distributionService.listDistributeDoc(processId, status, fromOrgId, fromUnitId, fromOrgUnitName,
                toOrgId, toUnitId, toOrgUnitName, fromTime, toTime, exactMatch);
    }

    @RequestMapping(value = "listFlowHistory", method = RequestMethod.GET)
    public Collection<DistributeHistory> getDistributeHistory(@RequestParam(value="processId") String processId) {
        PreconditionUtils.checkArguments(processId);
        return distributionService.listDistributeHistoryByProcessId(processId);
    }

    private void writeActionLog(HttpServletRequest httpServletRequest, String moduleName, String errorCode, String message,
            String eventLevel) {
        String currentUser = httpServletRequest.getRemoteUser();
        //if (null == currentUser) { throw new RestApplicationException("Not logged in"); }
        long accessedTime = httpServletRequest.getSession().getLastAccessedTime();
        ActionLogEntity actionLogEntity = ActionLogEntity.Builder.create()
                                                                 .setActionItem(moduleName)
                                                                 .setActionResult(message)
                                                                 .setErrorCode(errorCode)
                                                                 .setEventLevel(eventLevel)
                                                                 .setActorAccount(currentUser==null?"unknown":currentUser)
                                                                 .setActionTime(new Timestamp(accessedTime))
                                                                 .setRemoteIp(httpServletRequest.getRemoteAddr())
                                                                 .build();
        actionLogEntity.initSave(currentUser);
        actionLogService.insert(actionLogEntity);
    }
}
