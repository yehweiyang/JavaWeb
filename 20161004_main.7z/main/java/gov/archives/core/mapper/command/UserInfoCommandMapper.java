package gov.archives.core.mapper.command;

import java.util.Map;

import gov.archives.core.domain.entity.UserInfoEntity;

/**
 * UserInfoCommandMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/15.
 */
public interface UserInfoCommandMapper {
    String KEY_SYS_ID = "sysId";
    String KEY_ROLE_NAME = "roleName";
    String KEY_USER_ACCOUNT = "account";
    String KEY_MODIFIER_ACCOUNT = "modifierAccount";
    String KEY_MODIFIED_TIME = "modifiedTime";

    void save(UserInfoEntity user);

    void update(UserInfoEntity user);

    void remove(UserInfoEntity user);

    void updateUserByAccount(UserInfoEntity user);

    void updateUserByRoleName(Map<String, Object> params);

    void updateSingleUserByName(Map<String, Object> params);
}
