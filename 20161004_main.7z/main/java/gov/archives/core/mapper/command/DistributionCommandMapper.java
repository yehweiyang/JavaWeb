package gov.archives.core.mapper.command;

import java.util.Map;

import gov.archives.core.domain.entity.DistributeMappingEntity;
import gov.archives.core.domain.entity.DistributeUnitEntity;
import gov.archives.core.domain.vo.DistributeMapping;

/**
 * Created by tristan on 2016/8/26.
 */
public interface DistributionCommandMapper {
    void saveSenderUnit(DistributeUnitEntity senderUnitEntity);
    void saveReceiverUnit(DistributeUnitEntity receiverUnitEntity);
    void removeSenderUnit(DistributeUnitEntity senderUnitEntity);
    void removeReceiverUnit(DistributeUnitEntity receiverUnitEntity);
    void removeSenderUnitByOrgUnitId(Map idMap);
    void removeReceiverUnitByOrgUnitId(Map idMap);
    void saveMapping(DistributeMappingEntity mappingEntity);
    void removeMapping(DistributeMappingEntity mappingEntity);
    void removeMappingByOrgUnitId(DistributeMapping distributeMapping);
    void removeMappingBySenderUnitId(Map idMap);
    void removeMappingByReceiverUnitId(Map idMap);
}
