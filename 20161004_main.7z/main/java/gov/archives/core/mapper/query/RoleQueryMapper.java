package gov.archives.core.mapper.query;

import java.util.List;
import java.util.UUID;

import gov.archives.core.domain.entity.RoleEntity;

/**
 * RoleQueryMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
public interface RoleQueryMapper {

    List<RoleEntity> getRoleByStatus(int status);

    List<RoleEntity> findHaveSame(RoleEntity role);

    RoleEntity findById(UUID sysId);

    RoleEntity findByRoleName(String roleName);

    List<RoleEntity> list();
}
