package gov.archives.core.mapper.query;

import java.util.List;
import java.util.Map;

import gov.archives.core.domain.entity.DistributeDocEntity;
import gov.archives.core.domain.entity.DistributeHistoryEntity;
import gov.archives.core.domain.entity.DistributeMappingEntity;
import gov.archives.core.domain.entity.DistributeUnitEntity;
import gov.archives.core.domain.vo.DistributeMapping;

/**
 * Created by tristan on 2016/8/25.
 */
public interface DistributionQueryMapper {
    String KEY_ORG_ID = "orgId";
    String KEY_UNIT_ID = "unitId";
    String CENTER_ID = "centerId";
    String ORG_UNIT_NAME = "orgUnitName";
    String PROCESS_ID = "processId";
    String STATUS = "status";
    String FROM_ORG_ID = "fromOrgId";
    String FROM_UNIT_ID = "fromUnitId";
    String FROM_ORG_UNIT_NAME = "fromOrgUnitName";
    String TO_ORG_ID = "toOrgId";
    String TO_UNIT_ID = "toUnitId";
    String TO_ORG_UNIT_NAME = "toOrgUnitName";
    String FROM_TIME = "fromTime";
    String TO_TIME = "toTime";
    String EXACT_MATCH = "exactMatch";

    List<DistributeUnitEntity> listSenderUnit(Map queryMap);
    List<DistributeUnitEntity> listReceiverUnit(Map queryMap);
    DistributeUnitEntity getSenderUnitByOrgUnitId(Map orgUnitId);
    DistributeUnitEntity getReceiverUnitByOrgUnitId(Map orgUnitId);
    List<DistributeUnitEntity> listCenterSenderUnit(String centerId);
    List<DistributeUnitEntity> listCenterReceiverUnit(String centerId);

    List<DistributeUnitEntity> listReceiverUnitBySender(Map orgUnitId);
    List<DistributeMappingEntity> listMappingBySenderId(Map orgUnitId);
    DistributeMappingEntity getMappingByOrgUnitId(DistributeMapping distributeMapping);

    List<DistributeDocEntity> listDistributeDoc(Map queryMap);
    List<DistributeHistoryEntity> listDistributeHistoryByProcessId(String processId);
}
