package gov.archives.core.facade;

import gov.archives.core.domain.entity.MenuEntity;

import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

/**
 * Created by wtjiang on 2016/9/10.
 */
public interface RoleMenuMappingFacade {
    List<MenuEntity> getRoleMenuFacade(String account) throws UnknownHostException;
    Map getRoleMappingMenu (String account);
}
