package gov.archives.core.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;

/**
 * Created by kshsu on 2016/9/22.
 * 加密工具集
 */
abstract class EncryptUtils {

    private static final Logger log = LoggerFactory.getLogger(EncryptUtils.class);

    private final static String CONFIGFILE_NAME = "encryptUtils.properties";
    // 密鑰 (自訂)
    private final static String SECRET_KEY;
    private final static String DEFAULT_SECRET_KEY = "gov.archives.core.util.EncryptUtils";
    // 向量 (自訂 8 bytes)
    private final static String IV;
    private final static String DEFAULT_IV = "01234567";
    // 加解密統一使用的編碼方式
    private final static String ENCODING;
    private final static String DEFAULT_ENCODING = "utf-8";

    private static final char[] LEGAL_CHARS;
    private static final String DEFAULT_LEGAL_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    private EncryptUtils() {}

    static {
        Properties properties = new Properties();
        try {
            properties.load(
                    IOUtils.loadResourceInClasspath(CONFIGFILE_NAME));
        } catch (IOException ex) {
            properties.put("secretkey", DEFAULT_SECRET_KEY);
            properties.put("iv", DEFAULT_IV);
            properties.put("encoding", DEFAULT_ENCODING);
            properties.put("legalchars", DEFAULT_LEGAL_CHARS);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR, ex);
        } finally {
            SECRET_KEY = properties.getProperty("secretkey", DEFAULT_SECRET_KEY);
            IV = properties.getProperty("iv", DEFAULT_IV);
            ENCODING = properties.getProperty("encoding", DEFAULT_ENCODING);
            LEGAL_CHARS = properties.getProperty("legalchars", DEFAULT_LEGAL_CHARS).toCharArray();
        }
    }

    /**
     * 3DES加密
     */
    static String desEncode(String plainText) throws CoreException {

        String rtnStr;
        try {
            Key deskey;
            DESedeKeySpec spec = new DESedeKeySpec(SECRET_KEY.getBytes());
            SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");
            deskey = keyfactory.generateSecret(spec);
            Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
            IvParameterSpec ips = new IvParameterSpec(IV.getBytes());
            cipher.init(Cipher.ENCRYPT_MODE, deskey, ips);
            byte[] encryptData = cipher.doFinal(plainText.getBytes(ENCODING));
            rtnStr = Base64.encode(encryptData);
        } catch (Exception ex) {
            throw new CoreException(ex, CoreErrorCode.SYSTEM_ERROR);
        }
        return rtnStr;
    }

    /**
     * 3DES解密
     */
    static String desDecode(String encryptText) throws CoreException {

        String rtnStr;
        try {
            Key deskey;
            DESedeKeySpec spec = new DESedeKeySpec(SECRET_KEY.getBytes());
            SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");
            deskey = keyfactory.generateSecret(spec);
            Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
            IvParameterSpec ips = new IvParameterSpec(IV.getBytes());
            cipher.init(Cipher.DECRYPT_MODE, deskey, ips);
            byte[] decryptData = cipher.doFinal(Base64.decode(encryptText));
            rtnStr = new String(decryptData, ENCODING);
        } catch (Exception ex) {
            throw new CoreException(ex, CoreErrorCode.SYSTEM_ERROR);
        }
        return rtnStr;
    }

    static String StringHash(String sourceText) throws CoreException {

        String result;

        try {
            PreconditionUtils.checkArguments(sourceText);

            // SHA-256 Hash
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            // Change this to "UTF-16" if needed
            md.update(sourceText.getBytes("UTF-8"));
            byte[] digest = md.digest();

            // format to hex with left zero padding:
            result = String.format("%064x", new BigInteger(1, digest));

        } catch (NoSuchAlgorithmException | UnsupportedEncodingException ex) {
            throw new CoreException(ex, CoreErrorCode.SYSTEM_ERROR);
        }

        return result;
    }

    private static class Base64 {

        static {

        }

        static String encode(byte[] data) {
            int start = 0;
            int len = data.length;
            StringBuffer buf = new StringBuffer(data.length * 3 / 2);

            int end = len - 3;
            int i = start;
            int n = 0;

            while (i <= end) {
                int d = ((((int) data[i]) & 0x0ff) << 16) | ((((int) data[i + 1]) & 0x0ff) << 8) |
                        (((int) data[i + 2]) & 0x0ff);

                buf.append(LEGAL_CHARS[(d >> 18) & 63]);
                buf.append(LEGAL_CHARS[(d >> 12) & 63]);
                buf.append(LEGAL_CHARS[(d >> 6) & 63]);
                buf.append(LEGAL_CHARS[d & 63]);

                i += 3;

                if (n++ >= 14) {
                    n = 0;
                    buf.append(" ");
                }
            }

            if (i == start + len - 2) {
                int d = ((((int) data[i]) & 0x0ff) << 16) | ((((int) data[i + 1]) & 255) << 8);

                buf.append(LEGAL_CHARS[(d >> 18) & 63]);
                buf.append(LEGAL_CHARS[(d >> 12) & 63]);
                buf.append(LEGAL_CHARS[(d >> 6) & 63]);
                buf.append("=");
            } else if (i == start + len - 1) {
                int d = (((int) data[i]) & 0x0ff) << 16;

                buf.append(LEGAL_CHARS[(d >> 18) & 63]);
                buf.append(LEGAL_CHARS[(d >> 12) & 63]);
                buf.append("==");
            }

            return buf.toString();
        }

        private static int decode(char c) {
            if (c >= 'A' && c <= 'Z') { return ((int) c) - 65; } else if (c >= 'a' && c <= 'z') {
                return ((int) c) - 97 + 26;
            } else if (c >= '0' && c <= '9') {
                return ((int) c) - 48 + 26 + 26;
            } else {
                switch (c) {
                    case '+':
                        return 62;
                    case '/':
                        return 63;
                    case '=':
                        return 0;
                    default:
                        throw new RuntimeException("unexpected code: " + c);
                }
            }
        }

        /**
         * Decodes the given Base64 encoded String to a new byte array. The byte array holding the decoded data is
         * returned.
         */
        static byte[] decode(String s) {

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try {
                decode(s, bos);
            } catch (IOException e) {
                throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR, e);
            }
            byte[] decodedBytes = bos.toByteArray();
            try {
                bos.close();
                bos = null;
            } catch (IOException ex) {
                throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR, ex);
            }
            return decodedBytes;
        }

        private static void decode(String s, OutputStream os) throws IOException {
            int i = 0;

            int len = s.length();

            while (true) {
                while (i < len && s.charAt(i) <= ' ') { i++; }

                if (i == len) { break; }

                int tri =
                        (decode(s.charAt(i)) << 18) + (decode(s.charAt(i + 1)) << 12) + (decode(s.charAt(i + 2)) << 6) +
                                (decode(s.charAt(i + 3)));

                os.write((tri >> 16) & 255);
                if (s.charAt(i + 2) == '=') { break; }
                os.write((tri >> 8) & 255);
                if (s.charAt(i + 3) == '=') { break; }
                os.write(tri & 255);

                i += 4;
            }
        }
    }
}