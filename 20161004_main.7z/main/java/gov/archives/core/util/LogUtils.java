package gov.archives.core.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;

/**
 * Created by kshsu on 2016/9/21.
 * log 公用方法,隱藏真實程式架構路徑
 */
public abstract class LogUtils {

    private static final Logger log = LoggerFactory.getLogger(LogUtils.class);

    private static List<Level> LOG_CONFIGURATION_DEBUG;
    private static List<Level> LOG_CONFIGURATION_INFO;
    private static List<Level> LOG_CONFIGURATION_WARN;
    private static List<Level> LOG_CONFIGURATION_ERROR;
    private static List<Level> LOG_CONFIGURATION_FATAL;
    private static String NO_MESSAGE_DEFINED = "No Message Defined.";

    static {
        LOG_CONFIGURATION_DEBUG = new ArrayList<>();
        LOG_CONFIGURATION_DEBUG.add(Level.DEBUG);

        LOG_CONFIGURATION_INFO = new ArrayList<>();
        LOG_CONFIGURATION_INFO.add(Level.INFO);
        LOG_CONFIGURATION_INFO.add(Level.WARN);
        LOG_CONFIGURATION_INFO.add(Level.ERROR);
        LOG_CONFIGURATION_INFO.add(Level.FATAL);

        LOG_CONFIGURATION_WARN = new ArrayList<>();
        LOG_CONFIGURATION_WARN.add(Level.INFO);
        LOG_CONFIGURATION_WARN.add(Level.WARN);
        LOG_CONFIGURATION_WARN.add(Level.ERROR);
        LOG_CONFIGURATION_WARN.add(Level.FATAL);

        LOG_CONFIGURATION_ERROR = new ArrayList<>();
        LOG_CONFIGURATION_ERROR.add(Level.INFO);
        LOG_CONFIGURATION_ERROR.add(Level.WARN);
        LOG_CONFIGURATION_ERROR.add(Level.ERROR);
        LOG_CONFIGURATION_ERROR.add(Level.FATAL);

        LOG_CONFIGURATION_FATAL = new ArrayList<>();
        LOG_CONFIGURATION_FATAL.add(Level.INFO);
        LOG_CONFIGURATION_FATAL.add(Level.WARN);
        LOG_CONFIGURATION_FATAL.add(Level.ERROR);
        LOG_CONFIGURATION_FATAL.add(Level.FATAL);
    }

    private LogUtils() {}

    public static void logException(String message) {
        if (!Level.DEBUG.equals(CoreConf.ROOT_LOGGER_LEVEL)) {
            error(message);
        } else {
            debug(message);
        }
    }

    public static void logException(Throwable throwable) {
        if (!Level.DEBUG.equals(CoreConf.ROOT_LOGGER_LEVEL)) {
            error(throwable);
        } else {
            debug(throwable);
        }
    }

    public static void logException(String message, Throwable throwable) {
        if (!Level.DEBUG.equals(CoreConf.ROOT_LOGGER_LEVEL)) {
            error(message, throwable);
        } else {
            debug(message, throwable);
        }
    }

    public static void debug(String message) {
        log.debug(message);
    }

    public static void debug(Throwable throwable) {
        log.debug(StringUtils.stackTraceFromException(throwable));
    }

    public static void debug(String message, Throwable throwable) {
        log.debug(message, throwable);
    }

    public static void info(String message) {
        log.info(message);
    }

    public static void info(Throwable throwable) {
        log.info(StringUtils.stackTraceFromException(throwable));
    }

    public static void info(String message, Throwable throwable) {
        log.info(message, throwable);
    }

    public static void error(String message) {
        log.error(message);
    }

    public static void error(Throwable throwable) {
        log.error(StringUtils.stackTraceFromException(throwable));
    }

    public static void error(String message, Throwable throwable) {
        log.error(message, throwable);
    }

    public static String getErrorMessage(String errorCode) {
        return CoreErrorMessage.findByCode(errorCode).contains(NO_MESSAGE_DEFINED) ?
                errorCode : CoreErrorMessage.findByCode(errorCode);
    }

    public static String getErrorCodeIfExist(String errorCode) {
        return CoreErrorMessage.findByCode(errorCode).contains(NO_MESSAGE_DEFINED) ?
                CoreErrorCode.SYSTEM_ERROR : errorCode;
    }
}