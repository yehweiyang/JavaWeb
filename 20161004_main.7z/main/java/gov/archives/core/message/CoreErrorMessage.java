package gov.archives.core.message;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 140631 on 2016/7/26.
 */
public class CoreErrorMessage {
    private static Map<String, String> errorMessages;

    static {
        errorMessages = new HashMap<>();
        errorMessages.put(CoreErrorCode.SYSTEM_ERROR, "系統錯誤"); //SYS0000
        errorMessages.put(CoreErrorCode.UNAUTHORIZED, "使用者無此權限"); //SYS0001
        errorMessages.put(CoreErrorCode.FILE_SAVE_FAIL, "檔案儲存錯誤"); //SYS0003

        errorMessages.put(CoreErrorCode.DATA_NOT_FOUND, "Data not found.");     //AP0000
        errorMessages.put(CoreErrorCode.CAPTCHA_ERROR, "圖形驗證碼輸入錯誤，請重新登錄"); //AP0001
        errorMessages.put(CoreErrorCode.ACCOUNT_ERROR, "登入失敗，請重新登錄");  //AP0002
        errorMessages.put(CoreErrorCode.PIN_ERROR, "PIN碼輸入錯誤，請重新登錄"); //AP0003
        errorMessages.put(CoreErrorCode.CARD_EXPIRED, "卡片逾期，請重新登錄");  //AP0004
        errorMessages.put(CoreErrorCode.CARD_NOT_AVAILABLE, "卡片無效，請重新登錄"); //AP0005
        errorMessages.put(CoreErrorCode.SIGNATURE_ERROR, "卡片錯誤，請重新登錄"); //AP0006
        errorMessages.put(CoreErrorCode.CARD_NOT_MATCH_DATA, "卡片錯誤，請重新登錄"); //AP0007
        errorMessages.put(CoreErrorCode.LOGIN_EXPIRED, "登錄失敗三次，需等五分鐘才能重新登入"); //AP0008
        errorMessages.put(CoreErrorCode.CARD_INCORRECT, "卡片錯誤，請使用申請人之憑證卡"); //AP0011
        errorMessages.put(CoreErrorCode.DUPLICATE_ACCOUNT, "帳號已有人使用，請另取其他帳號"); //AP0012

        errorMessages.put(CoreErrorCode.ACCOUNT_PROCESSING, "此帳號審核中..."); //AP0013
        errorMessages.put(CoreErrorCode.ACCOUNT_SUSPENDED, "此帳號已被停用..."); //AP0014
        errorMessages.put(CoreErrorCode.PHONE_TYPE_INCORRECT, "電話號碼輸入格式錯誤");   //ED0001
        errorMessages.put(CoreErrorCode.PHONE_FORMAT_INCORRECT, "電話號碼輸入格式錯誤"); //ED0002
        errorMessages.put(CoreErrorCode.EMAIL_FORMAT_INCORRECT, "email輸入格式錯誤");  //ED0003
        errorMessages.put(CoreErrorCode.USER_ACCOUNT_FORMAT_INCORRECT, "使用者帳號輸入格式錯誤"); //ED0017
        errorMessages.put(CoreErrorCode.USER_NAME_FORMAT_INCORRECT, "使用者姓名輸入格式錯誤"); //ED0018
        errorMessages.put(CoreErrorCode.ROLE_VALUE_INCORRECT, "權限類型輸入錯誤"); //ED9000
        errorMessages.put(CoreErrorCode.ORG_INFO_FORMAT_INCORRECT, "所屬單位輸入格式錯誤"); //ED9001

        errorMessages.put(CoreErrorCode.ROLE_VALUE_SEARCH, "權限查詢失敗"); //RO0001
        errorMessages.put(CoreErrorCode.ROLE_VALUE_ADD, "新增權限失敗"); //RO0002
        errorMessages.put(CoreErrorCode.ROLE_VALUE_UPDATE, "修改權限失敗"); //RO0003
        errorMessages.put(CoreErrorCode.ROLE_VALUE_MENUMODIFY, "權限查詢失敗"); //RO0004


        errorMessages.put(CoreErrorCode.REPORT_INIT_ERROR, "報表初始化錯誤"); //PR0001
        errorMessages.put(CoreErrorCode.REPORT_QUERY_ERROR, "報表查詢錯誤"); //PR0002
        errorMessages.put(CoreErrorCode.REPORT_DOWNLOAD_ERROR, "報表下載錯誤"); //PR0003
        errorMessages.put(CoreErrorCode.REPORT_BACKGROUND_ERROR, "報表背景執行錯誤"); //PR0004
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_UNKNOWN, "無法判斷的錯誤"); //PR9001
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_TEST, "測試錯誤"); //PR9002
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_IN_UTILS, "ReportUtil Method 內部發生錯誤"); //PR9003
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND, "ReportBaseCommand Method 內部發生錯誤"); //PR9004
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_IN_COMMAND_PROCESSOR, "ReportCommandProcessor Method 內部發生錯誤"); //PR9005
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_IN_COMMAND_SERVICE, "ReportCommandService Method 內部發生錯誤"); //PR9006
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_IN_DATA_GEN_SERVICE, "ReportDataGenService Method 內部發生錯誤"); //PR9007
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_IN_DATA_PREPARE_SERVICE, "ReportDataPrepareService Method 內部發生錯誤"); //PR9008
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_IN_OUTPUT_FACADE, "ReportOutputFacade Method 內部發生錯誤"); //PR9009
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_IN_NOT_LOGIN, "Not login error"); //PR9010
        errorMessages.put(CoreErrorCode.REPORT_EXCEPTION_IN_INIT_FOLDER, "初始化資料夾錯誤"); //PR9011

        errorMessages.put(CoreErrorCode.ORG_ID_INCORRECT, "機關代碼錯誤"); //CEX0001
        errorMessages.put(CoreErrorCode.LOG_FILE_INEXISTENCE, "查無相關檔案"); //CEX0002
        errorMessages.put(CoreErrorCode.LOG_FILE_ERROR, "下載檔案錯誤"); //CEX0002

        errorMessages.put(CoreErrorCode.DOC_NOTICE_MAIL_READ_ERROR, "收文通知查詢發生錯誤"); //DNM0001
        errorMessages.put(CoreErrorCode.DOC_NOTICE_MAIL_CREATE_ERROR, "收文通知新增發生錯誤"); //DNM0002
        errorMessages.put(CoreErrorCode.DOC_NOTICE_MAIL_UPDATE_ERROR, "收文通知修改發生錯誤"); //DNM0003
        errorMessages.put(CoreErrorCode.DOC_NOTICE_MAIL_DELETE_ERROR, "收文通知刪除發生錯誤"); //DNM0004

        errorMessages.put(CoreErrorCode.SEARCH_MENU_ERROR, "查詢MENU錯誤"); //MENU001

        errorMessages.put(CoreErrorCode.SEARCH_SMTP_ERROR, "查詢SMTP錯誤"); //SMTP001
        errorMessages.put(CoreErrorCode.UPDATE_SMTP_ERROR, "新增SMTP錯誤"); //SMTP002
    }

    public static String findByCode(String errorCode) {
        return errorMessages.containsKey(errorCode) ? errorMessages.get(errorCode) : "No Message Defined.";
    }

}
