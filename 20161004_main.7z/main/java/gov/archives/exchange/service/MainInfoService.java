package gov.archives.exchange.service;

import java.util.List;
import java.util.Map;

import gov.archives.exchange.domain.entity.ExchangeInnerRecordEntity;
import gov.archives.exchange.domain.entity.MainInfoEntity;

/**
 * MainInfoService
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
public interface MainInfoService {
    String SENDER_TYPE_SCHEMA = "senderType";
    String EXCHANGE_SERIAL = "exchangeSerial";
    String CONTACT_NAME = "連絡人: ";
    String CONTACT_PHONE = " 連絡電話: ";
    String CONTACT_FAX = " 傳真: ";
    String CONTACT_EMAIL = " 電子信箱: ";

    List<ExchangeInnerRecordEntity> getMainInfoByMap(Map<String, Object> params);
}
