package gov.archives.exchange.service;

import gov.archives.exchange.command.ReportCommand;

/**
 * Created by kshsu on 2016/7/26.
 */
public interface ReportCommandService {
    void addCommand(String process, ReportCommand command);

    void doProcess(String process);
}
