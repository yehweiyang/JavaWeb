package gov.archives.exchange.service;

import java.util.List;

import gov.archives.exchange.domain.vo.ExchangeAbnormalQueryVo;

/**
 * ExchangeAbnormalQueryService
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
public interface ExchangeAbnormalQueryService {
    List<ExchangeAbnormalQueryVo> getErrorQueryList(ExchangeAbnormalQueryVo changeErrorQueryVo);
    ExchangeAbnormalQueryVo getErrorQueryID(String ID);

}
