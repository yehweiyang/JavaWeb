package gov.archives.exchange.service;

import java.util.List;
import java.util.Map;

import gov.archives.core.exception.ArchivesException;
import gov.archives.exchange.domain.vo.ReportScheduleManageVO;

/**
 * Created by jslee on 2016/9/8.
 */
public interface ReportScheduleManageService {

    void insertOneDayComfirmedRate(String triggerDate);

    void updateTwoDayComfirmedRate(Map<String, Object> workingDateMap);

    List<ReportScheduleManageVO> getReportScheduleManageVos() throws ArchivesException;

    void runInstant(String reportName) throws ArchivesException;

}
