package gov.archives.exchange.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import gov.archives.exchange.domain.entity.ReportConFirmedDataResult;
import gov.archives.exchange.domain.entity.ReportErrRankResult;
import gov.archives.exchange.domain.entity.ReportODFSendRateResult;
import gov.archives.exchange.domain.entity.ReportReceiveStatisticResult;
import gov.archives.exchange.domain.entity.ReportRecvErrListResult;
import gov.archives.exchange.domain.entity.ReportRecvListResult;
import gov.archives.exchange.domain.entity.ReportRecvStateResult;
import gov.archives.exchange.domain.entity.ReportSendErrListResult;
import gov.archives.exchange.domain.entity.ReportSendErrResult;
import gov.archives.exchange.domain.entity.ReportSendListResult;
import gov.archives.exchange.domain.entity.ReportSendRankResult;
import gov.archives.exchange.domain.entity.ReportSendStateResult;
import gov.archives.exchange.domain.entity.ReportSendStatisticResult;
import gov.archives.exchange.domain.entity.ReportSendUnConfmResult;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportConFirmedDataFilter;
import gov.archives.exchange.domain.vo.ReportODFSendRateFilter;
import gov.archives.exchange.domain.vo.ReportRSStateFilter;
import gov.archives.exchange.domain.vo.ReportRecvErrListFilter;
import gov.archives.exchange.domain.vo.ReportRecvListFilter;
import gov.archives.exchange.domain.vo.ReportSendErrFilter;
import gov.archives.exchange.domain.vo.ReportSendErrListFilter;
import gov.archives.exchange.domain.vo.ReportSendListFilter;
import gov.archives.exchange.domain.vo.ReportSendUnConfmFilter;

/**
 * Created by jslee on 2016/7/5.
 */
public interface ReportDataGenService {

    List<ReportSendRankResult> getReportSendRankByFilter(ReportBaseFilter reportBaseFilter);

    List<ReportErrRankResult> getReportErrRankByFilter(ReportBaseFilter reportBaseFilter);

    List<ReportReceiveStatisticResult> getReportReceiveStatisticByRSStateFilter(ReportRSStateFilter reportRSStateFilter);

    List<ReportSendStatisticResult> getReportSendStatisticByRSStateFilter(ReportRSStateFilter reportRSStateFilter);

    List<ReportSendErrResult> getReportSendErrBySendErrFilter(ReportSendErrFilter reportSendErrFilter);

    List<ReportSendStateResult> getReportSendStateByFilter(ReportBaseFilter reportBaseFilter);

    List<ReportSendListResult> getReportSendListBySendListFilter(ReportSendListFilter reportSendListFilter);

    List<ReportSendUnConfmResult> getReportSendUnConfmBySendUnConfomFilter(ReportSendUnConfmFilter reportSendUnConfmFilter);

    List<ReportSendErrListResult> getReportSendErrListBySendErrListFilter(ReportSendErrListFilter reportSendErrListFilter);

    List<ReportRecvStateResult> getReportRecvStateByFilter(ReportBaseFilter reportBaseFilter);

    List<ReportRecvListResult> getReportRecvListByRecvListFilter(ReportRecvListFilter reportRecvListFilter);

    List<ReportRecvErrListResult> getReportRecvErrListByRecvErrListFilter(ReportRecvErrListFilter reportRecvErrListFilter);

    List<ReportConFirmedDataResult> getReportConFirmedDataResultByConFirmedDataFilter(ReportConFirmedDataFilter reportConFirmedDataFilter);

    List<ReportODFSendRateResult> getReportODFSendRateByODFSendRateFilter(ReportODFSendRateFilter odfSendRateFilter);

    void saveSearchResult(String fileName, Object filterBean, Object resultBean);

    Map<String, Object> restoreSearchResult(String fileName, Class<?> filterClass, Class<?> resultClass)
            throws IOException, ClassNotFoundException;
}
