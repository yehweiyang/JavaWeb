package gov.archives.exchange.service;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import gov.archives.exchange.domain.vo.DocNoticeMailVO;

/**
 * Created by jslee on 2016/9/14.
 */
public interface DocNoticeMailService {

    void addDocNoticeMail(DocNoticeMailVO docNoticeMailVO);

    void updateDocNoticeMail(DocNoticeMailVO docNoticeMailVO);

    void removeDocNoticeMail(UUID sysid);

    List<DocNoticeMailVO> getDocNoticeMailByFilterMap(Map<String, Object> filterMap);

    Boolean isDocNoticeMailExist(Map<String, Object> filterMap);

}
