package gov.archives.exchange.service;

import java.util.List;
import java.util.Map;

/**
 * Created by jslee on 2016/7/21.
 */
public interface ReportDataPrepareService {

    public Map<String, Object> prepareReportData(String reportName);

    public String getTempFilePath(String reportName);

    public String getTempFilePath(String reportName, String userIs);

    public String getReportMonthFilePath(String reportName, String reportFileName);

    public Map<String, Object> getReportFilterAndResultClass(String reportName);

    public String getLastReportOperation(String userAccount, String... reportNames);

    public List<String> prepareReportMonthList(String reportName);

    public void initAllReportFolder();

}
