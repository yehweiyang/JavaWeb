package gov.archives.exchange.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.iii.common.util.PreconditionUtils;

import gov.archives.exchange.domain.entity.DocNoticeMailEntity;
import gov.archives.exchange.domain.vo.DocNoticeMailVO;
import gov.archives.exchange.mapper.command.DocNoticeMailCommandMapper;
import gov.archives.exchange.mapper.query.DocNoticeMailQueryMapper;
import gov.archives.exchange.service.DocNoticeMailService;

/**
 * Created by jslee on 2016/9/14.
 */
@Service
public class DocNoticeMailServiceImpl implements DocNoticeMailService {

    @Autowired
    private DocNoticeMailQueryMapper docNoticeMailQueryMapper;

    @Autowired
    private DocNoticeMailCommandMapper docNoticeMailCommandMapper;

    private DocNoticeMailEntity currentDocNoticeEntity;

    @Override
    public void addDocNoticeMail(DocNoticeMailVO docNoticeMailVO) {
        currentDocNoticeEntity = convertDocNoticeMailVoToEntity(docNoticeMailVO);
        currentDocNoticeEntity.initSave(currentDocNoticeEntity.getCreatorAccount());
        docNoticeMailCommandMapper.create(currentDocNoticeEntity);
    }

    @Override
    public void updateDocNoticeMail(DocNoticeMailVO docNoticeMailVO) {
        currentDocNoticeEntity = convertDocNoticeMailVoToEntity(docNoticeMailVO);
        currentDocNoticeEntity.initUpdate(currentDocNoticeEntity.getCreatorAccount());
        docNoticeMailCommandMapper.update(currentDocNoticeEntity);
    }

    @Override
    public void removeDocNoticeMail(UUID sysid) {
        docNoticeMailCommandMapper.delete(sysid);
    }

    @Override
    public List<DocNoticeMailVO> getDocNoticeMailByFilterMap(Map<String, Object> filterMap) {
        List<DocNoticeMailVO> docNoticeMailVOs = new ArrayList<>();
        docNoticeMailQueryMapper.findDocNoticeMailByFilterMap(filterMap).forEach(currentDocNotice -> {
            docNoticeMailVOs.add(convertDocNoticeMailEntityToVo(currentDocNotice));
        });

        return docNoticeMailVOs;
    }

    @Override
    public Boolean isDocNoticeMailExist(Map<String, Object> filterMap) {
        docNoticeMailQueryMapper.findDocNoticeMailExist(filterMap);
        return docNoticeMailQueryMapper.findDocNoticeMailExist(filterMap) > 0;
    }

    private DocNoticeMailVO convertDocNoticeMailEntityToVo(DocNoticeMailEntity docNoticeMailEntity) {
        PreconditionUtils.checkArguments(docNoticeMailEntity);

        DocNoticeMailVO docNoticeMailVO = new DocNoticeMailVO();
        docNoticeMailVO.setDocNoticeId(docNoticeMailEntity.getSysId());
        docNoticeMailVO.setDocNoticeOrgId(docNoticeMailEntity.getOrgId());
        docNoticeMailVO.setDocNoticeUnitId(docNoticeMailEntity.getUnitId());
        docNoticeMailVO.setDocNoticeOrgUnitName(docNoticeMailEntity.getOrgUnitName());
        docNoticeMailVO.setDocNoticeStatus(docNoticeMailEntity.getActiveStatus());
        docNoticeMailVO.setDocNoticeEmails(docNoticeMailEntity.getNoticeEmail());
        docNoticeMailVO.setDocNoticeCreator(docNoticeMailEntity.getCreatorAccount());
        docNoticeMailVO.setDocNoticeCreatedTime(docNoticeMailEntity.getCreatedTime());
        docNoticeMailVO.setDocNoticeModifier(docNoticeMailEntity.getModifierAccount());
        docNoticeMailVO.setDocNoticeModifiedTime(docNoticeMailEntity.getModifiedTime());

        return docNoticeMailVO;
    }

    private DocNoticeMailEntity convertDocNoticeMailVoToEntity(DocNoticeMailVO docNoticeMailVO) {
        PreconditionUtils.checkArguments(docNoticeMailVO);

        DocNoticeMailEntity docNoticeMailEntity = new DocNoticeMailEntity();
        docNoticeMailEntity.setSysId(docNoticeMailVO.getDocNoticeId());
        docNoticeMailEntity.setOrgId(docNoticeMailVO.getDocNoticeOrgId());
        docNoticeMailEntity.setUnitId(docNoticeMailVO.getDocNoticeUnitId());
        docNoticeMailEntity.setOrgUnitName(docNoticeMailVO.getDocNoticeOrgUnitName());
        docNoticeMailEntity.setActiveStatus(docNoticeMailVO.getDocNoticeStatus());
        docNoticeMailEntity.setNoticeEmail(docNoticeMailVO.getDocNoticeEmails());
        docNoticeMailEntity.setCreatorAccount(docNoticeMailVO.getDocNoticeCreator());
        docNoticeMailEntity.setCreatedTime(docNoticeMailVO.getDocNoticeCreatedTime());
        docNoticeMailEntity.setModifierAccount(docNoticeMailVO.getDocNoticeModifier());
        docNoticeMailEntity.setModifiedTime(docNoticeMailVO.getDocNoticeModifiedTime());

        return docNoticeMailEntity;
    }

}
