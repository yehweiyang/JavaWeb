package gov.archives.exchange.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.exception.ArchivesException;
import gov.archives.exchange.conf.ExchangeConf;
import gov.archives.exchange.domain.entity.TransmitDetailEntity;
import gov.archives.exchange.mapper.query.DetailInfoQueryMapper;
import gov.archives.exchange.message.ExchangeErrorCode;
import gov.archives.exchange.message.ExchangeErrorMessage;
import gov.archives.exchange.service.DetailInfoService;

@Service
@Transactional
public class DetailInfoServiceImpl implements DetailInfoService {

    @Autowired
    private DetailInfoQueryMapper queryMapper;

    @Override
    @Transactional(value = ExchangeConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<TransmitDetailEntity> getTransmitDetailByMap(Map<String, Object> params) {
        List<TransmitDetailEntity> transmitList = queryMapper.findByMap(params);
        if (null == transmitList || 0 == transmitList.size()) {
            throw new ArchivesException(ExchangeErrorMessage.AP0000_ERROR_MESSAGE,
                    ExchangeErrorCode.AP0000_DATA_NOT_FOUND);
        }

        for (TransmitDetailEntity entity : transmitList) {
            String exchangeType = entity.getExchangeType();
            if (exchangeType.equals(INNER_TYPE))
                entity.setExchangeType(INNER_EXCHANGE_TYPE);
            else if (exchangeType.equals(OUT_TYPE))
                entity.setExchangeType(OUT_EXCHANGE_TYPE);
            else
                entity.setExchangeType(OLD_EXCHANGE_TYPE);
            if (entity.getMsgCode() < 0) {
                entity.setMessageStatus(BAD_MSG_CODE);
            } else {
                entity.setMessageStatus(GOOD_MSG_CODE);
            }
        }
        return transmitList;
    }
}
