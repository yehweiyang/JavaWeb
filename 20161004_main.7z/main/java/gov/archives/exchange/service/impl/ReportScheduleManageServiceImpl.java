package gov.archives.exchange.service.impl;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.quartz.CronExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import org.iii.common.util.IOUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportScheduleManageVO;
import gov.archives.exchange.mapper.command.ReportScheduleCommandMapper;
import gov.archives.exchange.schedule.helper.ReportScheduleHelper;
import gov.archives.exchange.service.ReportScheduleManageService;

/**
 * Created by jslee on 2016/9/8.
 */
@Service
public class ReportScheduleManageServiceImpl implements ReportScheduleManageService {

    private static final String propertisName = "schedule.properties";
    private static final String scheduleMethodName = "excuteSchedule";

    @Autowired
    private ReportScheduleCommandMapper reportScheduleCommandMapper;

    @Autowired
    private ReportScheduleHelper reportScheduleHelper;


    @Override
    public void insertOneDayComfirmedRate(String triggerDate) {
        reportScheduleCommandMapper.saveOneDayConfirmedRate(triggerDate);
    }

    @Override
    public void updateTwoDayComfirmedRate(Map<String, Object> workingDateMap) {
        reportScheduleCommandMapper.updateTwoDaysConfirmedRate(workingDateMap);
    }

    @Override
    public List<ReportScheduleManageVO> getReportScheduleManageVos() throws ArchivesException {

        Properties prop = new Properties();
        List<ReportScheduleManageVO> reportScheduleManageVOs = new ArrayList();
        try {
            prop.load(IOUtils.loadResourceInClasspath(propertisName));

            Arrays.stream(ReportEnum.class.getEnumConstants()).forEach(reportEnum -> {
                if (reportEnum.isMonthSchedule()) {
                    Method method = null;
                    try {
                        method = reportScheduleHelper.getReportScheduler(reportEnum.toString()).getClass()
                                                     .getMethod(scheduleMethodName);

                        String scheduleValue = method.getAnnotation(Scheduled.class).cron();

                        CronExpression cronExpression = new CronExpression(
                                prop.get(
                                        formatAnnotationValueName(scheduleValue)
                                ).toString());

                        ReportScheduleManageVO scheduleManageVO = new ReportScheduleManageVO();
                        scheduleManageVO.setReportName(reportEnum.getTWName());
                        scheduleManageVO.setNextRunTime(cronExpression.getNextValidTimeAfter(new Date()));

                        reportScheduleManageVOs.add(scheduleManageVO);
                    } catch (Exception e) {
                        reportManageExceptionHandle(e);
                    }
                }
            });
        } catch (IOException e) {
            reportManageExceptionHandle(e);
        }

        return reportScheduleManageVOs;
    }

    @Override
    public void runInstant(String reportName) throws ArchivesException {
        try {
            Arrays.stream(ReportEnum.class.getEnumConstants()).forEach(reportEnum -> {
                if (reportEnum.toString().equals(reportName)) {
                    reportScheduleHelper.getReportScheduler(reportName).runReportSchedule(true);
                }
            });
        } catch (Exception e) {
            reportManageExceptionHandle(e);
        }
    }

    private String formatAnnotationValueName(String valueName) {
        return valueName.substring(2, valueName.length() - 1);
    }

    private void reportManageExceptionHandle(Throwable throwable) {
        throw new ArchivesException(CoreErrorCode.SYSTEM_ERROR, throwable);
    }

}
