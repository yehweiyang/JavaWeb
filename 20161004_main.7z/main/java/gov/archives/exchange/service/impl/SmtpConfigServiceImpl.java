package gov.archives.exchange.service.impl;

import gov.archives.exchange.domain.entity.SmtpConfigEntity;
import gov.archives.exchange.service.SmtpConfigService;

/**
 * Created by wtjiang on 2016/9/18.
 */
public class SmtpConfigServiceImpl implements SmtpConfigService {

    @Override
    public SmtpConfigEntity searchSmtpConfig() {
        return null;
    }

    @Override
    public void updateSmtpConfig(SmtpConfigEntity smtpConfigEntity) {

    }
}
