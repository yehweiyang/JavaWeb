package gov.archives.exchange.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.conf.CoreConf;
import gov.archives.exchange.domain.entity.AccessorEntity;
import gov.archives.exchange.mapper.query.AgencyCertQueryMapper;
import gov.archives.exchange.service.AgencyCertService;

/**
 * Created by wtjiang on 2016/8/26.
 */
@Service
@Transactional
public class AgencyCertServiceImpl implements AgencyCertService {

    @Autowired
   private AgencyCertQueryMapper accessorQueryMapper;

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<AccessorEntity> getCertHash(String orgId) {
        return accessorQueryMapper.findCertHashByOrgId(orgId);
    }
}
