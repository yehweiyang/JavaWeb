package gov.archives.exchange.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.domain.entity.LoginHistoryEntity;
import gov.archives.exchange.domain.vo.LoginHistory;
import gov.archives.exchange.mapper.query.LoginHistoryQueryMapper;
import gov.archives.exchange.service.LoginHistoryService;

/**
 * LoginHistoryServiceImpl
 * <p>
 * Created by WeiYang on 2016/9/14.
 */
@Service
public class LoginHistoryServiceImpl implements LoginHistoryService {

    @Autowired
    private LoginHistoryQueryMapper mapper;

    @Override
    public List<LoginHistory> getQueryList(LoginHistory loginHistory) {
        List<LoginHistory> resultQuery = new ArrayList<>();
        try {
            for (LoginHistoryEntity entity : mapper.findAllQuery(loginHistory)) {
                LoginHistory vo = new LoginHistory();
                BeanUtils.copyProperties(vo, entity);
                resultQuery.add(vo);
            }
        } catch (Exception ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR, ex);
        }
        return resultQuery;
    }
}
