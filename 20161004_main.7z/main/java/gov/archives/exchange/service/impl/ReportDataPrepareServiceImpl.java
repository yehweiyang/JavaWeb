package gov.archives.exchange.service.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletContext;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.context.ServletContextAware;

import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.vo.ReportAdvancedFilter;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportRSStateFilter;
import gov.archives.exchange.service.ReportDataPrepareService;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by kshsu on 2016/7/21.
 */
@Service
public class ReportDataPrepareServiceImpl implements ReportDataPrepareService, ServletContextAware {
    private static final Logger log = LoggerFactory.getLogger(ReportDataPrepareServiceImpl.class);

    private static final String DEFAULT_USER_NAME = "user";
    private static final String DEFAULT_HOUR_FROM = "00";
    private static final String DEFAULT_HOUR_TO = "23";
    private static final String DEFAULT_SORT_COLUMN = "rowIndex";
    private static final Boolean DEFAULT_CONTENT_FULL_CMP = false;
    private static final Boolean DEFAULT_SORT_DESCENDING = false;

    private ServletContext servletContext;

    private String tmpFilePathAndFileName;
    private String todayString;

    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @Override
    public String getTempFilePath(String reportName) {
        setTempFilePath(reportName, DEFAULT_USER_NAME);
        return tmpFilePathAndFileName;
    }

    @Override
    public String getTempFilePath(String reportName, String userIs) {
        setTempFilePath(reportName, userIs);
        return tmpFilePathAndFileName;
    }

    @Override
    public String getReportMonthFilePath(String reportName, String reportFileName) {
        return getReportMonthFolderPath(reportName) + "/" + reportFileName + CoreConf.SUFFIX_JSON;
    }


    @Override
    public String getLastReportOperation(String userAccount, String... reportNames) {
        String newerReportName = reportNames[0];
        for (String reportName : reportNames) {
            File newerReport = new File(getTempFilePath(newerReportName, userAccount));
            File eqlReport = new File(getTempFilePath(reportName, userAccount));
            if (newerReport.exists() && eqlReport.exists()) {
                newerReportName = FileUtils.isFileNewer(newerReport, eqlReport) ?
                        newerReportName : reportName;
            }
        }
        return newerReportName;
    }

    @Override
    public Map<String, Object> prepareReportData(String reportName) throws ArchivesException {
        PreconditionUtils.checkArguments(reportName);

        Map<String, Object> initMap = new HashMap<>();

        todayString = ReportUtils.getTodayString();

        //PRN001, PRN002, PRN005, PRN009, PRN012
        if (ReportEnum.REPORT_SEND_RANK.equalsName(reportName) ||
                ReportEnum.REPORT_ERR_RANK.equalsName(reportName) ||
                ReportEnum.REPORT_SEND_STATE.equalsName(reportName) ||
                ReportEnum.REPORT_RECEIVE_STATE.equalsName(reportName) ||
                ReportEnum.REPORT_CONFIRMED_QUERY.equalsName(reportName)) {
            initMap.put("filterContent", prepareReportBaseFilter());

            //PRN003
        } else if (ReportEnum.REPORT_R_STATE_STATIC.equalsName(reportName) ||
                ReportEnum.REPORT_S_STATE_STATIC.equalsName(reportName)) {
            initMap.put("filterContent", prepareReportRSStateFilter());

            //PRN004, PRN006, PRN007, PRN008, PRN010, PRN011 ,PRN013
        } else if (ReportEnum.REPORT_SEND_ERR.equalsName(reportName) ||
                ReportEnum.REPORT_SEND_LIST.equalsName(reportName) ||
                ReportEnum.REPORT_SEND_UNCONFIRM.equalsName(reportName) ||
                ReportEnum.REPORT_SEND_ERR_LIST.equalsName(reportName) ||
                ReportEnum.REPORT_RECEIVE_LIST.equalsName(reportName) ||
                ReportEnum.REPORT_RECEIVE_ERR_LIST.equalsName(reportName) ||
                ReportEnum.REPORT_ODF_SEND_RATE.equalsName(reportName)) {
            initMap.put("filterContent", prepareReportAdvancedFilter());
        } else {
            throw new ArchivesException(CoreErrorCode.REPORT_EXCEPTION_IN_DATA_PREPARE_SERVICE);
        }

        if (MapUtils.isNotEmpty(initMap) && !IOUtils.isFolderExist(getTempFilePath(reportName))) {
            initAllReportFolder();
        }

        return initMap;
    }

    @Override
    public Map<String, Object> getReportFilterAndResultClass(String reportName) throws ArchivesException {
        for (Enum reportEnum : ReportEnum.class.getEnumConstants()) {
            if (reportEnum.toString().equals(reportName)) {
                return ((ReportEnum) reportEnum).getFilterResultClassMap();
            }
        }
        throw new ArchivesException(CoreErrorCode.REPORT_EXCEPTION_IN_DATA_PREPARE_SERVICE);
    }

    @Override
    public List<String> prepareReportMonthList(String reportName) {
        List<String> reportMonthList = new ArrayList<>();
        try {
            String testPath = getReportMonthFolderPath(reportName);
            Files.walk(Paths.get(testPath)).forEach(fileName -> {
                if (Files.isRegularFile(fileName)) {
                    reportMonthList.add(fileName.toFile().getName().replace(".json", ""));
                }
            });
        } catch (Exception e) {
            prepareServiceExceptionHandler(e);
        }
        return reportMonthList;
    }

    @Override
    public void initAllReportFolder() {
        Arrays.stream(ReportEnum.class.getEnumConstants()).forEach(reportEnum -> {
            setTempFilePath(reportEnum.toString());
            try {
                ReportUtils.initReportFolder(tmpFilePathAndFileName);
                ReportUtils.initReportFolder(getReportMonthFolderPath(reportEnum.toString()));
            } catch (Exception e) {
                prepareServiceExceptionHandler(e);
            }
        });
    }

    private String getReportMonthFolderPath(String reportName) {
        return servletContext.getRealPath("") +
                ReportConf.WEB_INFO +
                ReportConf.REPORT_ROOT +
                "/" + reportName +
                ReportConf.REPORT_MONTH_FOLDER;
    }

    private void setTempFilePath(String reportName) throws ArchivesException {

        tmpFilePathAndFileName = servletContext.getRealPath("") +
                ReportConf.WEB_INFO +
                ReportConf.REPORT_ROOT +
                "/" + reportName +
                ReportConf.USER_TEMP_FOLDER;
    }

    private void setTempFilePath(String reportName, String userCode) throws ArchivesException {
        setTempFilePath(reportName);
        tmpFilePathAndFileName += "/" + userCode + CoreConf.SUFFIX_JSON;
    }

    private ReportBaseFilter prepareReportBaseFilter() {
        return prepareReportBaseFilter(new ReportBaseFilter());
    }

    private ReportAdvancedFilter prepareReportAdvancedFilter() {
        return prepareReportAdvancedFilter(new ReportAdvancedFilter());

    }

    private ReportBaseFilter prepareReportBaseFilter(ReportBaseFilter reportBaseFilter) {
        try {
            reportBaseFilter.setDateFrom(todayString);
            reportBaseFilter.setDateTo(todayString);
            reportBaseFilter.setSortColumnName(DEFAULT_SORT_COLUMN);
            reportBaseFilter.setSortDescending(DEFAULT_SORT_DESCENDING);
        } catch (Exception ex) {
            prepareServiceExceptionHandler(ex);
        }
        return reportBaseFilter;
    }

    private ReportAdvancedFilter prepareReportAdvancedFilter(ReportAdvancedFilter reportAdvancedFilter)
            throws ArchivesException {
        try {
            reportAdvancedFilter = (ReportAdvancedFilter) prepareReportBaseFilter(reportAdvancedFilter);
            reportAdvancedFilter.setTimeFrom(DEFAULT_HOUR_FROM);
            reportAdvancedFilter.setTimeTo(DEFAULT_HOUR_TO);
            reportAdvancedFilter.setContentFullCmp(DEFAULT_CONTENT_FULL_CMP);
        } catch (Exception ex) {
            prepareServiceExceptionHandler(ex);
        }
        return reportAdvancedFilter;
    }

    private ReportRSStateFilter prepareReportRSStateFilter() throws ArchivesException {

        ReportRSStateFilter rsStateFilter = null;
        try {
            rsStateFilter = (ReportRSStateFilter) prepareReportAdvancedFilter(new ReportRSStateFilter());
            rsStateFilter.setQueryTarget("收文");
        } catch (Exception ex) {
            prepareServiceExceptionHandler(ex);
        }
        return rsStateFilter;
    }

    private void prepareServiceExceptionHandler(Throwable throwable) throws ArchivesException {
        throw ArchivesException
                .getInstanceByErrorCode(CoreErrorCode.REPORT_EXCEPTION_IN_DATA_PREPARE_SERVICE, throwable);
    }
}
