package gov.archives.exchange.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.command.PdfReportCommandProcessor;
import gov.archives.exchange.command.ReportCommand;
import gov.archives.exchange.command.ReportCommandProcessor;
import gov.archives.exchange.service.ReportCommandService;

/**
 * Created by kshsu on 2016/7/26.
 */
@Service("pdfCommandService")
public class PdfReportCommandServiceImpl implements ReportCommandService {

    private static final Logger log = LoggerFactory.getLogger(PdfReportCommandServiceImpl.class);

    private Map<String, ReportCommand> commands = new HashMap<String, ReportCommand>();

    private ReportCommandProcessor reportCommandProcessor = new PdfReportCommandProcessor();

    @Override
    public void addCommand(String process, ReportCommand command) {
        commands.put(process, command);
    }

    @Override
    public void doProcess(String process) throws ArchivesException {
        try {
            commands.get(process).execute(reportCommandProcessor);
        } catch (Exception ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_EXCEPTION_IN_COMMAND_SERVICE, ex);
        }
    }
}
