package gov.archives.exchange.service;

import gov.archives.exchange.domain.entity.SmtpConfigEntity;

/**
 * Created by wtjiang on 2016/9/18.
 */
public interface SmtpConfigService {

    SmtpConfigEntity searchSmtpConfig();

    void updateSmtpConfig(SmtpConfigEntity smtpConfigEntity);
}
