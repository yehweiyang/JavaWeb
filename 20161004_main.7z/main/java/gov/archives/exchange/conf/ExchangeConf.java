package gov.archives.exchange.conf;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;

import org.iii.common.conf.CommonConfig;
import org.iii.common.util.IOUtils;

import gov.archives.core.exception.ArchivesException;

/**
 * ExchangeConf <br> exchange package 之共用設定 <br> gemhuang, 2016/8/16.
 */
public class ExchangeConf {
    public static final String QUERY_TX_MANAGER = "exchangeQueryTxManager";
    public static final String COMMAND_TX_MANAGER = "exchangeCommandTxManager";

    public static final String MANAGE_WEB_PROPERTIES = "manageWeb.properties";
    public static final String SMTP_PROPERTIES = "MailServer.properties";
    public static final String PROP_CLIENT_LOG = "client.log.location";
    public static final String SMTP_SERVER_IP = "SMTP.SERVER.IP";
    public static final String SMTP_SERVER_PORT = "SMTP.SERVER.PORT";
    public static final String IS_USE_SSL = "SMTP.USE.SSL";
    public static final String IS_NEED_CERTIFICATION = "SMTP.NEED.CERTIFICATION";
    public static final String SMTP_LOGIN_ACCOUNT = "SMTP.LOGIN.ACCOUNT";
    public static final String SMTP_LOGIN_PASSWORD = "SMTP.LOGIN.PASSWORD";
    public static final String SMTP_LAST_UPDATE = "SMTP.LAST.UPDATE";
    public static final String PROP_SERVER_CONFIG = "server.config.location";
    public static final String TEMP_CONTENT_NAME = "/tempQuery";
    public static final String RESOURCES_PATH = "src/main/resources";

    private static Properties prop;

    private static PropertiesConfiguration propertiesConfiguration;

    private static File mailServerPropertiesFile = CommonConfig.getRuntimeRoot(ExchangeConf.class)
            .resolve(RESOURCES_PATH)
            .resolve(SMTP_PROPERTIES).toFile();

    public static void initProperty(String property) {
        if (null == prop) {
            try {
                prop = new Properties();
                prop.load(IOUtils.loadResourceInClasspath(property));
            } catch (IOException e) {
                throw ArchivesException.getInstanceByErrorCode("9999");
            }
        }
    }

    public static String getClientLogLocation() {
        if (null == prop) {
            initProperty(MANAGE_WEB_PROPERTIES);
        }
        return prop.getProperty(PROP_CLIENT_LOG);
    }

    public static String getServerConfigLocation() {
        if (null == prop) {
            initProperty(MANAGE_WEB_PROPERTIES);
        }
        return prop.getProperty(PROP_SERVER_CONFIG);
    }

    public static String getSmtpConfig(String smtpConfigKey) {

        propertiesConfiguration = new PropertiesConfiguration();

        try {
            if (!IOUtils.isFileExist(mailServerPropertiesFile)) {

                mailServerPropertiesFile.createNewFile();
                OutputStream fos = new FileOutputStream(mailServerPropertiesFile);
                prop = new Properties();
                prop.setProperty(ExchangeConf.SMTP_SERVER_IP, "null");
                prop.setProperty(ExchangeConf.SMTP_SERVER_PORT, "null");
                prop.setProperty(ExchangeConf.SMTP_LOGIN_ACCOUNT, "null");
                prop.setProperty(ExchangeConf.SMTP_LOGIN_PASSWORD, "null");
                prop.setProperty(ExchangeConf.SMTP_LAST_UPDATE, "null");
                prop.setProperty(ExchangeConf.IS_USE_SSL, "false");
                prop.setProperty(ExchangeConf.IS_NEED_CERTIFICATION, "false");
                prop.store(fos, "SMTP Config 設定");
                fos.flush();
                fos.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        reloadPropertiesFile();

        return getProperties(smtpConfigKey);
    }

    public static String getProperties(final String key) {
        return (String) propertiesConfiguration.getProperty(key);
    }

    public static void reloadPropertiesFile(){
        try {
            propertiesConfiguration = new PropertiesConfiguration(SMTP_PROPERTIES);
        } catch (ConfigurationException e) {
            e.printStackTrace();
        }
        propertiesConfiguration.setReloadingStrategy(new FileChangedReloadingStrategy());
    }
}
