package gov.archives.exchange.command;

import gov.archives.core.exception.CoreException;
import gov.archives.exchange.domain.vo.ReportInputModel;

/**
 * Created by kshsu on 2016/7/26.
 */
public class PdfToFileCommand extends ReportBaseCommand implements ReportCommand {

    private PdfToFileCommand() {}

    public PdfToFileCommand(ReportInputModel reportInputModel) {
        this.sourceFilePath = reportInputModel.getSourceFileName();
        this.destFilePath = reportInputModel.getDestFileName();
        this.javaBean = reportInputModel.getJavaBean();
        this.reportParameter = reportInputModel.getReportParameter();
        this.reportType = reportInputModel.getReportType();
        this.baseReportInputModel = reportInputModel;
    }

    @Override
    public void execute(ReportCommandProcessor reportCommandProcessor) throws CoreException {
        reportCommandProcessor.genReportToFile(baseReportInputModel);
    }
}
