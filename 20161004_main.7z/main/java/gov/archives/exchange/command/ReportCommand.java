package gov.archives.exchange.command;

import gov.archives.core.exception.CoreException;

/**
 * Created by kshsu on 2016/7/26.
 */
public interface ReportCommand {
    void execute(ReportCommandProcessor reportCommandProcessor) throws CoreException;
}
