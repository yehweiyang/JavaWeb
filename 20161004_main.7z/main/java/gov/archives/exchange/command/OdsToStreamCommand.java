package gov.archives.exchange.command;

import gov.archives.core.exception.CoreException;
import gov.archives.exchange.domain.vo.ReportInputModel;

/**
 * Created by kshsu on 2016/7/26.
 */
public class OdsToStreamCommand extends ReportBaseCommand implements ReportCommand {

    private OdsToStreamCommand() {}

    public OdsToStreamCommand(ReportInputModel reportInputModel) {
        this.sourceFilePath = reportInputModel.getSourceFileName();
        this.javaBean = reportInputModel.getJavaBean();
        this.reportParameter = reportInputModel.getReportParameter();
        this.reportType = reportInputModel.getReportType();
        this.baseReportInputModel = reportInputModel;
    }

    @Override
    public void execute(ReportCommandProcessor reportCommandProcessor) throws CoreException {
        reportCommandProcessor.genReportToStream(baseReportInputModel);
    }
}
