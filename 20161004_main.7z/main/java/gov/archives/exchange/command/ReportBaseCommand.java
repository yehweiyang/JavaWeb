package gov.archives.exchange.command;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Lists;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRTableModelDataSource;
import net.sf.jasperreports.engine.util.JRLoader;


import org.iii.common.util.PreconditionUtils;

import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.domain.vo.ReportData;
import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by kshsu on 2016/7/26.
 */
public class ReportBaseCommand {
    protected String sourceFilePath = null;
    protected Object javaBean = null;
    protected Map<String, Object> reportParameter = null;
    protected String reportType = null;
    protected String destFilePath = null;
    protected ReportInputModel baseReportInputModel;

    public JasperPrint reportConvertTo(InputStream is, Map<String, Object> reportParameter) throws CoreException {

        PreconditionUtils.checkArguments(is, reportParameter);

        try {
            return JasperFillManager.fillReport(is, reportParameter);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public JasperPrint reportConvertTo(InputStream is, Map<String, Object> reportParameter, Connection connection)
            throws CoreException {

        PreconditionUtils.checkArguments(is, reportParameter, connection);

        try {
            return JasperFillManager.fillReport(is, reportParameter, connection);
        } catch (JRException e) {
            e.printStackTrace();
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public JasperPrint reportConvertTo(InputStream is, Map<String, Object> reportParameter, JRDataSource dataSource)
            throws CoreException {

        PreconditionUtils.checkArguments(is, reportParameter, dataSource);

        try {
            return JasperFillManager.fillReport(is, reportParameter, dataSource);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public JasperPrint reportConvertTo(JasperReport jasperReport, Map<String, Object> reportParameter)
            throws CoreException {

        PreconditionUtils.checkArguments(jasperReport, reportParameter);

        try {
            return JasperFillManager.fillReport(jasperReport, reportParameter);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }

    }

    public JasperPrint reportConvertTo(JasperReport jasperReport, Map<String, Object> reportParameter,
            Connection connection)
            throws CoreException {

        PreconditionUtils.checkArguments(jasperReport, reportParameter, connection);

        try {
            return JasperFillManager.fillReport(jasperReport, reportParameter, connection);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }

    }

    public JasperPrint reportConvertTo(JasperReport jasperReport, Map<String, Object> reportParameter,
            JRDataSource dataSource)
            throws CoreException {

        PreconditionUtils.checkArguments(jasperReport, reportParameter, dataSource);

        try {
            return JasperFillManager.fillReport(jasperReport, reportParameter, dataSource);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }

    }

    public JasperPrint reportConvertTo(String sourceFilePath, Map<String, Object> reportParameter)
            throws CoreException {

        PreconditionUtils.checkArguments(sourceFilePath, reportParameter);

        try {
            return JasperFillManager.fillReport(sourceFilePath, reportParameter);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public JasperPrint reportConvertTo(String sourceFilePath, Map<String, Object> reportParameter,
            Connection connection)
            throws CoreException {

        PreconditionUtils.checkArguments(sourceFilePath, reportParameter, connection);

        try {
            return JasperFillManager.fillReport(sourceFilePath, reportParameter, connection);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public JasperPrint reportConvertTo(String sourceFilePath, Map<String, Object> reportParameter,
            JRDataSource dataSource)
            throws CoreException {

        PreconditionUtils.checkArguments(sourceFilePath, reportParameter);

        try {
            return JasperFillManager.fillReport(sourceFilePath, reportParameter, dataSource);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public void reportConvertToStream(InputStream is, OutputStream os, Map<String, Object> reportParameter)
            throws CoreException {

        PreconditionUtils.checkArguments(is, os, reportParameter);

        try {
            JasperFillManager.fillReportToStream(is, os, reportParameter);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public void reportConvertToStream(JasperReport jasperReport, OutputStream os, Map<String, Object> reportParameter,
            JRDataSource dataSource) throws CoreException {

        PreconditionUtils.checkArguments(jasperReport, os, reportParameter, dataSource);

        try {
            JasperFillManager.fillReportToStream(jasperReport, os, reportParameter, dataSource);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public void reportConvertToFile(JasperReport jasperReport, String destFileName, Map<String, Object> reportParameter)
            throws CoreException {

        PreconditionUtils.checkArguments(jasperReport, destFileName, reportParameter);

        try {
            JasperFillManager.fillReportToFile(jasperReport, destFileName, reportParameter);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public String reportConvertToFile(String sourceFilePath, Map<String, Object> reportParameter)
            throws CoreException {

        PreconditionUtils.checkArguments(sourceFilePath, reportParameter);

        try {
            return JasperFillManager.fillReportToFile(sourceFilePath, reportParameter);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public void reportConvertToFile(String sourceFilePath, String destFileName, Map<String, Object> reportParameter)
            throws CoreException {

        PreconditionUtils.checkArguments(sourceFilePath, destFileName, reportParameter);

        try {
            JasperFillManager.fillReportToFile(sourceFilePath, destFileName, reportParameter);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public void reportConvertToFile(JasperReport jasperReport, String destFileName, Map<String, Object> reportParameter,
            JRDataSource dataSource) throws CoreException {

        PreconditionUtils.checkArguments(jasperReport, destFileName, reportParameter);

        try {
            JasperFillManager.fillReportToFile(jasperReport, destFileName, reportParameter, dataSource);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public String reportConvertToFile(String sourceFilePath, Map reportParameter, JRDataSource dataSource)
            throws CoreException {

        PreconditionUtils.checkArguments(sourceFilePath, reportParameter, dataSource);

        try {
            return JasperFillManager.fillReportToFile(sourceFilePath, reportParameter, dataSource);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public void reportConvertToFile(String sourceFilePath, String destFileName, Map reportParameter,
            JRDataSource dataSource) throws CoreException {

        PreconditionUtils.checkArguments(sourceFilePath, destFileName, reportParameter);

        try {
            JasperFillManager.fillReportToFile(sourceFilePath, destFileName, reportParameter);
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    public ReportData getReportDataVO(Object javaBean) throws CoreException {

        ReportData reportData = null;
        if (null != javaBean) {
            reportData = convertJsonNodeToReportFormat(ReportUtils.convertBeanToJsonNode(javaBean));
        }
        return reportData;
    }

    private ReportData convertJsonNodeToReportFormat(JsonNode jsNodeBean) {
        boolean isArray = jsNodeBean.isArray();
        ReportData reportData = new ReportData();
        /* 拆解 JsonNode 並填入欄位資訊 */
        reportData.setHeaderString(getHeaderStringFromJsonNode(jsNodeBean));
        reportData.setReportContent(getDataBodyFromJsonNode(jsNodeBean));
        return reportData;
    }

    private Object[] getHeaderStringFromJsonNode(JsonNode jsNodeBean) {
        return Lists.newArrayList(
                (jsNodeBean.isArray() ? jsNodeBean.get(0) : jsNodeBean)
                        .fieldNames()).toArray();
    }

    private Object[][] getDataBodyFromJsonNode(JsonNode jsNodeBean) {
        Object[][] reportDataBody = new Object[jsNodeBean.size()][];
        List<String> rowColumnData = new ArrayList<>();
        for (int i = 0; i < jsNodeBean.size(); i++) {
            rowColumnData.clear();
            (jsNodeBean.isArray() ? jsNodeBean.get(i) : jsNodeBean).fields()
                                                                   .forEachRemaining(nodeIter -> {
                                                                       rowColumnData.add(nodeIter.getValue().asText());
                                                                   });
            reportDataBody[i] = rowColumnData.toArray();
            if (!jsNodeBean.isArray()) { break; }
        }
        return reportDataBody;
    }

    protected JasperReport getJasperReportFromFileName(String sourceFileName) throws CoreException {
        try {
            return (JasperReport) JRLoader.loadObject(new File(sourceFileName));
        } catch (JRException e) {
            throw new CoreException(e, CoreErrorCode.REPORT_EXCEPTION_IN_BASECOMMAND);
        }
    }

    protected JRTableModelDataSource getJRTableDateSourceFromJavaBean(Object javaBean) throws CoreException {
        return new JRTableModelDataSource(getReportDataVO(javaBean).getDefaultTableModel());
    }
}