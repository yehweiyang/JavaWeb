package gov.archives.exchange.mapper.command;

import java.util.UUID;

import gov.archives.exchange.domain.entity.DocNoticeMailEntity;

/**
 * Created by jslee on 2016/9/14.
 */
public interface DocNoticeMailCommandMapper {

    void create(DocNoticeMailEntity docNoticeMailEntity);

    void update(DocNoticeMailEntity docNoticeMailEntity);

    void delete(UUID sysId);
}
