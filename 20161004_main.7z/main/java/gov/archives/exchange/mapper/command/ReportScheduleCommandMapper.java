package gov.archives.exchange.mapper.command;

import java.util.Map;

/**
 * Created by jslee on 2016/9/8.
 */
public interface ReportScheduleCommandMapper {
    void saveOneDayConfirmedRate(String triggerDate);

    void updateTwoDaysConfirmedRate(Map workingDateMap);
}
