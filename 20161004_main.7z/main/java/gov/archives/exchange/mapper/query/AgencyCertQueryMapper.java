package gov.archives.exchange.mapper.query;

import java.util.List;

import gov.archives.exchange.domain.entity.AccessorEntity;

/**
 * Created by wtjiang on 2016/8/26.
 */
public interface AgencyCertQueryMapper {
    List<AccessorEntity> findCertHashByOrgId(String orgId);
}
