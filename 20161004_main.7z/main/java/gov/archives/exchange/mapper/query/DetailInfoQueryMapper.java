package gov.archives.exchange.mapper.query;

import java.util.List;
import java.util.Map;

import gov.archives.exchange.domain.entity.TransmitDetailEntity;

public interface DetailInfoQueryMapper {
    List<TransmitDetailEntity> findByMap(Map<String, Object> params);

}
