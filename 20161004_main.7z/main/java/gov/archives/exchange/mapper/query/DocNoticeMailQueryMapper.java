package gov.archives.exchange.mapper.query;

import java.util.List;
import java.util.Map;

import gov.archives.exchange.domain.entity.DocNoticeMailEntity;

/**
 * Created by jslee on 2016/9/14.
 */
public interface DocNoticeMailQueryMapper {

    Integer findDocNoticeMailExist(Map<String, Object> map);

    List<DocNoticeMailEntity> findDocNoticeMailByFilterMap(Map<String, Object> map);

}
