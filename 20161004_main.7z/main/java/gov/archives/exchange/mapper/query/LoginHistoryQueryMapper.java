package gov.archives.exchange.mapper.query;

import java.util.List;

import gov.archives.exchange.domain.entity.LoginHistoryEntity;
import gov.archives.exchange.domain.vo.LoginHistory;

/**
 * LoginHistoryQueryMapper
 * <p>
 * Created by WeiYang on 2016/9/14.
 */
public interface LoginHistoryQueryMapper {
    List<LoginHistoryEntity> findAllQuery(LoginHistory loginHistory);
}
