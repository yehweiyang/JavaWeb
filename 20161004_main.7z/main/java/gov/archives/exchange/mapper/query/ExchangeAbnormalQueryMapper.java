package gov.archives.exchange.mapper.query;

import java.util.List;

import gov.archives.exchange.domain.entity.ExchangeAbnormalQueryEntity;
import gov.archives.exchange.domain.vo.ExchangeAbnormalQueryVo;

/**
 * ExchangeAbnormalQueryMapper
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
public interface ExchangeAbnormalQueryMapper {

    List<ExchangeAbnormalQueryEntity> findAllQuery(ExchangeAbnormalQueryVo changeErrorQueryVo);

    ExchangeAbnormalQueryEntity findIDQuery(String ID);

}
