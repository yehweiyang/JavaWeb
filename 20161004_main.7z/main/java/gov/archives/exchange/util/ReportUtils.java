package gov.archives.exchange.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;

import gov.archives.core.domain.entity.ActionLogEntity;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.util.LogUtils;
import gov.archives.exchange.domain.entity.ReportResult;


/**
 * Created by jslee on 2016/7/7. PRN001 ~ PRN012 瑣碎方法工具箱
 */
public abstract class ReportUtils {

    private static final Logger log = LoggerFactory.getLogger(ReportUtils.class);

    private ReportUtils() { }

    public static JsonNode convertBeanToJsonNode(Object resultBean) throws CoreException {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectWriter objectWriter =
                    objectMapper.writer()
                                .withDefaultPrettyPrinter();
            return objectMapper.readTree(objectWriter.writeValueAsString(resultBean));
        } catch (IOException ex) {
            throw new CoreException(ex, CoreErrorCode.REPORT_EXCEPTION_IN_UTILS);
        }
    }

    public static Object convertJsonNodeStringToBean(String jsonNode, Class<?> clazz)
            throws CoreException {
        try {
            return new ObjectMapper().readValue(jsonNode, clazz);
        } catch (IOException ex) {
            throw new CoreException(ex, CoreErrorCode.REPORT_EXCEPTION_IN_UTILS);
        }
    }

    public static List convertJsonNodeStringToBeanList(String jsonNode, Class<?> clazz)
            throws CoreException {
        try {
            return Arrays
                    .asList(new ObjectMapper()
                            .readValue(jsonNode,
                                    ((Object[]) Array.newInstance(clazz, 0)).getClass()));
        } catch (IOException ex) {
            throw new CoreException(ex, CoreErrorCode.REPORT_EXCEPTION_IN_UTILS);
        }
    }

    public static void saveAsJsonFile(String fileName, String strJson) throws CoreException {
        FileWriter fw = null;
        try {
            fw = new FileWriter(fileName);
            fw.write(strJson.toString());
            fw.flush();
        } catch (IOException ex) {
            throw new CoreException(ex, CoreErrorCode.REPORT_EXCEPTION_IN_UTILS);
        } finally {
            if (null != fw) {
                try {
                    fw.close();
                } catch (IOException e) {
                    LogUtils.logException(e);
                }
            }
        }
    }

    public static String readJsonFileAsString(String fileName) throws CoreException {
        FileReader fr = null;
        BufferedReader br = null;
        try {
            fr = new FileReader(fileName);
            br = new BufferedReader(fr);
            return org.apache.commons.io.IOUtils.toString(br);
        } catch (IOException ex) {
            throw new CoreException(ex, CoreErrorCode.REPORT_EXCEPTION_IN_UTILS);
        } finally {
            try {
                if (null != br) {
                    br.close();
                    if (null != fr) {
                        fr.close();
                    }
                }
            } catch (IOException e) {
                LogUtils.logException(e);
            }
        }
    }

    public static String getTodayString() {
        return LocalDate.now().toString();
    }

    /**
     * 取得 Result Column 對應的中文名稱
     */
    public static String getColumnTWName(Class<? extends ReportResult> resultClass, String columnName)
            throws CoreException {
        String returnValue = "";
        try {

            PreconditionUtils.checkArguments(resultClass, columnName);

            Class<?>[] resultClassColmunEnums = resultClass.getDeclaredClasses();
            for (Class<?> resultClassColmunEnum : resultClassColmunEnums) {
                Object[] consts = resultClassColmunEnum.getEnumConstants();

                for (Object object : consts) {
                    Class<?> subEnum = object.getClass();
                    Method method;
                    method = subEnum.getDeclaredMethod("toString");
                    String val;
                    val = (String) method.invoke(object);
                    if ("title".equals(val)) {
                        method = subEnum.getDeclaredMethod("getTWName");
                        returnValue = (String) method.invoke(object);
                    }
                }
            }
        } catch (Exception ex) {
            throw new CoreException(ex, CoreErrorCode.REPORT_EXCEPTION_IN_UTILS);
        }
        return returnValue;
    }

    public static void initReportFolder(String folderPath) throws CoreException {
        if (!IOUtils.isFolderExist(folderPath)) {
            boolean isSuccess = new File(folderPath).mkdirs();
            if (isSuccess) {
                log.info(folderPath + " 建立成功");
            } else {
                throw new CoreException(CoreErrorCode.REPORT_EXCEPTION_IN_INIT_FOLDER);
            }
        }
    }

    /**
     * 寫入 ActionLog Table
     * module ref ReportConf.MODULE_REPORT
     * eventLevel ref CoreConf.EVENT_LEVEL_HIGH / EVENT_LEVEL_MEDIUM / EVENT_LEVEL_LOW
     */
    public static void writeActionLog(HttpServletRequest httpServletRequest, ActionLogService actionLogService,
            String module, String resultCode, String message, String eventLevel) {
        String currentUser = httpServletRequest.getRemoteUser();
        if (null == currentUser) { throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.LOGIN_EXPIRED); }
        long accessedTime = httpServletRequest.getSession().getLastAccessedTime();
        ActionLogEntity actionLogEntity = ActionLogEntity.Builder.create()
                                                                 .setActionItem(module)
                                                                 .setActionResult(message)
                                                                 .setErrorCode(resultCode)
                                                                 .setEventLevel(eventLevel)
                                                                 .setActorAccount(currentUser)
                                                                 .setActionTime(new Timestamp(accessedTime))
                                                                 .setRemoteIp(httpServletRequest.getRemoteAddr())
                                                                 .build();
        actionLogEntity.initSave(currentUser);
        actionLogService.insert(actionLogEntity);
    }

}
