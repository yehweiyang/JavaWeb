package gov.archives.exchange.facade;

import gov.archives.exchange.domain.vo.ReportInputModel;

/**
 * Created by kshsu on 2016/7/26.
 */
public interface ReportOutputFacade {

    public void genReportToFile(ReportInputModel reportInputModel);

    public void genReportToStream(ReportInputModel reportInputModel);

    public void genReportToByteArray(ReportInputModel reportInputModel);
}
