package gov.archives.exchange.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.entity.ReportRecvListResult;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportRecvListFilter;
import gov.archives.core.exception.ArchivesException;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/8/17.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + ReportConf.REPORT_TOOL_PATH + "/rptRecvList")
public class ReportRecvListController extends ReportBaseController {

    private static final String currentReportName = ReportEnum.REPORT_RECEIVE_LIST.toString();

    @RequestMapping(value = ReportConf.LIST_PATH,
            method = RequestMethod.GET)
    public List<ReportRecvListResult> queryReportRecvList(
            @RequestParam
                    Map<String, Object> requestParams) {

        ReportRecvListFilter recvListFilter = convertMapToReportFilter(requestParams);
        List<ReportRecvListResult> recvListResults = reportDataGenService.getReportRecvListByRecvListFilter(recvListFilter);

        try {
            reportDataGenService
                    .saveSearchResult(
                            getTmpFileFullPath(currentReportName),
                            recvListFilter,
                            recvListResults);
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR, e);
        }
        return recvListResults;
    }

    @Override
    protected ReportRecvListFilter convertMapToReportFilter(Map<String, Object> params) {
        ReportRecvListFilter recvListFilter =
                (ReportRecvListFilter) super.convertMapToReportFilter(params, new ReportRecvListFilter());
        if (MapUtils.isNotEmpty(params)) {
            recvListFilter.setTimeFrom(MapUtils.getString(params, "timeFrom"));
            recvListFilter.setTimeTo(MapUtils.getString(params, "timeTo"));
            recvListFilter.setReceiverId(MapUtils.getString(params, "receiverId"));
            recvListFilter.setReceiverName(MapUtils.getString(params, "receiverName"));
            recvListFilter.setContentFullCmp(MapUtils.getBoolean(params, "contentFullCmp"));
        }

        return recvListFilter;
    }

}
