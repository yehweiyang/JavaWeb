package gov.archives.exchange.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.domain.vo.LoginHistory;
import gov.archives.exchange.service.LoginHistoryService;

/**
 * LoginHistoryController
 * <p>
 * Created by WeiYang on 2016/9/14.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + "/exchange")
public class LoginHistoryController {

    @Autowired
    private LoginHistoryService loginHistoryService;

    @RequestMapping(value = "querLoginHistory",
            method = RequestMethod.GET)
    public List<LoginHistory> querLoginHistory(@RequestParam Map<String, String> requestParams) {
        try {
            LoginHistory loginHistory = new LoginHistory();
            if (MapUtils.isNotEmpty(requestParams)) {
                loginHistory.setAccount(MapUtils.getString(requestParams, "account", "").trim());
                loginHistory.setDateFrom(MapUtils.getString(requestParams, "dateFrom", "").trim());
                loginHistory.setDateTo(MapUtils.getString(requestParams, "dateTo", "").trim());
                loginHistory.setTimeFrom(MapUtils.getString(requestParams, "timeFrom", "").trim());
                loginHistory.setTimeTo(MapUtils.getString(requestParams, "timeTo", "").trim());
            }

            return loginHistoryService.getQueryList(loginHistory);
        } catch (ArchivesException ex) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.DATA_NOT_FOUND, ex);
        }

    }
}
