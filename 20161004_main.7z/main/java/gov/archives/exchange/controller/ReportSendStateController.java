package gov.archives.exchange.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.entity.ReportSendStateResult;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/8/17.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + ReportConf.REPORT_TOOL_PATH + "/rptSendSt")
public class ReportSendStateController extends ReportBaseController {

    private static final String currentReportName = ReportEnum.REPORT_SEND_STATE.toString();

    @RequestMapping(value = ReportConf.LIST_PATH,
            method = RequestMethod.GET)
    public List<ReportSendStateResult> queryReportSendStatus(
            @RequestParam
                    Map<String, Object> requestParams) {

        ReportBaseFilter filter = super.convertMapToReportFilter(requestParams);

        List<ReportSendStateResult> sendStateResults = reportDataGenService.getReportSendStateByFilter(filter);

        try {
            reportDataGenService
                    .saveSearchResult(
                            getTmpFileFullPath(currentReportName),
                            filter,
                            sendStateResults);
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR, e);
        }
        return sendStateResults;
    }
}
