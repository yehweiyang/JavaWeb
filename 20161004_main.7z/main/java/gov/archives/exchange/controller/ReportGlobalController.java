package gov.archives.exchange.controller;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.IOUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.entity.ReportResult;
import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/7/5.
 */

@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + ReportConf.REPORT_TOOL_PATH)
public class ReportGlobalController extends ReportBaseController {

    @RequestMapping(value = ReportConf.REPORT_NAME_PARAMETER_PATH + ReportConf.INIT_PATH,
            method = RequestMethod.GET)
    public Map<String, Object> initReportPage(@PathVariable String reportName) {

        Map<String, Object> initMap = new HashMap<>();
        try {
            reportName = reportName.toLowerCase();

            tmpUserFilePath = getTmpFileFullPath(reportName);

            Map<String, Object> clazzMap =
                    reportDataPrepareService.getReportFilterAndResultClass(reportName);

            initMap = IOUtils.isFileExist(tmpUserFilePath) ?
                    (reportDataGenService
                            .restoreSearchResult(
                                    tmpUserFilePath,
                                    (Class<?>) clazzMap.get("filterClass"),
                                    (Class<?>) clazzMap.get("resultClass"))
                    ) :
                    reportDataPrepareService.prepareReportData(reportName);


            Method setMonthList =
                    initMap.get("filterContent").getClass().getMethod("setReportListFromMonth", List.class);
            setMonthList
                    .invoke(initMap.get("filterContent"), reportDataPrepareService.prepareReportMonthList(reportName));
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_INIT_ERROR, e);
        }
        return initMap;
    }

    @RequestMapping(value = ReportConf.REPORT_NAME_PARAMETER_PATH + ReportConf.MONTH_PATH + "/{selectedMonth}")
    public Map<String, Object> queryMonthReport(@PathVariable String reportName, @PathVariable String selectedMonth) {

        reportName = reportName.toLowerCase();
        Map<String, Object> restoreMap = new HashMap<>();
        try {
            Map<String, Object> clazzMap = reportDataPrepareService.getReportFilterAndResultClass(reportName);

            restoreMap = reportDataGenService
                    .restoreSearchResult(
                            reportDataPrepareService.getReportMonthFilePath(reportName, selectedMonth),
                            (Class<?>) clazzMap.get("filterClass"),
                            (Class<?>) clazzMap.get("resultClass"));

            reportDataGenService
                    .saveSearchResult(
                            getTmpFileFullPath(reportName),
                            restoreMap.get("filterContent"),
                            restoreMap.get("resultContent"));
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR, e);
        }
        return restoreMap;
    }

    /**
     * 讀取暫存檔並轉換為報表
     */
    @RequestMapping(value = ReportConf.REPORT_NAME_PARAMETER_PATH + ReportConf.DOWNLOAD_PATH + "/{exportType}",
            method = RequestMethod.GET)
    public void downloadReportFile(HttpServletRequest request, HttpServletResponse response,
            @PathVariable String reportName,
            @PathVariable String exportType) {
        Map<String, Object> frontEndLastDataMap = null;
        try {
            String currentAccount =
                    getCurrentAccountNameBySession((String) request.getSession().getAttribute("authorization"));

            reportName = reportName.toLowerCase();

            Map<String, Object> clazzMap =
                    reportDataPrepareService.getReportFilterAndResultClass(reportName);

            frontEndLastDataMap = reportDataGenService
                    .restoreSearchResult(
                            getTmpFileFullPath(reportName, currentAccount),
                            Map.class,
                            (Class<?>) clazzMap.get("resultClass"));

            ((Map) frontEndLastDataMap.get("filterContent")).put("title",
                    ReportUtils.getColumnTWName(
                            (Class<? extends ReportResult>) clazzMap.get("resultClass"), "title"));

            ((Map) frontEndLastDataMap.get("filterContent")).put("createDate",
                    new SimpleDateFormat(CoreConf.DATE_FORMAT).format(new Date()));

            Path reportJasperFilePath = Paths.get(
                    IOUtils.loadResourceURLInClasspath(
                            ReportConf.REPORT_TEMPLATE_FOLDER + "/" + reportName +
                                    CoreConf.SUFFIX_JASPER).toURI());

            ReportInputModel reportInputModel =
                    new ReportInputModel(reportJasperFilePath.toString(),
                            frontEndLastDataMap.get("resultContent"),
                            (Map) frontEndLastDataMap.get("filterContent"),
                            exportType);

            reportOutputFacade.genReportToByteArray(reportInputModel);
            response.setContentType("application/" + exportType);
            if (ReportConf.ODS.equals(exportType.toUpperCase(Locale.ENGLISH))) {
                response.setHeader("Content-Disposition",
                        "attachment; filename=" + currentAccount + CoreConf.SUFFIX_ODS);
            }

            org.apache.commons.io.IOUtils
                    .copy(new ByteArrayInputStream(reportInputModel.getOutput()), response.getOutputStream());
            response.flushBuffer();
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_DOWNLOAD_ERROR, e);
        }
    }

    private String getCurrentAccountNameBySession(String encodeStr) {
        String rtnStr;
        try {
            rtnStr = new String(Base64.getDecoder().decode(encodeStr.replace("Basic ", "")), "UTF-8").split(":")[0];
        } catch (UnsupportedEncodingException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR, e);
        }
        return rtnStr;
    }

}
