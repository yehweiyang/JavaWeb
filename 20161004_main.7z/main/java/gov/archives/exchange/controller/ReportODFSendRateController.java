package gov.archives.exchange.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.entity.ReportODFSendRateResult;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportODFSendRateFilter;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by kshsu on 2016/8/30.
 * ODF統計
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + ReportConf.REPORT_TOOL_PATH + "/rptOdfSendRate")
public class ReportODFSendRateController extends ReportBaseController {

    private static final String currentReportName = ReportEnum.REPORT_ODF_SEND_RATE.toString();

    @RequestMapping(value = ReportConf.LIST_PATH,
            method = RequestMethod.GET)
    public List<ReportODFSendRateResult> queryODFSendRate(
            @RequestParam
                    Map<String, Object> requestParams) {

        ReportODFSendRateFilter odfSendRateFilter = convartMapToReportFilter(requestParams);
        List<ReportODFSendRateResult> odfSendRateResults =
                reportDataGenService.getReportODFSendRateByODFSendRateFilter(odfSendRateFilter);
        try {
            reportDataGenService
                    .saveSearchResult(
                            getTmpFileFullPath(currentReportName),
                            odfSendRateFilter,
                            odfSendRateResults);
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR, e);
        }
        return odfSendRateResults;
    }

    protected ReportODFSendRateFilter convartMapToReportFilter(Map<String, Object> params) {
        ReportODFSendRateFilter odfSendRateFilter =
                (ReportODFSendRateFilter) super.convertMapToReportFilter(params, new ReportODFSendRateFilter());
        if (MapUtils.isNotEmpty(params)) {
            odfSendRateFilter.setSenderId(MapUtils.getString(params, "senderId"));
            odfSendRateFilter.setSenderName(MapUtils.getString(params, "senderName"));
            odfSendRateFilter.setContentFullCmp(MapUtils.getBoolean(params, "contentFullCmp"));
        }

        return odfSendRateFilter;
    }

}
