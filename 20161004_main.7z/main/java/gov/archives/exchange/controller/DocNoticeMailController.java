package gov.archives.exchange.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.UserInfoService;
import gov.archives.exchange.domain.vo.DocNoticeMailVO;
import gov.archives.exchange.service.DocNoticeMailService;

/**
 * Created by jslee on 2016/9/14.
 */
@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.SYSTEM_TOOL_URL + "/docNoticeMail")
public class DocNoticeMailController {
    private static final Logger log = LoggerFactory.getLogger(DocNoticeMailController.class);
    private static final String CREATE_ACTION_PATH = "/create";
    private static final String READ_ACTION_PATH = "/read";
    private static final String UPDATE_ACTION_PATH = "/update";
    private static final String DELETE_ACTION_PATH = "/delete";
    private static final String SYSTEM_ID_PATH = "/{sysId}";


    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private DocNoticeMailService docNoticeMailService;

    @RequestMapping(value = READ_ACTION_PATH,
            method = RequestMethod.GET)
    public List<DocNoticeMailVO> readDocNoticeMails(@RequestParam Map<String, Object> requestParams) {

        try {
            if (MapUtils.isNotEmpty(requestParams)) {
                requestParams.put("contentFullCmp", MapUtils.getBoolean(requestParams, "isFullCmp"));
                requestParams.put("orgId", MapUtils.getString(requestParams, "docNoticeOrgId"));
                requestParams.put("unitId", MapUtils.getString(requestParams, "docNoticeUnitId"));
                requestParams.put("orgUnitName", MapUtils.getString(requestParams, "docNoticeOrgUnitName"));
                requestParams.put("noticeEmail", MapUtils.getString(requestParams, "docNoticeEmails"));
            }
        } catch (Exception e) {
            exceptionCatcher(e, CoreErrorCode.DOC_NOTICE_MAIL_READ_ERROR);
        }

        return docNoticeMailService.getDocNoticeMailByFilterMap(requestParams);
    }

    @RequestMapping(value = CREATE_ACTION_PATH,
            method = RequestMethod.POST)
    public Map<String, String> createDocNoticeMail(@RequestParam Map<String, Object> requestParams) {

        Map<String, String> msgMap = new HashMap<>();
        String errorMsg = "";

        try {
            if (MapUtils.isNotEmpty(requestParams)) {
                String emails = MapUtils.getString(requestParams, "docNoticeEmails");
                errorMsg += isUniqueKeyExist(requestParams) ? "請檢查機關代碼、單位代碼是否存在;" : "";
                errorMsg += !isEmailValid(emails) ? "請檢查郵件地址格式是否正確" : "";
                if ("".equals(errorMsg)) {
                    DocNoticeMailVO docNoticeMailVO = new DocNoticeMailVO();
                    docNoticeMailVO.setDocNoticeCreator(userInfoService.getCurrentAccount());
                    docNoticeMailVO.setDocNoticeOrgId(MapUtils.getString(requestParams, "docNoticeOrgId"));
                    docNoticeMailVO.setDocNoticeUnitId(MapUtils.getString(requestParams, "docNoticeUnitId"));
                    docNoticeMailVO.setDocNoticeOrgUnitName(MapUtils.getString(requestParams, "docNoticeOrgUnitName"));
                    docNoticeMailVO.setDocNoticeEmails(emails);
                    docNoticeMailService.addDocNoticeMail(docNoticeMailVO);
                }
                msgMap.put("message", errorMsg);
            }
        } catch (Exception e) {
            exceptionCatcher(e, CoreErrorCode.DOC_NOTICE_MAIL_CREATE_ERROR);
        }

        return msgMap;
    }

    @RequestMapping(value = UPDATE_ACTION_PATH + SYSTEM_ID_PATH,
            method = RequestMethod.PUT)
    public Map<String, String> updateDocNoticeMailBySysId(@PathVariable String sysId,
            @RequestParam Map<String, Object> requestParams) {

        Map<String, String> msgMap = new HashMap<>();

        try {
            if (("".equals(sysId))) { throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR); }

            if (MapUtils.isNotEmpty(requestParams)) {
                String emails = MapUtils.getString(requestParams, "docNoticeEmails");
                if (isEmailValid(emails)) {
                    DocNoticeMailVO docNoticeMailVO = new DocNoticeMailVO();
                    docNoticeMailVO.setDocNoticeId(UUID.fromString(sysId));
                    docNoticeMailVO.setDocNoticeModifier(userInfoService.getCurrentAccount());
                    docNoticeMailVO.setDocNoticeStatus(MapUtils.getBoolean(requestParams, "docNoticeStatus"));
                    docNoticeMailVO.setDocNoticeEmails(emails);
                    docNoticeMailService.updateDocNoticeMail(docNoticeMailVO);
                    msgMap.put("message", "");
                } else {
                    msgMap.put("message", "收文通知修改失敗, 請檢查郵件地址格式是否正確");
                }
            }
        } catch (Exception e) {
            exceptionCatcher(e, CoreErrorCode.DOC_NOTICE_MAIL_CREATE_ERROR);
        }

        return msgMap;
    }

    @RequestMapping(value = DELETE_ACTION_PATH + SYSTEM_ID_PATH,
            method = RequestMethod.DELETE)
    public Map<String, String> deleteDocNoticeMailBySysId(@PathVariable String sysId) {

        Map<String, String> msgMap = new HashMap<>();

        try {
            if (!("".equals(sysId))) {
                docNoticeMailService.removeDocNoticeMail(UUID.fromString(sysId.trim()));
                msgMap.put("message", "");
            } else {
                msgMap.put("message", "收文通知刪除失敗");
            }
        } catch (Exception e) {
            exceptionCatcher(e, CoreErrorCode.DOC_NOTICE_MAIL_CREATE_ERROR);
        }

        return msgMap;
    }


    private void exceptionCatcher(Throwable throwable, String errorCode) {
        log.error(throwable.getClass().getName() +
                StringUtils.stackTraceFromException(throwable));
        throw ArchivesException.getInstanceByErrorCode(errorCode, throwable);
    }

    private Boolean isEmailValid(String emails) {
        return !("".equals(emails)) ?
                Arrays.stream(emails.split(";")).allMatch(email -> EmailValidator.getInstance().isValid(email))
                : false;
    }

    private Boolean isUniqueKeyExist(Map<String, Object> filterMap) {
        Boolean isExist = false;
        Map<String, Object> map = new HashMap<>();
        if (MapUtils.isNotEmpty(filterMap)){
            map.put("orgId", MapUtils.getString(filterMap, "docNoticeOrgId"));
            map.put("unitId", MapUtils.getString(filterMap, "docNoticeUnitId"));
            isExist = docNoticeMailService.isDocNoticeMailExist(map);
        }
        return isExist;
    }

}
