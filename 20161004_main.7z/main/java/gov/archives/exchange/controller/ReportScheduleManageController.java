package gov.archives.exchange.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.PreconditionUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportScheduleManageVO;
import gov.archives.exchange.service.ReportDataGenService;
import gov.archives.exchange.service.ReportDataPrepareService;
import gov.archives.exchange.service.ReportScheduleManageService;

/**
 * Created by jslee on 2016/9/22.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + CoreConf.SYSTEM_TOOL_URL + "/reportScheduleManage")
public class ReportScheduleManageController {

    private final static String RUN_SCHEDULE = "/runSchedule";

    @Autowired
    private ReportScheduleManageService reportScheduleManageService;

    @Autowired
    private ReportDataGenService reportDataGenService;

    @Autowired
    private ReportDataPrepareService reportDataPrepareService;

    @RequestMapping(value = ReportConf.INIT_PATH,
            method = RequestMethod.GET)
    public Map<String, Object> initReportManage() {

        Map<String, Object> map = new HashMap<>();

        try {

            LocalDate localDate = LocalDate.now().withDayOfMonth(1).minusDays(1);
            String monthReportRange = localDate.withDayOfMonth(1).toString() + " ~ " + localDate.toString();
            List<ReportScheduleManageVO> reportScheduleManageVOs =
                    reportScheduleManageService.getReportScheduleManageVos();

            map.put("dateRange", monthReportRange);
            map.put("scheduleList", reportScheduleManageVOs);

        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_INIT_ERROR, e);
        }

        return map;
    }

    @RequestMapping(value = RUN_SCHEDULE + ReportConf.REPORT_NAME_PARAMETER_PATH,
            method = RequestMethod.GET)
    public void runReportSchedule(@PathVariable String reportName) {
        PreconditionUtils.checkArguments(reportName);

        try {
            Arrays.stream(ReportEnum.class.getEnumConstants()).forEach(reportEnum -> {
                if (reportEnum.getTWName().equals(reportName) && reportEnum.isMonthSchedule()) {
                    reportScheduleManageService.runInstant(reportEnum.toString());
                }
            });
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_INIT_ERROR, e);
        }
    }

    //TODO: test case /manageWeb/v1/systemTool/reportScheduleManage/runTen
    @RequestMapping(value = "/runTen",
            method = RequestMethod.GET)
    public void genTenMonth() {
        reportDataPrepareService.initAllReportFolder();
        for (int i = 2; i < 12; i++) {
            LocalDate localDate = LocalDate.now().withMonthOfYear(i);
            ReportBaseFilter sendRankFilter = initBaseFilterByMonth(localDate);
            reportDataGenService
                    .saveSearchResult(
                            getReportMonthFilePath(ReportEnum.REPORT_SEND_RANK.toString(), localDate),
                            sendRankFilter,
                            reportDataGenService.getReportSendRankByFilter(sendRankFilter));
        }
    }


    private ReportBaseFilter initBaseFilterByMonth(LocalDate localDate) {
        ReportBaseFilter reportBaseFilter = new ReportBaseFilter();
        localDate = localDate.withDayOfMonth(1).minusDays(1);
        reportBaseFilter.setDateFrom(localDate.withDayOfMonth(1).toString());
        reportBaseFilter.setDateTo(localDate.toString());
        reportBaseFilter.setSortColumnName("rowIndex");
        reportBaseFilter.setSortDescending(false);

        return reportBaseFilter;
    }

    private String getReportMonthFilePath(String reportName, LocalDate localDate) {
        String fileName = localDate.minusMonths(1).toString("yyyy-MM") + "_(" + LocalDate.now() + ")";
        return reportDataPrepareService.getReportMonthFilePath(reportName, fileName);
    }

}
