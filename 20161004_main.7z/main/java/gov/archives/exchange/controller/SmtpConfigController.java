package gov.archives.exchange.controller;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.util.DateTimeUtils;
import gov.archives.exchange.accessor.ClientLogAccessor;
import gov.archives.exchange.conf.ExchangeConf;
import gov.archives.exchange.domain.entity.SmtpConfigEntity;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.iii.common.conf.CommonConfig;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static java.lang.Integer.parseInt;

/**
 * Created by wtjiang on 2016/9/14.
 */

@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.SYSTEM_TOOL_URL + "/")
public class SmtpConfigController {

    private SmtpConfigEntity smtpConfigEntity;

    @Autowired
    private ClientLogAccessor clientLogAccessor;

    @RequestMapping(value = "searchConfig", method = RequestMethod.GET)
    public SmtpConfigEntity searchSmtpConfig() {

        smtpConfigEntity = new SmtpConfigEntity();
        try{
            smtpConfigEntity.setSmtpServerIp(ExchangeConf.getSmtpConfig(ExchangeConf.SMTP_SERVER_IP));
            smtpConfigEntity.setSmtpServerPort(ExchangeConf.getSmtpConfig(ExchangeConf.SMTP_SERVER_PORT));
            smtpConfigEntity.setUseSsl(ExchangeConf.getSmtpConfig(ExchangeConf.IS_USE_SSL));
            smtpConfigEntity.setCertification(ExchangeConf.getSmtpConfig(ExchangeConf.IS_NEED_CERTIFICATION));
            smtpConfigEntity.setLoginAccount(ExchangeConf.getSmtpConfig(ExchangeConf.SMTP_LOGIN_ACCOUNT));
            smtpConfigEntity.setLoginPassword(ExchangeConf.getSmtpConfig(ExchangeConf.SMTP_LOGIN_PASSWORD));
            smtpConfigEntity.setLastUpdateTime(ExchangeConf.getSmtpConfig(ExchangeConf.SMTP_LAST_UPDATE));

            return smtpConfigEntity;
        } catch (ArchivesException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SEARCH_SMTP_ERROR);
        }
    }

    @RequestMapping(value = "updateConfig", method = RequestMethod.GET)
    public void updateSmtpConfig(@RequestParam Map<String, String> configForm) {

        smtpConfigEntity = new SmtpConfigEntity();
        try{
            String smtpPassWord = MapUtils.getString(configForm, "firstPassword");

            if (null == smtpPassWord) {
                smtpConfigEntity.setLoginPassword(ExchangeConf.getSmtpConfig(ExchangeConf.SMTP_LOGIN_PASSWORD));
            } else {
                smtpConfigEntity.setLoginPassword(MapUtils.getString(configForm, "firstPassword"));
            }

            smtpConfigEntity.setSmtpServerIp(MapUtils.getString(configForm, "smtpIP"));
            smtpConfigEntity.setSmtpServerPort(MapUtils.getString(configForm, "portNumber"));
            smtpConfigEntity.setUseSsl(MapUtils.getString(configForm, "sslValue"));
            smtpConfigEntity.setCertification(MapUtils.getString(configForm, "authenticateValue"));
            smtpConfigEntity.setLoginAccount(MapUtils.getString(configForm, "account"));
            smtpConfigEntity.setLastUpdateTime(new Date().toString());

            clientLogAccessor.updateSmtpConfigProperties(smtpConfigEntity);
        } catch (ArchivesException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.UPDATE_SMTP_ERROR);
        }

    }
}
