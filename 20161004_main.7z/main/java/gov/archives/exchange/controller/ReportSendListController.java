package gov.archives.exchange.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.entity.ReportSendListResult;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportSendListFilter;
import gov.archives.core.exception.ArchivesException;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/8/17.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + ReportConf.REPORT_TOOL_PATH + "/rptSendList")
public class ReportSendListController extends ReportBaseController {

    private static final String currentReportName = ReportEnum.REPORT_SEND_LIST.toString();

    @RequestMapping(value = ReportConf.LIST_PATH,
            method = RequestMethod.GET)
    public List<ReportSendListResult> queryReportSendList(
            @RequestParam
                    Map<String, Object> requestParams) {

        ReportSendListFilter sendListFilter = convertMapToReportFilter(requestParams);
        List<ReportSendListResult> sendListResults = reportDataGenService.getReportSendListBySendListFilter(sendListFilter);

        try {
            reportDataGenService
                    .saveSearchResult(
                            getTmpFileFullPath(currentReportName),
                            sendListFilter,
                            sendListResults);
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR, e);
        }
        return sendListResults;
    }

    protected ReportSendListFilter convertMapToReportFilter(Map<String, Object> params) {
        ReportSendListFilter sendListFilter =
                (ReportSendListFilter) super.convertMapToReportFilter(params, new ReportSendListFilter());

        if (MapUtils.isNotEmpty(params)) {
            sendListFilter.setTimeFrom(MapUtils.getString(params, "timeFrom"));
            sendListFilter.setTimeTo(MapUtils.getString(params, "timeTo"));
            sendListFilter.setSenderId(MapUtils.getString(params, "senderId"));
            sendListFilter.setSenderName(MapUtils.getString(params, "senderName"));
            sendListFilter.setReceiverId(MapUtils.getString(params, "receiverId"));
            sendListFilter.setReceiverName(MapUtils.getString(params, "receiverName"));
            sendListFilter.setContentFullCmp(MapUtils.getBoolean(params, "contentFullCmp"));
        }

        return sendListFilter;
    }

}
