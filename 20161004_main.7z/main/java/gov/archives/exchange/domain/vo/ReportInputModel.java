package gov.archives.exchange.domain.vo;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

/**
 * Created by kshsu on 2016/7/26.
 * Report 輸入參數的 Model
 */
public class ReportInputModel {
    private String sourceFileName;
    private String destFileName;
    private Object javaBean;
    private Map<String, Object> reportParameter;
    private byte[] output;
    private OutputStream os;
    private InputStream is;
    private String reportType;

    public ReportInputModel(String sourceFileName, String destFileName, Object javaBean,
            Map<String, Object> reportParameter, String reportType) {
        this.sourceFileName = sourceFileName;
        this.destFileName = destFileName;
        this.javaBean = javaBean;
        this.reportParameter = reportParameter;
        this.reportType = reportType;
    }


    public ReportInputModel(String sourceFileName, String destFileName, Object javaBean,
            Map<String, Object> reportParameter, OutputStream os, String reportType) {
        this.sourceFileName = sourceFileName;
        this.destFileName = destFileName;
        this.javaBean = javaBean;
        this.reportParameter = reportParameter;
        this.os = os;
        this.reportType = reportType;
    }

    public ReportInputModel(String sourceFileName, Object javaBean,
            Map<String, Object> reportParameter, OutputStream os, String reportType) {
        this.sourceFileName = sourceFileName;
        this.javaBean = javaBean;
        this.reportParameter = reportParameter;
        this.os = os;
        this.reportType = reportType;
    }

    public ReportInputModel(String sourceFileName, Object javaBean,
            Map<String, Object> reportParameter, String reportType) {
        this.sourceFileName = sourceFileName;
        this.javaBean = javaBean;
        this.reportParameter = reportParameter;
        this.reportType = reportType;
    }

    public ReportInputModel(String sourceFileName, String destFileName, Object javaBean,
            Map<String, Object> reportParameter, byte[] output, OutputStream os, InputStream is,
            String reportType) {
        this.sourceFileName = sourceFileName;
        this.destFileName = destFileName;
        this.javaBean = javaBean;
        this.reportParameter = reportParameter;
        this.output = output;
        this.os = os;
        this.is = is;
        this.reportType = reportType;
    }

    public String getSourceFileName() {
        return sourceFileName;
    }

    public ReportInputModel setSourceFileName(String sourceFileName) {
        this.sourceFileName = sourceFileName;
        return this;
    }

    public String getDestFileName() {
        return destFileName;
    }

    public ReportInputModel setDestFileName(String destFileName) {
        this.destFileName = destFileName;
        return this;
    }

    public Object getJavaBean() {
        return javaBean;
    }

    public ReportInputModel setJavaBean(Object javaBean) {
        this.javaBean = javaBean;
        return this;
    }

    public Map<String, Object> getReportParameter() {
        return reportParameter;
    }

    public ReportInputModel setReportParameter(Map<String, Object> reportParameter) {
        this.reportParameter = reportParameter;
        return this;
    }

    public byte[] getOutput() {
        return output;
    }

    public ReportInputModel setOutput(byte[] output) {
        this.output = output;
        return this;
    }

    public OutputStream getOs() {
        return os;
    }

    public ReportInputModel setOs(OutputStream os) {
        this.os = os;
        return this;
    }

    public InputStream getIs() {
        return is;
    }

    public ReportInputModel setIs(InputStream is) {
        this.is = is;
        return this;
    }

    public String getReportType() {
        return reportType;
    }

    public ReportInputModel setReportType(String reportType) {
        this.reportType = reportType;
        return this;
    }
}
