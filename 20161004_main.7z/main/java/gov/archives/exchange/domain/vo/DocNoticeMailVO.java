package gov.archives.exchange.domain.vo;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Created by jslee on 2016/9/14.
 */
public class DocNoticeMailVO {

    private UUID docNoticeId;
    private String docNoticeOrgId;
    private String docNoticeUnitId;
    private String docNoticeOrgUnitName;
    private Boolean docNoticeStatus;
    private String docNoticeEmails;
    private String docNoticeCreator;
    private Timestamp docNoticeCreatedTime;
    private String docNoticeModifier;
    private Timestamp docNoticeModifiedTime;

    public UUID getDocNoticeId() {
        return docNoticeId;
    }

    public void setDocNoticeId(UUID docNoticeId) {
        this.docNoticeId = docNoticeId;
    }

    public String getDocNoticeOrgId() {
        return docNoticeOrgId;
    }

    public void setDocNoticeOrgId(String docNoticeOrgId) {
        this.docNoticeOrgId = docNoticeOrgId;
    }

    public String getDocNoticeUnitId() {
        return docNoticeUnitId;
    }

    public void setDocNoticeUnitId(String docNoticeUnitId) {
        this.docNoticeUnitId = docNoticeUnitId;
    }

    public String getDocNoticeOrgUnitName() {
        return docNoticeOrgUnitName;
    }

    public void setDocNoticeOrgUnitName(String docNoticeOrgUnitName) {
        this.docNoticeOrgUnitName = docNoticeOrgUnitName;
    }

    public Boolean getDocNoticeStatus() {
        return docNoticeStatus;
    }

    public void setDocNoticeStatus(Boolean docNoticeStatus) {
        this.docNoticeStatus = docNoticeStatus;
    }

    public String getDocNoticeEmails() {
        return docNoticeEmails;
    }

    public void setDocNoticeEmails(String docNoticeEmails) {
        this.docNoticeEmails = docNoticeEmails;
    }

    public String getDocNoticeCreator() {
        return docNoticeCreator;
    }

    public void setDocNoticeCreator(String docNoticeCreator) {
        this.docNoticeCreator = docNoticeCreator;
    }

    public Timestamp getDocNoticeCreatedTime() {
        return docNoticeCreatedTime;
    }

    public void setDocNoticeCreatedTime(Timestamp docNoticeCreatedTime) {
        this.docNoticeCreatedTime = docNoticeCreatedTime;
    }

    public String getDocNoticeModifier() {
        return docNoticeModifier;
    }

    public void setDocNoticeModifier(String docNoticeModifier) {
        this.docNoticeModifier = docNoticeModifier;
    }

    public Timestamp getDocNoticeModifiedTime() {
        return docNoticeModifiedTime;
    }

    public void setDocNoticeModifiedTime(Timestamp docNoticeModifiedTime) {
        this.docNoticeModifiedTime = docNoticeModifiedTime;
    }
}
