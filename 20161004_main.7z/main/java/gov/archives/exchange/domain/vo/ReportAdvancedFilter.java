package gov.archives.exchange.domain.vo;

/**
 * Created by jslee on 2016/8/24.
 */
public class ReportAdvancedFilter extends ReportBaseFilter {

    /**
     * 欄位內容是否完整比對
     */
    private Boolean contentFullCmp;
    /**
     * 時間區間起始時間
     */
    private String timeFrom;
    /**
     * 時間區間結束時間
     */
    private String timeTo;

    public Boolean getContentFullCmp() {
        return contentFullCmp;
    }

    public void setContentFullCmp(Boolean contentFullCmp) {
        this.contentFullCmp = contentFullCmp;
    }

    public String getTimeFrom() {
        return timeFrom;
    }

    public void setTimeFrom(String timeFrom) {
        this.timeFrom = timeFrom;
    }

    public String getTimeTo() {
        return timeTo;
    }

    public void setTimeTo(String timeTo) {
        this.timeTo = timeTo;
    }
}
