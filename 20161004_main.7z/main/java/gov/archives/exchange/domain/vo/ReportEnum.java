package gov.archives.exchange.domain.vo;

import java.util.HashMap;
import java.util.Map;

import gov.archives.exchange.domain.entity.ReportConFirmedDataResult;
import gov.archives.exchange.domain.entity.ReportErrRankResult;
import gov.archives.exchange.domain.entity.ReportODFSendRateResult;
import gov.archives.exchange.domain.entity.ReportReceiveStatisticResult;
import gov.archives.exchange.domain.entity.ReportRecvErrListResult;
import gov.archives.exchange.domain.entity.ReportRecvListResult;
import gov.archives.exchange.domain.entity.ReportRecvStateResult;
import gov.archives.exchange.domain.entity.ReportSendErrListResult;
import gov.archives.exchange.domain.entity.ReportSendErrResult;
import gov.archives.exchange.domain.entity.ReportSendListResult;
import gov.archives.exchange.domain.entity.ReportSendRankResult;
import gov.archives.exchange.domain.entity.ReportSendStateResult;
import gov.archives.exchange.domain.entity.ReportSendStatisticResult;
import gov.archives.exchange.domain.entity.ReportSendUnConfmResult;

/**
 * Created by kshsu on 2016/7/22.
 */
public enum ReportEnum {
    /**
     * 中心交換量排行 001
     */
    REPORT_SEND_RANK("rptsendrank", true),
    /**
     * 中心異常排行 002
     */
    REPORT_ERR_RANK("rpterrrk", false),

    /**
     * 收文狀態統計 003
     */
    REPORT_R_STATE_STATIC("rptrss", false),
    /**
     * 收發文狀態統計 003
     */
    REPORT_S_STATE_STATIC("rptsss", false),
    /**
     * 交換異常統計 004
     */
    REPORT_SEND_ERR("rptsenderr", true),
    /**
     * 發文統計 005
     */
    REPORT_SEND_STATE("rptsendst", true),
    /**
     * 發文清單 006
     */
    REPORT_SEND_LIST("rptsendlist", true),
    /**
     * 發文待確認 007
     */
    REPORT_SEND_UNCONFIRM("rptsendunconfm", true),
    /**
     * 發文異常清單 008
     */
    REPORT_SEND_ERR_LIST("rptsenderrlist", true),
    /**
     * 收文統計 009
     */
    REPORT_RECEIVE_STATE("rptrecvstate", true),
    /**
     * 收文清單 010
     */
    REPORT_RECEIVE_LIST("rptrecvlist", true),
    /**
     * 收文異常清單 011
     */
    REPORT_RECEIVE_ERR_LIST("rptrecverrlist", true),
    /**
     * 確認率查詢 012
     */
    REPORT_CONFIRMED_QUERY("rptconfirmed", false),
    /**
     * ODF統計 013
     */
    REPORT_ODF_SEND_RATE("rptodfsendrate", true);

    private final String value;

    private final Boolean monthSchedule;

    ReportEnum(String value, Boolean monthSchedule) {
        this.value = value;
        this.monthSchedule = monthSchedule;
    }

    public boolean equalsName(String otherName) {
        return null != otherName && value.equals(otherName);
    }

    public String toString() {
        return this.value;
    }

    public Boolean isMonthSchedule() { return this.monthSchedule;}

    public String getTWName() {
        switch (value) {
            case "rptsendrank":
                return "中心交換量排行";
            case "rpterrrk":
                return "中心異常排行";
            case "rptrss":
            case "rptsss":
                return "收發文狀態統計";
            case "rptsenderr":
                return "交換異常統計";
            case "rptsendst":
                return "發文統計";
            case "rptsendlist":
                return "發文清單";
            case "rptsendunconfm":
                return "發文待確認";
            case "rptsenderrlist":
                return "發文異常清單";
            case "rptrecvstate":
                return "收文統計";
            case "rptrecvlist":
                return "收文清單";
            case "rptrecverrlist":
                return "收文異常清單";
            case "rptconfirmed":
                return "確認率查詢";
            case "rptodfsendrate":
                return "ODF統計";
            default:
                return value;
        }
    }

    /**
     * 依照 報表名稱產生對應的 Filter / Result Class 用在 ReportPrepareService.getReportFilterAndResultClass
     */
    public Map<String, Object> getFilterResultClassMap() {
        Map<String, Object> resultMap = new HashMap<>();
        switch (value) {
            case "rptsendrank":
                resultMap.put("filterClass", ReportBaseFilter.class);
                resultMap.put("resultClass", ReportSendRankResult.class);
                break;
            case "rpterrrk":
                resultMap.put("filterClass", ReportBaseFilter.class);
                resultMap.put("resultClass", ReportErrRankResult.class);
                break;
            // 切為 發文(rptsss) / 收文(rptrss)
            case "rptrss":
                resultMap.put("filterClass", ReportRSStateFilter.class);
                resultMap.put("resultClass", ReportReceiveStatisticResult.class);
                break;
            case "rptsss":
                resultMap.put("filterClass", ReportRSStateFilter.class);
                resultMap.put("resultClass", ReportSendStatisticResult.class);
                break;
            case "rptsenderr":
                resultMap.put("filterClass", ReportSendErrFilter.class);
                resultMap.put("resultClass", ReportSendErrResult.class);
                break;
            case "rptsendst":
                resultMap.put("filterClass", ReportBaseFilter.class);
                resultMap.put("resultClass", ReportSendStateResult.class);
                break;
            case "rptsendlist":
                resultMap.put("filterClass", ReportSendListFilter.class);
                resultMap.put("resultClass", ReportSendListResult.class);
                break;
            case "rptsendunconfm":
                resultMap.put("filterClass", ReportSendUnConfmFilter.class);
                resultMap.put("resultClass", ReportSendUnConfmResult.class);
                break;
            case "rptsenderrlist":
                resultMap.put("filterClass", ReportSendErrListFilter.class);
                resultMap.put("resultClass", ReportSendErrListResult.class);
                break;
            case "rptrecvstate":
                resultMap.put("filterClass", ReportBaseFilter.class);
                resultMap.put("resultClass", ReportRecvStateResult.class);
                break;
            case "rptrecvlist":
                resultMap.put("filterClass", ReportRecvListFilter.class);
                resultMap.put("resultClass", ReportRecvListResult.class);
                break;
            case "rptrecverrlist":
                resultMap.put("filterClass", ReportRecvErrListFilter.class);
                resultMap.put("resultClass", ReportRecvErrListResult.class);
                break;
            case "rptconfirmed":
                resultMap.put("filterClass", ReportConFirmedDataFilter.class);
                resultMap.put("resultClass", ReportConFirmedDataResult.class);
                break;
            case "rptodfsendrate":
                resultMap.put("filterClass", ReportODFSendRateFilter.class);
                resultMap.put("resultClass", ReportODFSendRateResult.class);
                break;
        }
        return resultMap;
    }
}
