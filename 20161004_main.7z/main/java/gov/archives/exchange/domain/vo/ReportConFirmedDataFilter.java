package gov.archives.exchange.domain.vo;

/**
 * Created by kshsu on 2016/8/1. 確認率查詢
 */
public class ReportConFirmedDataFilter extends ReportBaseFilter {
    /**
     * 中心代碼
     */
    private String getewayId;

    public String getGetewayId() {
        return getewayId;
    }

    public void setGetewayId(String getewayId) {
        this.getewayId = getewayId;
    }
}
