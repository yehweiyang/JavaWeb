package gov.archives.exchange.domain.vo;

import java.util.List;

/**
 * Created by kshsu on 2016/7/22.
 * 主要查詢條件父類別 FilterContent
 */
public class ReportBaseFilter {
    /**
     * 用於Server 端回傳所有已產生的月報表檔名列表，以 JSON 格式存放
     */
    private List<String> reportListFromMonth;
    /**
     * 所選取的月報表名稱
     */
    private String selectedReportOfMonth;
    /**
     * 時間區間起始日期
     */
    private String dateFrom;
    /**
     * 時間區間結束日期
     */
    private String dateTo;
    /**
     * 排序欄位名稱
     */
    private String sortColumnName;
    /**
     * 排序順序
     */
    private Boolean sortDescending;

    public List<String> getReportListFromMonth() {
        return reportListFromMonth;
    }

    public void setReportListFromMonth(List<String> reportListFromMonth) {
        this.reportListFromMonth = reportListFromMonth;
    }

    public String getSelectedReportOfMonth() {
        return selectedReportOfMonth;
    }

    public void setSelectedReportOfMonth(String selectedReportOfMonth) {
        this.selectedReportOfMonth = selectedReportOfMonth;
    }

    public String getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }

    public String getDateTo() {
        return dateTo;
    }

    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }

    public String getSortColumnName() {
        return sortColumnName;
    }

    public void setSortColumnName(String sortColumnName) {
        this.sortColumnName = sortColumnName;
    }

    public Boolean getSortDescending() {
        return sortDescending;
    }

    public void setSortDescending(Boolean sortDescending) {
        this.sortDescending = sortDescending;
    }
}
