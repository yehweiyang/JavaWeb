package gov.archives.exchange.domain.vo;

/**
 * Created by kshsu on 2016/7/29.
 * 發文清單
 */
public class ReportSendListFilter extends ReportAdvancedFilter {

    /**
     * 發文機關代碼欄位內容
     */
    private String senderId;
    /**
     * 發文機關名稱欄位內容
     */
    private String senderName;
    /**
     * 收文機關代碼欄位內容
     */
    private String receiverId;
    /**
     * 收文機關名稱欄位內容
     */
    private String receiverName;

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

}
