package gov.archives.exchange.domain.vo;

/**
 * Created by kshsu on 2016/8/1.
 * 收文異常清單
 */
public class ReportRecvErrListFilter extends ReportAdvancedFilter {

    /**
     * 收文機關代碼欄位內容
     */
    private String  receiverId;
    /**
     * 收文機關名稱欄位內容
     */
    private String  receiverName;


    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

}
