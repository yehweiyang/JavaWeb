package gov.archives.exchange.domain.vo;

/**
 * Created by kshsu on 2016/8/1.
 * 發文異常清單
 */
public class ReportSendErrListFilter extends ReportAdvancedFilter {

    /**
     * 發文機關代碼欄位內容
     */
    private String  senderId;
    /**
     * 發文機關名稱欄位內容
     */
    private String  senderName;

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

}
