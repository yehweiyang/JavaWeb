package gov.archives.exchange.domain.vo;

/**
 * Created by kshsu on 2016/7/25. 收發文狀態統計 FilterContent
 */
public class ReportRSStateFilter extends ReportAdvancedFilter {
    /**
     * 機關代碼欄位內容
     */
    private String orgId;
    /**
     * 機關名稱欄位內容
     */
    private String orgName;
    /**
     * 查詢標的，收文，發文
     */
    private String queryTarget;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getQueryTarget() {
        return queryTarget;
    }

    public void setQueryTarget(String queryTarget) {
        this.queryTarget = queryTarget;
    }

}
