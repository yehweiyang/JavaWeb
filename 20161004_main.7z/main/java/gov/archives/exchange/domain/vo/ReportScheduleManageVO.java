package gov.archives.exchange.domain.vo;

import java.util.Date;

/**
 * Created by jslee on 2016/9/22.
 */
public class ReportScheduleManageVO {

    private String reportName;
    private Date nextRunTime;

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public Date getNextRunTime() {
        return nextRunTime;
    }

    public void setNextRunTime(Date nextRunTime) {
        this.nextRunTime = nextRunTime;
    }

}
