package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by kshsu on 2016/8/1.
 * 確認率查詢 rptconfirmed
 */
@Alias("ReportConFirmed")
public class ReportConFirmedDataResult extends ReportResult{
    public enum ColmunEnum {
        title("確認率查詢"),
        rowIndex("序號"),
        gatewayId ("交換中心"),
        insertTime ("日期"),
        senderCount("發文數"),
        senderConfirmCount("發文系統確認數"),
        senderExceptionCount("發文系統異常數"),
        senderRejectCount("發文系統退文數"),
        senderConfirmPercent("發文系統確認率"),
        senderExceptionPercent("發文系統異常率"),
        senderRejectPercent("發文系統退文率"),
        senderConfirmCount_24("發文使用者確認數"),
        senderRejectCount_24("發文使用者退文數"),
        senderNonReplayCount_24("發文尚未回覆數"),
        senderConfirmPercent_24("發文使用者確認率"),
        senderRejectPercent_24("發文使用者退文率"),
        senderConfirmCount_48("發文使用者確認數"),
        senderRejectCount_48("發文使用者退文數"),
        senderNonReplayCount_48("發文尚未回覆數"),
        senderConfirmPercent_48("發文使用者確認率"),
        senderRejectPercent_48("發文使用者退文率"),
        totalDocumentCount("收文數"),
        receiverConfirmCount("收文系統確認數"),
        receiverExceptionCount("收文系統異常數"),
        receiverConfirmPercent("收文系統確認率"),
        receiverExceptionPercent("收文系統異常率"),
        receiverConfirmCount_24("收文使用者確認數"),
        receiverRejectCount_24("收文使用者退文數"),
        receiverNonReplayCount_24("收文尚未回覆數"),
        receiverConfirmPercent_24("收文使用者確認率"),
        receiverRejectPercent_24("收文使用者退文率"),
        receiverConfirmCount_48("收文使用者確認數"),
        receiverRejectCount_48("收文使用者退文數"),
        receiverNonReplayCount_48("收文尚未回覆數"),
        receiverConfirmPercent_48("收文使用者確認率"),
        receiverRejectPercent_48("收文使用者退文率");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 序號
     */
    private int rowIndex;
    /**
     * 交換中心
     */
    private String gatewayId;
    /**
     * 日期
     */
    private String insertTime;
    /**
     * 發文數
     */
    private String senderCount;
    /**
     * 發文系統確認數
     */
    private String senderConfirmCount;
    /**
     * 發文系統異常數
     */
    private String senderExceptionCount;
    /**
     * 發文系統退文數
     */
    private String senderRejectCount;
    /**
     * 發文系統確認率
     */
    private String senderConfirmPercent;
    /**
     * 發文系統異常率
     */
    private String senderExceptionPercent;
    /**
     * 發文系統退文率
     */
    private String senderRejectPercent;
    /**
     * 發文使用者確認數
     */
    private String senderConfirmCount_24;
    /**
     * 發文使用者退文數
     */
    private String senderRejectCount_24;
    /**
     * 發文尚未回覆數
     */
    private String senderNonReplayCount_24;
    /**
     * 發文使用者確認率
     */
    private String senderConfirmPercent_24;
    /**
     * 發文使用者退文率
     */
    private String senderRejectPercent_24;
    /**
     * 發文使用者確認數
     */
    private String senderConfirmCount_48;
    /**
     * 發文使用者退文數
     */
    private String senderRejectCount_48;
    /**
     * 發文尚未回覆數
     */
    private String senderNonReplayCount_48;
    /**
     * 發文使用者確認率
     */
    private String senderConfirmPercent_48;
    /**
     * 發文使用者退文率
     */
    private String senderRejectPercent_48;
    /**
     * 收文數
     */
    private String totalDocumentCount;
    /**
     * 收文系統確認數
     */
    private String receiverConfirmCount;
    /**
     * 收文系統異常數
     */
    private String receiverExceptionCount;
    /**
     * 收文系統確認率
     */
    private String receiverConfirmPercent;
    /**
     * 收文系統異常率
     */
    private String receiverExceptionPercent;
    /**
     * 收文使用者確認數
     */
    private String receiverConfirmCount_24;
    /**
     * 收文使用者退文數
     */
    private String receiverRejectCount_24;
    /**
     * 收文尚未回覆數
     */
    private String receiverNonReplayCount_24;
    /**
     * 收文使用者確認率
     */
    private String receiverConfirmPercent_24;
    /**
     * 收文使用者退文率
     */
    private String receiverRejectPercent_24;
    /**
     * 收文使用者確認數
     */
    private String receiverConfirmCount_48;
    /**
     * 收文使用者退文數
     */
    private String receiverRejectCount_48;
    /**
     * 收文尚未回覆數
     */
    private String receiverNonReplayCount_48;
    /**
     * 收文使用者確認率
     */
    private String receiverConfirmPercent_48;
    /**
     * 收文使用者退文率
     */
    private String receiverRejectPercent_48;

    public int getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getGatewayId() {
        return gatewayId;
    }

    public void setGatewayId(String gatewayId) {
        this.gatewayId = gatewayId;
    }

    public String getInsertTime() {
        return insertTime;
    }

    public void setInsertTime(String insertTime) {
        this.insertTime = insertTime;
    }

    public String getSenderCount() {
        return senderCount;
    }

    public void setSenderCount(String senderCount) {
        this.senderCount = senderCount;
    }

    public String getSenderConfirmCount() {
        return senderConfirmCount;
    }

    public void setSenderConfirmCount(String senderConfirmCount) {
        this.senderConfirmCount = senderConfirmCount;
    }

    public String getSenderExceptionCount() {
        return senderExceptionCount;
    }

    public void setSenderExceptionCount(String senderExceptionCount) {
        this.senderExceptionCount = senderExceptionCount;
    }

    public String getSenderRejectCount() {
        return senderRejectCount;
    }

    public void setSenderRejectCount(String senderRejectCount) {
        this.senderRejectCount = senderRejectCount;
    }

    public String getSenderConfirmPercent() {
        return senderConfirmPercent;
    }

    public void setSenderConfirmPercent(String senderConfirmPercent) {
        this.senderConfirmPercent = senderConfirmPercent;
    }

    public String getSenderExceptionPercent() {
        return senderExceptionPercent;
    }

    public void setSenderExceptionPercent(String senderExceptionPercent) {
        this.senderExceptionPercent = senderExceptionPercent;
    }

    public String getSenderRejectPercent() {
        return senderRejectPercent;
    }

    public void setSenderRejectPercent(String senderRejectPercent) {
        this.senderRejectPercent = senderRejectPercent;
    }

    public String getSenderConfirmCount_24() {
        return senderConfirmCount_24;
    }

    public void setSenderConfirmCount_24(String senderConfirmCount_24) {
        this.senderConfirmCount_24 = senderConfirmCount_24;
    }

    public String getSenderRejectCount_24() {
        return senderRejectCount_24;
    }

    public void setSenderRejectCount_24(String senderRejectCount_24) {
        this.senderRejectCount_24 = senderRejectCount_24;
    }

    public String getSenderNonReplayCount_24() {
        return senderNonReplayCount_24;
    }

    public void setSenderNonReplayCount_24(String senderNonReplayCount_24) {
        this.senderNonReplayCount_24 = senderNonReplayCount_24;
    }

    public String getSenderConfirmPercent_24() {
        return senderConfirmPercent_24;
    }

    public void setSenderConfirmPercent_24(String senderConfirmPercent_24) {
        this.senderConfirmPercent_24 = senderConfirmPercent_24;
    }

    public String getSenderRejectPercent_24() {
        return senderRejectPercent_24;
    }

    public void setSenderRejectPercent_24(String senderRejectPercent_24) {
        this.senderRejectPercent_24 = senderRejectPercent_24;
    }

    public String getSenderConfirmCount_48() {
        return senderConfirmCount_48;
    }

    public void setSenderConfirmCount_48(String senderConfirmCount_48) {
        this.senderConfirmCount_48 = senderConfirmCount_48;
    }

    public String getSenderRejectCount_48() {
        return senderRejectCount_48;
    }

    public void setSenderRejectCount_48(String senderRejectCount_48) {
        this.senderRejectCount_48 = senderRejectCount_48;
    }

    public String getSenderNonReplayCount_48() {
        return senderNonReplayCount_48;
    }

    public void setSenderNonReplayCount_48(String senderNonReplayCount_48) {
        this.senderNonReplayCount_48 = senderNonReplayCount_48;
    }

    public String getSenderConfirmPercent_48() {
        return senderConfirmPercent_48;
    }

    public void setSenderConfirmPercent_48(String senderConfirmPercent_48) {
        this.senderConfirmPercent_48 = senderConfirmPercent_48;
    }

    public String getSenderRejectPercent_48() {
        return senderRejectPercent_48;
    }

    public void setSenderRejectPercent_48(String senderRejectPercent_48) {
        this.senderRejectPercent_48 = senderRejectPercent_48;
    }

    public String getTotalDocumentCount() {
        return totalDocumentCount;
    }

    public void setTotalDocumentCount(String totalDocumentCount) {
        this.totalDocumentCount = totalDocumentCount;
    }

    public String getReceiverConfirmCount() {
        return receiverConfirmCount;
    }

    public void setReceiverConfirmCount(String receiverConfirmCount) {
        this.receiverConfirmCount = receiverConfirmCount;
    }

    public String getReceiverExceptionCount() {
        return receiverExceptionCount;
    }

    public void setReceiverExceptionCount(String receiverExceptionCount) {
        this.receiverExceptionCount = receiverExceptionCount;
    }

    public String getReceiverConfirmPercent() {
        return receiverConfirmPercent;
    }

    public void setReceiverConfirmPercent(String receiverConfirmPercent) {
        this.receiverConfirmPercent = receiverConfirmPercent;
    }

    public String getReceiverExceptionPercent() {
        return receiverExceptionPercent;
    }

    public void setReceiverExceptionPercent(String receiverExceptionPercent) {
        this.receiverExceptionPercent = receiverExceptionPercent;
    }

    public String getReceiverConfirmCount_24() {
        return receiverConfirmCount_24;
    }

    public void setReceiverConfirmCount_24(String receiverConfirmCount_24) {
        this.receiverConfirmCount_24 = receiverConfirmCount_24;
    }

    public String getReceiverRejectCount_24() {
        return receiverRejectCount_24;
    }

    public void setReceiverRejectCount_24(String receiverRejectCount_24) {
        this.receiverRejectCount_24 = receiverRejectCount_24;
    }

    public String getReceiverNonReplayCount_24() {
        return receiverNonReplayCount_24;
    }

    public void setReceiverNonReplayCount_24(String receiverNonReplayCount_24) {
        this.receiverNonReplayCount_24 = receiverNonReplayCount_24;
    }

    public String getReceiverConfirmPercent_24() {
        return receiverConfirmPercent_24;
    }

    public void setReceiverConfirmPercent_24(String receiverConfirmPercent_24) {
        this.receiverConfirmPercent_24 = receiverConfirmPercent_24;
    }

    public String getReceiverRejectPercent_24() {
        return receiverRejectPercent_24;
    }

    public void setReceiverRejectPercent_24(String receiverRejectPercent_24) {
        this.receiverRejectPercent_24 = receiverRejectPercent_24;
    }

    public String getReceiverConfirmCount_48() {
        return receiverConfirmCount_48;
    }

    public void setReceiverConfirmCount_48(String receiverConfirmCount_48) {
        this.receiverConfirmCount_48 = receiverConfirmCount_48;
    }

    public String getReceiverRejectCount_48() {
        return receiverRejectCount_48;
    }

    public void setReceiverRejectCount_48(String receiverRejectCount_48) {
        this.receiverRejectCount_48 = receiverRejectCount_48;
    }

    public String getReceiverNonReplayCount_48() {
        return receiverNonReplayCount_48;
    }

    public void setReceiverNonReplayCount_48(String receiverNonReplayCount_48) {
        this.receiverNonReplayCount_48 = receiverNonReplayCount_48;
    }

    public String getReceiverConfirmPercent_48() {
        return receiverConfirmPercent_48;
    }

    public void setReceiverConfirmPercent_48(String receiverConfirmPercent_48) {
        this.receiverConfirmPercent_48 = receiverConfirmPercent_48;
    }

    public String getReceiverRejectPercent_48() {
        return receiverRejectPercent_48;
    }

    public void setReceiverRejectPercent_48(String receiverRejectPercent_48) {
        this.receiverRejectPercent_48 = receiverRejectPercent_48;
    }
}
