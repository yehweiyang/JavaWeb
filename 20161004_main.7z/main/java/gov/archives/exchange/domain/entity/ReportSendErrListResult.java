package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by kshsu on 2016/8/1.
 * 發文異常清單 rptsenderrrlist
 */
@Alias("ReportSendErrList")
public class ReportSendErrListResult extends ReportResult {
    public enum ColmunEnum {
        title("發文異常清單"),
        rowIndex("序號"),
        serverTime("發文日期"),
        applicationId("文號"),
        senderName("發文單位"),
        receiverName("受文單位"),
        sendException("狀態"),
        msgInfo("異常原因");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 序號
     */
    private int rowIndex;
    /**
     * 發文日期
     */
    private String serverTime;
    /**
     * 文號
     */
    private String applicationId;
    /**
     * 發文單位
     */
    private String senderName;
    /**
     * 受文單位
     */
    private String receiverName;
    /**
     * 狀態
     */
    private String sendException;
    /**
     * 異常原因
     */
    private String msgInfo;


    public int getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getServerTime() {
        return serverTime;
    }

    public void setServerTime(String serverTime) {
        this.serverTime = serverTime;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getSendException() {
        return sendException;
    }

    public void setSendException(String sendException) {
        this.sendException = sendException;
    }

    public String getMsgInfo() {
        return msgInfo;
    }

    public void setMsgInfo(String msgInfo) {
        this.msgInfo = msgInfo;
    }
}
