package gov.archives.exchange.domain.entity;

/**
 * Created by wtjiang on 2016/9/18.
 */
public class SmtpConfigEntity {
    private String smtpServerIp;
    private String smtpServerPort;
    private String UseSsl;
    private String Certification;
    private String loginAccount;
    private String loginPassword;
    private String lastUpdateTime;

    public String getUseSsl() {
        return UseSsl;
    }

    public void setUseSsl(String useSsl) {
        UseSsl = useSsl;
    }

    public String getCertification() {
        return Certification;
    }

    public void setCertification(String certification) {
        Certification = certification;
    }

    public String getSmtpServerIp() {
        return smtpServerIp;
    }

    public void setSmtpServerIp(String smtpServerIp) {
        this.smtpServerIp = smtpServerIp;
    }

    public String getSmtpServerPort() {
        return smtpServerPort;
    }

    public void setSmtpServerPort(String smtpServerPort) {
        this.smtpServerPort = smtpServerPort;
    }

    public String getLoginAccount() {
        return loginAccount;
    }

    public void setLoginAccount(String loginAccount) {
        this.loginAccount = loginAccount;
    }

    public String getLoginPassword() {
        return loginPassword;
    }

    public void setLoginPassword(String loginPassword) {
        this.loginPassword = loginPassword;
    }

    public String getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(String lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }
}
