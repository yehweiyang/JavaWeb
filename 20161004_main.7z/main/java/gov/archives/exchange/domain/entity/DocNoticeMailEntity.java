package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

import gov.archives.core.domain.entity.BaseEntity;

/**
 * Created by jslee on 2016/9/14.
 */
@Alias("DocNoticeMail")
public class DocNoticeMailEntity extends BaseEntity {

    private String orgId;
    private String unitId;
    private String orgUnitName;
    private Boolean activeStatus;
    private String noticeEmail;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getUnitId() {
        return unitId;
    }

    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }

    public String getOrgUnitName() {
        return orgUnitName;
    }

    public void setOrgUnitName(String orgUnitName) {
        this.orgUnitName = orgUnitName;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getNoticeEmail() {
        return noticeEmail;
    }

    public void setNoticeEmail(String noticeEmail) {
        this.noticeEmail = noticeEmail;
    }

}
