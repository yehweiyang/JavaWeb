package gov.archives.exchange.domain.entity;

import java.util.UUID;

import org.apache.ibatis.type.Alias;

/**
 * ExchangeAbnormalQueryEntity
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
@Alias("ExchangeAbnormalQuery")
public class ExchangeAbnormalQueryEntity {

    private UUID sysId;
    private String serialNo;
    private String msgCode;
    private String exchangeId;
    private String senderOrgId;
    private String senderUnitId;
    private String applicationId;
    private String senderUnitName;
    private String receiverUnitName;
    private String processId;
    private String receiverOrgId;
    private String receiverUnitId;
    private String msgInfo;
    private String docSubject;
    private String exchangeType;
    private String dtdName;
    private String receiverCount;
    private String userMsgTime;
    private String sysMsgTime;
    private String toServerTime;
    private String senderContactInfo;
    private String eHub;
    public UUID getSysId() {
        return sysId;
    }

    public void setSysId(UUID sysId) {
        this.sysId = sysId;
    }

    public String getExchangeId() {
        return exchangeId;
    }

    public void setExchangeId(String exchangeId) {
        this.exchangeId = exchangeId;
    }


    public String getSenderOrgId() {
        return senderOrgId;
    }

    public void setSenderOrgId(String senderOrgId) {
        this.senderOrgId = senderOrgId;
    }

    public String getSenderUnitId() {
        return senderUnitId;
    }

    public void setSenderUnitId(String senderUnitId) {
        this.senderUnitId = senderUnitId;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getReceiverOrgId() {
        return receiverOrgId;
    }

    public void setReceiverOrgId(String receiverOrgId) {
        this.receiverOrgId = receiverOrgId;
    }

    public String getReceiverUnitId() {
        return receiverUnitId;
    }

    public void setReceiverUnitId(String receiverUnitId) {
        this.receiverUnitId = receiverUnitId;
    }

    public String getSenderUnitName() {
        return senderUnitName;
    }

    public void setSenderUnitName(String senderUnitName) {
        this.senderUnitName = senderUnitName;
    }

    public String getReceiverUnitName() {
        return receiverUnitName;
    }

    public void setReceiverUnitName(String receiverUnitName) {
        this.receiverUnitName = receiverUnitName;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getMsgCode() {
        return msgCode;
    }

    public void setMsgCode(String msgCode) {
        this.msgCode = msgCode;
    }

    public String getMsgInfo() {
        return msgInfo;
    }

    public void setMsgInfo(String msgInfo) {
        this.msgInfo = msgInfo;
    }

    public String getDocSubject() {
        return docSubject;
    }

    public void setDocSubject(String docSubject) {
        this.docSubject = docSubject;
    }

    public String getExchangeType() {
        return exchangeType;
    }

    public void setExchangeType(String exchangeType) {
        this.exchangeType = exchangeType;
    }

    public String getDtdName() {
        return dtdName;
    }

    public void setDtdName(String dtdName) {
        this.dtdName = dtdName;
    }

    public String getReceiverCount() {
        return receiverCount;
    }

    public void setReceiverCount(String receiverCount) {
        this.receiverCount = receiverCount;
    }

    public String getUserMsgTime() {
        return userMsgTime;
    }

    public void setUserMsgTime(String userMsgTime) {
        this.userMsgTime = userMsgTime;
    }

    public String getSysMsgTime() {
        return sysMsgTime;
    }

    public void setSysMsgTime(String sysMsgTime) {
        this.sysMsgTime = sysMsgTime;
    }

    public String getToServerTime() {
        return toServerTime;
    }

    public void setToServerTime(String toServerTime) {
        this.toServerTime = toServerTime;
    }

    public String getSenderContactInfo() {
        return senderContactInfo;
    }

    public void setSenderContactInfo(String senderContactInfo) {
        this.senderContactInfo = senderContactInfo;
    }

    public String geteHub() {
        return eHub;
    }

    public void seteHub(String eHub) {
        this.eHub = eHub;
    }
}
