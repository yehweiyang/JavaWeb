package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by jslee on 2016/7/5. 交換異常統計 rptsendlist
 */
@Alias("ReportSendErr")
public class ReportSendErrResult extends ReportResult {
    public enum ColmunEnum {
        title("交換異常統計"),
        rowIndex("序號"),
        serverTime("發文日期"),
        applicationId("文號"),
        senderName("發文單位"),
        receiverName("受文機關"),
        msgInfo("異常原因"),
        sendException("狀態");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 序號
     */
    private int rowIndex;
    /**
     * 發文日期
     */
    private String serverTime;
    /**
     * 文號
     */
    private String applicationId;
    /**
     * 發文單位
     */
    private String senderName;
    /**
     * 受文機關
     */
    private String receiverName;
    /**
     * 異常原因
     */
    private String msgInfo;
    /**
     * 狀態
     */
    private String sendException;

    public int getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getServerTime() {
        return serverTime;
    }

    public void setServerTime(String serverTime) {
        this.serverTime = serverTime;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getMsgInfo() {
        return msgInfo;
    }

    public void setMsgInfo(String msgInfo) {
        this.msgInfo = msgInfo;
    }

    public String getSendException() {
        return sendException;
    }

    public void setSendException(String sendException) {
        this.sendException = sendException;
    }
}
