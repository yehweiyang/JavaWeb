package gov.archives.exchange.domain.entity;

import java.sql.Date;
import java.util.UUID;
import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

/**
 * Created by wtjiang on 2016/8/26.
 */
@Alias("Accessor")
public class AccessorEntity {

    private UUID sysId;
    private String orgId;
    private String unitId;
    private String orgUnitId;
    private String rsType;
    private String certType;
    private String signCertSerialNum;
    private String signCertHash;
    private String encryptCertSerialNum;
    private String encryptCertHash;
    private String certCardNum;
    private Timestamp validBegin;
    private Timestamp validEnd;
    private Boolean isBlack;
    private Boolean isDefault;
    private Timestamp chkCrlTime;
    private Timestamp certUpdateTime;
    private Date nextUpdateDate;
    private String pbSerial;
    private String pbHash;
    private String creatorAccount;
    private Timestamp createdTime;
    private String modifierAccount;
    private Timestamp modifiedTime;

    public Timestamp getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Timestamp createdTime) {
        this.createdTime = createdTime;
    }

    public Timestamp getCertUpdateTime() {
        return certUpdateTime;
    }

    public void setCertUpdateTime(Timestamp certUpdateTime) {
        this.certUpdateTime = certUpdateTime;
    }

    public Timestamp getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Timestamp modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public String getCertCardNum() {
        return certCardNum;
    }

    public void setCertCardNum(String certCardNum) {
        this.certCardNum = certCardNum;
    }

    public String getCertType() {
        return certType;
    }

    public void setCertType(String certType) {
        this.certType = certType;
    }

    public Timestamp getChkCrlTime() {
        return chkCrlTime;
    }

    public void setChkCrlTime(Timestamp chkCrlTime) {
        this.chkCrlTime = chkCrlTime;
    }

    public String getCreatorAccount() {
        return creatorAccount;
    }

    public void setCreatorAccount(String creatorAccount) {
        this.creatorAccount = creatorAccount;
    }

    public String getEncryptCertHash() {
        return encryptCertHash;
    }

    public void setEncryptCertHash(String encryptCertHash) {
        this.encryptCertHash = encryptCertHash;
    }

    public String getEncryptCertSerialNum() {
        return encryptCertSerialNum;
    }

    public void setEncryptCertSerialNum(String encryptCertSerialNum) {
        this.encryptCertSerialNum = encryptCertSerialNum;
    }

    public Boolean getBlack() {
        return isBlack;
    }

    public void setBlack(Boolean black) {
        isBlack = black;
    }

    public Boolean getDefault() {
        return isDefault;
    }

    public void setDefault(Boolean aDefault) {
        isDefault = aDefault;
    }

    public String getModifierAccount() {
        return modifierAccount;
    }

    public void setModifierAccount(String modifierAccount) {
        this.modifierAccount = modifierAccount;
    }

    public Date getNextUpdateDate() {
        return nextUpdateDate;
    }

    public void setNextUpdateDate(Date nextUpdateDate) {
        this.nextUpdateDate = nextUpdateDate;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getOrgUnitId() {
        return orgUnitId;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public String getPbHash() {
        return pbHash;
    }

    public void setPbHash(String pbHash) {
        this.pbHash = pbHash;
    }

    public String getPbSerial() {
        return pbSerial;
    }

    public void setPbSerial(String pbSerial) {
        this.pbSerial = pbSerial;
    }

    public String getRsType() {
        return rsType;
    }

    public void setRsType(String rsType) {
        this.rsType = rsType;
    }

    public String getSignCertHash() {
        return signCertHash;
    }

    public void setSignCertHash(String signCertHash) {
        this.signCertHash = signCertHash;
    }

    public String getSignCertSerialNum() {
        return signCertSerialNum;
    }

    public void setSignCertSerialNum(String signCertSerialNum) {
        this.signCertSerialNum = signCertSerialNum;
    }

    public UUID getSysId() {
        return sysId;
    }

    public void setSysId(UUID sysId) {
        this.sysId = sysId;
    }

    public String getUnitId() {
        return unitId;
    }

    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }

    public Timestamp getValidBegin() {
        return validBegin;
    }

    public void setValidBegin(Timestamp validBegin) {
        this.validBegin = validBegin;
    }

    public Timestamp getValidEnd() {
        return validEnd;
    }

    public void setValidEnd(Timestamp validEnd) {
        this.validEnd = validEnd;
    }
}
