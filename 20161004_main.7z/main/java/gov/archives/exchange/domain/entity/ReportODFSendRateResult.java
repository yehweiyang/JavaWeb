package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by kshsu on 2016/8/30.
 * ODF統計 rptodfsendrate
 */
@Alias("ReportODFSendRate")
public class ReportODFSendRateResult extends ReportResult {
    public enum ColmunEnum {
        title("ODF統計"),
        rowIndex("序號"),
        senderId("發文機關代碼"),
        senderName("發文機關名稱"),
        attachFileCount("有附件公文數"),
        attachOdfCount("含ODF公文數"),
        attachOdfPercent("ODF比例");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 序號
     */
    private String rowIndex;

    /**
     * 發文機關代碼
     */
    private String senderId;

    /**
     * senderName
     */
    private String senderName;

    /**
     * attachFileCount
     */
    private String attachFileCount;

    /**
     * 含ODF公文數
     */
    private String attachOdfCount;

    /**
     * ODF比例
     */
    private String attachOdfPercent;

    public String getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(String rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getAttachFileCount() {
        return attachFileCount;
    }

    public void setAttachFileCount(String attachFileCount) {
        this.attachFileCount = attachFileCount;
    }

    public String getAttachOdfCount() {
        return attachOdfCount;
    }

    public void setAttachOdfCount(String attachOdfCount) {
        this.attachOdfCount = attachOdfCount;
    }

    public String getAttachOdfPercent() {
        return attachOdfPercent;
    }

    public void setAttachOdfPercent(String attachOdfPercent) {
        this.attachOdfPercent = attachOdfPercent;
    }
}
