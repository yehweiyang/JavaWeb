package gov.archives.exchange.schedule.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import gov.archives.core.exception.ArchivesException;
import gov.archives.exchange.schedule.scheduler.ReportBaseScheduler;

/**
 * 排程程式工廠
 * Created by jslee on 2016/9/21.
 */
@Component
public class ReportScheduleHelper {

    @Autowired
    ApplicationContext applicationContext;

    public ReportBaseScheduler getReportScheduler(String reportName) throws ArchivesException {
        return (ReportBaseScheduler) applicationContext.getBean(reportName + "Schedule");
    }

}
