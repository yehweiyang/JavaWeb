package gov.archives.exchange.schedule.scheduler;

import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.domain.entity.ReportSendStateResult;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/9/1.
 */
@Component("rptsendstSchedule")
public class ReportSendStateScheduler extends ReportBaseScheduler {

    private static final String reportName = ReportEnum.REPORT_SEND_STATE.toString();

    @Override
    @Scheduled(cron = "${SCHEDULE.REPORT.TRIGGER}")
    public void excuteSchedule() {
        try {
            if (isEnabled) {
                recordTriggerStartMsg(reportName);
                ReportBaseFilter sendStateFilter = initBaseFilterByMonth();

                List<ReportSendStateResult> sendStateResults =
                        reportDataGenService.getReportSendStateByFilter(sendStateFilter);

                if (isScheduleCase) {
                    reportDataGenService
                            .saveSearchResult(
                                    getReportMonthFilePath(reportName),
                                    sendStateFilter,
                                    sendStateResults);
                }
            }
        } catch (Exception e) {
            isSuccess = false;
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_BACKGROUND_ERROR);
        } finally {
            recordTriggerEndMsg(reportName, isEnabled);
            publish(isSuccess, isEnabled);
        }
    }

}
