package gov.archives.exchange.schedule.scheduler;

import java.util.HashMap;
import java.util.Map;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.service.ReportScheduleManageService;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/9/8.
 */
@Component("rptconfirmedSchedule")
public class ReportConfirmedRateScheduler extends ReportBaseScheduler {

    private static final String reportName = ReportEnum.REPORT_CONFIRMED_QUERY.toString();

    @Autowired
    private ReportScheduleManageService reportDataModifiedService;

    @Override
    @Scheduled(cron = "${SCHEDULE.REPORT.REPORT_CONFIRMED_RATE.TRIGGER}")
    public void excuteSchedule() {
        try {
            if (isEnabled) {
                recordTriggerStartMsg(reportName);
                LocalDate triggerDate = LocalDate.now();
                reportDataModifiedService.updateTwoDayComfirmedRate(getWorkingDateMapFromTriggerDate(triggerDate));
                reportDataModifiedService.insertOneDayComfirmedRate(triggerDate.minusDays(1).toString());
            }
        } catch (Exception e) {
            isSuccess = false;
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_BACKGROUND_ERROR, e);
        } finally {
            recordTriggerEndMsg(reportName, isEnabled);
            publish(isSuccess, isEnabled);
        }
    }

    private Map<String, Object> getWorkingDateMapFromTriggerDate(LocalDate localDate) {
        Map<String, Object> workingDateMap = new HashMap<>();
        workingDateMap.put("workingDateFrom",
                (localDate.minusDays(2).getDayOfWeek() == 7 ?
                        localDate.minusDays(4) : localDate.minusDays(2)).toString());
        workingDateMap.put("workingDateTo", localDate.minusDays(1).toString());
        return workingDateMap;
    }

}
