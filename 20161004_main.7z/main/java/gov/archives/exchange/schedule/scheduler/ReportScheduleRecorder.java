package gov.archives.exchange.schedule.scheduler;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;

import org.iii.common.util.PreconditionUtils;

import gov.archives.exchange.event.ScheduleEvent;

/**
 * 紀錄排程程式起訖時間及寫入 log 判斷是否存活
 * Created by jslee on 2016/9/21.
 */
public class ReportScheduleRecorder implements ApplicationEventPublisherAware {

    private static final Logger log = LoggerFactory.getLogger(ReportScheduleRecorder.class);

    private Instant startTime;

    private Instant endTime;

    private ApplicationEventPublisher publisher;

    protected void recordTriggerStartMsg(String reportName) {
        startTime = Instant.now();
        log.info(reportName + "Schedule Start " + new Date());
    }

    protected void recordTriggerEndMsg(String reportName) {
        log.info(reportName + "Schedule End " + new Date());
    }

    protected void recordTriggerEndMsg(String reportName, boolean enableSchedule) {
        if (enableSchedule) {
            endTime = Instant.now();
            PreconditionUtils.checkArguments(startTime, endTime);
            log.info(reportName + "Schedule End " + new Date() +
                    " Total time: " + Duration.between(startTime, endTime).toMillis() + " milliseconds");
        }
    }

    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        this.publisher = applicationEventPublisher;
    }

    protected void publish(boolean isSuccess, boolean isEnable) {
        ScheduleEvent se = new ScheduleEvent(this, isSuccess);
        if (isEnable) { publisher.publishEvent(se); }
    }

}
