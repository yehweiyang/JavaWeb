package gov.archives.exchange.schedule.scheduler;


import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import gov.archives.exchange.domain.vo.ReportAdvancedFilter;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.service.ReportDataGenService;
import gov.archives.exchange.service.ReportDataPrepareService;

/**
 * 各類排程程式基本設定 Created by jslee on 2016/8/31.
 */
public abstract class ReportBaseScheduler extends ReportScheduleRecorder {

    private static final String DEFAULT_SORT_COLUMN = "rowIndex";
    private static final Boolean DEFAULT_SORT_DESCENDING = false;
    private static final String DEFAULT_HOUR_FROM = "00";
    private static final String DEFAULT_HOUR_TO = "23";

    protected Boolean isSuccess = true;
    protected Boolean isScheduleCase = true;
    private LocalDate localDate;

    @Value("${SCHEDULE.REPORT.ENABLE}")
    protected Boolean isEnabled;

    @Autowired
    protected ReportDataPrepareService reportDataPrepareService;

    @Autowired
    protected ReportDataGenService reportDataGenService;

    public abstract void excuteSchedule();

    protected ReportBaseFilter initBaseFilterByMonth() {
        return initBaseFilterByMonth(new ReportBaseFilter());
    }

    protected ReportAdvancedFilter initAdvancedilterByMonth() {
        ReportAdvancedFilter reportAdvancedFilter = new ReportAdvancedFilter();

        reportAdvancedFilter = (ReportAdvancedFilter) initBaseFilterByMonth(reportAdvancedFilter);
        reportAdvancedFilter.setTimeFrom(DEFAULT_HOUR_FROM);
        reportAdvancedFilter.setTimeTo(DEFAULT_HOUR_TO);

        return reportAdvancedFilter;
    }

    private ReportBaseFilter initBaseFilterByMonth(ReportBaseFilter reportBaseFilter) {
        localDate = LocalDate.now().withDayOfMonth(1).minusDays(1);

        reportBaseFilter.setDateFrom(localDate.withDayOfMonth(1).toString());
        reportBaseFilter.setDateTo(localDate.toString());
        reportBaseFilter.setSortColumnName(DEFAULT_SORT_COLUMN);
        reportBaseFilter.setSortDescending(DEFAULT_SORT_DESCENDING);

        return reportBaseFilter;
    }

    public void runReportSchedule(Boolean isScheduleCase) {
        this.isScheduleCase = isScheduleCase;
        excuteSchedule();
    }

    protected String getReportMonthFilePath(String reportName) {
        reportDataPrepareService.initAllReportFolder();

        localDate = LocalDate.now();
        String fileName = localDate.minusMonths(1).toString("yyyy-MM") + "_(" + localDate + ")";
        return reportDataPrepareService.getReportMonthFilePath(reportName, fileName);
    }
}
