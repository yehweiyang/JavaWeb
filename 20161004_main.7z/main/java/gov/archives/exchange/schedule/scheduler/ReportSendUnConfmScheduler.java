package gov.archives.exchange.schedule.scheduler;

import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.util.BeanUtils;
import gov.archives.exchange.domain.entity.ReportSendUnConfmResult;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportSendUnConfmFilter;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/9/1.
 */
@Component("rptsendunconfmSchedule")
public class ReportSendUnConfmScheduler extends ReportBaseScheduler {

    private static final String reportName = ReportEnum.REPORT_SEND_UNCONFIRM.toString();

    @Override
    @Scheduled(cron = "${SCHEDULE.REPORT.TRIGGER}")
    public void excuteSchedule() {
        try {
            if (isEnabled) {
                recordTriggerStartMsg(reportName);

                ReportSendUnConfmFilter sendUnConfmFilter = new ReportSendUnConfmFilter();
                BeanUtils.copyProperties(sendUnConfmFilter, initAdvancedilterByMonth());


                List<ReportSendUnConfmResult> sendUnConfmResults =
                        reportDataGenService.getReportSendUnConfmBySendUnConfomFilter(sendUnConfmFilter);

                if (isScheduleCase) {
                    reportDataGenService
                            .saveSearchResult(
                                    getReportMonthFilePath(reportName),
                                    sendUnConfmFilter,
                                    sendUnConfmResults);
                }
            }
        } catch (Exception e) {
            isSuccess = false;
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_BACKGROUND_ERROR, e);
        } finally {
            recordTriggerEndMsg(reportName, isEnabled);
            publish(isSuccess, isEnabled);
        }
    }

}
