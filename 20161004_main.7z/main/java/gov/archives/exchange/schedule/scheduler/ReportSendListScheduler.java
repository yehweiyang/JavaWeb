package gov.archives.exchange.schedule.scheduler;

import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.util.BeanUtils;
import gov.archives.exchange.domain.entity.ReportSendListResult;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportSendListFilter;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/9/1.
 */
@Component("rptsendlistSchedule")
public class ReportSendListScheduler extends ReportBaseScheduler {

    private static final String reportName = ReportEnum.REPORT_SEND_LIST.toString();

    @Override
    @Scheduled(cron = "${SCHEDULE.REPORT.TRIGGER}")
    public void excuteSchedule() {
        try {
            if (isEnabled) {
                recordTriggerStartMsg(reportName);

                ReportSendListFilter sendListFilter = new ReportSendListFilter();
                BeanUtils.copyProperties(sendListFilter, initAdvancedilterByMonth());


                List<ReportSendListResult> sendListResults =
                        reportDataGenService.getReportSendListBySendListFilter(sendListFilter);

                if (isScheduleCase) {
                    reportDataGenService
                            .saveSearchResult(
                                    getReportMonthFilePath(reportName),
                                    sendListFilter,
                                    sendListResults);
                }
            }
        } catch (Exception e) {
            isSuccess = false;
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_BACKGROUND_ERROR, e);
        } finally {
            recordTriggerEndMsg(reportName, isEnabled);
            publish(isSuccess, isEnabled);
        }
    }

}
