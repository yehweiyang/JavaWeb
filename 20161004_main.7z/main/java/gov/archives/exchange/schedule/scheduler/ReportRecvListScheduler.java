package gov.archives.exchange.schedule.scheduler;

import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.util.BeanUtils;
import gov.archives.exchange.domain.entity.ReportRecvListResult;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportRecvListFilter;

/**
 * Created by jslee on 2016/9/1.
 */
@Component("rptrecvlistSchedule")
public class ReportRecvListScheduler extends ReportBaseScheduler {

    private static final String reportName = ReportEnum.REPORT_RECEIVE_LIST.toString();

    @Override
    @Scheduled(cron = "${SCHEDULE.REPORT.TRIGGER}")
    public void excuteSchedule() {
        try {
            if (isEnabled) {
                recordTriggerStartMsg(reportName);

                ReportRecvListFilter recvListFilter = new ReportRecvListFilter();
                BeanUtils.copyProperties(recvListFilter, initAdvancedilterByMonth());

                List<ReportRecvListResult> recvListResults =
                        reportDataGenService.getReportRecvListByRecvListFilter(recvListFilter);

                if (isScheduleCase) {
                    reportDataGenService
                            .saveSearchResult(
                                    getReportMonthFilePath(reportName),
                                    recvListFilter,
                                    recvListResults);
                }
            }
        } catch (Exception e) {
            isSuccess = false;
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_BACKGROUND_ERROR, e);
        } finally {
            recordTriggerEndMsg(reportName, isEnabled);
            publish(isSuccess, isEnabled);
        }
    }

}
