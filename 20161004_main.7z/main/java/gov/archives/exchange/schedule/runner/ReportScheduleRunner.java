package gov.archives.exchange.schedule.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.schedule.helper.ReportScheduleHelper;
import gov.archives.exchange.schedule.scheduler.ReportBaseScheduler;

/**
 * Created by jslee on 2016/9/1.
 */
@Configuration
@EnableScheduling
public class ReportScheduleRunner {

    @Autowired
    private ReportScheduleHelper reportScheduleHelper;

    /*PRN001*/
    @Bean
    public ReportBaseScheduler runReportSendRankScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_SEND_RANK.toString());
    }

    /*PRN004*/
    @Bean
    public ReportBaseScheduler runReportSendErrScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_SEND_ERR.toString());
    }

    /*PRN005*/
    @Bean
    public ReportBaseScheduler runReportSendStateScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_SEND_STATE.toString());
    }

    /*PRN006*/
    @Bean
    public ReportBaseScheduler runReportSendListScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_SEND_LIST.toString());
    }

    /*PRN007*/
    @Bean
    public ReportBaseScheduler runReportSendUnConfmScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_SEND_UNCONFIRM.toString());
    }

    /*PRN008*/
    @Bean
    public ReportBaseScheduler runReportSendErrListScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_SEND_ERR_LIST.toString());
    }

    /*PRN009*/
    @Bean
    public ReportBaseScheduler runReportRecvStateScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_RECEIVE_STATE.toString());
    }

    /*PRN010*/
    @Bean
    public ReportBaseScheduler runReportRecvListScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_RECEIVE_LIST.toString());
    }

    /*PRN011*/
    @Bean
    public ReportBaseScheduler runReportRecvErrListScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_RECEIVE_ERR_LIST.toString());
    }

    /*PRN012*/
    @Bean
    public ReportBaseScheduler runReportConfirmedRateScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_CONFIRMED_QUERY.toString());
    }

    /*PRN013*/
    @Bean
    public ReportBaseScheduler runReportODFSendRateScheduler() {
        return reportScheduleHelper.getReportScheduler(ReportEnum.REPORT_ODF_SEND_RATE.toString());
    }
}
