package gov.archives.exchange.event;

import java.sql.Timestamp;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.ExceptionMessage;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.util.LogUtils;

/**
 * Created by kshsu on 2016/9/20.
 */
public class ArchivesExceptionEvent extends BaseEvent {

    private static final Logger log = LoggerFactory.getLogger(ArchivesExceptionEvent.class);

    private static final String EVENT_NAME = "ArchivesExceptionEvent";

    private ExceptionMessage exceptionMessage;

    private Throwable cause;

    private HttpServletRequest httpServletRequest;

    public ArchivesExceptionEvent(Object source) {
        super(source);
    }

    public ArchivesExceptionEvent(Object source, String errorMessage, String errorCode, Object... objects) {
        super(source);
        this.exceptionMessage = initExceptionMessage(errorMessage, errorCode);

        this.cause = initThrowable(objects);
        this.httpServletRequest = initHttpServletRequest(objects);
    }

    public ArchivesExceptionEvent(Object source, String errorCodeOrMessage, Object... objects) {
        super(source);
        this.exceptionMessage = initExceptionMessage(errorCodeOrMessage);

        this.cause = initThrowable(objects);
        this.httpServletRequest = initHttpServletRequest(objects);
    }

    @Override
    public String toString() {
        return EVENT_NAME;
    }

    @Override
    public void logEvent() {
        Timestamp actionTime = new Timestamp(System.currentTimeMillis());

        String remoteIp = getIp();

        String actionItem = (null != source ? source.getClass().getName() : CoreConf.ACTION_ITEM_INNER);

        String actorAccount = (null != httpServletRequest ?
                (StringUtils.isEmpty(httpServletRequest.getRemoteUser()) ?
                        CoreConf.ACTOR_ACCOUNT_SYSTEM : httpServletRequest.getRemoteUser()) :
                CoreConf.ACTOR_ACCOUNT_SYSTEM);

        String actionResult = StringUtils.isEmpty(exceptionMessage.getErrorMessage()) ?
                LogUtils.getErrorMessage(CoreErrorCode.SYSTEM_ERROR) :
                exceptionMessage.getErrorMessage();

        String errorCode = StringUtils.isEmpty(exceptionMessage.getErrorCode()) ?
                CoreErrorCode.SYSTEM_ERROR : exceptionMessage.getErrorCode();

        String eventLevel =
                CoreErrorCode.SYSTEM_ERROR.equals(LogUtils.getErrorCodeIfExist(exceptionMessage.getErrorCode())) ?
                        CoreConf.EVENT_LEVEL_HIGH : CoreConf.EVENT_LEVEL_MEDIUM;
        String logMessage = actionTime + "," +
                remoteIp + "," +
                actionItem + "," +
                actorAccount + "," +
                actionResult + "," +
                errorCode + "," +
                eventLevel;

        if (null == cause) {
            LogUtils.logException(logMessage);
        } else {
            LogUtils.logException(logMessage, cause);
        }
    }

    private ExceptionMessage initExceptionMessage(String errorCodeOrMessage) {
        return ExceptionMessage.getInstanceByCodeAndMessage(
                LogUtils.getErrorCodeIfExist(errorCodeOrMessage), LogUtils.getErrorMessage(errorCodeOrMessage));
    }

    private ExceptionMessage initExceptionMessage(String errorMessage, String errorCode) {
        return ExceptionMessage.getInstanceByCodeAndMessage(errorCode, errorMessage);
    }

    private HttpServletRequest initHttpServletRequest(Object[] objects) {
        for (Object obj : objects) {
            if (obj instanceof HttpServletRequest) {
                return (HttpServletRequest) obj;
            }
        }
        return null;
    }

    private Throwable initThrowable(Object[] objects) {
        for (Object obj : objects) {
            if (obj instanceof Throwable) {
                return (Throwable) obj;
            }
        }
        return null;
    }

    private String getIp() {
        String ip = "";
        if (null != httpServletRequest) {
            ip = httpServletRequest.getRemoteAddr();
        }
        return StringUtils.isEmpty(ip) ? CoreConf.ACTOR_ACCOUNT_SYSTEM : ip;
    }
}
