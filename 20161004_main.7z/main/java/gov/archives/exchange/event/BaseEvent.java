package gov.archives.exchange.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEvent;

/**
 * Created by kshsu on 2016/9/7.
 */
public class BaseEvent extends ApplicationEvent {

    private static final Logger log = LoggerFactory.getLogger(BaseEvent.class);

    private static final String EVENT_NAME = "BaseEvent";

    protected String EVENT_OCCUR = EVENT_NAME + " is occur!";

    protected String EXCUTE_RESULT = "excute result";

    public BaseEvent(Object source) {
        super(source);
    }

    @Override
    public String toString() {
        return EVENT_NAME;
    }

    public void logEvent() {
        log.info(EVENT_OCCUR);
    }

}
