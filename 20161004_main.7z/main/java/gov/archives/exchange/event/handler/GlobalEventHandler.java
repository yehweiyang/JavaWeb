package gov.archives.exchange.event.handler;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import gov.archives.exchange.event.ArchivesExceptionEvent;
import gov.archives.exchange.event.ScheduleEvent;

/**
 * Created by kshsu on 2016/9/7.
 */
@Component
public class GlobalEventHandler implements ApplicationListener<ApplicationEvent> {

    @Override
    public void onApplicationEvent(ApplicationEvent event) {
        if (event instanceof ScheduleEvent) {
            ((ScheduleEvent) event).logEvent();
        } else if (event instanceof ArchivesExceptionEvent) {
            ((ArchivesExceptionEvent) event).logEvent();
        }
    }
}
