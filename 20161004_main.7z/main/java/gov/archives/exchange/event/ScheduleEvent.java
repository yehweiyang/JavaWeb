package gov.archives.exchange.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.archives.exchange.conf.ReportConf;

/**
 * Created by kshsu on 2016/9/7.
 */
public class ScheduleEvent extends BaseEvent {

    private static final Logger log = LoggerFactory.getLogger(ScheduleEvent.class);

    private static final String EVENT_NAME = "ScheduleEvent";

    private boolean isSuccess;

    public ScheduleEvent(Object source) {
        super(source);
    }

    public ScheduleEvent(Object source, boolean isSuccess) {
        super(source);
        this.isSuccess = isSuccess;
    }

    @Override
    public String toString() {
        return EVENT_NAME;
    }

    @Override
    public void logEvent() {
        log.info(EVENT_NAME + ": " + source.getClass().getSimpleName() + " " +
                EXCUTE_RESULT + ": " +
                (this.isSuccess ? ReportConf.EVENT_SUCCESS : ReportConf.EVENT_FAIL));
    }
}
