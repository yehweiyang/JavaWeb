# gov.archives.exchange

負責處理 eManager 核心業務：交換歷程與報表

使用 g2b2c_2017 的 main_info 與 detail_info 兩個資料表