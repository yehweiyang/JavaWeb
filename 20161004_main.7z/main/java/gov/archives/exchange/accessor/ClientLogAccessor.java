package gov.archives.exchange.accessor;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.springframework.stereotype.Service;

import org.iii.common.conf.CommonConfig;
import org.iii.common.util.IOUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ExchangeConf;
import gov.archives.exchange.domain.entity.SmtpConfigEntity;

/**
 * ClientLogAccessor <br> (尚未描述類別目的與用途) <br> gemhuang, 2016/9/1.
 */
@Service
public class ClientLogAccessor {

    private static Properties prop;

    public List<String> getLocationAllFile(String orgId, String certHash) throws IOException {
        String path = ExchangeConf.getClientLogLocation() + orgId + "/" + certHash + "/";
        if (!IOUtils.isFolderExist(path)) {
            new File(path).mkdirs();
        }
        List<String> prepareLocationFileNames = new ArrayList<>();
        Files.walk(Paths.get(path)).forEach(currentFile -> {
            if (Files.isRegularFile(currentFile)) {
                prepareLocationFileNames.add(currentFile.getFileName().toString());
            }
        });
        return prepareLocationFileNames;
    }

    public InputStream getLocationFile(String orgId, String certHash, String fileName) {
        String filePath = ExchangeConf.getClientLogLocation() + orgId + "/" + certHash + "/" + fileName;
        File download = new File(filePath);
        try {
            InputStream inputStream = new BufferedInputStream(new FileInputStream(download));
            return inputStream;
        } catch (FileNotFoundException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.LOG_FILE_ERROR);
        }
    }

    public void updateSmtpConfigProperties(SmtpConfigEntity smtpConfigEntity) {
        try {
            File mailServerPropertiesFile = CommonConfig.getRuntimeRoot(ClientLogAccessor.class)
                    .resolve(ExchangeConf.RESOURCES_PATH)
                    .resolve(ExchangeConf.SMTP_PROPERTIES).toFile();

            OutputStream fos = new FileOutputStream(mailServerPropertiesFile);
            prop = new Properties();
            prop.put(ExchangeConf.SMTP_SERVER_IP, smtpConfigEntity.getSmtpServerIp());
            prop.put(ExchangeConf.SMTP_SERVER_PORT, smtpConfigEntity.getSmtpServerPort());
            prop.put(ExchangeConf.SMTP_LOGIN_ACCOUNT, smtpConfigEntity.getLoginAccount());
            prop.put(ExchangeConf.SMTP_LOGIN_PASSWORD, smtpConfigEntity.getLoginPassword());
            prop.put(ExchangeConf.SMTP_LAST_UPDATE, smtpConfigEntity.getLastUpdateTime());
            prop.put(ExchangeConf.IS_USE_SSL, smtpConfigEntity.getUseSsl());
            prop.put(ExchangeConf.IS_NEED_CERTIFICATION, smtpConfigEntity.getCertification());
            prop.store(fos, "SMTP Config 設定");
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
