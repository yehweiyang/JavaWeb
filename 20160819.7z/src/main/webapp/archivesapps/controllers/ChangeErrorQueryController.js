angular.module('ArchivesApp').controller('ChangeErrorQueryController', function($rootScope, $scope, $http) {

$scope.query=function() {
var error = $scope.error;
$scope.userList = [];
    $http.get('/manageWeb/v1/change/error').then(function(response) {
     $scope.userList = response.data;
      console.log($scope.userList)
    })

//console.log($scope.error.sendOrganName);
//console.log($scope.error.sendOrganId);
//console.log($scope.error.receiverOrgName);
//console.log($scope.error.receiverOrgId);
//console.log($scope.error.processId);
//console.log($scope.error.exchangeId);
//console.log($scope.error.startNo);
//console.log($scope.error.endNo);


 }
 $scope.reset=function() {
$scope.error ='';
 }
var initDates = function() {
$scope.startTimes=[];
    var i;
    for (i = 0;i <24; i++) {
      $scope.startTimes.push(i);
    }
    $scope.endTimes=[];
        var i;
        for (i = 0;i <24; i++) {
          $scope.endTimes.push(i);
        }
//     $scope.times = ['01','02','03','04']
  }

  initDates();

            $scope.openDateFromCalendar = function() {
    	$scope.dateFromCalendar.opened = true;
    };


               $scope.openDateToCalendar = function() {
    	$scope.dateToCalendar.opened = true;
    };
    $scope.dateFromCalendar = {
    	opened: false
    };

    $scope.dateToCalendar = {
        opened: false
    };

});
/*
$scope.save=function(query) {
var query  = $scope.query;
if(typeof query!='undefined'){
console.log('發文機關名稱     ==>'+$scope.query.sendOrganName  )
console.log('發文機關代碼    ==>'+$scope.query.sendOrganId   )
console.log('收文機關名稱    ==>'+$scope.query.catchOrganName   )
console.log('收文機關代碼    ==>'+$scope.query.catchOrganId   )
console.log('處理序號    ==>'+$scope.query.processNo   )
console.log('交換編號    ==>'+$scope.query.changeNo   )
console.log('文號1    ==>'+$scope.query.startNo   )
console.log('文號2    ==>'+$scope.query.endNo   )
//console.log('來源eposition    ==>'+$scope.query.   )
console.log('上傳時間1    ==>'+$scope.query.dateFrom   )
console.log('上傳小時1    ==>'+$scope.query.startTime   )
console.log('上傳時間2    ==>'+$scope.query.dateTo   )
console.log('上傳小時2    ==>'+$scope.query.endTime   )
}
 }

*/