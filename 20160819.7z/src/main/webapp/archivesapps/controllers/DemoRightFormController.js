angular.module("ArchivesApp").controller('DemoRightFormController', function($scope, $http) {
    $('.selectpicker').selectpicker();
    $('.archives-checkbox').checkboxpicker();
});
