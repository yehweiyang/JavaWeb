$(function(){
    includeOtherScript("frontDemoService");
});

angular.module("ArchivesApp").controller('DemoFormAdvancedV1Controller', function($scope, $http, frontDemo) {
    $scope.frontDemo = frontDemo;
    $scope.toggleCalendar = function (datePickerId) {
        $scope[datePickerId] = $scope.frontDemo.toggleCalendar($scope[datePickerId]);
    };

    $scope.initLoop = function() {
        return new Array(10);
    };

    $scope.toggleException = function() {
        $scope.showException = $scope.showException === 'undefined' ? true : !$scope.showException;
        $scope.btnExceptionText = $scope.btnExceptionText === "顯示異常訊息" ? "隱藏異常訊息" : "顯示異常訊息";
    };

    $('.archives-checkbox').checkboxpicker();

    $scope.btnExceptionText = "顯示異常訊息";

});
