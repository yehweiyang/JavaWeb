$(function(){
    includeOtherScript("frontDemoService");
});

angular.module("ArchivesApp").controller('DemoFormController', function($scope, $http, frontDemo) {
    $scope.reportUtil = frontDemo;
    $scope.toggleCalendar = function (datePickerId) {
        $scope[datePickerId] = $scope.frontDemo.toggleCalendar($scope[datePickerId]);
    };

    $scope.initLoop = function() {
        $('.archives-checkbox').checkboxpicker();
        return new Array(10);
    };
});
