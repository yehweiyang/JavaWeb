ArchivesApp.service('frontDemo', function(){
    this.getToday = function() {
        return new Date();
    };

    this.toggleCalendar = function(datePicker) {
        return datePicker = { opened : typeof datePicker === 'undefined' ? true : !datePicker.opened  };
    };
});