function includeOtherScript(yourScriptName) {
    if (typeof yourScriptName === 'string' && $('#' + yourScriptName).length === 0) {
        $('head').append($("<script></script>").attr({
            id : yourScriptName,
            src : $('#ng_load_plugins_before').attr("value") + "/archivesapps/assets/js/" + yourScriptName + ".js",
            type : "text/javascript"
        }));
    }
}