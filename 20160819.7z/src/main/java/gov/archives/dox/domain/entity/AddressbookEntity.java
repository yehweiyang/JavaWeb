package gov.archives.dox.domain.entity;

import org.apache.ibatis.type.Alias;

import gov.archives.core.domain.entity.BaseEntity;

/**
 * AddressbookEntity
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@Alias("Addressbook")
public class AddressbookEntity extends BaseEntity {
    private String centerId;
    private String orgId;
    private String unitId;
    private String orgUnitName;
    private String orgUnitAddress;
    private String orgUnitPhone;
    private String orgUnitFax;
    private String orgUnitUrl;
    private String adminName;
    private String adminEmail;
    private String adminMobile;
    private Integer activeStatus;
    private String relatedOrgUnitId;
    private String signCertSerialNum;
    private String encryptCertSerialNum;
    private String cryptoType;
    private String pbSerial;

    public String getCenterId() {
        return centerId;
    }

    public String getOrgId() {
        return orgId;
    }

    public String getUnitId() {
        return unitId;
    }

    public String getOrgUnitName() {
        return orgUnitName;
    }

    public String getOrgUnitAddress() {
        return orgUnitAddress;
    }

    public String getOrgUnitPhone() {
        return orgUnitPhone;
    }

    public String getOrgUnitFax() {
        return orgUnitFax;
    }

    public String getOrgUnitUrl() {
        return orgUnitUrl;
    }

    public String getAdminName() {
        return adminName;
    }

    public String getAdminEmail() {
        return adminEmail;
    }

    public String getAdminMobile() {
        return adminMobile;
    }

    public Integer getActiveStatus() {
        return activeStatus;
    }

    public String getRelatedOrgUnitId() {
        return relatedOrgUnitId;
    }

    public String getSignCertSerialNum() {
        return signCertSerialNum;
    }

    public String getEncryptCertSerialNum() {
        return encryptCertSerialNum;
    }

    public String getCryptoType() {
        return cryptoType;
    }

    public String getPbSerial() {
        return pbSerial;
    }

    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }

    public void setOrgUnitName(String orgUnitName) {
        this.orgUnitName = orgUnitName;
    }

    public void setOrgUnitAddress(String orgUnitAddress) {
        this.orgUnitAddress = orgUnitAddress;
    }

    public void setOrgUnitPhone(String orgUnitPhone) {
        this.orgUnitPhone = orgUnitPhone;
    }

    public void setOrgUnitFax(String orgUnitFax) {
        this.orgUnitFax = orgUnitFax;
    }

    public void setOrgUnitUrl(String orgUnitUrl) {
        this.orgUnitUrl = orgUnitUrl;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public void setAdminEmail(String adminEmail) {
        this.adminEmail = adminEmail;
    }

    public void setAdminMobile(String adminMobile) {
        this.adminMobile = adminMobile;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

    public void setRelatedOrgUnitId(String relatedOrgUnitId) {
        this.relatedOrgUnitId = relatedOrgUnitId;
    }

    public void setSignCertSerialNum(String signCertSerialNum) {
        this.signCertSerialNum = signCertSerialNum;
    }

    public void setEncryptCertSerialNum(String encryptCertSerialNum) {
        this.encryptCertSerialNum = encryptCertSerialNum;
    }

    public void setCryptoType(String cryptoType) {
        this.cryptoType = cryptoType;
    }

    public void setPbSerial(String pbSerial) {
        this.pbSerial = pbSerial;
    }

    public static class Builder {
        public static synchronized Builder create() {
            return new Builder();
        }

        private AddressbookEntity addressbook;
        private Builder self;

        private Builder() {
            this.addressbook = new AddressbookEntity();
            this.self = this;
        }

        public Builder setCenterId(String centerId) {
            this.addressbook.centerId = centerId;

            return self;
        }

        public Builder setOrgId(String orgId) {
            this.addressbook.orgId = orgId;

            return self;
        }

        public Builder setUnitId(String unitId) {
            this.addressbook.unitId = unitId;

            return self;
        }

        public Builder setOrgUnitName(String orgUnitName) {
            this.addressbook.orgUnitName = orgUnitName;

            return self;
        }

        public Builder setOrgUnitAddress(String orgUnitAddress) {
            this.addressbook.orgUnitAddress = orgUnitAddress;

            return self;
        }

        public Builder setOrgUnitPhone(String orgUnitPhone) {
            this.addressbook.orgUnitPhone = orgUnitPhone;

            return self;
        }

        public Builder setOrgUnitFax(String orgUnitFax) {
            this.addressbook.orgUnitFax = orgUnitFax;

            return self;
        }

        public Builder setOrgUnitUrl(String orgUnitUrl) {
            this.addressbook.orgUnitUrl = orgUnitUrl;

            return self;
        }

        public Builder setAdminName(String adminName) {
            this.addressbook.adminName = adminName;

            return self;
        }

        public Builder setAdminEmail(String adminEmail) {
            this.addressbook.adminEmail = adminEmail;

            return self;
        }

        public Builder setAdminMobile(String adminMobile) {
            this.addressbook.adminMobile = adminMobile;

            return self;
        }

        public Builder setActiveStatus(Integer activeStatus) {
            this.addressbook.activeStatus = activeStatus;

            return self;
        }

        public Builder setRelatedOrgUnitId(String relatedOrgUnitId) {
            this.addressbook.relatedOrgUnitId = relatedOrgUnitId;

            return self;
        }

        public Builder setSignCertSerialNum(String signCertSerialNum) {
            this.addressbook.signCertSerialNum = signCertSerialNum;

            return self;
        }

        public Builder setEncryptCertSerialNum(String encryptCertSerialNum) {
            this.addressbook.encryptCertSerialNum = encryptCertSerialNum;

            return self;
        }

        public Builder setCryptoType(String cryptoType) {
            this.addressbook.cryptoType = cryptoType;

            return self;
        }

        public Builder setPbSerial(String pbSerial) {
            this.addressbook.pbSerial = pbSerial;

            return self;
        }

        public Builder initSave(String creator) {
            this.addressbook.initSave(creator);

            return self;
        }

        public AddressbookEntity build() {
            return this.addressbook;
        }
    }
}
