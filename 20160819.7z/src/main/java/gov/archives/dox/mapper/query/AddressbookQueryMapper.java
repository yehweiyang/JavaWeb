package gov.archives.dox.mapper.query;

import java.util.Map;

import gov.archives.dox.domain.entity.AddressbookEntity;

/**
 * AddressbookQueryMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
public interface AddressbookQueryMapper {
    String KEY_ORG_ID = "orgId";
    String KEY_UNIT_ID = "unitId";

    AddressbookEntity findByOrgUnitId(Map<String, String> queryMap);
}
