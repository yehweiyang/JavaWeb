package gov.archives.dox.service;

import gov.archives.dox.domain.entity.AddressbookEntity;

/**
 * AddressbookService
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
public interface AddressbookService {

    AddressbookEntity getByOrgUnitId(String orgId, String unitId);
}
