package gov.archives.dox.service.impl;

import java.util.Map;

import com.google.common.collect.ImmutableMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import org.iii.common.util.PreconditionUtils;

import gov.archives.dox.conf.DoxConf;
import gov.archives.dox.domain.entity.AddressbookEntity;
import gov.archives.dox.mapper.query.AddressbookQueryMapper;
import gov.archives.dox.service.AddressbookService;

/**
 * AddressbookServiceImpl
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@Service
@Transactional
public class AddressbookServiceImpl implements AddressbookService {

    @Autowired
    private AddressbookQueryMapper queryMapper;

    @Override
    @Transactional(value = DoxConf.QUERY_TX_MANAGER,
            readOnly = true)
    public AddressbookEntity getByOrgUnitId(String orgId, String unitId) {
        PreconditionUtils.checkArguments(orgId, unitId);

        Map<String, String> queryMap = new ImmutableMap.Builder<String, String>()
                .put(AddressbookQueryMapper.KEY_ORG_ID, orgId)
                .put(AddressbookQueryMapper.KEY_UNIT_ID, unitId)
                .build();

        return queryMapper.findByOrgUnitId(queryMap);
    }
}
