package gov.archives.core.security;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;

public class RestAuthenticationDetailsSource extends WebAuthenticationDetailsSource {
    @Override
    public WebAuthenticationDetails buildDetails(HttpServletRequest context) {
        return new RestAuthenticationDetails(context);
    }

	private class RestAuthenticationDetails extends WebAuthenticationDetails {
		private static final long serialVersionUID = -2375726621288579580L;

		public RestAuthenticationDetails(HttpServletRequest request) {
            super(request);
        }
    }
}
