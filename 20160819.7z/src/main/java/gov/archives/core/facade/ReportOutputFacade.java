package gov.archives.core.facade;

import gov.archives.core.domain.vo.ReportInputModel;
import gov.archives.core.exception.RestApplicationException;

/**
 * Created by kshsu on 2016/7/26.
 */
public interface ReportOutputFacade {

    public void genReportToFile(ReportInputModel reportInputModel) throws RestApplicationException;

    public void genReportToStream(ReportInputModel reportInputModel) throws RestApplicationException;

    public void genReportToByteArray(ReportInputModel reportInputModel) throws RestApplicationException;
}
