package gov.archives.core.message;

/**
 * Created by 140631 on 2016/7/26.
 */
public class CoreErrorMessage {
}
