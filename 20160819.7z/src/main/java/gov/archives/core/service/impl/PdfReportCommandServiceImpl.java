package gov.archives.core.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import org.iii.common.util.StringUtils;

import gov.archives.core.command.PdfReportCommandProcessor;
import gov.archives.core.command.ReportCommand;
import gov.archives.core.command.ReportCommandProcessor;
import gov.archives.core.exception.ReportException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.service.ReportCommandService;

/**
 * Created by kshsu on 2016/7/26.
 */
@Service("pdfCommandService")
public class PdfReportCommandServiceImpl implements ReportCommandService {

    private static final Logger log = LoggerFactory.getLogger(PdfReportCommandServiceImpl.class);

    private Map<String, ReportCommand> commands = new HashMap<String, ReportCommand>();

    private ReportCommandProcessor reportCommandProcessor = new PdfReportCommandProcessor();

    @Override
    public void addCommand(String process, ReportCommand command) {
        commands.put(process, command);
    }

    @Override
    public void doProcess(String process) throws RestApplicationException {
        try {
            commands.get(process).execute(reportCommandProcessor);
        } catch (ReportException ex) {
            log.error("CAUSE: " + StringUtils.stackTraceFromException(ex));
            throw new RestApplicationException((null != ex.getMessage() ? ex.getMessage() : "no message"), ex);
        }
    }
}
