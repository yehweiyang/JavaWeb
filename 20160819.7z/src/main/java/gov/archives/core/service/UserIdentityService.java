package gov.archives.core.service;

import java.io.File;
import java.util.UUID;

import org.springframework.security.core.AuthenticationException;

import gov.archives.core.domain.vo.SignCertData;
import gov.archives.core.domain.vo.VerifyResult;

public interface UserIdentityService {

	void userLoginIdentity(SignCertData signCert, File file, String signCertHash, UUID uuid, long lastAccessedTime);

	String saveRequestCertificate(String base64Cert, File file, String fileName, long lastAccessedTime);
	
	void certifiedSmartCardSignature(SignCertData signCert);
	
	VerifyResult userIdentityException(AuthenticationException e);

	void cleanSignCertFile(File certFile);
}
