package gov.archives.core.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.mapper.command.ActionLogCommandMapper;
import gov.archives.core.mapper.query.ActionLogQueryMapper;
import gov.archives.core.service.ActionLogService;

/**
 * ActionLogServiceImpl
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@Service
@Transactional
public class ActionLogServiceImpl implements ActionLogService {

    @Autowired
    private ActionLogCommandMapper commandMapper;

    @Autowired
    private ActionLogQueryMapper queryMapper;

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void insert(ActionLogEntity actionLog) {
        PreconditionUtils.checkArguments(actionLog);

        commandMapper.save(actionLog);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void delete(ActionLogEntity actionLog) {
        PreconditionUtils.checkArguments(actionLog);

        commandMapper.remove(actionLog);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public ActionLogEntity getLastLogInByAccount(String actorAccount) {
        PreconditionUtils.checkArguments(actorAccount);

        return queryMapper.lastLogInByAccount(actorAccount);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public ActionLogEntity getLogInCountByAccount(String actorAccount) {
        PreconditionUtils.checkArguments(actorAccount);

        return queryMapper.logInCountByAccount(actorAccount);
    }
}
