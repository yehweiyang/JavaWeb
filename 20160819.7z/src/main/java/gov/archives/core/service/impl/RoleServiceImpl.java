package gov.archives.core.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.entity.RoleMenuMappingEntity;
import gov.archives.core.domain.vo.RoleMenuMapping;
import gov.archives.core.domain.vo.RoleName;
import gov.archives.core.mapper.command.RoleCommandMapper;
import gov.archives.core.mapper.command.RoleMenuMappingCommandMapper;
import gov.archives.core.mapper.query.RoleMenuMappingQueryMapper;
import gov.archives.core.mapper.query.RoleQueryMapper;
import gov.archives.core.service.MenuService;
import gov.archives.core.service.RoleService;

/**
 * RoleServiceImpl
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@Service
@Transactional
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleQueryMapper roleQueryMapper;

    @Autowired
    private RoleCommandMapper roleCommandMapper;

    @Autowired
    private RoleMenuMappingCommandMapper roleMenuCommandMapper;

    @Autowired
    private RoleMenuMappingQueryMapper roleMenuQueryMapper;

    @Autowired
    private MenuService menuService;

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public RoleEntity getBySysId(UUID sysId) {
        PreconditionUtils.checkArguments(sysId);

        return roleQueryMapper.findById(sysId);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public RoleEntity getByRoleName(String roleName) {
        PreconditionUtils.checkArguments(roleName);

        return roleQueryMapper.findByRoleName(roleName);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public RoleMenuMapping getMenuMappingByRoleName(String roleName) {
        PreconditionUtils.checkArguments(roleName);

        List<RoleMenuMappingEntity> mappingEntities = roleMenuQueryMapper.findByRoleName(roleName);

        return mapRoleMenuMappingEntitiesToVo(mappingEntities);
    }

    private RoleMenuMapping mapRoleMenuMappingEntitiesToVo(List<RoleMenuMappingEntity> mappingEntities) {
        RoleMenuMapping mapping = new RoleMenuMapping();

        if (null != mappingEntities && !mappingEntities.isEmpty()) {
            RoleMenuMappingEntity first = mappingEntities.get(0);

            mapping.setRole(getBySysId(first.getRoleSysId()));

            mappingEntities.stream().forEach(entity -> mapping.addMenu(menuService.getBySysId(entity.getMenuSysId())));
        }

        return mapping;
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public RoleMenuMapping getMenuMappingByRoleSysId(UUID roleSysId) {
        PreconditionUtils.checkArguments(roleSysId);

        List<RoleMenuMappingEntity> mappingEntities = roleMenuQueryMapper.findByRoleSysId(roleSysId);

        return mapRoleMenuMappingEntitiesToVo(mappingEntities);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void insert(RoleEntity role) {
        PreconditionUtils.checkArguments(role);

        roleCommandMapper.save(role);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void update(RoleEntity role) {
        PreconditionUtils.checkArguments(role);

        roleCommandMapper.update(role);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void delete(RoleEntity role) {
        PreconditionUtils.checkArguments(role);

        roleCommandMapper.remove(role);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void updateRoleMenuMapping(RoleMenuMapping mapping) {
        PreconditionUtils.checkArguments(mapping);

        deleteMenuMapping(mapping.getRole());

        List<RoleMenuMappingEntity> mappingEntities = collectRoleMenuMappingFromVo(mapping);

        if (null != mappingEntities && !mappingEntities.isEmpty()) {
            mappingEntities.stream().forEach(entity -> roleMenuCommandMapper.save(entity));
        }
    }

    private List<RoleMenuMappingEntity> collectRoleMenuMappingFromVo(RoleMenuMapping mapping) {
        List<RoleMenuMappingEntity> entities = new ArrayList<>();

        RoleEntity role = mapping.getRole();
        String creator = mapping.getCreatorAccount();
        mapping.getMenus()
               .stream()
               .forEach(menu -> entities
                       .add(getRoleMenuMappingEntityByRoleSysIdAndMenuSysIdAndCreator(role.getSysId(), menu.getSysId(),
                               creator)));

        return entities;
    }

    private RoleMenuMappingEntity getRoleMenuMappingEntityByRoleSysIdAndMenuSysIdAndCreator(UUID roleSysId,
            UUID menuSysId, String creator) {
        RoleMenuMappingEntity entity = RoleMenuMappingEntity.getInstanceByRoleSysIdAndMenuSysId(roleSysId, menuSysId);

        entity.initSave(creator);

        return entity;
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void deleteMenuMapping(RoleEntity role) {
        PreconditionUtils.checkArguments(role);

        roleMenuCommandMapper.removeByRoleSysId(role.getSysId());
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<RoleName> listRoleName() {
        List<RoleEntity> roleEntityList = roleQueryMapper.list();
        List<RoleName> roleNameList = new ArrayList<>();
        for (RoleEntity roleEntity : roleEntityList) {
            RoleName roleName = new RoleName();
            BeanUtils.copyProperties(roleEntity, roleName);
            roleNameList.add(roleName);
        }

        return roleNameList;
    }
}
