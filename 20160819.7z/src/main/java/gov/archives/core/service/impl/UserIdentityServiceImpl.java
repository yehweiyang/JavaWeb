package gov.archives.core.service.impl;

import java.io.File;
import java.util.Date;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Service;
import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.SignCertData;
import gov.archives.core.domain.vo.VerifyResult;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.security.DigitalSignHandle;
import gov.archives.core.service.UserIdentityService;

@Service
public class UserIdentityServiceImpl implements UserIdentityService {
    private static final Logger log = LoggerFactory.getLogger(UserIdentityServiceImpl.class);

    @Autowired
    private DigitalSignHandle pkcs1Handle;

    @Override
    public void userLoginIdentity(SignCertData signCert, File file, String signCertHash, UUID uuid,
            long lastAccessedTime) {
        pkcs1Handle.initDigitalSignCertData(signCert);
        if (file.exists()) {
            pkcs1Handle.readCertFile(file);
            if (pkcs1Handle.isCredentialsExpired(new Date(lastAccessedTime))) {
                throw new BadCredentialsException(CoreErrorCode.CODE_CARD_EXPIRED);
            }
        } else {
            throw new BadCredentialsException(CoreErrorCode.CODE_CARD_NOT_AVAILABLE);
        }

        String signSH256Hash = pkcs1Handle.getCertSHA256Hash();
        if (!signCertHash.equals(signSH256Hash)) {
            throw new BadCredentialsException(CoreErrorCode.CODE_CARD_NOT_MATCH_DATA);
        }

        if (!uuid.toString()
                 .equals(signCert.getToken()) || !pkcs1Handle.verifySignature()) {
            throw new BadCredentialsException(CoreErrorCode.CODE_SIGNATURE_ERROR);
        }
    }

    @Override
    public String saveRequestCertificate(String base64Cert, File file, String fileName, long lastAccessedTime) {
        pkcs1Handle.transBase64CertIntoX509Cert(base64Cert);
        if (pkcs1Handle.isCredentialsExpired(new Date(lastAccessedTime))) {
            throw new CredentialsExpiredException(CoreErrorCode.CODE_CARD_EXPIRED);
        }
		File certPath = file.toPath().resolve(CoreConf.CERT_FOLDER).toFile();
		File resultFile = new File(certPath, fileName + CoreConf.SUFFIX_CERT);
		if (!IOUtils.isFileExist(resultFile)) {
	        FileSystemUtils.checkFolder(certPath);
			pkcs1Handle.saveCertFile(resultFile);
		}
        return pkcs1Handle.getCertSHA256Hash();
    }

    @Override
    public void certifiedSmartCardSignature(SignCertData signCert) {
        pkcs1Handle.initDigitalSignCertData(signCert);
        pkcs1Handle.transBase64CertIntoX509Cert(signCert.getB64SignCert());
        if (!pkcs1Handle.verifySignature()) {
            throw new RuntimeException(HttpStatus.METHOD_NOT_ALLOWED.toString());
        }
    }

    @Override
    public void cleanSignCertFile(File certFile) {
        IOUtils.deleteFile(certFile);
    }

    @Override
    public VerifyResult userIdentityException(AuthenticationException e) {
        VerifyResult verifyResult = pkcs1Handle.getVerifyResult();
        verifyResult.setIsVerify(false);
        verifyResult.setErrorCode(e.getMessage());
        verifyResult.setErrorMessage(e.getMessage());
        log.error("userIdentityException: " + verifyResult.toString());
        return verifyResult;
    }
}
