package gov.archives.core.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * HomeController
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/19.
 */
@Controller
public class HomeController {
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String getHome() {
        return "redirect:/index";
    }

    @RequestMapping(path = "/index")
    public String getIndex() {
        return "/core/index";
    }
}
