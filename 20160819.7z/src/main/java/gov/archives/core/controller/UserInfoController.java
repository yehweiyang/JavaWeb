package gov.archives.core.controller;

import java.util.Collection;

import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.validator.routines.RegexValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.AccountVO;
import gov.archives.core.domain.vo.UserInfo;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.UserInfoService;

/**
 * Created by tristan on 2016/7/25.
 */
@RestController
@RequestMapping(value = "/v1/systemTools/user")
public class UserInfoController {

    private static final Logger log = LoggerFactory.getLogger(UserInfoController.class);

    @Autowired
    private UserInfoService userInfoService;

    @RequestMapping(value = "/list",
            method = RequestMethod.GET)
    public Collection<UserInfo> getAll() {
        try {
            return userInfoService.list();
        } catch (RuntimeException e) {
            throw new RestApplicationException(e.getMessage());
        }
    }

    @RequestMapping(value = "/saveUser",
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void saveUser(
            @RequestBody
                    UserInfo user) {
        try {
            if (null == user) {
                throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
            }
            verifyUserInfo(user);
            userInfoService.updateUserByAccount(user);
        } catch (RuntimeException e) {
            log.error(StringUtils.stackTraceFromException(e));
            throw new RestApplicationException(e.getMessage());
        }
    }

    /*
    private boolean isValid (String str, String regex) {
        return Pattern.compile(regex).matcher(str).matches();
    }
    */

    private void verifyUserInfo(UserInfo user) {
        RegexValidator digitValidator = new RegexValidator(CoreConf.DIGIT_PATTERN);
        RegexValidator digitOrEmptyValidator = new RegexValidator(CoreConf.DIGIT_EMPTY_PATTERN);
        RegexValidator alphaNumericValidator = new RegexValidator(CoreConf.ALPHANUMERIC_PATTERN);
        RegexValidator alphaNumericNlsValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);

        String account = user.getAccount();
        if (null == account || !alphaNumericValidator.isValid(account)) {
            throw new RestApplicationException(CoreErrorCode.CODE_ACCOUNT_FORMAT_ERROR);
        }
        String roleName = user.getRoleName();
        if (roleName == null || (!roleName.isEmpty() && !alphaNumericNlsValidator.isValid(roleName))) {
            throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
        }
        String userName = user.getUserName();
        if (null == userName || !alphaNumericNlsValidator.isValid(userName)) {
            throw new RestApplicationException(CoreErrorCode.CODE_NAME_FORMAT_ERROR);
        }
        String email = user.getEmail();
        if (null == email || !EmailValidator.getInstance()
                                            .isValid(email)) {
            throw new RestApplicationException(CoreErrorCode.CODE_EMAIL_FORMAT_ERROR);
        }
        if (!alphaNumericNlsValidator.isValid(user.getOrgInfo())) {
            throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
        }
        int activeStatus = user.getActiveStatus();
        if (!(activeStatus == CoreConf.STATUS_APPLYING || activeStatus == CoreConf.STATUS_DISABLED
                || activeStatus == CoreConf.STATUS_ENABLED)) {
            throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
        }
        String deputyAccount = user.getDeputyAccount();
        if (null == deputyAccount || (!deputyAccount.isEmpty() && !alphaNumericValidator.isValid(deputyAccount))) {
            throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
        }
        String phoneAreaCode = user.getPhoneAreaCode();
        if (null == phoneAreaCode || !digitValidator.isValid(phoneAreaCode)) {
            throw new RestApplicationException(CoreErrorCode.CODE_PHONE_TYPE_ERROR);
        }
        String phoneLocalNumber = user.getPhoneLocalNumber();
        if (null == phoneLocalNumber || !digitValidator.isValid(phoneLocalNumber)) {
            throw new RestApplicationException(CoreErrorCode.CODE_PHONE_TYPE_ERROR);
        }
        String phoneExtNumber = user.getPhoneExtNumber();
        if (null == phoneExtNumber || !digitOrEmptyValidator.isValid(phoneExtNumber)) {
            throw new RestApplicationException(CoreErrorCode.CODE_PHONE_TYPE_ERROR);
        }
        String mobileAreaCode = user.getMobileAreaCode();
        if (null == mobileAreaCode || !digitOrEmptyValidator.isValid(mobileAreaCode)) {
            throw new RestApplicationException(CoreErrorCode.CODE_PHONE_TYPE_ERROR);
        }
        String mobileLocalNumber = user.getMobileLocalNumber();
        if (null == mobileLocalNumber || !digitOrEmptyValidator.isValid(mobileLocalNumber)) {
            throw new RestApplicationException(CoreErrorCode.CODE_PHONE_TYPE_ERROR);
        }
    }

    @RequestMapping(value = "/currentAccount")
    public ResponseEntity<AccountVO> getCurrentUserName() throws RestApplicationException {
        return new ResponseEntity<>(userInfoService.getCurrentAccount(), HttpStatus.OK);
    }
}
