package gov.archives.core.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.domain.vo.RoleName;
import gov.archives.core.service.RoleService;

/**
 * Created by tristan on 2016/8/2.
 */
@RestController
@RequestMapping(value="/v1/systemTool/role")
public class RoleController {
    @Autowired
    private RoleService roleService;

    @RequestMapping(value = "/listRoleName",
            method = RequestMethod.GET)
    public Collection<RoleName> listRoleName() {
        return roleService.listRoleName();
    }
}
