package gov.archives.core.util;

import org.apache.commons.lang3.StringEscapeUtils;

public class EscapeUtils extends StringEscapeUtils {

	public static final String escapeHtml(String input) {
		String escapeText = StringEscapeUtils.escapeHtml4(input);
		escapeText = escapeText.replaceAll("\'", "&#039;");
		return escapeText;
	}
}
