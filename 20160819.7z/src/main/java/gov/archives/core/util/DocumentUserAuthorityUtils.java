package gov.archives.core.util;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.UserInfoEntity;

public class DocumentUserAuthorityUtils {
    private static final List<GrantedAuthority> ADMIN_ROLES =
            AuthorityUtils.createAuthorityList(CoreConf.ROLE_ADMIN, CoreConf.ROLE_USER);
    private static final List<GrantedAuthority> USER_ROLES = AuthorityUtils.createAuthorityList(CoreConf.ROLE_USER);
    private static final List<GrantedAuthority> ROLE_REST = AuthorityUtils.createAuthorityList(CoreConf.ROLE_REST);

    public static Collection<? extends GrantedAuthority> createAuthorities(UserInfoEntity user, boolean restful) {
        if (null == user) {
            return USER_ROLES;
        }

        return restful ? ROLE_REST : ADMIN_ROLES;
    }
}
