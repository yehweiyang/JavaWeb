package gov.archives.core.util;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;

import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;

/**
 * jAgent - DateTimeHandler
 * <p>
 * Define: The Joda DateTime handler of DB Mapping.
 * <p>
 * Issue:
 * <p>
 * Created by gem, 2015/3/25. Soli Deo Gloria.
 */
public class DateTimeHandler implements TypeHandler<DateTime> {
    @Override
    public void setParameter(PreparedStatement preparedStatement, int i, DateTime dateTime, JdbcType jdbcType)
            throws SQLException {
        preparedStatement.setObject(i, new Timestamp(dateTime.getMillis()), Types.TIMESTAMP);
    }

    @Override
    public DateTime getResult(ResultSet resultSet, String s) throws SQLException {
        Object timestamp = resultSet.getObject(s);

        if (timestamp instanceof Timestamp) {
            return new DateTime(((Timestamp) timestamp).getTime());
        } else {
            return DateTime
                    .parse(StringUtils.trimFromUnknown(timestamp),
                            DateTimeFormat.forPattern(CoreConf.DB_TIMESTAMP_PATTERN));
        }
    }

    @Override
    public DateTime getResult(ResultSet resultSet, int i) throws SQLException {
        Object timestamp = resultSet.getObject(i);

        if (timestamp instanceof Timestamp) {
            return new DateTime(((Timestamp) timestamp).getTime());
        } else {
            return DateTime
                    .parse(StringUtils.trimFromUnknown(timestamp),
                            DateTimeFormat.forPattern(CoreConf.DB_TIMESTAMP_PATTERN));
        }
    }

    @Override
    public DateTime getResult(CallableStatement callableStatement, int i) throws SQLException {
        Object timestamp = callableStatement.getObject(i);

        if (timestamp instanceof Timestamp) {
            return new DateTime(((Timestamp) timestamp).getTime());
        } else {
            return DateTime
                    .parse(StringUtils.trimFromUnknown(timestamp),
                            DateTimeFormat.forPattern(CoreConf.DB_TIMESTAMP_PATTERN));
        }
    }
}
