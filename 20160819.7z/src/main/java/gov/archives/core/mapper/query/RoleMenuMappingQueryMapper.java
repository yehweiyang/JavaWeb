package gov.archives.core.mapper.query;

import java.util.List;
import java.util.UUID;

import gov.archives.core.domain.entity.RoleMenuMappingEntity;

/**
 * RoleMenuMappingQueryMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/19.
 */
public interface RoleMenuMappingQueryMapper {
    List<RoleMenuMappingEntity> findByRoleName(String roleName);

    List<RoleMenuMappingEntity> findByRoleSysId(UUID roleSysId);
}
