package gov.archives.core.conf;

/**
 * Created by 140631 on 2016/7/25.
 */
public class ReportConf {
    public static final String REPORT_PDF = "pdf";
    public static final String REPORT_ODS = "ods";
}
