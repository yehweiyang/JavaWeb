package gov.archives.core.domain.vo;


import org.iii.common.util.StringUtils;

/**
 * Created by tristan on 2016/7/25.
 */
public class UserInfo {
    private String account;
    private String roleName;
    private String userName;
    private String email;
    private String phoneNumber;
    private String mobileNumber;
    private String orgInfo;
    private Integer activeStatus;
    private String deputyAccount;
    private String certCardNum;

    private String phoneAreaCode;
    private String phoneLocalNumber;
    private String phoneExtNumber;
    private String mobileAreaCode;
    private String mobileLocalNumber;

    public void composePhoneNumber() {
        phoneNumber = phoneAreaCode + "-" + phoneLocalNumber +
                ((StringUtils.isEmpty(phoneExtNumber)) ? "" : ("#" + phoneExtNumber));
    }

    public void composeMobileNumber() {
        mobileNumber = ((mobileAreaCode == null || mobileAreaCode.isEmpty()) ? "" : mobileAreaCode) +
                ((StringUtils.isEmpty(mobileLocalNumber)) ? "" : "-" + mobileLocalNumber);
    }

    public void rebuildPhoneNumbers() {
        composePhoneNumber();
        composeMobileNumber();
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getOrgInfo() {
        return orgInfo;
    }

    public void setOrgInfo(String orgInfo) {
        this.orgInfo = orgInfo;
    }

    public Integer getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getDeputyAccount() {
        return deputyAccount;
    }

    public void setDeputyAccount(String deputyAccount) {
        this.deputyAccount = deputyAccount;
    }

    public String getCertCardNum() {
        return certCardNum;
    }

    public void setCertCardNum(String certCardNum) {
        this.certCardNum = certCardNum;
    }

    public String getPhoneAreaCode() {
        return phoneAreaCode;
    }

    public void setPhoneAreaCode(String phoneAreaCode) {
        this.phoneAreaCode = phoneAreaCode;
    }

    public String getPhoneLocalNumber() {
        return phoneLocalNumber;
    }

    public void setPhoneLocalNumber(String phoneLocalNumber) {
        this.phoneLocalNumber = phoneLocalNumber;
    }

    public String getPhoneExtNumber() {
        return phoneExtNumber;
    }

    public void setPhoneExtNumber(String phoneExtNumber) {
        this.phoneExtNumber = phoneExtNumber;
    }

    public String getMobileAreaCode() {
        return mobileAreaCode;
    }

    public void setMobileAreaCode(String mobileAreaCode) {
        this.mobileAreaCode = mobileAreaCode;
    }

    public String getMobileLocalNumber() {
        return mobileLocalNumber;
    }

    public void setMobileLocalNumber(String mobileLocalNumber) {
        this.mobileLocalNumber = mobileLocalNumber;
    }
}
