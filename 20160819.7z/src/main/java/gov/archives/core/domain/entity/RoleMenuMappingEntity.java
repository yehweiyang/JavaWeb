package gov.archives.core.domain.entity;

import java.util.UUID;

import org.apache.ibatis.type.Alias;

/**
 * RoleMenuMappingEntity
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/19.
 */
@Alias("RoleMenuMapping")
public class RoleMenuMappingEntity extends BaseEntity {

    public static synchronized RoleMenuMappingEntity getInstanceByRoleSysIdAndMenuSysId(UUID roleSysId,
            UUID menuSysId) {
        RoleMenuMappingEntity entity = new RoleMenuMappingEntity();

        entity.setRoleSysId(roleSysId);
        entity.setMenuSysId(menuSysId);

        return entity;
    }

    private UUID roleSysId;
    private UUID menuSysId;

    public UUID getRoleSysId() {
        return roleSysId;
    }

    public void setRoleSysId(UUID roleSysId) {
        this.roleSysId = roleSysId;
    }

    public UUID getMenuSysId() {
        return menuSysId;
    }

    public void setMenuSysId(UUID menuSysId) {
        this.menuSysId = menuSysId;
    }
}
