package gov.archives.core.domain.vo;

import java.io.Serializable;
import java.sql.Timestamp;

public class AccountForm implements Serializable {
	private static final long serialVersionUID = -2859976001619288699L;
	private String userName = null;
    private String fullName = null;
    private String phoneLocal  = null;
    private String phoneNum = null;
    private String phonExt = null;
    private String mobileLocal = null;
    private String mobileNum = null;

    private String eMailAddr =null;
    private String cardNo = null;
    private String certb64 = null;
	private String loginCount = null;
	private String loginIp = null;
	private Timestamp LogDateTime = null;

	public String getFullName() {
		return fullName;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public String getPhonExt() {
		return phonExt;
	}

	public String getCardNo() {
		return cardNo;
	}

	public String getCertb64() {
		return certb64;
	}

	public String getLoginCount() {
		return loginCount;
	}

	public String getLoginIp() {
		return loginIp;
	}

	public Timestamp getLogDateTime() {
		return LogDateTime;
	}

	public String getUserName() {
		return userName;
	}

	public String getMobileLocal() {
		return mobileLocal;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public String geteMailAddr() {
		return eMailAddr;
	}

	public String getPhoneLocal() {	return phoneLocal;}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public void setPhonExt(String phonExt) {
		this.phonExt = phonExt;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public void setCertb64(String certb64) {
		this.certb64 = certb64;
	}

	public void setLoginCount(String loginCount) {
		this.loginCount = loginCount;
	}

	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}

	public void setLogDateTime(Timestamp logDateTime) {
		LogDateTime = logDateTime;
	}

	public void setMobileLocal(String mobileLocal) {
		this.mobileLocal = mobileLocal;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public void seteMailAddr(String eMailAddr) {
		this.eMailAddr = eMailAddr;
	}

	public void setPhoneLocal(String phoneLocal) {this.phoneLocal = phoneLocal;}
}
