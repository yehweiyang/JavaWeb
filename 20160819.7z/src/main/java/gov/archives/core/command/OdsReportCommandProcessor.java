package gov.archives.core.command;

import java.io.ByteArrayOutputStream;

import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.oasis.JROdsExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.IOUtils;

import gov.archives.core.domain.vo.ReportInputModel;
import gov.archives.core.exception.ErrorCode;
import gov.archives.core.exception.ReportException;

/**
 * Created by kshsu on 2016/7/26.
 */
public class OdsReportCommandProcessor extends ReportBaseCommand implements ReportCommandProcessor {
    private static final Logger log = LoggerFactory.getLogger(OdsReportCommandProcessor.class);

    ByteArrayOutputStream baos;

    @Override
    public void genReportToFile(ReportInputModel reportInputModel) throws ReportException {
        try {
            baos = genReportOutput(reportInputModel);
            IOUtils.exportBytesToFile(baos.toByteArray(), reportInputModel.getDestFileName());
            baos.flush();
        } catch (Exception ex) {
            throw new ReportException(ex, ErrorCode.EXCEPTION_IN_REPORT_COMMAND_PROCESSOR);
        }
    }

    @Override
    public void genReportToStream(ReportInputModel reportInputModel) throws ReportException {
        try {
            baos = genReportOutput(reportInputModel);
            reportInputModel.getOs().write(baos.toByteArray());
            baos.flush();
        } catch (Exception ex) {
            throw new ReportException(ex, ErrorCode.EXCEPTION_IN_REPORT_COMMAND_PROCESSOR);
        }
    }

    @Override
    public void genReportToByteArray(ReportInputModel reportInputModel) throws ReportException {
        try {
            baos = genReportOutput(reportInputModel);
            reportInputModel.setOutput(baos.toByteArray());
            baos.flush();
        } catch (Exception ex) {
            throw new ReportException(ex, ErrorCode.EXCEPTION_IN_REPORT_COMMAND_PROCESSOR);
        }
    }

    private JasperPrint genJasperPrintObj(ReportInputModel reportInputModel) throws ReportException {
        try {
            return reportConvertTo(
                    getJasperReportFromFileName(reportInputModel.getSourceFileName()),
                    reportInputModel.getReportParameter(),
                    getJRTableDateSourceFromJavaBean(reportInputModel.getJavaBean())
            );
        } catch (Exception ex) {
            throw new ReportException(ex, ErrorCode.EXCEPTION_IN_REPORT_COMMAND_PROCESSOR);
        }
    }

    private ByteArrayOutputStream genReportOutput(ReportInputModel reportInputModel) throws ReportException {
        JROdsExporter jrOdsExporter;
        ByteArrayOutputStream byteArrayOutputStream;
        try {
            jrOdsExporter = new JROdsExporter();
            byteArrayOutputStream = new ByteArrayOutputStream();
            jrOdsExporter.setExporterInput(new SimpleExporterInput(genJasperPrintObj(reportInputModel)));
            jrOdsExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(byteArrayOutputStream));
            jrOdsExporter.exportReport();
            byteArrayOutputStream.close();
        } catch (Exception ex) {
            throw new ReportException(ex, ErrorCode.EXCEPTION_IN_REPORT_COMMAND_PROCESSOR);
        }
        return byteArrayOutputStream;
    }
}