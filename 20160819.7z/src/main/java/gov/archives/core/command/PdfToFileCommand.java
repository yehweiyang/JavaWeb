package gov.archives.core.command;

import gov.archives.core.domain.vo.ReportInputModel;
import gov.archives.core.exception.ReportException;

/**
 * Created by kshsu on 2016/7/26.
 */
public class PdfToFileCommand extends ReportBaseCommand implements ReportCommand {

    private PdfToFileCommand() {}

    public PdfToFileCommand(ReportInputModel reportInputModel) {
        this.sourceFilePath = reportInputModel.getSourceFileName();
        this.destFilePath = reportInputModel.getDestFileName();
        this.javaBean = reportInputModel.getJavaBean();
        this.reportParameter = reportInputModel.getReportParameter();
        this.reportType = reportInputModel.getReportType();
        this.baseReportInputModel = reportInputModel;
    }

    @Override
    public void execute(ReportCommandProcessor reportCommandProcessor) throws ReportException {
        reportCommandProcessor.genReportToFile(baseReportInputModel);
    }
}
