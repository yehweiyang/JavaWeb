package gov.archives.exchange.controller;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.exchange.domain.entity.ChangeErrorQueryEntity;
import gov.archives.exchange.domain.entity.vo.ChangeErrorQueryVo;
import gov.archives.exchange.service.ChangeErrorQueryService;

/**
 * ChangeErrorQueryController
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
@RestController
@RequestMapping(value = "/v1/change")
public class ChangeErrorQueryController {

    @Autowired
    private ChangeErrorQueryService queryService;

    @RequestMapping(value = "/error",
            method = RequestMethod.GET)
    public Map<String, ChangeErrorQueryVo> test() {
        queryService.getAllQuery();

        return queryService.getErrorQueryMap();
    }

}
