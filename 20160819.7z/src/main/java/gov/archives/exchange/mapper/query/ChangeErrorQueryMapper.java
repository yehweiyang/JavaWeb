package gov.archives.exchange.mapper.query;

import java.util.List;

import gov.archives.exchange.domain.entity.ChangeErrorQueryEntity;

/**
 * ChangeErrorQueryMapper
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
public interface ChangeErrorQueryMapper {

    List<ChangeErrorQueryEntity> findAllQuery();

}
