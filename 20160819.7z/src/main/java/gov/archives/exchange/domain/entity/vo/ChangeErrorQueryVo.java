package gov.archives.exchange.domain.entity.vo;

import java.util.UUID;

/**
 * ChangeErrorQueryVo
 * <p>
 * Created by WeiYang on 2016/8/18.
 */
public class ChangeErrorQueryVo {
    private UUID sysId;
    private String exchangeId;
    private String senderOrgId;
    private String senderUnitId;
    private String applicationId;

    private String processId;
    private String receiverOrgId;
    private String receiverUnitId;


    public UUID getSysId() {
        return sysId;
    }

    public void setSysId(UUID sysId) {
        this.sysId = sysId;
    }

    public String getExchangeId() {
        return exchangeId;
    }

    public void setExchangeId(String exchangeId) {
        this.exchangeId = exchangeId;
    }

    public String getSenderOrgId() {
        return senderOrgId;
    }

    public void setSenderOrgId(String senderOrgId) {
        this.senderOrgId = senderOrgId;
    }

    public String getSenderUnitId() {
        return senderUnitId;
    }

    public void setSenderUnitId(String senderUnitId) {
        this.senderUnitId = senderUnitId;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getReceiverOrgId() {
        return receiverOrgId;
    }

    public void setReceiverOrgId(String receiverOrgId) {
        this.receiverOrgId = receiverOrgId;
    }

    public String getReceiverUnitId() {
        return receiverUnitId;
    }

    public void setReceiverUnitId(String receiverUnitId) {
        this.receiverUnitId = receiverUnitId;
    }
}
