package gov.archives.exchange.service;

import gov.archives.exchange.domain.entity.MainInfoEntity;

/**
 * MainInfoService
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
public interface MainInfoService {
    MainInfoEntity getByExchangeId(String exchangeId);
}
