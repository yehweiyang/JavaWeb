package gov.archives.exchange.service.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.util.BeanUtils;
import gov.archives.exchange.domain.entity.ChangeErrorQueryEntity;
import gov.archives.exchange.domain.entity.vo.ChangeErrorQueryVo;
import gov.archives.exchange.mapper.query.ChangeErrorQueryMapper;
import gov.archives.exchange.service.ChangeErrorQueryService;

/**
 * ChangeErrorQueryServiceImpl
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
@Service
@Transactional
public class ChangeErrorQueryServiceImpl implements ChangeErrorQueryService {
    @Autowired
    ChangeErrorQueryMapper mapper;


    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<ChangeErrorQueryEntity> getAllQuery() {

        Logger log = Logger.getLogger("123");
        log.info("5555555555");
        return mapper.findAllQuery();
    }

    @Override
    public Map<String, ChangeErrorQueryVo> getErrorQueryMap() {
        ChangeErrorQueryVo vo = new ChangeErrorQueryVo();
        List<ChangeErrorQueryEntity> list = mapper.findAllQuery();
        Map<String, ChangeErrorQueryVo> resultQuery = new LinkedHashMap();
        int i =1;
        for (ChangeErrorQueryEntity entity:mapper.findAllQuery()
                ) {
            BeanUtils.copyProperties(vo, entity);
            resultQuery.put(vo.getExchangeId(),vo);
        }
        return resultQuery;
    }

}
