package gov.archives.exchange.message;

/**
 * ExchangeErrorMessage
 * <br>
 * exchange package 之錯誤訊息設定
 * <br>
 * gemhuang, 2016/8/16.
 */
public class ExchangeErrorMessage {
}
