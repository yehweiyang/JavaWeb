package gov.archives.exchange.message;

/**
 * ExchangeErrorCode
 * <br>
 * exchange package 之錯誤代碼設定
 * <br>
 * gemhuang, 2016/8/16.
 */
public class ExchangeErrorCode {
}
