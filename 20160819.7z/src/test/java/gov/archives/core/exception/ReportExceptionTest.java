package gov.archives.core.exception;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.conf.CommonConfig;
import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.vo.ReportInputModel;
import gov.archives.core.facade.ReportOutputFacade;
import gov.archives.core.service.MenuService;
import gov.archives.core.service.ReportServiceTest;

/**
 * Created by jslee on 2016/7/25.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper.xml"})
public class ReportExceptionTest {

    private static final Logger log = LoggerFactory.getLogger(ReportExceptionTest.class);

    private static final String REPORT_TEMPLATE = "menuReport.jasper";
    private static final String REPORT_FOLDER = "reportTemplate";
    private static final String TEST_RESOURCES_FOLDER = "test-resources";
    private static final String REPORT_OUTPUT_FOLDER = "menuReport";
    private static final String REPORT_OUTPUT_FILE_IS_NULL = "";

    @Autowired
    private MenuService menuService;

    @Autowired
    private ReportOutputFacade outputFacade;

    @Before
    public void setUp() throws Exception {
        Path outputFolder = CommonConfig.getRuntimeRoot(ReportServiceTest.class)
                                        .resolve(TEST_RESOURCES_FOLDER)
                                        .resolve(REPORT_OUTPUT_FOLDER);

        FileSystemUtils.checkFolder(outputFolder);

    }

    @Test
    public void mainTest() {
        /* Exception Test */
        try {
            // errorCode: ERR_0999 errorMessage: 無法判斷的錯誤
            testReportException();
        } catch (ReportException e) {
            Assert.assertNotNull(e);
        }

        // errorCode: ERR_1003 errorMessage: ReportCommandProcessor Method 內部發生錯誤
        exportReport(REPORT_OUTPUT_FILE_IS_NULL, "pdf");
    }

    private void testReportException() throws ReportException {
        try {
            Class<?> clazz = Class.forName("");
        } catch (Exception ex) {
            throw new ReportException(ex, ErrorCode.EXCEPTION_UNKNOWN);
        }
    }

    public void exportReport(String fileName, String exportType) {
        List<MenuEntity> menuEntities = menuService.getAllMenu();
        try {
            File reportTemplate =
                    Paths.get(IOUtils.loadResourceURLInClasspath(REPORT_FOLDER + "/" + REPORT_TEMPLATE).toURI())
                         .toFile();

            File reportOutput = CommonConfig.getRuntimeRoot(ReportServiceTest.class)
                                            .resolve(TEST_RESOURCES_FOLDER)
                                            .resolve(REPORT_OUTPUT_FOLDER)
                                            .resolve(fileName)
                                            .toFile();

            outputFacade.genReportToFile(
                    new ReportInputModel(reportTemplate.getAbsolutePath(), reportOutput.getAbsolutePath(), menuEntities,
                            initParamsMap(), exportType));

        } catch (Exception e) {
            log.error(StringUtils.stackTraceFromException(e));
            Assert.assertNotNull(e);
        }
    }

    public Map<String, Object> initParamsMap() {
        Map<String, Object> paramsMap = new HashMap<>();
        paramsMap.put("title", "選單");
        paramsMap.put("dateFrom", "2016/05/01");
        paramsMap.put("dateTo", "2016/06/01");
        return paramsMap;
    }
}
