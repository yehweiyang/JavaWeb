package gov.archives.core.service;

import java.sql.Timestamp;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.StringUtils;

import gov.archives.core.domain.entity.LogInControlEntity;

/**
 * LogInControlServiceTest
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper.xml"})
public class LogInControlServiceTest {
    private static final Logger log = LoggerFactory.getLogger(LogInControlServiceTest.class);

    private static final String TEST_ACCOUNT = "admin";
    private static final String TEST_CARD_NUM = "123456789";
    private static final String TEST_REMOTE_IP = "127.0.0.1";
    private static final String TEST_SESSION_ID = "987654321";

    @Autowired
    private LogInControlService service;

    @Before
    public void setUp() throws Exception {
        LogInControlEntity loginCtrl = service.getBySessionIdAndAccount(TEST_SESSION_ID, TEST_ACCOUNT);

        if (null != loginCtrl) {
            service.delete(loginCtrl);
        }
    }

    @Test
    public void testInsert() throws Exception {
        try {
            LogInControlEntity loginCtrl = prepareLogInControl();

            service.insert(loginCtrl);

            loginCtrl = service.getBySessionIdAndAccount(loginCtrl.getSessionId(), loginCtrl.getLoginAccount());

            Assert.assertNotNull(loginCtrl);

            service.delete(loginCtrl);
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));

            Assert.assertNull(ex);
        }
    }

    private LogInControlEntity prepareLogInControl() {
        LogInControlEntity logInCtrl = new LogInControlEntity();

        logInCtrl.setCertCardNum(TEST_CARD_NUM);
        logInCtrl.setLoginAccount(TEST_ACCOUNT);
        logInCtrl.setLoginCount(1);
        logInCtrl.setLoginTime(new Timestamp(System.currentTimeMillis()));
        logInCtrl.setRemoteIp(TEST_REMOTE_IP);
        logInCtrl.setSessionId(TEST_SESSION_ID);

        logInCtrl.initSysId();

        return logInCtrl;
    }
}
