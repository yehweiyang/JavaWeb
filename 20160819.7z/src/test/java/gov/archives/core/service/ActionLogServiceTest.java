package gov.archives.core.service;

import java.sql.Timestamp;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.StringUtils;

import gov.archives.core.domain.entity.ActionLogEntity;

/**
 * ActionLogServiceTest
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper.xml"})
public class ActionLogServiceTest {

    private static final Logger log = LoggerFactory.getLogger(ActionLogServiceTest.class);

    @Autowired
    private ActionLogService service;

    @Test
    public void testInsertLog() throws Exception {
        try {
            ActionLogEntity actionLog = prepareLog();

            service.insert(actionLog);

            service.delete(actionLog);
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));

            Assert.assertNull(ex);
        }
    }

    private ActionLogEntity prepareLog() {
        ActionLogEntity actionLog =
                ActionLogEntity.Builder.create()
                                       .setActionItem("Func-01")
                                       .setActionResult("Successed")
                                       .setActionTime(new Timestamp(System.currentTimeMillis()))
                                       .setActorAccount("admin")
                                       .setErrorCode("000")
                                       .setEventLevel("1")
                                       .setRemoteIp("127.0.0.1")
                                       .build();

        return actionLog;
    }
}
