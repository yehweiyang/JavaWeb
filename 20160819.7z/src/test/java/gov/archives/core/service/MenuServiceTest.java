package gov.archives.core.service;

import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.util.DebugUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.vo.TopMenuVo;

/**
 * MenuServiceTest
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper.xml"})
public class MenuServiceTest {
    private static final Logger log = LoggerFactory.getLogger(MenuServiceTest.class);

    private static final String TEST_MENU_CODE = "ADMIN";
    private static final String TEST_MENU_NAME = "TEST_MANU";
    private static final String TEST_MENU_NAME_2 = "TEST_MANU_2";

    @Autowired
    private MenuService service;

    @Before
    public void setUp() throws Exception {
        MenuEntity menu = service.getByMenuCode(TEST_MENU_CODE);

        if (null != menu) {
            service.delete(menu);
        }
    }

    @Test
    public void testInsert() {
        try {
            MenuEntity menu = prepareMenu();

            service.insert(menu);

            MenuEntity menu1 = service.getByMenuCode(TEST_MENU_CODE);
            MenuEntity menu2 = service.getBySysId(menu.getSysId());

            Assert.assertNotNull(menu1);
            Assert.assertNotNull(menu2);

            Assert.assertEquals(menu1.getSysId(), menu2.getSysId());
            Assert.assertEquals(menu1.getMenuCode(), menu2.getMenuCode());

            service.delete(menu1);
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));

            Assert.assertNull(ex);
        }
    }

    private MenuEntity prepareMenu() {
        MenuEntity menu = new MenuEntity();

        menu.setMenuCode(TEST_MENU_CODE);
        menu.setMenuName(TEST_MENU_NAME);
        menu.setMenuSeq(1);
        menu.setActiveStatus(CoreConf.STATUS_ENABLED);
        menu.setModifiedMemo("");
        menu.setTopMenuId(CoreConf.DEFAULT_ID);
        menu.initSysId();

        return menu;
    }

    @Test
    public void testUpdate() {
        try {
            MenuEntity menu = prepareExistsMenu();

            menu.setMenuName(TEST_MENU_NAME_2);

            service.update(menu);

            menu = service.getByMenuCode(TEST_MENU_CODE);

            Assert.assertEquals(TEST_MENU_NAME_2, menu.getMenuName());

            service.delete(menu);
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));

            Assert.assertNull(ex);
        }
    }

    private MenuEntity prepareExistsMenu() {
        MenuEntity menu = prepareMenu();

        service.insert(menu);

        menu = service.getByMenuCode(TEST_MENU_CODE);

        return menu;
    }

    @Test
    public void testGetMenuTree() {
        MenuEntity menu = prepareExistsMenu();

        Map<Integer, TopMenuVo> menuTree = service.getMenuTree();

        Assert.assertNotNull(menuTree);

        DebugUtils.dumpMap(menuTree);

        service.delete(menu);
    }

}
