package gov.archives.core.service;

import java.io.File;
import java.nio.file.Path;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.conf.CommonConfig;
import org.iii.common.util.FileSystemUtils;

import gov.archives.core.TestConf;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.SignCertData;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper.xml"})
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserIdentityServiceTest {
    private static final String b64Cert = "MIIEojCCA4qgAwIBAgIQKaPJRLZR7sEy1J9/Y/cy3TANBgkqhkiG9w0BAQsFADBWMQsw" +
            "CQYDVQQGEwJUVzESMBAGA1UECgwJ6KGM5pS/6ZmiMTMwMQYDVQQLDCoo5ris6Kmm55SoKSDmlL/lupzmuKzoqabmhpHorYn" +
            "nrqHnkIbkuK3lv4MwHhcNMTYwMzI0MTAzOTE0WhcNMTYwOTIzMTAzOTE0WjAlMQswCQYDVQQGEwJUVzEWMBQGA1UECgwN5r" +
            "is6Kmm5qmf6ZecMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANck44iblq+X9tR1IRjgfnmzFCa6DVMlJOfPL" +
            "eSNwx/f++jN6RNn+trqEWFFvDVjjjYw8kHFtTptt+f5/WX07nlX1Qz4ECx5QVGvm4Y6krRj0WKUsSMlpVPyPhHOOlfWQPZG" +
            "qH/QPpvhKoHTmhqBXk6jtrSz4dxyUJ0sRHcl03saNozVjYMP0vSxWubMkd/WKzJgQdIuSfkcKpGJQnhAB9eNAOnCb044Flp" +
            "q+FJPpONjb8ViugEqJJteW4vA4x9LLsth2+fFONpQzXvgVArW+rCQi2tTU5CZuQsuBI3IIN8+rAEIGL/XgsB0h09AOSfd8E" +
            "YxhJC1V+kXDOFhSpMt8EkCAwEAAaOCAZswggGXMHcGCCsGAQUFBwEBBGswaTA6BggrBgEFBQcwAoYuaHR0cDovLzIxMC4yN" +
            "DEuNjkuMTgxL2NlcnRzL0lzc3VlZFRvVGhpc0NBLnA3YjArBggrBgEFBQcwAYYfaHR0cDovLzIxMC4yNDEuNjkuMTgxL09D" +
            "U1Avb2NzcDAUBgNVHSAEDTALMAkGB2CGdmUAAwAwTgYDVR0JBEcwRTAWBgdghnYBZAIBMQsGCWCGdgFkAwIBATAUBgdghnY" +
            "BZAICMQkTB3ByaW1hcnkwFQYHYIZ2AWQCZjEKBghghnYBZYGcITAaBgNVHREEEzARgQ90ZXN0QGNodC5jb20udHcwDgYDVR" +
            "0PAQH/BAQDAgeAMB8GA1UdIwQYMBaAFHev0GWH7h3IqfaXoCVHDsmV2nGrMB0GA1UdDgQWBBTXXiFfJ0JhlmSY68DGtzQPX" +
            "3Yk9zBKBgNVHR8EQzBBMD+gPaA7hjlodHRwOi8vMjEwLjI0MS42OS4xODEvc2hhMi9jcmwvR1Rlc3RDQTIvY29tcGxldGVk" +
            "ZWx0YS5jcmwwDQYJKoZIhvcNAQELBQADggEBAAka2/S7RNhEfI/pfZp36PWR/auosw+ggfjk1YNPq9BYpRz1rHGx/P3tghD" +
            "JCp6+ALlT6j4ogCYIjeabm4SKkqpqIQBJx0NFHuOJl/Rm39o+qxLbDj1xpkruBr5m33q16VZ1c3RjvUno+s/t7QqKtSpTG6" +
            "7+Uof3r3oeSZ1/Whrm7kXjtpXVeKEdTvi3z9qWRNwEtSM5Z8ITx5+Fwfskyb+WWFC8kAXtJ1UXZ50icw4TgC+ZuFHS8wmpC" +
            "/NO4kDiHRiy/lNQ2PyP522XYKkxj6gffM+HOcDnEVMX5yUs2BD9JlcoX74MjiZF+/aIaimx7ipReOZBGWlP7oo9YVWAF1c=";

    private static final String b64Signature = "U8/jicJX96Oqa0W/eH6YZjvTyhbSpw1E1RpRXFL+X/aJPnh9qAPQlA3Mhw8OGXH" +
            "H8krwnXBKwWWzlZ4SVkXeTm7PgwvRlM92VDxfS4LbDJXlCqV9fEW84kObnhZA1OMyCcztFPWuQH9hbEp6AR1J0MLafAzOri" +
            "qZydwL+cSAYIZiCMb0f07wdZdRO8Aev405K1aLSVtelPrVSTWarC0fR/UYDrSrKlKevkJi4NgRfSJIeR57P4eaRTKmLZJ8T" +
            "tsNsXQ01Wv1uUt1MKokH7Z7+AknxR5rHDojkFRnldxiMQwimS7s6plRstVEswhl0bd1pZzZ+YZY44GVzuiCYadSTg==";

    private static final String realPath = "testUserIdentityService";
    private static final String fileName = "TTA0000000001853";
    private static final String guid = "bc260bde-17f9-411a-834b-a48e63c3c216";
    private static final String signCertHash = "fab9b9a9853e82f8868340df841d621484e689f5f8f8ccccd7b24922075b127b";

    @Autowired
    private UserIdentityService userIdentityService;

    @Before
    public void setUp() throws Exception {
        Path fileSaveDir =
                CommonConfig.getRuntimeRoot(UserIdentityServiceTest.class)
                            .resolve(TestConf.TEST_RESOURCES_FOLDER)
                            .resolve(realPath)
                            .resolve(CoreConf.CERT_FOLDER);

        FileSystemUtils.checkFolder(fileSaveDir);
    }

    @Test
    public void test1SaveRequestCertificate() {
        try {
            File fileSaveDir = getTestFileSaveDir();

            userIdentityService.saveRequestCertificate(b64Cert, fileSaveDir, fileName, System.currentTimeMillis());

            // IOUtils.deleteFile(resultFile);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }

    private File getTestFileSaveDir() {
        return CommonConfig.getRuntimeRoot(UserIdentityServiceTest.class)
                           .resolve(TestConf.TEST_RESOURCES_FOLDER)
                           .resolve(realPath)
                           .toFile();
    }

    @Test
    public void test2CertifiedSmartCardSignature() {
        try {
            SignCertData signCert = new SignCertData();
            signCert.setToken(guid);
            signCert.setB64Signature(b64Signature);
            signCert.setB64SignCert(b64Cert);

            userIdentityService.certifiedSmartCardSignature(signCert);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }

    @Test
    public void test3UserLoginIdentity() {
        try {
            SignCertData signCert = new SignCertData();
            signCert.setToken(guid);
            signCert.setB64Signature(b64Signature);

            UUID uuid = UUID.fromString(guid);

            File resultFile = getTestResultFile();

            userIdentityService.userLoginIdentity(signCert, resultFile, signCertHash, uuid, System.currentTimeMillis());
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }

    private File getTestResultFile() {
        return getTestFileSaveDir().toPath()
                                   .resolve(CoreConf.CERT_FOLDER)
                                   .resolve(fileName + CoreConf.SUFFIX_CERT)
                                   .toFile();
    }

    @Test
    public void test4CleanSignCertFile() {
        try {
            userIdentityService.cleanSignCertFile(getTestResultFile());
            File directory = getTestFileSaveDir();
            FileUtils.deleteDirectory(directory);
        } catch (Exception e) {
            Assert.assertTrue(false);
        }
    }
}
