package gov.archives.core.service;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.iii.common.conf.CommonConfig;
import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.vo.ReportInputModel;
import gov.archives.core.facade.ReportOutputFacade;

/**
 * Created by jslee on 2016/7/25.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper.xml"})
public class ReportServiceTest {

    private static final Logger log = LoggerFactory.getLogger(ReportServiceTest.class);

    private static final String REPORT_FOLDER = "reportTemplate";
    private static final String TEST_RESOURCES_FOLDER = "test-resources";
    private static final String REPORT_OUTPUT_FOLDER = "reportOutput";


    @Autowired
    private ReportOutputFacade outputFacade;

    @Autowired
    private MenuService menuService;

    @Before
    public void setUp() throws Exception {
        Path outputFolder = CommonConfig.getRuntimeRoot(ReportServiceTest.class)
                                        .resolve(TEST_RESOURCES_FOLDER)
                                        .resolve(REPORT_OUTPUT_FOLDER);
        FileSystemUtils.checkFolder(outputFolder);
    }

    @Test
    public void mainTest() {
        testMenuReport();
    }

    private void testMenuReport() {
        List<MenuEntity> menuEntityList = menuService.getAllMenu();
        try {
            exportReport(menuEntityList, "menuReport", "pdf");
            exportReport(menuEntityList, "menuReport", "ods");
        } catch (Exception ex) {
            log.error(StringUtils.stackTraceFromException(ex));
            Assert.assertNull(ex);
        }
    }


    /* TestCase Params */
    private Map<String, Object> initParamsMap() {
        Map<String, Object> paramsMap = new HashMap<>();
        paramsMap.put("title", "選單");
        paramsMap.put("dateFrom", "2016/05/01");
        paramsMap.put("dateTo", "2016/06/01");
        return paramsMap;
    }

    /* Export Report */
    private void exportReport(Object javaBean, String reportTemplate, String exportType) {
        try {
            File reportTemplateFile =
                    Paths.get(IOUtils.loadResourceURLInClasspath(
                            REPORT_FOLDER + "/" + reportTemplate + CoreConf.SUFFIX_JASPER).toURI())
                         .toFile();

            File reportOutput = CommonConfig.getRuntimeRoot(ReportServiceTest.class)
                                            .resolve(TEST_RESOURCES_FOLDER)
                                            .resolve(REPORT_OUTPUT_FOLDER)
                                            .resolve(reportTemplate + ("pdf".equals(exportType) ? CoreConf.SUFFIX_PDF :
                                                    CoreConf.SUFFIX_ODS))
                                            .toFile();

            outputFacade.genReportToFile(
                    new ReportInputModel(reportTemplateFile.getAbsolutePath(), reportOutput.getAbsolutePath(), javaBean,
                            initParamsMap(), exportType));

        } catch (Exception e) {
            log.error(StringUtils.stackTraceFromException(e));
            Assert.assertNull(e);
        }
    }
}
