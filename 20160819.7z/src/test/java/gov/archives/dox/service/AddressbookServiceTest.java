package gov.archives.dox.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.dox.domain.entity.AddressbookEntity;

/**
 * AddressbookServiceTest
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper.xml"})
public class AddressbookServiceTest {

    private static final String TEST_ORG_ID = "TEST000000";
    private static final String TEST_UNIT_ID = "0000000";

    @Autowired
    private AddressbookService service;

    @Before
    public void setUp() throws Exception {}

    @Test
    public void testGetByOrgUnitId() throws Exception {
        AddressbookEntity entity = service.getByOrgUnitId(TEST_ORG_ID, TEST_UNIT_ID);

        Assert.assertNull(entity);
    }
}
