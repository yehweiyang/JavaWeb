package gov.archives.dox.mapper.query;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.archives.dox.domain.entity.AddressbookEntity;

/**
 * AddressbookQueryMapperTest
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-service.xml", "classpath:spring-mapper.xml"})
public class AddressbookQueryMapperTest {

    private static final String TEST_ORG_ID = "TEST000000";
    private static final String TEST_UNIT_ID = "0000000";

    @Autowired
    private AddressbookQueryMapper queryMapper;

    @Before
    public void setUp() throws Exception {}

    @Test
    public void testFindByOrgUnitId() throws Exception {
        Map<String, String> queryMap = prepareQueryMap();

        AddressbookEntity entity = queryMapper.findByOrgUnitId(queryMap);

        Assert.assertNull(entity);
    }

    private Map<String, String> prepareQueryMap() {
        Map<String, String> queryMap = new HashMap<>();

        queryMap.put(AddressbookQueryMapper.KEY_ORG_ID, TEST_ORG_ID);
        queryMap.put(AddressbookQueryMapper.KEY_UNIT_ID, TEST_UNIT_ID);

        return queryMap;
    }
}
