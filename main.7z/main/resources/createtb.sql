-- 執行於 g2b2c_2017

-- 清除視表
drop view if exists last_access;
drop view if exists login_count;
drop view if exists  login_maxtime;
-- 使用者資料表
alter table if exists public.user_info drop constraint if exists pk_user_info;
alter table if exists public.user_info drop constraint if exists uidx_user_account;
drop table if exists public.user_info;

create table user_info (
    sys_id uuid NOT NULL,
    account  character varying(100) DEFAULT '' NOT NULL,
    role_sys_id uuid DEFAULT '00000000-0000-0000-0000-000000000000' NOT NULL,
    user_name character varying(200) DEFAULT '' NOT NULL,
    email character varying(200) DEFAULT '' NOT NULL,
    phone_number character varying(200) DEFAULT '' NOT NULL,
    mobile_number character varying(200) DEFAULT '' NOT NULL,
    org_info character varying(200) DEFAULT '' NOT NULL,
    active_status int DEFAULT -1 NOT NULL,
    deputy_account character varying(100) NOT NULL DEFAULT '',
    cert_card_num character varying(100) NOT NULL DEFAULT '',
    cert_hash character varying(200) NOT NULL DEFAULT '',
    creator_account character varying(100) DEFAULT '' NOT NULL,
    created_time timestamp without time zone DEFAULT current_timestamp NOT NULL,
    modifier_account character varying(100) DEFAULT '' NOT NULL,
    modified_time timestamp without time zone DEFAULT current_timestamp NOT NULL,

    CONSTRAINT pk_user_info PRIMARY KEY ( sys_id ),
    CONSTRAINT uidx_user_account UNIQUE ( account )
)WITH (
    OIDS=FALSE
);

COMMENT ON TABLE public.user_info  IS '使用者資料';
COMMENT ON COLUMN public.user_info.account IS '帳號';
COMMENT ON COLUMN public.user_info.role_sys_id IS '使用者角色';
COMMENT ON COLUMN public.user_info.user_name IS '使用者名稱';
COMMENT ON COLUMN public.user_info.email IS '電子信箱';
COMMENT ON COLUMN public.user_info.phone_number IS '聯絡電話';
COMMENT ON COLUMN public.user_info.mobile_number IS '緊急行動電話';
COMMENT ON COLUMN public.user_info.org_info IS '機關單位資訊';
COMMENT ON COLUMN public.user_info.active_status IS '啟用狀態 [-1:審查中 | 0:停用 | 1:啟用]';
COMMENT ON COLUMN public.user_info.deputy_account IS '代理人';
COMMENT ON COLUMN public.user_info.cert_card_num IS '憑證卡號';
COMMENT ON COLUMN public.user_info.cert_hash IS '憑證雜湊';
COMMENT ON COLUMN public.user_info.creator_account IS '建立者帳號';
COMMENT ON COLUMN public.user_info.created_time IS '建立時間';
COMMENT ON COLUMN public.user_info.modifier_account IS '修改者帳號';
COMMENT ON COLUMN public.user_info.modified_time IS '修改時間';

-- 權限資料表
alter table if exists public.role drop constraint if exists pk_role;
alter table if exists public.role drop constraint if exists uidx_role_name;
drop table if exists public.role;

CREATE TABLE "role" (
    sys_id uuid  NOT NULL,
    role_name character varying(100) DEFAULT '' NOT NULL,
    active_status int DEFAULT 0 NOT NULL,
    creator_account character varying(100) DEFAULT '' NOT NULL,
    created_time timestamp without time zone DEFAULT current_timestamp NOT NULL,
    modifier_account character varying(100) DEFAULT '' NOT NULL,
    modified_time timestamp without time zone DEFAULT current_timestamp NOT NULL,

    CONSTRAINT pk_role PRIMARY KEY ( sys_id ),
    CONSTRAINT uidx_role_name UNIQUE ( role_name )
)WITH (
    OIDS=FALSE
);

COMMENT ON TABLE public.role IS '使用者角色';
COMMENT ON COLUMN public.role.role_name IS '角色名稱';
COMMENT ON COLUMN public.role.active_status IS '啟用狀態 [0:停用 | 1:啟用]';
COMMENT ON COLUMN public.role.creator_account IS '建立者帳號';
COMMENT ON COLUMN public.role.created_time IS '建立時間';
COMMENT ON COLUMN public.role.modifier_account IS '修改者帳號';
COMMENT ON COLUMN public.role.modified_time IS '修改時間';

-- 選單資料表
alter table if exists public.menu drop constraint if exists pk_menu;
alter table if exists public.menu drop constraint if exists uidx_menu_code;
drop table if exists public.menu;

CREATE TABLE menu (
    sys_id uuid  NOT NULL,
    menu_code character varying(100) DEFAULT '' NOT NULL,
    menu_name character varying(100) DEFAULT '' NOT NULL,
    menu_seq int DEFAULT 0 NOT NULL,
    top_menu_id uuid DEFAULT '00000000-0000-0000-0000-000000000000' NOT NULL,
    active_status int DEFAULT 0 NOT NULL,
    modified_memo character varying(1000) DEFAULT '' NOT NULL,

    CONSTRAINT pk_menu PRIMARY KEY ( sys_id ),
    CONSTRAINT uidx_menu_code UNIQUE ( menu_code )
 )WITH (
    OIDS=FALSE
);

COMMENT ON TABLE menu IS '功能選單';
COMMENT ON COLUMN menu.menu_code IS '選單編號';
COMMENT ON COLUMN menu.menu_name IS '選單名稱';
COMMENT ON COLUMN menu.menu_seq IS '選單次序';
COMMENT ON COLUMN menu.top_menu_id IS '上層選單編號';
COMMENT ON COLUMN menu.active_status IS '啟用狀態';
COMMENT ON COLUMN menu.modified_memo IS '修改備忘';

-- 權限與選單對應資料表
alter table if exists public.role_menu_mapping drop constraint if exists pk_role_menu_mapping;
drop table if exists public.role_menu_mapping;

CREATE TABLE role_menu_mapping (
    role_sys_id uuid NOT NULL,
    menu_sys_id uuid NOT NULL,
    creator_account character varying(100) DEFAULT '' NOT NULL,
    created_time timestamp DEFAULT current_timestamp NOT NULL,

    CONSTRAINT pk_role_menu_mapping PRIMARY KEY ( role_sys_id, menu_sys_id )
 )WITH (
    OIDS=FALSE
);

COMMENT ON TABLE role_menu_mapping IS '使用者角色_選單-對照';
COMMENT ON COLUMN role_menu_mapping.role_sys_id IS '角色序號';
COMMENT ON COLUMN role_menu_mapping.menu_sys_id IS '功能選單序號';
COMMENT ON COLUMN role_menu_mapping.creator_account IS '建立者帳號';
COMMENT ON COLUMN role_menu_mapping.created_time IS '建立時間';

-- 使用者操作紀錄資料表
alter table if exists public.action_log drop constraint if exists pk_action_log;
alter table if exists public.action_log drop constraint if exists uidx_action_log;
drop table if exists public.action_log;

CREATE TABLE action_log (
    sys_id uuid NOT NULL,
    action_time timestamp without time zone NOT NULL DEFAULT now(),
    remote_ip character varying(200) NOT NULL DEFAULT '',
    action_item character varying(100) NOT NULL,
    actor_account character varying(100) NOT NULL,
    action_result text NOT NULL DEFAULT ''::text,
    error_code character varying(100) NOT NULL DEFAULT '',
    event_level character varying(100),

    CONSTRAINT pk_action_log PRIMARY KEY (sys_id),
    CONSTRAINT uidx_action_log UNIQUE (action_time, actor_account, action_item)
)WITH (
  OIDS=FALSE
);

COMMENT ON TABLE action_log IS '使用者操作紀錄';
COMMENT ON COLUMN action_log.action_time IS '紀錄日期時間';
COMMENT ON COLUMN action_log.remote_ip IS '連線 IP';
COMMENT ON COLUMN action_log.action_item IS '紀錄功能或選單';
COMMENT ON COLUMN action_log.actor_account IS '使用者帳號';
COMMENT ON COLUMN action_log.action_result IS '操作結果';
COMMENT ON COLUMN action_log.error_code IS '錯誤代碼';
COMMENT ON COLUMN action_log.event_level IS '事件重要等級';

-- 登入管控資料表
alter table if exists public.login_control drop constraint if exists pk_login_control;
alter table if exists public.login_control drop constraint if exists uidx_login_control;
drop table if exists public.login_control;

CREATE TABLE login_control (
    sys_id uuid not null,
    session_id character varying(256) not null,
    login_account character varying(100) not null,
    cert_card_num character varying(32) default '' not null,
    login_time timestamp without time zone default current_timestamp not null,
    remote_ip character varying(256) default '' not null,
    login_count int not null,

    CONSTRAINT pk_login_control PRIMARY KEY ( sys_id ),
    CONSTRAINT uidx_login_control UNIQUE ( session_id, login_account )
)WITH (
  OIDS=FALSE
);

COMMENT ON TABLE login_control IS '登入管控';
COMMENT ON COLUMN login_control.session_id IS '登入的 session_id';
COMMENT ON COLUMN login_control.login_account IS '登入的使用者';
COMMENT ON COLUMN login_control.cert_card_num IS '使用者卡號';
COMMENT ON COLUMN login_control.login_time IS '登入時間';
COMMENT ON COLUMN login_control.remote_ip IS '遠端 IP';
COMMENT ON COLUMN login_control.login_count IS '登入次數';

-- 使用者最後登入視表
CREATE OR REPLACE VIEW last_access AS
    SELECT
        actor_account,
        remote_ip,
        max(action_time) AS action_time
    FROM action_log
    WHERE actor_account IN (SELECT account FROM user_info)
    AND action_item = 'webapp_001'
    AND action_result = 'success'
    GROUP BY actor_account, remote_ip
    ORDER BY actor_account, remote_ip;

-- 使用者登入次數視表
CREATE OR REPLACE VIEW login_count AS
    SELECT
        actor_account,
        count(*)::character varying(50) AS action_result
    FROM action_log
    WHERE actor_account IN ( SELECT account FROM user_info)
    AND action_item = 'webapp_001'
    AND action_result = 'success'
    GROUP BY actor_account;

-- DROP VIEW public.vlogin_control;

CREATE OR REPLACE VIEW login_maxtime AS
 SELECT login_control.sys_id,
    login_control.session_id,
    login_control.login_account,
    login_control.cert_card_num,
    login_control.login_time,
    login_control.login_time + '00:05:00'::interval AS maxlimit,
    login_control.remote_ip,
    login_control.login_count
   FROM login_control;


-- 建立權限
revoke all privileges on all tables in schema public from g2b2c_mgr;
grant all privileges on all tables in schema public to g2b2c_mgr;

revoke all privileges on all tables in schema public from g2b2c_usr;
grant select on all tables in schema public to g2b2c_usr;