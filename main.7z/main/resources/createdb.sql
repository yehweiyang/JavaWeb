-- 執行於 postgres
drop database if exists g2b2c_2017;

CREATE DATABASE g2b2c_2017 ENCODING = 'UTF8' CONNECTION LIMIT = -1;

drop role if exists g2b2c_mgr;

create role g2b2c_mgr login password '!QAZ 0okm';

drop role if exists g2b2c_usr;

create role g2b2c_usr login password '!QAZ 2wsx';

ALTER DATABASE g2b2c_2017 OWNER TO g2b2c_mgr;

-- 執行於 g2b2c_2017

-- 建立擴充元件
drop extension if exists "uuid-ossp";

create extension "uuid-ossp";

drop extension if exists "pgcrypto";

create extension "pgcrypto";
