# accessor

## 目的

負責檔案系統的存取機制