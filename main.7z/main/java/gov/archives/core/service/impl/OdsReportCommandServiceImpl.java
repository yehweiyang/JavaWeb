package gov.archives.core.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import gov.archives.core.command.OdsReportCommandProcessor;
import gov.archives.core.command.ReportCommand;
import gov.archives.core.command.ReportCommandProcessor;
import gov.archives.core.service.ReportCommandService;

/**
 * Created by kshsu on 2016/7/26.
 */
@Service("odsCommandService")
public class OdsReportCommandServiceImpl implements ReportCommandService {
    private Map<String, ReportCommand> commands = new HashMap<String, ReportCommand>();

    private ReportCommandProcessor reportCommandProcessor = new OdsReportCommandProcessor();

    @Override
    public void addCommand(String process, ReportCommand command) {
        commands.put(process, command);
    }

    @Override
    public void doProcess(String process) throws Exception {
        commands.get(process).execute(reportCommandProcessor);
    }
}
