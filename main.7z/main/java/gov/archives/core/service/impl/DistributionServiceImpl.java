package gov.archives.core.service.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.common.collect.ImmutableMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;

import gov.archives.common.json.JsonUtils;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.DistributeDocEntity;
import gov.archives.core.domain.entity.DistributeHistoryEntity;
import gov.archives.core.domain.entity.DistributeMappingEntity;
import gov.archives.core.domain.entity.DistributeUnitEntity;
import gov.archives.core.domain.vo.DistributeDoc;
import gov.archives.core.domain.vo.DistributeHistory;
import gov.archives.core.domain.vo.DistributeMapping;
import gov.archives.core.domain.vo.DistributeUnit;
import gov.archives.core.mapper.command.DistributionCommandMapper;
import gov.archives.core.mapper.query.DistributionQueryMapper;
import gov.archives.core.service.DistributionService;
import gov.archives.core.util.BeanUtils;
import gov.archives.core.util.DateTimeUtils;

/**
 * Created by tristan on 2016/8/25.
 */
@Service
@Transactional
public class DistributionServiceImpl implements DistributionService {
    private static final Logger log = LoggerFactory.getLogger(DistributionServiceImpl.class);

    @Autowired
    private DistributionQueryMapper queryMapper;

    @Autowired
    private DistributionCommandMapper commandMapper;

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void insertSenderUnit(DistributeUnitEntity senderUnitEntity) {
        PreconditionUtils.checkArguments(senderUnitEntity);
        commandMapper.saveSenderUnit(senderUnitEntity);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void insertReceiverUnit(DistributeUnitEntity receiverUnitEntity) {
        PreconditionUtils.checkArguments(receiverUnitEntity);
        commandMapper.saveReceiverUnit(receiverUnitEntity);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void deleteSenderUnit(DistributeUnitEntity senderUnitEntity) {
        PreconditionUtils.checkArguments(senderUnitEntity);
        this.deleteMappingBySenderUnitId(senderUnitEntity.getOrgId(), senderUnitEntity.getUnitId());
        commandMapper.removeSenderUnit(senderUnitEntity);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void deleteReceiverUnit(DistributeUnitEntity receiverUnitEntity) {
        PreconditionUtils.checkArguments(receiverUnitEntity);
        this.deleteMappingByReceiverUnitId(receiverUnitEntity.getOrgId(), receiverUnitEntity.getUnitId());
        commandMapper.removeReceiverUnit(receiverUnitEntity);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void deleteSenderUnitByOrgUnitId(DistributeUnit senderUnit) {
        PreconditionUtils.checkArguments(senderUnit);
        String orgId = senderUnit.getOrgId();
        String unitId = senderUnit.getUnitId();
        Map<String, String> idMap = new ImmutableMap.Builder<String, String>()
                .put(DistributionQueryMapper.KEY_ORG_ID, orgId)
                .put(DistributionQueryMapper.KEY_UNIT_ID, unitId)
                .build();
        this.deleteMappingBySenderUnitId(orgId, unitId);
        commandMapper.removeSenderUnitByOrgUnitId(idMap);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void deleteReceiverUnitByOrgUnitId(DistributeUnit receiverUnit) {
        PreconditionUtils.checkArguments(receiverUnit);
        String orgId = receiverUnit.getOrgId();
        String unitId = receiverUnit.getUnitId();
        Map<String, String> idMap = new ImmutableMap.Builder<String, String>()
                .put(DistributionQueryMapper.KEY_ORG_ID, orgId)
                .put(DistributionQueryMapper.KEY_UNIT_ID, unitId)
                .build();
        this.deleteMappingByReceiverUnitId(orgId, unitId);
        commandMapper.removeReceiverUnitByOrgUnitId(idMap);
    }

    @Override
    public DistributeUnitEntity getSenderUnitByOrgUnitId(Map queryMap) {
        PreconditionUtils.checkArguments(queryMap);
        return queryMapper.getSenderUnitByOrgUnitId(queryMap);
    }

    @Override
    public DistributeUnitEntity getReceiverUnitByOrgUnitId(Map queryMap) {
        PreconditionUtils.checkArguments(queryMap);
        return queryMapper.getReceiverUnitByOrgUnitId(queryMap);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<DistributeUnit> listSenderUnit(String centerId, String orgId, String unitId, String orgUnitName,
            boolean exactMatch) {
        Map<String, String> queryMap = new ImmutableMap.Builder<String, String>()
                .put(DistributionQueryMapper.CENTER_ID, centerId)
                .put(DistributionQueryMapper.KEY_ORG_ID, orgId)
                .put(DistributionQueryMapper.KEY_UNIT_ID, unitId)
                .put(DistributionQueryMapper.ORG_UNIT_NAME, orgUnitName)
                .put(DistributionQueryMapper.EXACT_MATCH, String.valueOf(exactMatch))
                .build();
        List<DistributeUnitEntity> distributeUnitEntityList = queryMapper.listSenderUnit(queryMap);
        /*List<DistributeUnit> distributeUnitList = new ArrayList<>();
        for(DistributeUnitEntity distributeUnitEntity : distributeUnitEntityList) {
            DistributeUnit distributeUnit = new DistributeUnit();
            BeanUtils.copyProperties(distributeUnit, distributeUnitEntity);
            distributeUnitList.add(distributeUnit);
        }
        return distributeUnitList;*/
        return getVOFromEntity(distributeUnitEntityList);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<DistributeUnit> listReceiverUnit(String centerId, String orgId, String unitId, String orgUnitName,
            boolean exactMatch) {
        Map<String, String> queryMap = new ImmutableMap.Builder<String, String>()
                .put(DistributionQueryMapper.CENTER_ID, centerId)
                .put(DistributionQueryMapper.KEY_ORG_ID, orgId)
                .put(DistributionQueryMapper.KEY_UNIT_ID, unitId)
                .put(DistributionQueryMapper.ORG_UNIT_NAME, orgUnitName)
                .put(DistributionQueryMapper.EXACT_MATCH, String.valueOf(exactMatch))
                .build();
        List<DistributeUnitEntity> distributeUnitEntityList = queryMapper.listReceiverUnit(queryMap);
        /*List<DistributeUnit> distributeUnitList = new ArrayList<>();
        for(DistributeUnitEntity distributeUnitEntity : distributeUnitEntityList) {
            DistributeUnit distributeUnit = new DistributeUnit();
            BeanUtils.copyProperties(distributeUnit, distributeUnitEntity);
            distributeUnitList.add(distributeUnit);
        }
        return distributeUnitList;*/
        return getVOFromEntity(distributeUnitEntityList);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<DistributeUnit> listCenterSenderUnit(String centerId) {
        List<DistributeUnitEntity> distributeUnitEntityList = queryMapper.listCenterSenderUnit(centerId);

        /*List<DistributeUnit> distributeUnitList = new ArrayList<>();
        for(DistributeUnitEntity distributeUnitEntity : distributeUnitEntityList) {
            DistributeUnit distributeUnit = new DistributeUnit();
            BeanUtils.copyProperties(distributeUnit, distributeUnitEntity);
            distributeUnitList.add(distributeUnit);
        }
        return distributeUnitList;*/
        return getVOFromEntity(distributeUnitEntityList);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<DistributeUnit> listCenterReceiverUnit(String centerId) {
        List<DistributeUnitEntity> distributeUnitEntityList = queryMapper.listCenterReceiverUnit(centerId);

        /*List<DistributeUnit> distributeUnitList = new ArrayList<>();
        for(DistributeUnitEntity distributeUnitEntity : distributeUnitEntityList) {
            DistributeUnit distributeUnit = new DistributeUnit();
            BeanUtils.copyProperties(distributeUnit, distributeUnitEntity);
            distributeUnitList.add(distributeUnit);
        }
        return distributeUnitList;*/
        return getVOFromEntity(distributeUnitEntityList);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<DistributeUnit> listReceiverUnitBySenderId(String orgId, String unitId) {
        Map<String, String> idMap = new ImmutableMap.Builder<String, String>()
                .put(DistributionQueryMapper.KEY_ORG_ID, orgId)
                .put(DistributionQueryMapper.KEY_UNIT_ID, unitId)
                .build();
        List<DistributeUnitEntity> distributeUnitEntityList = queryMapper.listReceiverUnitBySender(idMap);
        return getVOFromEntity(distributeUnitEntityList);
    }

    List<DistributeUnit> getVOFromEntity(List<DistributeUnitEntity> entityList) {
        List<DistributeUnit> distributeUnitList = new ArrayList<>();
        for (DistributeUnitEntity distributeUnitEntity : entityList) {
            DistributeUnit distributeUnit = new DistributeUnit();
            BeanUtils.copyProperties(distributeUnit, distributeUnitEntity);
            distributeUnitList.add(distributeUnit);
        }
        return distributeUnitList;
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false)
    public void insertDistributeMapping(DistributeMappingEntity mappingEntity) {
        PreconditionUtils.checkArguments(mappingEntity);
        commandMapper.saveMapping(mappingEntity);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false)
    public void deleteDistributeMapping(DistributeMappingEntity mappingEntity) {
        PreconditionUtils.checkArguments(mappingEntity);
        commandMapper.removeMapping(mappingEntity);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false)
    public void deleteMappingByOrgUnitId(DistributeMapping mapping) {
        PreconditionUtils.checkArguments(mapping);
        commandMapper.removeMappingByOrgUnitId(mapping);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false)
    public void deleteMappingBySenderUnitId(String orgId, String unitId) {
        PreconditionUtils.checkArguments(orgId);
        PreconditionUtils.checkArguments(unitId);
        Map<String, String> idMap = new ImmutableMap.Builder<String, String>()
                .put(DistributionQueryMapper.KEY_ORG_ID, orgId)
                .put(DistributionQueryMapper.KEY_UNIT_ID, unitId)
                .build();
        commandMapper.removeMappingBySenderUnitId(idMap);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false)
    public void deleteMappingByReceiverUnitId(String orgId, String unitId) {
        PreconditionUtils.checkArguments(orgId);
        PreconditionUtils.checkArguments(unitId);
        Map<String, String> idMap = new ImmutableMap.Builder<String, String>()
                .put(DistributionQueryMapper.KEY_ORG_ID, orgId)
                .put(DistributionQueryMapper.KEY_UNIT_ID, unitId)
                .build();
        commandMapper.removeMappingByReceiverUnitId(idMap);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<DistributeMapping> listMappingBySenderId(String orgId, String unitId) {
        Map<String, String> idMap = new ImmutableMap.Builder<String, String>()
                .put(DistributionQueryMapper.KEY_ORG_ID, orgId)
                .put(DistributionQueryMapper.KEY_UNIT_ID, unitId)
                .build();
        List<DistributeMappingEntity> mappingEntitiesList = queryMapper.listMappingBySenderId(idMap);
        List<DistributeMapping> mappingList = new ArrayList<>();
        for (DistributeMappingEntity mappingEntity : mappingEntitiesList) {
            DistributeMapping mapping = new DistributeMapping();
            BeanUtils.copyProperties(mapping, mappingEntity);
            mappingList.add(mapping);
        }
        return mappingList;
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public DistributeMappingEntity getMappingByOrgUnitId(DistributeMapping distributeMapping) {
        PreconditionUtils.checkArguments(distributeMapping);
        return queryMapper.getMappingByOrgUnitId(distributeMapping);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<DistributeDoc> listDistributeDoc(String processId, int status, String fromOrgId, String fromUnitId,
            String fromOrgUnitName, String toOrgId, String toUnitId, String toOrgUnitName, String fromTime,
            String toTime, boolean exactMatch) {
        Map<String, String> queryMap = new ImmutableMap.Builder<String, String>()
                .put(DistributionQueryMapper.PROCESS_ID, processId)
                .put(DistributionQueryMapper.STATUS, String.valueOf(status))
                .put(DistributionQueryMapper.FROM_ORG_ID, fromOrgId)
                .put(DistributionQueryMapper.FROM_UNIT_ID, fromUnitId)
                .put(DistributionQueryMapper.FROM_ORG_UNIT_NAME, fromOrgUnitName)
                .put(DistributionQueryMapper.TO_ORG_ID, toOrgId)
                .put(DistributionQueryMapper.TO_UNIT_ID, toUnitId)
                .put(DistributionQueryMapper.TO_ORG_UNIT_NAME, toOrgUnitName)
                .put(DistributionQueryMapper.FROM_TIME, DateTimeUtils.convertLocalFromUtcTime(fromTime))
                .put(DistributionQueryMapper.TO_TIME, DateTimeUtils.convertLocalFromUtcTime(toTime))
                .put(DistributionQueryMapper.EXACT_MATCH, String.valueOf(exactMatch))
                .build();
        log.info("QueryDistDoc: " + JsonUtils.getJsonTextByObject(queryMap));
        List<DistributeDocEntity> distDocEntityList = queryMapper.listDistributeDoc(queryMap);
        List<DistributeDoc> distDocList = new ArrayList<>();
        for (DistributeDocEntity distDocEntity : distDocEntityList) {
            DistributeDoc distDoc = new DistributeDoc();
            BeanUtils.copyProperties(distDoc, distDocEntity);
            distDoc.setInsertTime(getTimestampStrWithoutMs(distDocEntity.getInsertTime()));
            if (distDocEntity.getConfirmTime() != null) {
                distDoc.setConfirmTime(getTimestampStrWithoutMs(distDocEntity.getConfirmTime()));
            }
            distDocList.add(distDoc);
        }
        return distDocList;
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public List<DistributeHistory> listDistributeHistoryByProcessId(String processId) {
        List<DistributeHistoryEntity> historyEntityList = queryMapper.listDistributeHistoryByProcessId(processId);
        List<DistributeHistory> historyList = new ArrayList<>();
        for (DistributeHistoryEntity historyEntity : historyEntityList) {
            DistributeHistory history = new DistributeHistory();
            BeanUtils.copyProperties(history, historyEntity);
            history.setDistTime(getTimestampStrWithoutMs(historyEntity.getDistTimestamp()));
            historyList.add(history);
        }
        return historyList;
    }

    public String getTimestampStrWithoutMs(Timestamp timestamp) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(timestamp);
    }
}
