package gov.archives.core.service;

import java.util.List;
import java.util.Map;

import gov.archives.core.domain.entity.DistributeMappingEntity;
import gov.archives.core.domain.entity.DistributeUnitEntity;
import gov.archives.core.domain.vo.DistributeDoc;
import gov.archives.core.domain.vo.DistributeHistory;
import gov.archives.core.domain.vo.DistributeMapping;
import gov.archives.core.domain.vo.DistributeUnit;

/**
 * Created by tristan on 2016/8/25.
 */
public interface DistributionService {
    void insertSenderUnit(DistributeUnitEntity senderUnitEntity);
    void insertReceiverUnit(DistributeUnitEntity receiverUnitEntity);
    void deleteSenderUnit(DistributeUnitEntity senderUnitEntity);
    void deleteReceiverUnit(DistributeUnitEntity receiverUnitEntity);
    void deleteSenderUnitByOrgUnitId(DistributeUnit senderUnit);
    void deleteReceiverUnitByOrgUnitId(DistributeUnit receiverUnit);
    DistributeUnitEntity getSenderUnitByOrgUnitId(Map queryMap);
    DistributeUnitEntity getReceiverUnitByOrgUnitId(Map queryMap);

    List<DistributeUnit> listSenderUnit(String centerId, String orgId, String unitId, String orgUnitName, boolean exactMatch);
    List<DistributeUnit> listReceiverUnit(String centerId, String orgId, String unitId, String orgUnitName, boolean exactMatch);
    List<DistributeUnit> listCenterSenderUnit(String centerId);
    List<DistributeUnit> listCenterReceiverUnit(String centerId);

    void insertDistributeMapping(DistributeMappingEntity mappingEntity);
    void deleteDistributeMapping(DistributeMappingEntity mappingEntity);
    void deleteMappingByOrgUnitId(DistributeMapping mapping);
    void deleteMappingBySenderUnitId(String orgId, String unitId);
    void deleteMappingByReceiverUnitId(String orgId, String unitId);
    List<DistributeUnit> listReceiverUnitBySenderId(String orgId,  String unitId);
    List<DistributeMapping> listMappingBySenderId(String orgId, String unitId);
    DistributeMappingEntity getMappingByOrgUnitId(DistributeMapping distributeMapping);

    List<DistributeDoc> listDistributeDoc(String processId, int status, String fromOrgId, String fromUnitId, String fromOrgUnitName,
            String toOrgId, String toUnitId, String toOrgUnitName, String fromTime, String toTime, boolean exactMatch);
    List<DistributeHistory> listDistributeHistoryByProcessId(String processId);
}
