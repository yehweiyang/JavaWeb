package gov.archives.core.service;

import java.util.List;
import java.util.UUID;

import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.vo.RoleMenuMapping;
import gov.archives.core.domain.vo.RoleName;

/**
 * RoleService
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
public interface RoleService {
    RoleEntity getBySysId(UUID sysId);

    RoleEntity getByRoleName(String roleName);

    List<RoleEntity> getOtherList(RoleEntity role);

    List<RoleEntity> getRoleList();

    List<RoleEntity> getRoleListByStatus(int status);

    void insert(RoleEntity role);

    void update(RoleEntity role);

    void delete(RoleEntity role);

    RoleMenuMapping getMenuMappingByRoleName(String roleName);

    RoleMenuMapping getMenuMappingByRoleSysId(UUID roleSysId);

    void updateRoleMenuMapping(RoleMenuMapping mapping);

    void deleteMenuMapping(RoleEntity role);

    List<RoleName> listRoleName();
}
