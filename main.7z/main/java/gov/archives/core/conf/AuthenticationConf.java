package gov.archives.core.conf;

/**
 * Created by 140631 on 2016/8/5.
 */
public class AuthenticationConf {
    public static final String PARAM_USER_NAME = "account";
    public static final String LOGIN_PROCESSOR_URL = "/core/login";
    public static final String PARAM_CARD_NUM = "cardNo";
}
