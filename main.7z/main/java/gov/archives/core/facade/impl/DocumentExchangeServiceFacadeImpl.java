package gov.archives.core.facade.impl;

import java.io.File;
import java.sql.Timestamp;
import java.util.Map;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.AccountForm;
import gov.archives.core.domain.vo.VerifyResult;
import gov.archives.core.exception.BadCaptchaException;
import gov.archives.core.facade.DocumentExchangeServiceFacade;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.service.UserIdentityService;
import gov.archives.core.service.UserInfoService;

@Transactional
@Service
public class DocumentExchangeServiceFacadeImpl implements DocumentExchangeServiceFacade {
    private static final Logger log = LoggerFactory.getLogger(DocumentExchangeServiceFacadeImpl.class);
    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private UserIdentityService userIdentityService;

    @Autowired
    private ActionLogService actionLogService;


    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
    		isolation = Isolation.REPEATABLE_READ,
            propagation = Propagation.REQUIRED,
            rollbackFor = AuthenticationException.class)
    public void accountRegister(AccountForm account, HttpServletRequest request, Map<String, Object> model)
            throws AuthenticationException {
        // TODO Auto-generated method stub
        HttpSession session = request.getSession();
        //ActionLogEntity actlog = new ActionLogEntity();
        UUID sysId = UUID.randomUUID();
        ActionLogEntity actionLogEmtity = new ActionLogEntity();
        UUID roleSysId = UUID.fromString("00000000-0000-0000-0000-000000000000");
        try {

            String captcha = request.getParameter("captcha");
            String CAPTCHA = (String) session.getAttribute("CAPTCHA");

            if (!CAPTCHA.equals(captcha)) {
                throw new BadCaptchaException(CoreErrorCode.CODE_CAPTCHA_ERROR);
            }
            UserInfoEntity user = userInfoService.getByAccount(account.getUserName());

            log.info("start new user : " + captcha + " " + account.getUserName() + " " + account.getCardNo());
            if ((null != user && user.getAccount().equals(account.getUserName()))) {
                throw new UsernameNotFoundException(CoreErrorCode.CODE_ACCOUNT_ALREADY_USE);
            }
            File realFile = new File(request.getServletContext().getRealPath(""));
            String certSHA256Hash = userIdentityService.saveRequestCertificate(account.getCertb64(),
            		realFile,
                    account.getCardNo(),
                    session.getLastAccessedTime());	

            user = new UserInfoEntity();
            // save to database
            user.setAccount(account.getUserName());
            user.setUserName(account.getFullName());
            user.setPhoneNumber(account.getPhoneLocal() + "-" + account.getPhoneNum() + "#" + account.getPhonExt());
            user.setMobileNumber(account.getMobileLocal() + "-" + account.getMobileNum());
            user.setEmail(account.geteMailAddr());
            user.setCertCardNum(account.getCardNo());
            user.setCertHash(certSHA256Hash);
            user.setOrgInfo(" ");
            user.setActiveStatus(0);
            user.setRoleSysId(roleSysId);
            user.setDeputyAccount("");
            user.initSave(account.getUserName());
            log.info("login_save " + user.toString());
            userInfoService.insert(user);

            actionLogEmtity.setSysId(sysId);
            actionLogEmtity.setActionTime(new Timestamp(session.getLastAccessedTime()));
            actionLogEmtity.setRemoteIp(request.getRemoteAddr());
            actionLogEmtity.setActorAccount(account.getUserName());
            actionLogEmtity.setActionItem("EXT-002");
            actionLogEmtity.setActionResult("success");
            actionLogEmtity.setErrorCode("");
            actionLogEmtity.setEventLevel("A");
            log.info("log_save " + ToStringBuilder.reflectionToString(actionLogEmtity));
            actionLogService.insert(actionLogEmtity);
        } catch (AuthenticationException e) {
            log.info("new user error eee " + e);
            VerifyResult verifyResult = userIdentityService.userIdentityException(e);
            log.info("new user error " + e + verifyResult.getErrorMessage());
            actionLogEmtity.setSysId(sysId);
            actionLogEmtity.setActionTime(new Timestamp(session.getLastAccessedTime()));
            actionLogEmtity.setRemoteIp(request.getRemoteAddr());
            actionLogEmtity.setActorAccount(account.getUserName());
            actionLogEmtity.setActionItem("EXT-002");
            actionLogEmtity.setActionResult(verifyResult.getErrorMessage());
            actionLogEmtity.setErrorCode(verifyResult.getErrorCode());
            actionLogEmtity.setEventLevel("Fail");
            log.info("log_save " + ToStringBuilder.reflectionToString(actionLogEmtity));
            actionLogService.insert(actionLogEmtity);
            log.info("accountRegister: " + verifyResult.toString());
            model.put("errorMessage", verifyResult.getErrorMessage());
            throw new AuthenticationServiceException(verifyResult.getErrorMessage());
        }
        model.put("errorMessage", "申請帳號成功!!");
    }

}
