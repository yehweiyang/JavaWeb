package gov.archives.core.facade;

import gov.archives.core.domain.vo.ReportInputModel;

/**
 * Created by kshsu on 2016/7/26.
 */
public interface ReportOutputFacade {

    public void genReportToFile(ReportInputModel reportInputModel) throws Exception;

    public void genReportToStream(ReportInputModel reportInputModel) throws Exception;

    public void genReportToByteArray(ReportInputModel reportInputModel) throws Exception;
}
