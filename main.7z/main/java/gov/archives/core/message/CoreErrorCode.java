package gov.archives.core.message;

/**
 * Created by 140631 on 2016/7/26.
 */
public class CoreErrorCode {
    public static final String SYSTEM_ERROR = "SYS0000";
    public static final String UNAUTHORIZED = "SYS0001";
    public static final String FILE_SAVE_FAIL = "SYS0003";

    public static final String DATA_NOT_FOUND = "AP0000";
    public static final String CAPTCHA_ERROR = "AP0001";
    public static final String ACCOUNT_ERROR = "AP0002";
    public static final String PIN_ERROR = "AP0003";
    public static final String CARD_EXPIRED = "AP0004";
    public static final String CARD_NOT_AVAILABLE = "AP0005";
    public static final String SIGNATURE_ERROR = "AP0006";
    public static final String CARD_NOT_MATCH_DATA = "AP0007";
    public static final String LOGIN_EXPIRED = "AP0008";
    public static final String CARD_INCORRECT = "AP0011";
    public static final String DUPLICATE_ACCOUNT = "AP0012";
    public static final String ACCOUNT_PROCESSING = "AP0013";
    public static final String ACCOUNT_SUSPENDED = "AP0014";
    public static final String PHONE_TYPE_INCORRECT = "ED0001";
    public static final String PHONE_FORMAT_INCORRECT = "ED0002";
    public static final String EMAIL_FORMAT_INCORRECT = "ED0003";
    public static final String USER_ACCOUNT_FORMAT_INCORRECT = "ED0017";
    public static final String USER_NAME_FORMAT_INCORRECT = "ED0018";
    public static final String ROLE_VALUE_INCORRECT = "ED9000";
    public static final String ORG_INFO_FORMAT_INCORRECT = "ED9001";

    public static final String ROLE_VALUE_SEARCH = "RO0001";
    public static final String ROLE_VALUE_ADD = "RO0002";
    public static final String ROLE_VALUE_UPDATE = "RO0003";
    public static final String ROLE_VALUE_MENUMODIFY = "RO0004";

    public static final String REPORT_INIT_ERROR = "PR0001";
    public static final String REPORT_QUERY_ERROR = "PR0002";
    public static final String REPORT_DOWNLOAD_ERROR = "PR0003";
    public static final String REPORT_RESAVE_ERROR = "PR0004";

    public static final String ORG_ID_INCORRECT = "CEX0001";
    public static final String LOG_FILE_INEXISTENCE = "CEX0002";
    public static final String LOG_FILE_ERROR = "CEX0003";


}
