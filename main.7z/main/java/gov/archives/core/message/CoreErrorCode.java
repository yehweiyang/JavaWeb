package gov.archives.core.message;

/**
 * Created by 140631 on 2016/7/26.
 */
public class CoreErrorCode {
    public static final String CODE_CAPTCHA_ERROR = "ERROR_AP001";
    public static final String CODE_ACCOUNT_ERROR = "ERROR_AP002";
    public static final String CODE_PIN_ERROR = "ERROR_AP003";
    public static final String CODE_CARD_EXPIRED = "ERROR_AP004";
    public static final String CODE_CARD_NOT_AVAILABLE = "ERROR_AP005";
    public static final String CODE_SIGNATURE_ERROR = "ERROR_AP0006";
    public static final String CODE_CARD_NOT_MATCH_DATA = "ERROR_AP007";
    public static final String CODE_LOGIN_EXPIRED = "ERROR_AP008";
    public static final String CODE_ACCOUNT_IS_APPLICANT = "ERROR_AP0011";
    public static final String CODE_ACCOUNT_ALREADY_USE = "ERROR_AP0012";
    public static final String CODE_PHONE_TYPE_ERROR = "ERROR_ED0001";
    public static final String CODE_PHONE_LENGTH_ERROR = "ERROR_ED0002";
    public static final String CODE_EMAIL_FORMAT_ERROR = "ERROR_ED0003";
    public static final String CODE_ACCOUNT_FORMAT_ERROR = "ERROR_ED0017";
    public static final String CODE_NAME_FORMAT_ERROR = "ERROR_ED0018";
    public static final String CODE_ACCOUNT_NO_RIGHT = "ERROR_SYS001";
    public static final String FILE_SAVE_FAIL = "ERROR_SYS003";
}
