package gov.archives.core.security;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.www.BasicAuthenticationEntryPoint;

import gov.archives.core.conf.AuthenticationConf;
import gov.archives.core.conf.CoreConf;

@EnableWebSecurity
public class SecurityConfig {

    @Configuration
    @Order(1)
    public static class RestSecurityConfigurationAdapter extends WebSecurityConfigurerAdapter {
        @Autowired
        private RestAuthenticationProvider restAuthenticationProvider;

        @Autowired
        public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
            auth.authenticationProvider(restAuthenticationProvider);
        }

        @Bean
        RestBasicAuthenticationFilter restBasicAuthenticationFilter() throws Exception {
            List<AuthenticationProvider> authenticationProviderList = new ArrayList<>();
            authenticationProviderList.add(restAuthenticationProvider);
            AuthenticationManager authenticationManager = new ProviderManager(authenticationProviderList);
            BasicAuthenticationEntryPoint entryPoint = new BasicAuthenticationEntryPoint();
            entryPoint.setRealmName(CoreConf.SYSTEM_NAME);
            RestBasicAuthenticationFilter authenticationFilter =
                    new RestBasicAuthenticationFilter(authenticationManager, entryPoint);
            authenticationFilter.setBeanName("RestFilter");
            authenticationFilter.setAuthenticationDetailsSource(new RestAuthenticationDetailsSource());
            return authenticationFilter;
        }

        @Override
        protected void configure(HttpSecurity http) throws Exception {
            http.antMatcher(CoreConf.REST_API_VERSION + "/**")
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .addFilter(restBasicAuthenticationFilter())
                .authorizeRequests()
                .antMatchers(HttpMethod.GET, CoreConf.REST_API_VERSION + "/**").permitAll()
                .antMatchers(HttpMethod.POST, CoreConf.REST_API_VERSION + "/**").permitAll()
                .and()
                .csrf().disable()
                .httpBasic().realmName(CoreConf.SYSTEM_NAME);
        }
    }

    @Configuration
    public static class LoginWeFormbSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {
        @Autowired
        private DocumentUserAuthenticationProvider documentUserAuthenticationProvider;

        @Autowired
        public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
            auth.authenticationProvider(documentUserAuthenticationProvider);
        }

        @Bean
        CaptchaPKIAuthenticationFilter authenticationFilter() throws Exception {
            List<AuthenticationProvider> authenticationProviderList = new ArrayList<>();
            authenticationProviderList.add(documentUserAuthenticationProvider);
            AuthenticationManager authenticationManager = new ProviderManager(authenticationProviderList);

            CaptchaPKIAuthenticationFilter authenticationFilter = new CaptchaPKIAuthenticationFilter();
            authenticationFilter.setFilterProcessesUrl(AuthenticationConf.LOGIN_PROCESSOR_URL);
            authenticationFilter.setAuthenticationManager(authenticationManager);
            authenticationFilter.setUsernameParameter(AuthenticationConf.PARAM_USER_NAME);
            authenticationFilter.setPasswordParameter(AuthenticationConf.PARAM_CARD_NUM);
            SavedRequestAwareAuthenticationSuccessHandler successHandler =
                    new SavedRequestAwareAuthenticationSuccessHandler();
            successHandler.setDefaultTargetUrl(CoreConf.INDEX_URL);
            authenticationFilter.setAuthenticationSuccessHandler(successHandler);
            SimpleUrlAuthenticationFailureHandler failureHandler = new SimpleUrlAuthenticationFailureHandler();
            failureHandler.setDefaultFailureUrl(CoreConf.LOGIN_URL + "?error");
            authenticationFilter.setAuthenticationFailureHandler(failureHandler);
            return authenticationFilter;
        }

        @Override
        protected void configure(HttpSecurity http) throws Exception {
            http.sessionManagement()
                .maximumSessions(CoreConf.SESSION_LIMIT).expiredUrl("/sessionExpired.jsp")
                .and()
                .sessionFixation().migrateSession()
                .invalidSessionUrl("/invalidSession.jsp")
                .and()
                .exceptionHandling()
                .authenticationEntryPoint(new LoginUrlAuthenticationEntryPoint(CoreConf.LOGIN_URL))
                .and()
                .authorizeRequests()
                .antMatchers(CoreConf.INDEX_URL).permitAll()
                .antMatchers("/newAccount").permitAll()
                .and()
                .addFilterBefore(authenticationFilter(), UsernamePasswordAuthenticationFilter.class)
                .exceptionHandling()
                .accessDeniedPage("/errors/403")
                .and()
                .csrf().disable()
                .logout()
                .permitAll();
        }
    }
}
