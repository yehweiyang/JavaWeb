package gov.archives.core.security;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.DocumentUserAuthorityUtils;

@Component
public class RestAuthenticationProvider implements AuthenticationProvider {
    private UserInfoService userService;

    @Autowired
    public void setUserInfoService(UserInfoService userService) {
        if (null == userService) {
            throw new IllegalArgumentException("userService cannot be null");
        }
        this.userService = userService;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) authentication;
        String principal = (String) auth.getPrincipal();
        String credential = (String) auth.getCredentials();
        UserInfoEntity user = userService.getByAccount(principal);
        if (null == user || !user.getCertCardNum().equals(credential)) {
            throw new UsernameNotFoundException("Invalid username/password.");
        }
        Collection<? extends GrantedAuthority> authorities = DocumentUserAuthorityUtils.createAuthorities(null, true);
        return new UsernamePasswordAuthenticationToken(principal, credential, authorities);
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.getSimpleName().equals(UsernamePasswordAuthenticationToken.class.getSimpleName());
    }
}
