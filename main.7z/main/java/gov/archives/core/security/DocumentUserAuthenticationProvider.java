package gov.archives.core.security;

import java.util.Collection;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.util.DocumentUserAuthorityUtils;

@Component
public class DocumentUserAuthenticationProvider implements AuthenticationProvider {

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		CaptchaPKIAuthenticationToken token = (CaptchaPKIAuthenticationToken) authentication;
		UserInfoEntity user = token.getUser();
		String cardNo = user.getCertCardNum();
		Collection<? extends GrantedAuthority> authorities = DocumentUserAuthorityUtils.createAuthorities(user, false);
		return new CaptchaPKIAuthenticationToken(user, cardNo, authorities);
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.getSimpleName().equals(CaptchaPKIAuthenticationToken.class.getSimpleName());
	}
}
