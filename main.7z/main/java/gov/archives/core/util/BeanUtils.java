package gov.archives.core.util;

import java.lang.reflect.InvocationTargetException;

import org.iii.common.exception.ApplicationException;

/**
 * Created by 140631 on 2016/7/25.
 */
public abstract class BeanUtils {

    private BeanUtils() {}

    public static void copyProperties(Object dest, Object source) {
        try {
            org.apache.commons.beanutils.BeanUtils.copyProperties(dest, source);
        } catch (InvocationTargetException | IllegalAccessException e) {
            throw new ApplicationException(e);
        }
    }
}
