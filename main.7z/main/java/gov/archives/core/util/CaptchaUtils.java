package gov.archives.core.util;

import java.security.SecureRandom;

public abstract class CaptchaUtils {
	private CaptchaUtils() {}

	public static String generateCaptcha(int minLength, int maxLength, String saltChars) {
		int length = getRandomNumberInRange(minLength, maxLength);

		return generateCaptchaTextMethod2(length, saltChars);
	}

	private static int getRandomNumberInRange(int min, int max) {
		SecureRandom r = new SecureRandom();

		return r.nextInt((max - min) + 1) + min;
	}

	private static String generateCaptchaTextMethod2(int length, String saltChars) {
		StringBuffer captchaStrBuffer = new StringBuffer();
		SecureRandom rnd = new SecureRandom();

		while (captchaStrBuffer.length() < length) {
			int index = (int) (rnd.nextFloat() * saltChars.length());

			captchaStrBuffer.append(saltChars.substring(index, index + 1));
		}

		return captchaStrBuffer.toString();
	}
}
