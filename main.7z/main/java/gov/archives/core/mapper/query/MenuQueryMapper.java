package gov.archives.core.mapper.query;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import gov.archives.core.domain.entity.MenuEntity;

/**
 * MenuQueryMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
public interface MenuQueryMapper {
    MenuEntity findByMenuCode(String menuCode);

    List<MenuEntity> findAllMenu();

    List<MenuEntity> findAllRouter();

    MenuEntity findBySysId(UUID sysId);
}
