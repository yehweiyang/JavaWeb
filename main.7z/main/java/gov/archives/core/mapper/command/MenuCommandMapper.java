package gov.archives.core.mapper.command;

import gov.archives.core.domain.entity.MenuEntity;

/**
 * MenuCommandMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
public interface MenuCommandMapper {
    void save(MenuEntity menu);

    void update(MenuEntity menu);

    void remove(MenuEntity menu);
}
