package gov.archives.core.command;

/**
 * Created by kshsu on 2016/7/26.
 */
public interface ReportCommand {
    void execute(ReportCommandProcessor reportCommandProcessor) throws Exception;
}
