package gov.archives.core.command;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Lists;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;

import org.iii.common.util.PreconditionUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.ReportData;
import gov.archives.core.domain.vo.ReportInputModel;
import gov.archives.core.util.ReportUtils;

/**
 * Created by kshsu on 2016/7/26.
 */
public class ReportBaseCommand {
    protected static final String TEMP_FILE_NAME = "temp";
    protected static final String DATETIME_FORMAT = "yyyyMMddHHmmss";

    protected String sourceFilePath = null;
    protected Object javaBean = null;
    protected byte[] output = null;
    protected Map<String, Object> reportParameter = null;
    protected String reportType = null;
    protected String destFilePath = null;
    protected OutputStream os = null;
    protected ReportInputModel baseReportInputModel;

    protected String tmpFileDir = "src/main/webapp/WEB-INF/report/tmp/";
    protected String todayString;

    public JasperPrint reportConvertTo(InputStream is, Map<String, Object> reportParameter) throws Exception {

        PreconditionUtils.checkArguments(is, reportParameter);

        return JasperFillManager.fillReport(is, reportParameter);
    }

    public JasperPrint reportConvertTo(InputStream is, Map<String, Object> reportParameter, Connection connection)
            throws Exception {

        PreconditionUtils.checkArguments(is, reportParameter, connection);

        return JasperFillManager.fillReport(is, reportParameter, connection);
    }

    public JasperPrint reportConvertTo(InputStream is, Map<String, Object> reportParameter, JRDataSource dataSource)
            throws Exception {

        PreconditionUtils.checkArguments(is, reportParameter, dataSource);

        return JasperFillManager.fillReport(is, reportParameter, dataSource);
    }

    public JasperPrint reportConvertTo(JasperReport jasperReport, Map<String, Object> reportParameter)
            throws Exception {

        PreconditionUtils.checkArguments(jasperReport, reportParameter);

        return JasperFillManager.fillReport(jasperReport, reportParameter);

    }

    public JasperPrint reportConvertTo(JasperReport jasperReport, Map<String, Object> reportParameter,
            Connection connection)
            throws Exception {

        PreconditionUtils.checkArguments(jasperReport, reportParameter, connection);

        return JasperFillManager.fillReport(jasperReport, reportParameter, connection);

    }

    public JasperPrint reportConvertTo(JasperReport jasperReport, Map<String, Object> reportParameter,
            JRDataSource dataSource)
            throws Exception {

        PreconditionUtils.checkArguments(jasperReport, reportParameter, dataSource);

        return JasperFillManager.fillReport(jasperReport, reportParameter, dataSource);

    }

    public JasperPrint reportConvertTo(String sourceFilePath, Map<String, Object> reportParameter) throws Exception {

        PreconditionUtils.checkArguments(sourceFilePath, reportParameter);

        return JasperFillManager.fillReport(sourceFilePath, reportParameter);
    }

    public JasperPrint reportConvertTo(String sourceFilePath, Map<String, Object> reportParameter,
            Connection connection)
            throws Exception {

        PreconditionUtils.checkArguments(sourceFilePath, reportParameter, connection);

        return JasperFillManager.fillReport(sourceFilePath, reportParameter, connection);
    }

    public JasperPrint reportConvertTo(String sourceFilePath, Map<String, Object> reportParameter,
            JRDataSource dataSource)
            throws Exception {

        PreconditionUtils.checkArguments(sourceFilePath, reportParameter);

        return JasperFillManager.fillReport(sourceFilePath, reportParameter, dataSource);
    }

    public void reportConvertToStream(InputStream is, OutputStream os, Map<String, Object> reportParameter)
            throws Exception {

        PreconditionUtils.checkArguments(is, os, reportParameter);

        JasperFillManager.fillReportToStream(is, os, reportParameter);
    }

    public void reportConvertToStream(JasperReport jasperReport, OutputStream os, Map<String, Object> reportParameter,
            JRDataSource dataSource) throws Exception {

        PreconditionUtils.checkArguments(jasperReport, os, reportParameter, dataSource);

        JasperFillManager.fillReportToStream(jasperReport, os, reportParameter, dataSource);
    }

    public void reportConvertToFile(JasperReport jasperReport, String destFileName, Map<String, Object> reportParameter)
            throws Exception {

        PreconditionUtils.checkArguments(jasperReport, destFileName, reportParameter);

        JasperFillManager.fillReportToFile(jasperReport, destFileName, reportParameter);
    }

    public String reportConvertToFile(String sourceFilePath, Map<String, Object> reportParameter) throws Exception {

        PreconditionUtils.checkArguments(sourceFilePath, reportParameter);

        return JasperFillManager.fillReportToFile(sourceFilePath, reportParameter);
    }

    public void reportConvertToFile(String sourceFilePath, String destFileName, Map<String, Object> reportParameter)
            throws Exception {

        PreconditionUtils.checkArguments(sourceFilePath, destFileName, reportParameter);

        JasperFillManager.fillReportToFile(sourceFilePath, destFileName, reportParameter);
    }

    public void reportConvertToFile(JasperReport jasperReport, String destFileName, Map<String, Object> reportParameter,
            JRDataSource dataSource) throws Exception {

        PreconditionUtils.checkArguments(jasperReport, destFileName, reportParameter);

        JasperFillManager.fillReportToFile(jasperReport, destFileName, reportParameter, dataSource);
    }

    public String reportConvertToFile(String sourceFilePath, Map reportParameter, JRDataSource dataSource)
            throws Exception {

        PreconditionUtils.checkArguments(sourceFilePath, reportParameter, dataSource);

        return JasperFillManager.fillReportToFile(sourceFilePath, reportParameter, dataSource);
    }

    public void reportConvertToFile(String sourceFilePath, String destFileName, Map reportParameter,
            JRDataSource dataSource) throws Exception {

        PreconditionUtils.checkArguments(sourceFilePath, destFileName, reportParameter);

        JasperFillManager.fillReportToFile(sourceFilePath, destFileName, reportParameter);
    }

    public ReportData getReportDataVO(Object javaBean) throws Exception {

        ReportData reportData = null;
        if (null != javaBean) {
            reportData = convertJsonNodeToReportFormat(ReportUtils.convertBeanToJsonNode(javaBean));
        }
        return reportData;
    }

    private ReportData convertJsonNodeToReportFormat(JsonNode jsNodeBean) {
        boolean isArray = jsNodeBean.isArray();
        ReportData reportData = new ReportData();
        /* 拆解 JsonNode 並填入欄位資訊 */
        reportData.setHeaderString(getHeaderStringFromJsonNode(jsNodeBean));
        reportData.setReportContent(getDataBodyFromJsonNode(jsNodeBean));
        return reportData;
    }

    private Object[] getHeaderStringFromJsonNode(JsonNode jsNodeBean) {
        return Lists.newArrayList(
                (jsNodeBean.isArray() ? jsNodeBean.get(0) : jsNodeBean)
                        .fieldNames()).toArray();
    }

    private Object[][] getDataBodyFromJsonNode(JsonNode jsNodeBean) {
        Object[][] reportDataBody = new Object[jsNodeBean.size()][];
        List<String> rowColumnData = new ArrayList<>();
        for (int i = 0; i < jsNodeBean.size(); i++) {
            rowColumnData.clear();
            (jsNodeBean.isArray() ?
                    jsNodeBean.get(i) :
                    jsNodeBean).fields()
                               .forEachRemaining(nodeIter -> {
                                   rowColumnData.add(nodeIter.getValue().asText());
                               });
            reportDataBody[i] = rowColumnData.toArray();
            if (!jsNodeBean.isArray()) { break; }
        }
        return reportDataBody;
    }

    /**
     * 建立 Ods 報表檔案
     */
    protected void createOds(File reportOdsFile, ReportData reportdata) throws IOException {
        Sheet sheet = SpreadSheet.createEmpty(reportdata.getDefaultTableModel()).getSheet(0);
        sheet.setName("Merge Sheet");
        sheet.getCellAt("A1").merge(reportdata.getHeaderString().length, 1);
        sheet.getSpreadSheet().saveAs(reportOdsFile);
    }

    /**
     * 轉為 jOpenDocument Ods 報表格式
     */
    protected ReportData convertToOdsFormat(ReportData reportData, Map<String, Object> params) {
        ReportData odsFormat = new ReportData();

        List<Object> mergeArray = new ArrayList<Object>();
        mergeArray.add("製作日期: " + ReportUtils.getTodayString(DATETIME_FORMAT));
        mergeArray.add("日期區間: " + params.get("dateFrom") + " ~ " + params.get("dateTo"));
        mergeArray.add(Arrays.asList(reportData.getHeaderString()));
        mergeArray.addAll(
                Arrays.stream(reportData.getReportContent()).map(Arrays::asList).collect(Collectors.toList())
        );

        Object[][] odsContent = mergeArray.stream().map(
                subArray ->
                        subArray instanceof List ?
                                ((List<?>) subArray).toArray() :
                                new Object[]{subArray}).toArray(Object[][]::new);
        odsFormat.setHeaderString(
                newEmptyArrayFromTitleStr((String) params.get("title"), reportData.getHeaderString().length));
        odsFormat.setReportContent(odsContent);
        return odsFormat;
    }

    /**
     * 建立 jOpenDocument Ods Title 格式
     */
    protected String[] newEmptyArrayFromTitleStr(String titleStr, int arrayLength) {
        String[] strArray = new String[arrayLength];
        strArray[0] = titleStr;
        for (int i = 1; i < strArray.length; i++) {
            strArray[i] = "";
        }
        return strArray;
    }

    /**
     * 轉換File To byte[] Array
     */
    protected byte[] getBytesFromFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);

        //取得檔案大小
        long length = file.length();
        byte[] bytes = new byte[(int) length];

        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
                && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
            offset += numRead;
        }

        is.close();
        return bytes;
    }

    protected String getTodayTempOdsFile() {
        String todayString = ReportUtils.getTodayString(DATETIME_FORMAT);
        return TEMP_FILE_NAME + "_" + todayString + CoreConf.SUFFIX_ODS;
    }
}
