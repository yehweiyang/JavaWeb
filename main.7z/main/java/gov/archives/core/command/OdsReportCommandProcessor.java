package gov.archives.core.command;

import java.io.File;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.domain.vo.ReportInputModel;

/**
 * Created by kshsu on 2016/7/26.
 */
public class OdsReportCommandProcessor extends ReportBaseCommand implements ReportCommandProcessor {
    private static final Logger log = LoggerFactory.getLogger(OdsReportCommandProcessor.class);

    private final String TEMP_FILE_REALPATH = super.tmpFileDir + super.getTodayTempOdsFile();

    @Override
    public void genReportToFile(ReportInputModel reportInputModel) throws Exception {
        try {
            makeOdsReportFile(reportInputModel);
        } catch (Exception ex) {
            throw new Exception(this.getClass().getName() + ":genReportToFile => error error", ex.getCause());
        }
    }

    @Override
    public void genReportToStream(ReportInputModel reportInputModel) throws Exception {
        try {
            File file = makeOdsReportFile(reportInputModel);
            reportInputModel.getOs().write(IOUtils.readBytesFromFile(file));
        } catch (Exception ex) {
            throw new Exception(this.getClass().getName() + ":genReportToStream => orrur error", ex.getCause());
        }
    }

    @Override
    public void genReportToByteArray(ReportInputModel reportInputModel) throws Exception {
        try {
            File file = makeOdsReportFile(reportInputModel);
            reportInputModel.setOutput(IOUtils.readBytesFromFile(file));
        } catch (Exception ex) {
            throw new Exception(this.getClass().getName() + ":genReportToStream => orrur error", ex.getCause());
        }
    }

    private File makeOdsReportFile(Object javaBean, Map<String, Object> params, String destFileName) throws Exception {
        File odsFile = new File(destFileName);
        createOds(odsFile, convertToOdsFormat(getReportDataVO(javaBean), params));
        return odsFile;
    }

    private File makeOdsReportFile(ReportInputModel reportInputModel) throws Exception {
        reportInputModel.setDestFileName(
                StringUtils.isEmpty(reportInputModel.getDestFileName()) ?
                        TEMP_FILE_REALPATH : reportInputModel.getDestFileName()
        );
        File odsFile = new File(reportInputModel.getDestFileName());
        createOds(odsFile, convertToOdsFormat(getReportDataVO(reportInputModel.getJavaBean()),
                reportInputModel.getReportParameter()));
        return odsFile;
    }
}
