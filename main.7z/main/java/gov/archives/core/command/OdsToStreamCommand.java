package gov.archives.core.command;

import java.util.Map;

import gov.archives.core.domain.vo.ReportInputModel;

/**
 * Created by kshsu on 2016/7/26.
 */
public class OdsToStreamCommand extends ReportBaseCommand implements ReportCommand {

    private void OdsToStreamCommand() {}

    public OdsToStreamCommand(ReportInputModel reportInputModel) {
        this.sourceFilePath = reportInputModel.getSourceFileName();
        this.javaBean = reportInputModel.getJavaBean();
        this.reportParameter = reportInputModel.getReportParameter();
        this.reportType = reportInputModel.getReportType();
        this.baseReportInputModel = reportInputModel;
    }

    @Override
    public void execute(ReportCommandProcessor reportCommandProcessor) throws Exception {
        reportCommandProcessor.genReportToStream(baseReportInputModel);
    }
}
