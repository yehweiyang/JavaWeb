package gov.archives.core.command;

import java.io.File;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRTableModelDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.StringUtils;

import gov.archives.core.domain.vo.ReportInputModel;

/**
 * Created by kshsu on 2016/7/26.
 */
public class PdfReportCommandProcessor extends ReportBaseCommand implements ReportCommandProcessor {
    private static final Logger log = LoggerFactory.getLogger(PdfReportCommandProcessor.class);

    @Override
    public void genReportToFile(ReportInputModel reportInputModel) throws Exception {
        JasperPrint jasperPrint;

        try {
            jasperPrint = reportConvertTo(
                    getJasperReportFromFileName(reportInputModel.getSourceFileName()),
                    reportInputModel.getReportParameter(),
                    getJRTableDateSourceFromJavaBean(reportInputModel.getJavaBean())
            );
            JasperExportManager.exportReportToPdfFile(jasperPrint, reportInputModel.getDestFileName());
        } catch (Exception ex) {
            log.error(this.getClass().getName() + ":genReportToFile => error error");
            log.error(StringUtils.stackTraceFromException(ex));
            throw new Exception(this.getClass().getName() + ":genReportToFile => error error", ex);
        }
    }

    @Override
    public void genReportToStream(ReportInputModel reportInputModel) throws Exception {
        JasperPrint jasperPrint;
        try {
            jasperPrint = reportConvertTo(
                    getJasperReportFromFileName(reportInputModel.getSourceFileName()),
                    reportInputModel.getReportParameter(),
                    getJRTableDateSourceFromJavaBean(reportInputModel.getJavaBean())
            );
            JasperExportManager.exportReportToPdfStream(jasperPrint, reportInputModel.getOs());
        } catch (Exception ex) {
            log.error(this.getClass().getName() + ":genReportToStream => error error", ex.getCause());
            throw new Exception(this.getClass().getName() + ":genReportToStream => orrur error", ex.getCause());
        }
    }

    @Override
    public void genReportToByteArray(ReportInputModel reportInputModel) throws Exception {
        try {
            reportInputModel.setOutput(
                    JasperRunManager.runReportToPdf(
                            getJasperReportFromFileName(reportInputModel.getSourceFileName()),
                            reportInputModel.getReportParameter(),
                            getJRTableDateSourceFromJavaBean(reportInputModel.getJavaBean())
                    )
            );
        } catch (Exception ex) {
            throw new Exception(this.getClass().getName() + ":genReportToByteArray => orrur error", ex.getCause());
        }
    }

    private JasperReport getJasperReportFromFileName(String sourceFileName) throws JRException {
        return (JasperReport) JRLoader.loadObject(new File(sourceFileName));
    }

    private JRTableModelDataSource getJRTableDateSourceFromJavaBean(Object javaBean) throws Exception {
        return new JRTableModelDataSource(getReportDataVO(javaBean).getDefaultTableModel());
    }
}
