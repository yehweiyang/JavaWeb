# exception

## 目的

exception 在於定義本系統或本 package 下的例外事件