package gov.archives.core.exception;

import gov.archives.core.message.CoreErrorMessage;

/**
 * Created by 140631 on 2016/8/12.
 */
public class ArchivesException extends RuntimeException {
    public static ArchivesException getInstanceByErrorCode(String errorCode) {
        String errorMessage = CoreErrorMessage.findByCode(errorCode);

        return new ArchivesException(errorMessage, errorCode);
    }

    private String errorCode;

    private String errorMessage;

    public ArchivesException() {
        super();
    }

    public ArchivesException(String message) {
        super(message);
    }

    public ArchivesException(String message, Throwable cause) {
        super(message, cause);
    }

    public ArchivesException(Throwable cause) {
        super(cause);
    }

    protected ArchivesException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public ArchivesException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
        this.errorMessage = message;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
