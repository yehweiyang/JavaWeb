package gov.archives.core.exception;

/**
 * Created by 140631 on 2016/8/12.
 */
public class DataEmptyException extends ArchivesException {
    public DataEmptyException() {
        super();
    }

    public DataEmptyException(String message) {
        super(message);
    }

    public DataEmptyException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataEmptyException(Throwable cause) {
        super(cause);
    }

    protected DataEmptyException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public DataEmptyException(String message, String errorCode) {
        super(message, errorCode);
    }
}
