package gov.archives.core.exception;

public class RestApplicationException extends RuntimeException {

    private static final long serialVersionUID = 7337987170281203420L;

    public RestApplicationException(String msg, Throwable cause) {
        super(msg, cause);
    }

    public RestApplicationException(String msg) {
        super(msg);
    }
}
