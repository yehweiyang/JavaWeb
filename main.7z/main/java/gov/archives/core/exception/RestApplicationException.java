package gov.archives.core.exception;

import org.springframework.http.HttpStatus;

public class RestApplicationException extends RuntimeException {

    private static final long serialVersionUID = 7337987170281203420L;

    public RestApplicationException() {
        super();
    }

    public RestApplicationException(String msg) {
        super(msg);
    }

    public RestApplicationException(HttpStatus status) {
        super(status.toString());
    }

    public RestApplicationException(String msg, Throwable cause) {
        super(msg, cause);
    }

    public RestApplicationException(Throwable cause) {
        super(cause);
    }
}
