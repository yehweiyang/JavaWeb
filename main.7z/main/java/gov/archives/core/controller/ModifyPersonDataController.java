package gov.archives.core.controller;

import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.validator.routines.RegexValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.common.json.JsonUtils;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.AccountVO;
import gov.archives.core.domain.vo.ModifyPersonDataVO;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.BeanUtils;

/**
 * Created by pywang on 2016/8/9.
 */

@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.SYSTEM_TOOL_URL +"/user")
public class ModifyPersonDataController {

    private static final Logger log = LoggerFactory.getLogger(ModifyPersonDataController.class);

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private ActionLogService actionLogService;

    @RequestMapping(value = "/getUser", method = RequestMethod.GET)

    public ModifyPersonDataVO getUser() {

        String account = userInfoService.getCurrentAccount();

        ModifyPersonDataVO userVO = new ModifyPersonDataVO();

        UserInfoEntity user = userInfoService.getByAccount(account);

        ActionLogEntity actionLog = actionLogService.getLogInCountByAccount(account);
        userVO.setLoginCount(actionLog.getActionResult());

        actionLog = actionLogService.getLastLogInByAccount(account);

        userVO.setLoginIP(actionLog.getRemoteIp());

        userVO.setLoginTime(actionLog.getActionTime().toString());

        BeanUtils.copyProperties(userVO, user);

        return userVO;

    }

    @RequestMapping(value = "/modifyUser", method = RequestMethod.POST)
    public void saveUser(@RequestBody ModifyPersonDataVO user) {
        if (null == user) { throw new RestApplicationException(HttpStatus.BAD_REQUEST); }
        verifySingleUserInfo(user);

        UserInfoEntity userInfoEntity = userInfoService.getByAccount(user.getAccount());
        if (null == userInfoEntity) { throw new RestApplicationException(HttpStatus.BAD_REQUEST); }

        user.rebuildPhoneNumbers();

        BeanUtils.copyProperties(userInfoEntity, user);

        userInfoEntity.initUpdate(userInfoService.getCurrentAccount());

        userInfoService.update(userInfoEntity);

    }

    private void verifySingleUserInfo(ModifyPersonDataVO user) {
        RegexValidator digitValidator = new RegexValidator(CoreConf.DIGIT_PATTERN);
        RegexValidator digitOrEmptyValidator = new RegexValidator(CoreConf.DIGIT_EMPTY_PATTERN);
        RegexValidator alphaNumericValidator = new RegexValidator(CoreConf.ALPHANUMERIC_PATTERN);
        RegexValidator alphaNumericNlsValidator = new RegexValidator(CoreConf.ALPHANUMERIC_NLS_PATTERN);

        String account = user.getAccount();
        if (null == account || !alphaNumericValidator.isValid(account)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.USER_ACCOUNT_FORMAT_INCORRECT);
        }

        String userName = user.getUserName();
        if (null == userName || !alphaNumericNlsValidator.isValid(userName)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.USER_NAME_FORMAT_INCORRECT);
        }
        String email = user.getEmail();
        if (null == email || !EmailValidator.getInstance().isValid(email)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.EMAIL_FORMAT_INCORRECT);
        }

        if (!alphaNumericNlsValidator.isValid(user.getOrgInfo())) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ORG_INFO_FORMAT_INCORRECT);
        }


        String phoneAreaCode = user.getPhoneAreaCode();
        if (null == phoneAreaCode || !digitValidator.isValid(phoneAreaCode)) {
            throw new RestApplicationException(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }

        String phoneLocalNumber = user.getPhoneLocalNumber();
        if (null == phoneLocalNumber || !digitValidator.isValid(phoneLocalNumber)) {
            throw new RestApplicationException(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }

        String phoneExtNumber = user.getPhoneExtNumber();
        if (null == phoneExtNumber || !digitOrEmptyValidator.isValid(phoneExtNumber)) {
            throw new RestApplicationException(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }

        String mobileAreaCode = user.getMobileAreaCode();
        if (null == mobileAreaCode || !digitOrEmptyValidator.isValid(mobileAreaCode)) {
            throw new RestApplicationException(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }

        String mobileLocalNumber = user.getMobileLocalNumber();
        if (null == mobileLocalNumber || !digitOrEmptyValidator.isValid(mobileLocalNumber)) {
            throw new RestApplicationException(CoreErrorCode.PHONE_FORMAT_INCORRECT);
        }
        validationStringType(user.getMobileLocalNumber(), digitOrEmptyValidator);

        }

        private void validationStringType(String params, RegexValidator regex) {
            if (null == params || !regex.isValid(params)) {
                throw new RestApplicationException(CoreErrorCode.PHONE_FORMAT_INCORRECT);
            }
        }


}
