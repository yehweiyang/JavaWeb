package gov.archives.core.controller;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import gov.archives.core.conf.AuthenticationConf;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.AccountForm;
import gov.archives.core.domain.vo.VerifyResult;
import gov.archives.core.facade.DocumentExchangeServiceFacade;

@Controller
public class AccountController {

    private static final Logger log = LoggerFactory.getLogger(AccountController.class);

    @Autowired
    @Qualifier("accountModelValidator")
    private Validator validator;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }

    @Autowired
    private DocumentExchangeServiceFacade documentExchangeServiceFacade;

    @RequestMapping(value = "/newAccount",
            method = RequestMethod.GET)
    public String newAccount(ModelMap model) {
        AccountForm account = new AccountForm();
        model.addAttribute("accountForm", account);
        return AuthenticationConf.NEWLOG_PROCESSOR_URL;
    }

    @RequestMapping(value = "/accountForm",
            method = RequestMethod.POST)
    public String accountForm(HttpServletRequest request, @Validated AccountForm account, BindingResult result,
            Map<String, Object> model) {
        try {
            if (result.hasErrors()) {
            	result.getAllErrors();
            	log.error("getAllErrors " + result.getAllErrors().toString());
                model.put("errorMessage", VerifyResult.ERROR_AP0000);
                return AuthenticationConf.NEWLOG_PROCESSOR_URL;
            }
            documentExchangeServiceFacade.accountRegister(account, request, model);
        } catch (AuthenticationException e) {
            return AuthenticationConf.NEWLOG_PROCESSOR_URL;
        }
        model.put("errorMessage", CoreConf.NEW_USER_APPLY_SUCCESS);
        return AuthenticationConf.FORWARD_TO_LOGIN_URL;
    }
}