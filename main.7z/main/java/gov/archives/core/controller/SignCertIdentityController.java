package gov.archives.core.controller;

import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.domain.vo.SignCertData;
import gov.archives.core.exception.RestApplicationException;

@RestController
@RequestMapping(path = "/v1")
public class SignCertIdentityController {
	private UUID uuid;

    @RequestMapping(value = "/uuid", method = RequestMethod.GET)
    public ResponseEntity<SignCertData> getSignCert() throws RestApplicationException {
    	SignCertData cert = new SignCertData();
    	uuid = UUID.randomUUID();
		cert.setToken(uuid.toString());
		return new ResponseEntity<SignCertData>(cert, HttpStatus.OK);
    }
}
