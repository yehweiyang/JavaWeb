package gov.archives.core.controller;

import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.common.collect.ImmutableMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.domain.vo.TopMenuVo;
import gov.archives.core.service.MenuService;

/**
 * MenuQueryMapper <br> (尚未描述類別目的與用途) <br> wtjiang, 2016/7/21.
 */
@RestController
@RequestMapping(value = "/v1/core")
public class MenuController {

    @Autowired
    private MenuService findMenu;

    @RequestMapping(value = "/menu",
            method = RequestMethod.GET)
    public Map AllMenu() {

        Map<Integer, TopMenuVo> resultMenu = findMenu.getMenuTree();

        return ImmutableMap.of("menu", resultMenu);
    }

    /**
     * AllRouter() <br> (尚未描述類別目的與用途) <br> weiyang, 2016/08/03
     */
    @RequestMapping(value = "/router",
            method = RequestMethod.POST)
    public Map<String, JsonNode> AllRouter() {
        Map<String, JsonNode> resultRouter = findMenu.getRouter();
        return resultRouter;
    }
}
