package gov.archives.core.controller;

import java.util.Map;

import com.google.common.collect.ImmutableMap;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.TopMenuVo;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.MenuService;

/**
 * MenuQueryMapper <br> (尚未描述類別目的與用途) <br> wtjiang, 2016/7/21.
 */
@RestController
@RequestMapping(value = CoreConf.REST_API_VERSION + CoreConf.CORE_BASE_URL)
public class MenuController {

    public static final String GET_MENUS = "/menu";
    public static final String GET_ROUTERS = "/router";

    @Autowired
    private MenuService findMenu;

    @RequestMapping(value = "/menu",
            method = RequestMethod.GET)
    public Map getAllMenu() {
        return this.getMenu();
    }

    /**
     * getAllRouter() <br> (尚未描述類別目的與用途) <br> weiyang, 2016/08/03
     */
    @RequestMapping(value = "/router",
            method = RequestMethod.GET)
    public Map getAllRouter() {
        return this.getMenu();
    }

    public Map getMenu() {

        Map<Integer, TopMenuVo> resultMenu = findMenu.getMenuTree();

        if (MapUtils.isEmpty(resultMenu)) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.DATA_NOT_FOUND);
        }

        return ImmutableMap.of("menu", resultMenu);
    }

}
