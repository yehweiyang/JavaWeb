package gov.archives.core.controller;

import java.util.Map;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import gov.archives.core.conf.AuthenticationConf;
import gov.archives.core.domain.vo.SignCertData;

@Controller
public class LoginController {

    @RequestMapping(value = {"/login"},
            method = {RequestMethod.GET, RequestMethod.POST})
    public String loginPage(Map<String, Object> model, HttpSession session) {
        SignCertData data = new SignCertData();
        model.put("loginForm", data);
        UUID tbs = UUID.randomUUID();
        session.setAttribute("login_uuid", tbs);
        model.put("tbs", tbs.toString());
        return AuthenticationConf.LOGIN_PROCESSOR_URL;
    }

    @RequestMapping(value = "/logout",
            method = RequestMethod.GET)
    public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext()
                                                   .getAuthentication();
        if (auth != null) {
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return AuthenticationConf.REDIRECT_LOGOUT_URL;
    }

    @RequestMapping(value = "/sessionExpired",
                    method = RequestMethod.GET)
    public String sessionExpired(HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext()
                                                   .getAuthentication();
        if (auth != null) {
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "redirect:/login?expired";
    }

    @RequestMapping(value = "/errors/403",
            method = RequestMethod.GET)
    public String accessDeniedPage() {
        return  AuthenticationConf.AUTHENFAIL;
    }
}
