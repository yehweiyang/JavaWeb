package gov.archives.core.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.service.HomeService;

/**
 * HomeController <br> (尚未描述類別目的與用途) <br> gemhuang and jslee, 2016/7/19.
 */
@Controller
public class HomeController {

    private static final String REDIRECT_ACTION = "redirect:";

    @Autowired
    private HomeService homeService;

    @RequestMapping(value = "/",
            method = RequestMethod.GET)
    public String getHome() {
        return REDIRECT_ACTION + CoreConf.INDEX_URL;
    }

    @RequestMapping(path = CoreConf.INDEX_URL)
    public String getIndex() {
        return CoreConf.CORE_BASE_URL + CoreConf.INDEX_URL;
    }


    @RequestMapping(path = CoreConf.REST_API_VERSION + CoreConf.HOME_URL,
            method = RequestMethod.GET)
    public
    @ResponseBody
    Map<String, String> initHomeAction() {
        Map<String, String> map = new HashMap<>();
        map.put("viewText", homeService.readHomePageTextASString());

        return map;
    }

}
