package gov.archives.core.domain.vo;

import java.util.ArrayList;
import java.util.List;

import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.entity.RoleEntity;

/**
 * RoleMenuMapping
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/19.
 */
public class RoleMenuMapping {
    private RoleEntity role;
    private List<MenuEntity> menus;
    private String creatorAccount;

    public RoleMenuMapping() {
        menus = new ArrayList<>();
    }

    public RoleEntity getRole() {
        return role;
    }

    public void setRole(RoleEntity role) {
        this.role = role;
    }

    public List<MenuEntity> getMenus() {
        return menus;
    }

    public void setMenus(List<MenuEntity> menus) {
        this.menus = menus;
    }

    public void addMenu(MenuEntity menu) {
        this.menus.add(menu);
    }

    public String getCreatorAccount() {
        return creatorAccount;
    }

    public void setCreatorAccount(String creatorAccount) {
        this.creatorAccount = creatorAccount;
    }
}
