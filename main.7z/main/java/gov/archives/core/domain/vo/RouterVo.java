package gov.archives.core.domain.vo;

import java.util.UUID;

/**
 * RouterVo
 * <p>
 * Created by WeiYang on 2016/8/12.
 */
public class RouterVo {
    private String menuCode;
    private String menuName;
    private UUID menuId;

    public String getMenuCode() {
        return menuCode;
    }

    public void setMenuCode(String menuCode) {
        this.menuCode = menuCode;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public UUID getMenuId() {
        return menuId;
    }

    public void setMenuId(UUID menuId) {
        this.menuId = menuId;
    }
}
