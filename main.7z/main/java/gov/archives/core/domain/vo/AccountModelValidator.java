package gov.archives.core.domain.vo;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class AccountModelValidator implements Validator {
    private Pattern pattern;
    private Pattern pattern1;
    private Pattern pattern2;
    private Matcher matcher;
    private Matcher matcher1;
    private Matcher matcher2;
    private static final String EMAIL_PATTERN =
            "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                    + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

    private static final String NAME_PATTERN =
            "^[A-Za-z0-9]+$";

    private static final String NUM_PATTERN =
            "^[0-9]+$";

    public AccountModelValidator() {
        pattern = Pattern.compile(EMAIL_PATTERN);
        pattern1 = Pattern.compile(NAME_PATTERN);
        pattern2 = Pattern.compile(NUM_PATTERN);
    }

    public boolean validateMaile(final String mailAddr) {
        matcher = pattern.matcher(mailAddr);
        return matcher.matches();
    }
    public boolean validateName(final String userPattern) {
        matcher1 = pattern1.matcher(userPattern);
        return matcher1.matches();
    }
    public boolean validateNum(final String numPattern) {
        matcher2 = pattern2.matcher(numPattern);
        return matcher2.matches();
    }

    @Override
    public boolean supports(Class<?> clazz) {
        // TODO Auto-generated method stub
        if (clazz.getSimpleName().equals(AccountForm.class.getSimpleName())) { return true; }
        return false;
    }

    @Override
    public void validate(Object target, Errors errors) {
        // TODO Auto-generated method stub
        AccountForm account = (AccountForm) target;
        if (account.getUserName() == null) {
            errors.rejectValue("userName", "userName.empty");
        } else if (account.getUserName().length() > 20) {
            errors.rejectValue("userName", "userName.maxvalue");
        } else {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "userName.required");
        }
        if (account.getFullName().length() > 20) {
            errors.rejectValue("fullName", "fullName.maxvalue");
        } else {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "fullName", "fullName.required");
        }
  /*      String fullName = account.getFullName();
        if (fullName.length() <= 20) {
            System.out.println("myVaildate3 " + fullName);
            if (!validateName(fullName)) {

                errors.rejectValue("fullName", "fullName.error");
            }
        }
*/
        String phoneLocal = account.getPhoneLocal();
        if (phoneLocal.length() > 4) {
            errors.rejectValue("phoneLocal", "phoneLocal.maxvalue");
        } else if (phoneLocal.length() > 0) {
            if (phoneLocal.length() < 2) {
                errors.rejectValue("phoneLocal", "phoneLocal.minvalue");
            }
            if (!validateNum(phoneLocal)) {
                errors.rejectValue("phoneLocal", "phoneLocal.isNotNumber");
            }
        } else {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phoneLocal", "phoneLocal.required");
        }

        String phoneNum = account.getPhoneNum();
        if (phoneNum.length() > 10) {
            errors.rejectValue("phoneNum", "phoneNum.maxvalue");
        } else if (phoneNum.length() > 0) {
            if (!validateNum(phoneNum)) {
                errors.rejectValue("phoneNum", "phoneNum.isNotNumber");
            }
        } else {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phoneNum", "phoneNum.required");
        }

        String phonExt = account.getPhonExt();
        if (phonExt.length() > 6) {
            errors.rejectValue("phonExt", "phonExt.maxvalue");
        } else if (phonExt.length() > 0) {
            if (!validateNum(phonExt)) {
                errors.rejectValue("phonExt", "phonExt.isNotNumber");
            }
        }

        String mobileLocal = account.getMobileLocal();
        if (mobileLocal.length() > 0) {
            if (!validateNum(mobileLocal)) {
                errors.rejectValue("mobileLocal", "mobileLocal.isNotNumber");
            }
        }
        String mobileNum = account.getMobileNum();
        if (mobileNum.length() > 0) {
            if (!validateNum(mobileNum)) {
                errors.rejectValue("mobileNum", "mobileNum.isNotNumber");
            }
        }
        String eMailAddr = account.geteMailAddr();
        if (eMailAddr.length() > 0) {
            if (!validateMaile(eMailAddr)) {
                errors.rejectValue("eMailAddr", "eMailAddr.error");
            }
        } else {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eMailAddr", "eMailAddr.required");
        }
    }

}