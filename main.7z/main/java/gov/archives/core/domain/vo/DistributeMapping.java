package gov.archives.core.domain.vo;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.ibatis.type.Alias;

/**
 * Created by tristan on 2016/9/1.
 */
@Alias("DistMappingVO")
public class DistributeMapping {
    private String senderOrgId;
    private String senderUnitId;
    private String receiverOrgId;
    private String receiverUnitId;

    public String getSenderOrgId() {
        return senderOrgId;
    }

    public void setSenderOrgId(String senderOrgId) {
        this.senderOrgId = senderOrgId;
    }

    public String getSenderUnitId() {
        return senderUnitId;
    }

    public void setSenderUnitId(String senderUnitId) {
        this.senderUnitId = senderUnitId;
    }

    public String getReceiverOrgId() {
        return receiverOrgId;
    }

    public void setReceiverOrgId(String receiverOrgId) {
        this.receiverOrgId = receiverOrgId;
    }

    public String getReceiverUnitId() {
        return receiverUnitId;
    }

    public void setReceiverUnitId(String receiverUnitId) {
        this.receiverUnitId = receiverUnitId;
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj);
    }
}
