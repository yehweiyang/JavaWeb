package gov.archives.core.domain.vo;

import java.sql.Timestamp;

/**
 * Created by tristan on 2016/9/6.
 */
public class DistributeDoc {
    private String serviceId;
    private String processId;
    private String fromOrgUnitName;
    private String toOrgUnitName;
    private String insertTime;
    private String confirmTime;
    private int flowStatus;

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getFromOrgUnitName() {
        return fromOrgUnitName;
    }

    public void setFromOrgUnitName(String fromOrgUnitName) {
        this.fromOrgUnitName = fromOrgUnitName;
    }

    public String getToOrgUnitName() {
        return toOrgUnitName;
    }

    public void setToOrgUnitName(String toOrgUnitName) {
        this.toOrgUnitName = toOrgUnitName;
    }

    public String getConfirmTime() {
        return confirmTime;
    }

    public void setConfirmTime(String confirmTime) {
        this.confirmTime = confirmTime;
    }

    public String getInsertTime() {
        return insertTime;
    }

    public void setInsertTime(String insertTime) {
        this.insertTime = insertTime;
    }

    public int getFlowStatus() {
        return flowStatus;
    }

    public void setFlowStatus(int flowStatus) {
        this.flowStatus = flowStatus;
    }
}
