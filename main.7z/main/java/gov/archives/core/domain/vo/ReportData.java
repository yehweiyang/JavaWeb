
package gov.archives.core.domain.vo;

import javax.swing.table.DefaultTableModel;

/**
 * Created by kshsu on 2016/7/20.
 */
public class ReportData extends DefaultTableModel {
    private Object[] headerString;
    private Object[][] reportContent;

    public Object[] getHeaderString() {
        return headerString;
    }

    public void setHeaderString(Object[] headerString) {
        this.headerString = headerString;
    }

    public Object[][] getReportContent() {
        return reportContent;
    }

    public void setReportContent(Object[][] reportContent) {
        this.reportContent = reportContent;
    }

    public DefaultTableModel getDefaultTableModel() {
        super.setDataVector(reportContent, headerString);
        return this;
    }
}

