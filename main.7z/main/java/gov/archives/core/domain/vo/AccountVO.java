package gov.archives.core.domain.vo;

public class AccountVO {
    private String account;

    public AccountVO(String account) {
        this.account = account;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }
}
