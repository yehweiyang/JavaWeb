package gov.archives.core.domain.vo;

import gov.archives.core.message.CoreErrorCode;

public class VerifyResult {
	public static final String ERROR_SYS001 = "使用者無此權限";
	public static final String ERROR_AP0000 = "";
	public static final String ERROR_AP0001 = "圖型驗證碼輸入錯誤,請重新登錄";
	public static final String ERROR_AP0002 = "登入失敗,請重新登錄";
	public static final String ERROR_AP0003 = "Pin 碼輸入錯誤，請重新登入";
	public static final String ERROR_AP0004 = "卡片逾期";
	public static final String ERROR_AP0005 = "卡片錯誤，請重新登錄";
	public static final String ERROR_AP0006 = "卡片錯誤，請重新登錄";
	public static final String ERROR_AP0007 = "卡片錯誤，請重新登錄";
	public static final String ERROR_AP0008 = "登入失敗三次，要等五分鐘才能再登";
	public static final String ERROR_AP0011 = "卡片需為申請人所有";
	public static final String ERROR_AP0012 = "帳號已有人使用，請另取其他帳號";
	public static final String ERROR_AP0013 = "帳號已有人使用，請另取其他帳號";

	public static final String ERROR_ED0001 = "電話號碼輸入格式錯誤";
	public static final String ERROR_ED0002 = "電話號碼輸入格式錯誤";
	public static final String ERROR_ED0003 = "email輸入格式錯誤";
	public static final String ERROR_ED0017 = "帳號輸入格式錯誤";
	public static final String ERROR_ED0018 = "姓名已輸入格式錯誤";



	private Boolean isVerify;
	private String errorCode;
	private String errorMessage;

	public Boolean getIsVerify() {
		return isVerify;
	}

	public void setIsVerify(Boolean isVerify) {
		this.isVerify = isVerify;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
	
	public void setErrorMessage(String errorCode) {
		switch (errorCode) {
		case "ERROR_AP0000":
				this.errorMessage = ERROR_AP0000;
				break;
		case CoreErrorCode.CODE_ACCOUNT_NO_RIGHT:
			this.errorMessage = ERROR_SYS001;
			break;
		case CoreErrorCode.CODE_CAPTCHA_ERROR:
			this.errorMessage = ERROR_AP0001;
			break;
		case CoreErrorCode.CODE_ACCOUNT_ERROR:
			this.errorMessage = ERROR_AP0002;
			break;
		case CoreErrorCode.CODE_PIN_ERROR:
			this.errorMessage = ERROR_AP0003;
			break;
		case CoreErrorCode.CODE_CARD_EXPIRED:
			this.errorMessage = ERROR_AP0004;
			break;
		case CoreErrorCode.CODE_CARD_NOT_AVAILABLE:
			this.errorMessage = ERROR_AP0005;
			break;
		case CoreErrorCode.CODE_SIGNATURE_ERROR:
			this.errorMessage = ERROR_AP0006;
			break;
		case CoreErrorCode.CODE_CARD_NOT_MATCH_DATA:
			this.errorMessage = ERROR_AP0007;
			break;
		case CoreErrorCode.CODE_LOGIN_EXPIRED:
			this.errorMessage = ERROR_AP0008;
			break;
		case CoreErrorCode.CODE_ACCOUNT_IS_APPLICANT:
			this.errorMessage = ERROR_AP0011;
			break;
		case CoreErrorCode.CODE_ACCOUNT_ALREADY_USE:
			this.errorMessage = ERROR_AP0012;
			break;
		case CoreErrorCode.CODE_ACCOUNT_FORMAT_ERROR:
			this.errorMessage = ERROR_ED0017;
			break;
		case CoreErrorCode.CODE_NAME_FORMAT_ERROR:
			this.errorMessage = ERROR_ED0018;
			break;
		case "Success":
			this.errorMessage = errorCode;
			break;	
		default:
			this.errorMessage = "Undefine Error";
		}
	}

	
    @Override
    public String toString()
    {
        return "VerifyResult [isVerify=" + isVerify + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage + "]";
    }
}
