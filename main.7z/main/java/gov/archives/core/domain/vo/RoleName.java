package gov.archives.core.domain.vo;

/**
 * Created by tristan on 2016/8/2.
 */
public class RoleName {
    private String roleName;

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
