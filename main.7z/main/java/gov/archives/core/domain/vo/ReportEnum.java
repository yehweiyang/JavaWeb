package gov.archives.core.domain.vo;

/**
 * Created by kshsu on 2016/7/22.
 */
public enum ReportEnum {
    /**
     * 中心交換量排行 001
     */
    REPORT_SEND_RANK("rptsendrank"),
    /**
     * 中心異常排行 002
     */
    REPORT_ERR_RANK("reporterrrk"),
    /**
     * 發文狀態統計 003
     */
    REPORT_RS_STATE("reportrss"),
    /**
     * 中心異常排行 004
     */
    REPORT_SEND_ERR("reportsenderr"),
    /**
     * 發文統計 005
     */
    REPORT_SEND_STATE("reportsendst"),
    PDF("PDF"),
    CSV("CSV"),
    XLS("XLS"),
    ODS("ODS");

    private final String value;

    private ReportEnum(String s) {
        value = s;
    }

    public boolean equalsName(String otherName) {
        return null != otherName && value.equals(otherName);
    }

    public String toString() {
        return this.value;
    }

    public String getTWName() {
        switch (value) {
            case "rptsendrank":
                return "中心交換量排行";
            case "reporterrrk":
                return "中心異常排行";
            case "reportrss":
                return "發文狀態統計";
            case "reportsenderr":
                return "中心異常排行";
            case "reportsendst":
                return "發文統計";
            default:
                return value;
        }
    }
}
