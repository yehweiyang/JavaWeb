package gov.archives.core.domain.entity;

import java.util.UUID;

import org.apache.ibatis.type.Alias;

import gov.archives.core.conf.CoreConf;

/**
 * MenuEntity
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@Alias("Menu")
public class MenuEntity extends BaseEntity {
    private String menuCode;
    private String menuName;
    private Integer menuSeq;
    private UUID topMenuId = CoreConf.DEFAULT_ID;
    private Integer activeStatus;
    private String modifiedMemo;

    public String getMenuCode() {
        return menuCode;
    }

    public void setMenuCode(String menuCode) {
        this.menuCode = menuCode;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public Integer getMenuSeq() {
        return menuSeq;
    }

    public void setMenuSeq(Integer menuSeq) {
        this.menuSeq = menuSeq;
    }

    public UUID getTopMenuId() {
        return topMenuId;
    }

    public void setTopMenuId(UUID topMenuId) {
        this.topMenuId = topMenuId;
    }

    public Integer getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getModifiedMemo() {
        return modifiedMemo;
    }

    public void setModifiedMemo(String modifiedMemo) {
        this.modifiedMemo = modifiedMemo;
    }
}
