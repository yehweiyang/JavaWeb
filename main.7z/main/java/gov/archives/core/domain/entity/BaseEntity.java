package gov.archives.core.domain.entity;

import java.sql.Timestamp;
import java.util.UUID;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by gemhuang on 2016/5/25.
 */
public class BaseEntity {
    private UUID sysId;
    private Timestamp createdTime;
    private Timestamp modifiedTime;
    private String creatorAccount;
    private String modifierAccount;

    public UUID getSysId() {
        return sysId;
    }

    public void setSysId(UUID sysId) {this.sysId = sysId;}

    public Timestamp getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Timestamp createdTime) {
        this.createdTime = createdTime;
    }

    public Timestamp getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Timestamp modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public String getCreatorAccount() {
        return creatorAccount;
    }

    public void setCreatorAccount(String creatorAccount) {
        this.creatorAccount = creatorAccount;
    }

    public String getModifierAccount() {
        return modifierAccount;
    }

    public void setModifierAccount(String modifierAccount) {
        this.modifierAccount = modifierAccount;
    }

    public void initSysId() {
        this.sysId = UUID.randomUUID();
    }

    public void initSave(String creator) {
        this.creatorAccount = creator;
        this.modifierAccount = creator;

        this.createdTime = new Timestamp(System.currentTimeMillis());
        this.modifiedTime = new Timestamp(System.currentTimeMillis());

        this.sysId = UUID.randomUUID();
    }

    public void initUpdate(String modifier) {
        this.modifierAccount = modifier;

        this.modifiedTime = new Timestamp(System.currentTimeMillis());
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
