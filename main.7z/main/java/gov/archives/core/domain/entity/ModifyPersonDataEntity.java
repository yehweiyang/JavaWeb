package gov.archives.core.domain.entity;

import java.util.UUID;

/**
 * Created by pywang on 2016/8/9.
 */
public class ModifyPersonDataEntity {

        private UUID sysID;
        private String account;
        private String telNumLocal;
        private String telNum;
        private String telNumExt;
        private String urgTelNumLocal;
        private String urgTelNum;
        private String urgTelNumExt;
        private String email;

        public UUID getSysID() {
            return sysID;
        }

        public String getAccount() {
            return account;
        }

        public String getTelNumLocal() {
            return telNumLocal;
        }

        public String getTelNum() {
            return telNum;
        }

        public String getTelNumExt() {
            return telNumExt;
        }

        public String getUrgTelNumLocal() {
            return urgTelNumLocal;
        }

        public String getUrgTelNum() {
            return urgTelNum;
        }

        public String getUrgTelNumExt() {
            return urgTelNumExt;
        }

        public String getEmail() {
            return email;
        }

        public void setSysID(UUID sysID) {
            this.sysID = sysID;
        }

        public void setAccount(String account) {
            this.account = account;
        }

        public void setTelNumLocal(String telNumLocal) {
            this.telNumLocal = telNumLocal;
        }

        public void setTelNum(String telNum) {
            this.telNum = telNum;
        }

        public void setTelNumExt(String telNumExt) {
            this.telNumExt = telNumExt;
        }

        public void setUrgTelNumLocal(String urgTelNumLocal) {
            this.urgTelNumLocal = urgTelNumLocal;
        }

        public void setUrgTelNum(String urgTelNum) {
            this.urgTelNum = urgTelNum;
        }

        public void setUrgTelNumExt(String urgTelNumExt) {
            this.urgTelNumExt = urgTelNumExt;
        }

        public void setEmail(String email) {
            this.email = email;
        }
    }


