package gov.archives.core.domain.entity;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

/**
 * LogInControl
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@Alias("LogInControl")
public class LogInControlEntity extends BaseEntity {
    private String sessionId;
    private String loginAccount;
    private String certCardNum;
    private Timestamp loginTime;
    private String remoteIp;
    private Integer loginCount;
    private Timestamp maxLimitLoginTime;

    public String getSessionId() {
        return sessionId;
    }

    public Timestamp getMaxLimitLoginTime() {
        return maxLimitLoginTime;
    }


    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getLoginAccount() {
        return loginAccount;
    }

    public void setLoginAccount(String loginAccount) {
        this.loginAccount = loginAccount;
    }

    public String getCertCardNum() {
        return certCardNum;
    }

    public void setCertCardNum(String certCardNum) {
        this.certCardNum = certCardNum;
    }

    public Timestamp getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(Timestamp loginTime) {
        this.loginTime = loginTime;
    }

    public String getRemoteIp() {
        return remoteIp;
    }

    public void setRemoteIp(String remoteIp) {
        this.remoteIp = remoteIp;
    }

    public Integer getLoginCount() {
        return loginCount;
    }

    public void setLoginCount(Integer loginCount) {
        this.loginCount = loginCount;
    }


    public void setMaxLimitLoginTime(Timestamp maxLimitLoginTime) {
        this.maxLimitLoginTime = maxLimitLoginTime;
    }
}
