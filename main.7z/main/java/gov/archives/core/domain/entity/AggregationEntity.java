package gov.archives.core.domain.entity;

/**
 * AggregationEntity
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
public class AggregationEntity extends BaseEntity {
    private String creatorApp;
    private String modifierApp;

    public String getCreatorApp() {
        return creatorApp;
    }

    public String getModifierApp() {
        return modifierApp;
    }

    public void setCreatorApp(String creatorApp) {
        this.creatorApp = creatorApp;
    }

    public void setModifierApp(String modifierApp) {
        this.modifierApp = modifierApp;
    }

    public void initSave(String creator) {
        super.initSave(creator);

        this.creatorApp = creator;
        this.modifierApp = creator;
    }

    public void initUpdate(String modifier) {
        super.initUpdate(modifier);

        this.modifierApp = modifier;
    }
}
