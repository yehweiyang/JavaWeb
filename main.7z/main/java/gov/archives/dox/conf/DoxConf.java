package gov.archives.dox.conf;

/**
 * DoxConf
 * <br>
 * dox package 下之共用設定
 * <br>
 * gemhuang, 2016/8/16.
 */
public class DoxConf {
    public static final String QUERY_TX_MANAGER = "doxQueryTxManager";
    public static final String COMMAND_TX_MANAGER = "doxCommandTxManager";
    public static final String SUCCESS_MSG = "Success";
    public static final String REST_CERT_EXPIRED_LIST_SUCCESS = "/certExpired/list: Success";
    public static final String REST_CERT_EXPIRED_OUTPUT_SUCCESS = "/certExpired/output: Success";
    public static final String REST_NUMBER_SEARCH_LIST_SUCCESS = "/numberSearch/list: Success";
    public static final String REST_ADDRESS_SEARCH_LIST_SUCCESS = "/addressSearch/list: Success";
    public static final String REST_ADDRESS_SEARCH_DETAIL_SUCCESS = "/addressSearch/detail: Success";
    public static final String REST_ADDRESS_SEARCH_CENTER_LIST_SUCCESS = "/addressSearch/center/list: Success";
    public static final String PRIMARY_RELATED_ATTRIBUTE = "PRIMARY";
    public static final String NONE_RELATED_ATTRIBUTE = "NONE";
    public static final String PRIMARY_ORG_CARD_STATUS = "有卡";
    public static final String NONE_ORG_CARD_STATUS = "無卡";
    public static final String YES_DEFAULT_CERT = "是";
    public static final String NO_DEFAULT_CERT = "否";
    public static final String ACTIVE_STATUS_ONE = "啟用";
    public static final String ACTIVE_STATUS_TWO = "審查中";
    public static final String ACTIVE_STATUS_ZERO = "停用";
    public static final String DOC_FORM_TYPE = "exdoc";
    public static final String DOC_FORM_VALE = "公文交換";
    public static final String MANGER_FORM_TYPE = "eManager";
    public static final String MANGER_FORM_VALDE = "e管家";
    public static final String STATUS_INDEX = "statusIndex";
}
