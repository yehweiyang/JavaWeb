package gov.archives.dox.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.dox.conf.DoxConf;
import gov.archives.core.controller.RestControllerBase;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.service.ActionLogService;
import gov.archives.dox.domain.entity.SubrogationEntity;
import gov.archives.dox.message.DoxErrorCode;
import gov.archives.dox.message.DoxErrorMessage;
import gov.archives.dox.service.SubrogationService;

@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + "/numberSearch")
public class NumberSearchController extends RestControllerBase {
    private static final String MODULE_NAME = "代字號查詢模組";
    private static final String AGENCY_ID = "agencyId";
    private static final String AUTH_AGENCY_ID = "authAgencyId";
    private static final String SUB_RO_GATE = "subRoGate";
    private static final String EFFECT_DATE_END = "effectDateEnd";
    private static final String EFFECT_DATE_START = "effectDateStart";
    private static final String VALID_DATE_START = "validDateStart";
    private static final String VALID_DATE_END = "validDateEnd";

    @Autowired
    SubrogationService subrogationService;

    @Autowired
    private ActionLogService actionLogService;

    private List<SubrogationEntity> entityList;

    public NumberSearchController() {
        this.setModuleName(MODULE_NAME);
    }

    @RequestMapping(value = "/list",
                    method = RequestMethod.GET)
    public ResponseEntity<List<SubrogationEntity>> getAllDocWordList(HttpServletRequest request, @RequestParam Map<String, Object>
            params) {
        try {
            Object cacheData = params.get(CACHE_DATE);
            subRoGateParamsValidate(params);
            if ("false".equals(cacheData))
                entityList = subrogationService.getByQueryMap(params);
            else if ("true".equals(cacheData)) {
                if (null == entityList)
                    entityList = subrogationService.getByQueryMap(params);
            }
            actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                    HttpStatus.OK.getReasonPhrase(),
                    DoxConf.REST_NUMBER_SEARCH_LIST_SUCCESS,
                    CoreConf.EVENT_LEVEL_LOW));
            return new ResponseEntity<>(entityList, HttpStatus.OK);
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                            e.getErrorCode() != null ? e.getErrorCode() : UNDEFINE_ERROR_CODE,
                            e.getErrorMessage() != null ? e.getErrorMessage() : UNDEFINE_ERROR_MESSAGE,
                            CoreConf.EVENT_LEVEL_LOW));
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }

    private void subRoGateParamsValidate(Map<String, Object> params) {
        if (!validateFiled((String) params.get(AGENCY_ID), CoreConf.ALPHANUMERIC_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0010_ERROR_MESSAGE,
                    DoxErrorCode.ED0010_AGENCY_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(AUTH_AGENCY_ID), CoreConf.ALPHANUMERIC_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0009_ERROR_MESSAGE,
                    DoxErrorCode.ED0009_AUTH_AGENCY_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(SUB_RO_GATE), CoreConf.ALPHANUMERIC_NLS_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0011_ERROR_MESSAGE,
                    DoxErrorCode.ED0011_SUBROGATE_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(EFFECT_DATE_START), CoreConf.DATE_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0017_ERROR_MESSAGE,
                    DoxErrorCode.ED0017_EFFECT_DATE_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(EFFECT_DATE_END), CoreConf.DATE_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0017_ERROR_MESSAGE,
                    DoxErrorCode.ED0017_EFFECT_DATE_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(VALID_DATE_START), CoreConf.DATE_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0018_ERROR_MESSAGE,
                    DoxErrorCode.ED0018_EXPIRED_DATE_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(VALID_DATE_END), CoreConf.DATE_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0018_ERROR_MESSAGE,
                    DoxErrorCode.ED0018_EXPIRED_DATE_FORMAT_INCORRECT);
        }
    }
}
