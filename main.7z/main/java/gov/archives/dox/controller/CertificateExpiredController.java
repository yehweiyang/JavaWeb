package gov.archives.dox.controller;

import java.io.File;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.controller.RestControllerBase;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.dox.domain.entity.OrgCertExpiredEntity;
import gov.archives.dox.message.DoxErrorCode;
import gov.archives.dox.message.DoxErrorMessage;
import gov.archives.dox.service.OrgCertService;
import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.facade.ReportOutputFacade;

import static gov.archives.core.conf.CoreConf.DATE_FORMAT;
import static gov.archives.dox.conf.DoxConf.REST_CERT_EXPIRED_LIST_SUCCESS;
import static gov.archives.dox.conf.DoxConf.REST_CERT_EXPIRED_OUTPUT_SUCCESS;
import static gov.archives.dox.service.OrgCertService.DAY_PARAMETER;
import static gov.archives.dox.service.OrgCertService.MONTH_PARAMETER;
import static gov.archives.dox.service.OrgCertService.TITLE_NAME;
import static gov.archives.dox.service.OrgCertService.TITLE_PARAMETER;
import static gov.archives.dox.service.OrgCertService.YEAR_PARAMETER;

@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + "/certExpired")
public class CertificateExpiredController extends RestControllerBase {
    private static final String MODULE_NAME = "憑證即將過期模組";
    private static final String REPORT_FOLDER = "reportTemplate/certExpired";
    private static final String OUTPUT_FOLDER = "CertExpire";

    @Autowired
    private OrgCertService orgCertService;

    @Autowired
    private ReportOutputFacade outputFacade;

    @Autowired
    private ActionLogService actionLogService;

    private List<OrgCertExpiredEntity> certExpiredEntityList = null;

    public CertificateExpiredController() {
        this.setModuleName(MODULE_NAME);
    }

    @RequestMapping(value = "/list",
                    method = RequestMethod.GET)
    public ResponseEntity<List<OrgCertExpiredEntity>> getCertExpired(HttpServletRequest request) {

        try {
            certExpiredEntityList = orgCertService.getCertExpired();
            actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                    HttpStatus.OK.getReasonPhrase(),
                    REST_CERT_EXPIRED_LIST_SUCCESS,
                    CoreConf.EVENT_LEVEL_LOW));
            return new ResponseEntity<>(certExpiredEntityList, HttpStatus.OK);
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(), e.getErrorCode(),
                            e.getErrorMessage(),
                            CoreConf.EVENT_LEVEL_LOW));
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }

    @RequestMapping(value = "/output",
                    method = RequestMethod.POST)
    public ResponseEntity<Void> outputFile(HttpServletRequest request, @RequestBody String exportType) {
        try {
            if (exportType.equals("ods") || exportType.equals("pdf")) {
                if (null == certExpiredEntityList) {
                    certExpiredEntityList = orgCertService.getCertExpired();
                }
                String realPath = request.getServletContext()
                                         .getRealPath("");

                String date = LocalDateTime.now().toDateTime().toString(DATE_FORMAT);
                String fileName = OUTPUT_FOLDER + "-" + date + "." + exportType;
                exportReport(certExpiredEntityList, realPath, fileName, exportType);
                actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                        HttpStatus.OK.getReasonPhrase(),
                        REST_CERT_EXPIRED_OUTPUT_SUCCESS,
                        CoreConf.EVENT_LEVEL_LOW));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } else {
                throw new ArchivesException(DoxErrorMessage.ED0019_ERROR_MESSAGE,
                        DoxErrorCode.ED0019_OUTPUT_FILE_FORMAT_INCORRECT);
            }
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                            e.getErrorCode() != null ? e.getErrorCode() : UNDEFINE_ERROR_CODE,
                            e.getErrorMessage() != null ? e.getErrorMessage() : UNDEFINE_ERROR_MESSAGE,
                            CoreConf.EVENT_LEVEL_LOW));
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }

    private Map<String, Object> initParamsMap() {
        Map<String, Object> paramsMap = new HashMap<>();
        paramsMap.put(TITLE_PARAMETER, TITLE_NAME);
        LocalDateTime dateTime = LocalDateTime.now();
        paramsMap.put(YEAR_PARAMETER, dateTime.getYear() - 1911);
        paramsMap.put(MONTH_PARAMETER, dateTime.getMonthOfYear());
        paramsMap.put(DAY_PARAMETER, dateTime.getDayOfMonth());
        return paramsMap;
    }

    private void exportReport(Object javaBean, String realPath, String fileName, String exportType) {
        try {
            File reportTemplateFile = Paths.get(IOUtils.loadResourceURLInClasspath(
                    REPORT_FOLDER + CoreConf.SUFFIX_JASPER).toURI())
                                           .toFile();

            String certPath = realPath + OUTPUT_FOLDER;
            FileSystemUtils.checkFolder(new File(certPath));
            File reportOutput = new File(certPath, fileName);

            outputFacade.genReportToFile(
                    new ReportInputModel(reportTemplateFile.getAbsolutePath(), reportOutput.getAbsolutePath(), javaBean,
                            initParamsMap(), exportType));

        } catch (URISyntaxException e) {
            throw new ArchivesException(CoreErrorCode.FILE_SAVE_FAIL);
        }
    }
}
