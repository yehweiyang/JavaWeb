package gov.archives.dox.controller;

import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.controller.RestControllerBase;
import gov.archives.core.exception.ArchivesException;
import gov.archives.dox.domain.entity.FormEntity;
import gov.archives.dox.message.DoxErrorCode;
import gov.archives.dox.message.DoxErrorMessage;
import gov.archives.dox.service.FormInfoService;

import static gov.archives.dox.conf.DoxConf.*;
import static gov.archives.dox.message.DoxErrorCode.*;
import static gov.archives.dox.message.DoxErrorMessage.*;

@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + "/form")
public class FormRegisterController extends RestControllerBase {
    private static final String MODULE_NAME = "註冊表單查詢模組";
    private static final String TABLE_ID = "tableId";
    private static final String TABLE_NAME = "tableName";
    private static final String AGENCY_ORG_ID = "agencyOrgId";
    private static final String FORM_TYPE = "formType";
    private static final String STATUS_CODE = "statusCode";
    private static final String MAIN_FILE_TYPE = "mainFileType";
    private static final String FORM_TYPE_INDEX = "formTypeIndex";
    private static final String FILE_TYPE_INDEX = "fileTypeIndex";
    private static final String SHOW_FILE_TYPE_INDEX = "showFileTypeIndex";
    private static final String VIEW_FILE_TYPE = "viewFileType";
    private static final String ALIVE_FORM_STATUS = "ALIVE";
    private static final String SUSPEND_FORM_STATUS = "SUSPEND";
    private static final String STOP_FORM_STATUS = "STOP";
    private static final String XML_FILE = "XML";
    private static final String DOC_FILE = "DOC";
    private static final String PDF_FILE = "PDF";
    private static final String PNG_FILE = "PNG";
    private static final String TIF_FILE = "TIF";
    private static final String NONE_FILE = "無";

    public FormRegisterController() {
        this.setModuleName(MODULE_NAME);
    }

    @Autowired
    private FormInfoService formInfoService;

    private List<FormEntity> entityList;

    @RequestMapping(value = "/list",
                    method = RequestMethod.GET)
    public ResponseEntity<List<FormEntity>> getAllFormList(HttpServletRequest request, @RequestParam Map<String, Object>
            params) {
        try {
            Object cacheData = params.get(CACHE_DATE);
            formParamsValidate(params);
            if ("false".equals(cacheData))
                entityList = formInfoService.getByQueryMap(params);
            else if ("true".equals(cacheData)) {
                if (null == entityList)
                    entityList = formInfoService.getByQueryMap(params);
            }
            return new ResponseEntity<>(entityList, HttpStatus.OK);
        } catch (ArchivesException e) {
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }

    private void formParamsValidate(Map<String, Object> params) {
        genStatusCodeParam(params);
        genFormTypeParam(params);
        genMainFileTypeParam(params);
        genViewFileTypeParam(params);
        if (!validateFiled((String) params.get(TABLE_ID), CoreConf.DIGIT_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0020_ERROR_MESSAGE,
                    DoxErrorCode.ED0020_FORM_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(TABLE_NAME), CoreConf.ALPHANUMERIC_NLS_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0021_ERROR_MESSAGE,
                    DoxErrorCode.ED0021_FORM_NAME_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(AGENCY_ORG_ID), CoreConf.ALPHANUMERIC_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0022_ERROR_MESSAGE,
                    DoxErrorCode.ED0022_AGENCY_ID_UNIT_FORMAT_INCORRECT);
        }
    }

    private void genStatusCodeParam(Map<String, Object> params) {
        String[] formStatusArray = { null, ALIVE_FORM_STATUS, SUSPEND_FORM_STATUS , STOP_FORM_STATUS};
        int index = new Integer((String) params.get(STATUS_INDEX));
        if (index >= 0  && index < formStatusArray.length)
            params.put(STATUS_CODE, formStatusArray[index]);
        else
            throw new ArchivesException(ED0025_ERROR_MESSAGE, ED0025_FORM_STATUS_INDEX_INCORRECT);
    }

    private void genFormTypeParam(Map<String, Object> params) {
        String[] formTypeArray = { null, DOC_FORM_TYPE, MANGER_FORM_TYPE};
        int index = new Integer((String) params.get(FORM_TYPE_INDEX));
        if (index >= 0  && index < formTypeArray.length)
            params.put(FORM_TYPE, formTypeArray[index]);
        else
            throw new ArchivesException(ED0026_ERROR_MESSAGE, ED0026_FORM_TYPE_INDEX_INCORRECT);
    }

    private void genMainFileTypeParam(Map<String, Object> params) {
        String[] fileTypeArray = { null, XML_FILE, DOC_FILE, PDF_FILE};
        int index = new Integer((String) params.get(FILE_TYPE_INDEX));
        if (index >= 0  && index < fileTypeArray.length)
            params.put(MAIN_FILE_TYPE, fileTypeArray[index]);
        else
            throw new ArchivesException(ED0027_ERROR_MESSAGE, ED0027_MAIN_FILE_TYPE_INDEX_INCORRECT);
    }

    private void genViewFileTypeParam(Map<String, Object> params) {
        String[] viewFileTypeArray = { null, NONE_FILE, PDF_FILE, PNG_FILE, TIF_FILE};
        int index = new Integer((String) params.get(SHOW_FILE_TYPE_INDEX));
        if (index >= 0  && index < viewFileTypeArray.length)
            params.put(VIEW_FILE_TYPE, viewFileTypeArray[index]);
        else
            throw new ArchivesException(ED0028_ERROR_MESSAGE, ED0028_VIEW_FILE_TYPE_INDEX_INCORRECT);
    }
}
