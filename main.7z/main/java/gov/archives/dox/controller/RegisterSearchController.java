package gov.archives.dox.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.controller.RestControllerBase;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.service.ActionLogService;
import gov.archives.dox.conf.DoxConf;
import gov.archives.dox.domain.entity.AddressBookBase;
import gov.archives.dox.domain.entity.AddressbookEntity;
import gov.archives.dox.domain.entity.CenterEntity;
import gov.archives.dox.message.DoxErrorCode;
import gov.archives.dox.message.DoxErrorMessage;
import gov.archives.dox.service.AddressbookService;
import gov.archives.dox.service.CenterListService;

import static gov.archives.dox.conf.DoxConf.*;
import static gov.archives.dox.message.DoxErrorCode.*;
import static gov.archives.dox.message.DoxErrorMessage.*;

@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + "/addressSearch")
public class RegisterSearchController extends RestControllerBase {
    private static final String GATEWAY_ID = "gatewayId";
    private static final String AGENCY_ID = "agencyId";
    private static final String AGENCY_UNIT_ID = "agencyUnitId";
    private static final String AGENCY_NAME = "agencyName";
    private static final String ACTIVE_STATUS = "activeStatus";
    private static final String CENTER_INDEX = "centerIndex";
    private static final String MODULE_NAME = "地址簿查詢模組";

    @Autowired
    private CenterListService centerListService;

    @Autowired
    private AddressbookService addressBookService;

    @Autowired
    private ActionLogService actionLogService;

    private List<AddressBookBase> bookBaseList;

    private List<CenterEntity> centerEntityList;

    private int centerListSize;

    public RegisterSearchController() {
        this.setModuleName(MODULE_NAME);
    }

    @RequestMapping(value = "/center/list",
                    method = RequestMethod.GET)
    public ResponseEntity<List<CenterEntity>> getAllCenter(HttpServletRequest request) {
        try {
            centerEntityList = centerListService.getAllCenterInfo();
            actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                    HttpStatus.OK.getReasonPhrase(),
                    DoxConf.REST_ADDRESS_SEARCH_CENTER_LIST_SUCCESS,
                    CoreConf.EVENT_LEVEL_LOW));
            return new ResponseEntity<>(centerEntityList, HttpStatus.OK);
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(), e.getErrorCode(),
                            e.getErrorMessage(),
                            CoreConf.EVENT_LEVEL_LOW));
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }

    @RequestMapping(value = "/list",
                    method = RequestMethod.GET)
    public ResponseEntity<List<AddressBookBase>> getAllAddressBook(HttpServletRequest request,
            @RequestParam Map<String, Object> params) {
        try {
            addressBookParamsValidate(params);
            genCenterIdParam(params);
            genActiveStatusParam(params);
            Object cacheData = params.get(CACHE_DATE);
            if ("false".equals(cacheData))
                bookBaseList = addressBookService.getAllAddressBook(params);
            else if ("true".equals(cacheData)) {
                if (null == bookBaseList)
                    bookBaseList = addressBookService.getAllAddressBook(params);
            }
            actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                    HttpStatus.OK.getReasonPhrase(),
                    DoxConf.REST_ADDRESS_SEARCH_LIST_SUCCESS,
                    CoreConf.EVENT_LEVEL_LOW));
            return new ResponseEntity<>(bookBaseList, HttpStatus.OK);
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                            e.getErrorCode() != null ? e.getErrorCode() : UNDEFINE_ERROR_CODE,
                            e.getErrorMessage() != null ? e.getErrorMessage() : UNDEFINE_ERROR_MESSAGE,
                            CoreConf.EVENT_LEVEL_LOW));
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }

    private void addressBookParamsValidate(Map<String, Object> params) {
        if (!validateFiled((String) params.get(GATEWAY_ID), CoreConf.DIGIT_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0013_ERROR_MESSAGE,
                    DoxErrorCode.ED0013_CENTER_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(AGENCY_ID), CoreConf.ALPHANUMERIC_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0006_ERROR_MESSAGE,
                    DoxErrorCode.ED0006_AGENCY_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(AGENCY_UNIT_ID), CoreConf.ALPHANUMERIC_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0008_ERROR_MESSAGE,
                    DoxErrorCode.ED0008_UNIT_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(AGENCY_NAME), CoreConf.ALPHANUMERIC_NLS_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0014_ERROR_MESSAGE,
                    DoxErrorCode.ED0014_AGENCY_NAME_FORMAT_INCORRECT);
        }
    }

    private void genCenterIdParam(Map<String, Object> params) {
        int index = new Integer((String) params.get(CENTER_INDEX));
        centerListSize = centerEntityList.size();
        if (index >= 0  && index < centerListSize)
            params.put(GATEWAY_ID, centerEntityList.get(index).getCenterId());
        else
            throw new ArchivesException(ED0023_ERROR_MESSAGE, ED0023_CENTER_INDEX_INCORRECT);
    }

    private void genActiveStatusParam(Map<String, Object> params) {
        Integer[] activeStatusArray = { null, 1, -1 , 0};
        int index = new Integer((String) params.get(STATUS_INDEX));
        if (index >= 0  && index < activeStatusArray.length)
            params.put(ACTIVE_STATUS, activeStatusArray[index]);
        else
            throw new ArchivesException(ED0024_ERROR_MESSAGE, ED0024_STATUS_INDEX_INCORRECT);
    }

    @RequestMapping(value = "/detail",
                    method = RequestMethod.GET)
    public ResponseEntity<AddressbookEntity> getAddressBookDetail(HttpServletRequest request, @RequestParam Map<String, Object>
            params) {
        try {
            addressBookParamsValidate(params);
            AddressbookEntity entity = addressBookService.getByOrgUnitId(params);
            actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                    HttpStatus.OK.getReasonPhrase(),
                    DoxConf.REST_ADDRESS_SEARCH_DETAIL_SUCCESS,
                    CoreConf.EVENT_LEVEL_LOW));
            return new ResponseEntity<>(entity, HttpStatus.OK);
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                            e.getErrorCode() != null ? e.getErrorCode() : UNDEFINE_ERROR_CODE,
                            e.getErrorMessage() != null ? e.getErrorMessage() : UNDEFINE_ERROR_MESSAGE,
                            CoreConf.EVENT_LEVEL_LOW));
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }
}
