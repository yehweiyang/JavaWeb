package gov.archives.dox.domain.entity;

import org.apache.ibatis.type.Alias;

@Alias("DocWord")
public class SubrogationEntity {
    private String agencyId;
    private String authAgencyId;
    private String subRoGate;
    private String effectStartDate;
    private String validDate;
    private String updateTime;
    private String agencyName;
    private String authAgencyName;

    public String getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(String agencyId) {
        this.agencyId = agencyId;
    }

    public String getAuthAgencyId() {
        return authAgencyId;
    }

    public void setAuthAgencyId(String authAgencyId) {
        this.authAgencyId = authAgencyId;
    }

    public String getSubRoGate() {
        return subRoGate;
    }

    public void setSubRoGate(String subRoGate) {
        this.subRoGate = subRoGate;
    }

    public String getEffectStartDate() {
        return effectStartDate;
    }

    public void setEffectStartDate(String effectStartDate) {
        this.effectStartDate = effectStartDate;
    }

    public String getValidDate() {
        return validDate;
    }

    public void setValidDate(String validDate) {
        this.validDate = validDate;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public String getAuthAgencyName() {
        return authAgencyName;
    }

    public void setAuthAgencyName(String authAgencyName) {
        this.authAgencyName = authAgencyName;
    }
}
