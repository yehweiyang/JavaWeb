package gov.archives.dox.domain.entity;

import org.apache.ibatis.type.Alias;

@Alias("OrgCertExpired")
public class OrgCertExpiredEntity {
    private String agencyId;
    private String agencyName;
    private String signDigitalNum;
    private String effectEnd;

    public String getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(String agencyId) {
        this.agencyId = agencyId;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public String getSignDigitalNum() {
        return signDigitalNum;
    }

    public void setSignDigitalNum(String signDigitalNum) {
        this.signDigitalNum = signDigitalNum;
    }

    public String getEffectEnd() {
        return effectEnd;
    }

    public void setEffectEnd(String effectEnd) {
        this.effectEnd = effectEnd;
    }
}
