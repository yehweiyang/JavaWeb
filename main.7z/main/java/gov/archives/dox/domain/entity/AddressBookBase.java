package gov.archives.dox.domain.entity;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

import gov.archives.core.domain.entity.BaseEntity;
import gov.archives.core.util.EscapeUtils;

import static gov.archives.dox.conf.DoxConf.*;

@Alias("AddressBookInfo")
public class AddressBookBase extends BaseEntity implements Serializable {
    private String gatewayId;
    private String agencyId;
    private String agencyUnitId;
    private String agencyName;
    private Integer activeStatus;
    private String statusCode;
    private String updateTime;

    public String getGatewayId() {
        return gatewayId;
    }

    public void setGatewayId(String gatewayId) {
        this.gatewayId = gatewayId;
    }

    public String getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(String agencyId) {
        this.agencyId = agencyId;
    }

    public String getAgencyUnitId() {
        return agencyUnitId;
    }

    public void setAgencyUnitId(String agencyUnitId) {
        this.agencyUnitId = agencyUnitId;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public Integer getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public void buildGatewayId() {
        setGatewayId(EscapeUtils.escapeHtml(gatewayId));
    }

    public void buildAgencyId() {
        setAgencyId(EscapeUtils.escapeHtml(agencyId));
    }

    public void buildAgencyUnitId() {
        setAgencyUnitId(EscapeUtils.escapeHtml(agencyUnitId));
    }

    public void buildAgencyName() {
        setAgencyName(EscapeUtils.escapeHtml(agencyName));
    }

    public void buildStatusMessage() {
        if (getActiveStatus() > 0) {
            setStatusCode(ACTIVE_STATUS_ONE);
        } else if (getActiveStatus() < 0) {
            setStatusCode(ACTIVE_STATUS_TWO);
        } else {
            setStatusCode(ACTIVE_STATUS_ZERO);
        }
    }

    public void buildUpdateTime() {
        setUpdateTime(EscapeUtils.escapeHtml(getUpdateTime().substring(0, 19)));
    }
}
