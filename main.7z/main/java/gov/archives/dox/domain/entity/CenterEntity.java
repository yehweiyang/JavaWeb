package gov.archives.dox.domain.entity;

import java.io.Serializable;

import org.apache.ibatis.type.Alias;

@Alias("CenterInfo")
public class CenterEntity implements Serializable {
    private String centerId;
    private String centerName;
    private Integer activeStatus;

    public String getCenterId() {
        return centerId;
    }

    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    public String getCenterName() {
        return centerName;
    }

    public void setCenterName(String centerName) {
        this.centerName = centerName;
    }

    public Integer getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

}
