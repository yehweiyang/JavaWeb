# gov.archives.dox

負責公文交換系統定義性資料的增刪查改，使用 dox_2017 資料庫