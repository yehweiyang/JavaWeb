package gov.archives.dox.mapper.query;

import java.util.List;

import gov.archives.dox.domain.entity.CenterEntity;

public interface CenterListQueryMapper {
    public List<CenterEntity> getAll();
}
