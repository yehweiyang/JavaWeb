package gov.archives.dox.mapper.query;


import java.util.List;
import java.util.Map;

import gov.archives.dox.domain.entity.SubrogationEntity;

public interface SubrogationQueryMapper {

    List<SubrogationEntity> findByMap(Map<String, Object> queryMap);
}
