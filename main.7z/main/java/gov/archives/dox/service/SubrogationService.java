package gov.archives.dox.service;

import java.util.List;
import java.util.Map;

import gov.archives.dox.domain.entity.SubrogationEntity;

public interface SubrogationService {

    List<SubrogationEntity> getByQueryMap(Map<String, Object> queryMap);
}
