package gov.archives.dox.service.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.exception.ArchivesException;
import gov.archives.dox.conf.DoxConf;
import gov.archives.dox.domain.entity.SubrogationEntity;
import gov.archives.dox.mapper.query.SubrogationQueryMapper;
import gov.archives.dox.message.DoxErrorCode;
import gov.archives.dox.message.DoxErrorMessage;
import gov.archives.dox.service.SubrogationService;

@Service
@Transactional
public class SubrogationServiceImpl implements SubrogationService {

    @Autowired
    SubrogationQueryMapper queryMapper;

    @Override
    @Transactional(value = DoxConf.QUERY_TX_MANAGER,
                   readOnly = true)
    public List<SubrogationEntity> getByQueryMap(Map<String, Object> queryMap) {
        List<SubrogationEntity> entityList = queryMapper.findByMap(queryMap);
        if (null == entityList || 0 == entityList.size()) {
            throw new ArchivesException(DoxErrorMessage.AP0000_ERROR_MESSAGE,
                    DoxErrorCode.AP0000_DATA_NOT_FOUND);
        }
        Iterator<SubrogationEntity> iterator = entityList.iterator();
        while (iterator.hasNext()) {
            SubrogationEntity entity = iterator.next();
            String updateTime = entity.getUpdateTime().substring(0, 19);
            entity.setUpdateTime(updateTime);
        }
        return entityList;
    }
}
