package gov.archives.dox.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.dox.conf.DoxConf;
import gov.archives.dox.domain.entity.OrgCertExpiredEntity;
import gov.archives.dox.mapper.query.OrgCertQueryMapper;
import gov.archives.dox.message.DoxErrorCode;
import gov.archives.dox.message.DoxErrorMessage;
import gov.archives.dox.service.OrgCertService;

import static gov.archives.dox.mapper.query.OrgCertQueryMapper.*;

@Service
@Transactional
public class OrgCertServiceImpl implements OrgCertService {

    @Autowired
    OrgCertQueryMapper queryMapper;

    @Override
    @Transactional(value = DoxConf.QUERY_TX_MANAGER,
                   readOnly = true)
    public List<OrgCertExpiredEntity> getCertExpired() {
        Map<String, String> queryMap = new HashMap<>();
        queryMap.put(KEY_VALID_END, LocalDateTime.now().plusDays(90).toDateTime().toString(CoreConf.DATE_FORMAT));
        List<OrgCertExpiredEntity> entityList = queryMapper.findByValidEnd(queryMap);
        if (null == entityList || 0 == entityList.size()) {
            throw new ArchivesException(DoxErrorMessage.AP0000_ERROR_MESSAGE,
                    DoxErrorCode.AP0000_DATA_NOT_FOUND);
        }
        return entityList;
    }
}
