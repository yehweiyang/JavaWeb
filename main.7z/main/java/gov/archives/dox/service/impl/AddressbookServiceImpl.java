package gov.archives.dox.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.exception.ArchivesException;
import gov.archives.dox.conf.DoxConf;
import gov.archives.dox.domain.entity.AddressBookBase;
import gov.archives.dox.domain.entity.AddressbookEntity;
import gov.archives.dox.domain.entity.OrgCertEntity;
import gov.archives.dox.mapper.query.AddressbookQueryMapper;
import gov.archives.dox.mapper.query.OrgCertQueryMapper;
import gov.archives.dox.message.DoxErrorCode;
import gov.archives.dox.message.DoxErrorMessage;
import gov.archives.dox.service.AddressbookService;
import gov.archives.exchange.message.ExchangeErrorCode;
import gov.archives.exchange.message.ExchangeErrorMessage;

/**
 * AddressbookServiceImpl
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@Service
@Transactional
public class AddressbookServiceImpl implements AddressbookService {

    @Autowired
    private AddressbookQueryMapper queryMapper;

    @Autowired
    private OrgCertQueryMapper orgCertQueryMapper;

    @Override
    @Transactional(value = DoxConf.QUERY_TX_MANAGER,
                   readOnly = true)
    public List<AddressBookBase> getAllAddressBook(Map<String, Object> queryMap) {
        List<AddressBookBase> list = queryMapper.findByMap(queryMap);
        if (null == list || 0 == list.size()) {
            throw new ArchivesException(DoxErrorMessage.AP0000_ERROR_MESSAGE,
                    DoxErrorCode.AP0000_DATA_NOT_FOUND);
        }
        for (AddressBookBase entity : list) {
            entity.buildGatewayId();
            entity.buildAgencyId();
            entity.buildAgencyUnitId();
            entity.buildAgencyName();
            entity.buildStatusMessage();
            entity.buildUpdateTime();
        }
        return list;
    }

    @Override
    @Transactional(value = DoxConf.QUERY_TX_MANAGER,
                   readOnly = true)
    public AddressbookEntity getByOrgUnitId(Map<String, Object> queryMap) {
        AddressbookEntity entity = queryMapper.findByOrgUnitId(queryMap);
        OrgCertEntity orgCert = orgCertQueryMapper.findByOrgUnitId(queryMap);
        if (null == entity || null == orgCert) {
            throw new ArchivesException(DoxErrorMessage.AP0000_ERROR_MESSAGE,
                    DoxErrorCode.AP0000_DATA_NOT_FOUND);
        } else {
            entity.buildGatewayId();
            entity.buildAgencyName();
            entity.buildAgencyId();
            entity.buildAgencyUnitId();
            entity.buildAgencyAddress();
            entity.buildAgencyPhone();
            entity.buildAgencyFax();
            entity.buildContactName();
            entity.buildContactEmail();
            entity.buildStatusMessage();
            entity.buildOrgCardStatus();
            entity.buildAgencyCertId();
            entity.buildCipherModule();
            entity.buildUpdateTime();
            entity.setOrgCert(orgCert);
            entity.buildApplyType();
            entity.buildSmartCardType();
            entity.buildSignDigitalNum();
            entity.buildEncryptDigitalNum();
            entity.buildEffectBegin();
            entity.buildEffectEnd();
            entity.buildDefaultCert();
            entity.buildCertCardSerial();
            entity.buildPublicKeySerial();
        }
        return entity;
    }

}
