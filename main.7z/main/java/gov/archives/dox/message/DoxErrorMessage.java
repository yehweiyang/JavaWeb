package gov.archives.dox.message;

/**
 * DoxErrorMessage
 * <br>
 * dox package 之錯誤訊息設定
 * <br>
 * gemhuang, 2016/8/16.
 */
public class DoxErrorMessage {
    public static final String AP0000_ERROR_MESSAGE = "無符合條件的查詢結果";
    public static final String ED0006_ERROR_MESSAGE = "機關代碼輸入格式錯誤";
    public static final String ED0007_ERROR_MESSAGE = "機關代碼輸入長度錯誤";
    public static final String ED0008_ERROR_MESSAGE = "單位代碼輸入格式錯誤";
    public static final String ED0009_ERROR_MESSAGE = "授權機關單位輸入格式錯誤";
    public static final String ED0010_ERROR_MESSAGE = "被授權機關單位輸入格式錯誤";
    public static final String ED0011_ERROR_MESSAGE = "代字號輸入格式錯誤";
    public static final String ED0013_ERROR_MESSAGE = "交換中心輸入格式錯誤";
    public static final String ED0014_ERROR_MESSAGE = "機關名稱輸入格式錯誤";
    public static final String ED0015_ERROR_MESSAGE = "文號輸入格式錯誤";
    public static final String ED0016_ERROR_MESSAGE = "交換編號輸入格式錯誤";
    public static final String ED0017_ERROR_MESSAGE = "生效日期輸入格式錯誤";
    public static final String ED0018_ERROR_MESSAGE = "有效日期輸入格式錯誤";
    public static final String ED0019_ERROR_MESSAGE = "輸出檔案格式錯誤";
    public static final String ED0020_ERROR_MESSAGE = "表單編號輸入格式錯誤";
    public static final String ED0021_ERROR_MESSAGE = "表單名稱輸入格式錯誤";
    public static final String ED0022_ERROR_MESSAGE = "機關單位代碼輸入格式錯誤";
    public static final String ED0023_ERROR_MESSAGE = "交換中心索引錯誤";
    public static final String ED0024_ERROR_MESSAGE = "交換狀況索引錯誤";
    public static final String ED0025_ERROR_MESSAGE = "表單狀況索引錯誤";
    public static final String ED0026_ERROR_MESSAGE = "表單類型索引錯誤";
    public static final String ED0027_ERROR_MESSAGE = "主檔案類型索引錯誤";
    public static final String ED0028_ERROR_MESSAGE = "呈現檔案類型";
}
