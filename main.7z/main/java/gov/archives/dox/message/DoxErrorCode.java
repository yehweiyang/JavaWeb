package gov.archives.dox.message;

/**
 * DoxErrorCode
 * <br>
 * dox package 之錯誤代碼設定
 * <br>
 * gemhuang, 2016/8/16.
 */
public class DoxErrorCode {
    public static final String AP0000_DATA_NOT_FOUND = "AP0000";
    public static final String ED0006_AGENCY_ID_FORMAT_INCORRECT = "ED0006";
    public static final String ED0007_AGENCY_ID_LENGTH_INCORRECT = "ED0007";
    public static final String ED0008_UNIT_ID_FORMAT_INCORRECT = "ED0008";
    public static final String ED0009_AUTH_AGENCY_ID_FORMAT_INCORRECT = "ED0009";
    public static final String ED0010_AGENCY_ID_FORMAT_INCORRECT = "ED0010";
    public static final String ED0011_SUBROGATE_ID_FORMAT_INCORRECT = "ED0011";
    public static final String ED0013_CENTER_ID_FORMAT_INCORRECT = "ED0013";
    public static final String ED0014_AGENCY_NAME_FORMAT_INCORRECT = "ED0014";
    public static final String ED0015_DOC_ID_FORMAT_INCORRECT = "ED0015";
    public static final String ED0016_EXCHANGE_ID_FORMAT_INCORRECT = "ED0016";
    public static final String ED0017_EFFECT_DATE_FORMAT_INCORRECT = "ED0017";
    public static final String ED0018_EXPIRED_DATE_FORMAT_INCORRECT = "ED0018";
    public static final String ED0019_OUTPUT_FILE_FORMAT_INCORRECT = "ED0019";
    public static final String ED0020_FORM_ID_FORMAT_INCORRECT = "ED0020";
    public static final String ED0021_FORM_NAME_FORMAT_INCORRECT = "ED0021";
    public static final String ED0022_AGENCY_ID_UNIT_FORMAT_INCORRECT = "ED0022";
    public static final String ED0023_CENTER_INDEX_INCORRECT = "ED0023";
    public static final String ED0024_STATUS_INDEX_INCORRECT = "ED0024";
    public static final String ED0025_FORM_STATUS_INDEX_INCORRECT = "ED0025";
    public static final String ED0026_FORM_TYPE_INDEX_INCORRECT = "ED0026";
    public static final String ED0027_MAIN_FILE_TYPE_INDEX_INCORRECT = "ED0027";
    public static final String ED0028_VIEW_FILE_TYPE_INDEX_INCORRECT = "ED0028";
}
