package gov.archives.exchange.message;

import java.util.HashMap;
import java.util.Map;

import gov.archives.core.message.CoreErrorCode;

/**
 * ExchangeErrorMessage
 * <br>
 * exchange package 之錯誤訊息設定
 * <br>
 * gemhuang, 2016/8/16.
 */
public class ExchangeErrorMessage {
    public static final String AP0000_ERROR_MESSAGE = "無符合條件的查詢結果";
    public static final String ED0006_ERROR_MESSAGE = "機關代碼輸入格式錯誤";
    public static final String ED0007_ERROR_MESSAGE = "機關代碼輸入長度錯誤";
    public static final String ED0014_ERROR_MESSAGE = "機關名稱輸入格式錯誤";
    public static final String ED0015_ERROR_MESSAGE = "文號輸入格式錯誤";
    public static final String ED0016_ERROR_MESSAGE = "交換編號輸入格式錯誤";
    public static final String ED0017_ERROR_MESSAGE = "上傳時間格式錯誤";
}
