package gov.archives.exchange.domain.entity;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import gov.archives.core.domain.entity.AggregationEntity;

/**
 * MainInfoEntity
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@Alias("MainInfo")
public class MainInfoEntity extends AggregationEntity {
    private String exchangeId;
    private String clientId;
    private String senderOrgId;
    private String senderUnitId;
    private Integer receiverCount;
    private String applicationId;
    private String docSubject;
    private Timestamp expireDate;
    private Timestamp clientTime;
    private Timestamp serverTime;
    private Timestamp processTime;
    private Timestamp completeTime;
    private String senderType;
    private Integer sysErrCount;
    private Integer userCfmCount;
    private Integer userErrCount;

    public String getExchangeId() {
        return exchangeId;
    }

    public String getClientId() {
        return clientId;
    }

    public String getSenderOrgId() {
        return senderOrgId;
    }

    public String getSenderUnitId() {
        return senderUnitId;
    }

    public Integer getReceiverCount() {
        return receiverCount;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getDocSubject() {
        return docSubject;
    }

    public Timestamp getExpireDate() {
        return expireDate;
    }

    public Timestamp getClientTime() {
        return clientTime;
    }

    public Timestamp getServerTime() {
        return serverTime;
    }

    public Timestamp getProcessTime() {
        return processTime;
    }

    public Timestamp getCompleteTime() {
        return completeTime;
    }

    public String getSenderType() {
        return senderType;
    }

    public Integer getSysErrCount() {
        return sysErrCount;
    }

    public Integer getUserCfmCount() {
        return userCfmCount;
    }

    public Integer getUserErrCount() {
        return userErrCount;
    }

    public void setExchangeId(String exchangeId) {
        this.exchangeId = exchangeId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public void setSenderOrgId(String senderOrgId) {
        this.senderOrgId = senderOrgId;
    }

    public void setSenderUnitId(String senderUnitId) {
        this.senderUnitId = senderUnitId;
    }

    public void setReceiverCount(Integer receiverCount) {
        this.receiverCount = receiverCount;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public void setDocSubject(String docSubject) {
        this.docSubject = docSubject;
    }

    public void setExpireDate(Timestamp expireDate) {
        this.expireDate = expireDate;
    }

    public void setClientTime(Timestamp clientTime) {
        this.clientTime = clientTime;
    }

    public void setServerTime(Timestamp serverTime) {
        this.serverTime = serverTime;
    }

    public void setProcessTime(Timestamp processTime) {
        this.processTime = processTime;
    }

    public void setCompleteTime(Timestamp completeTime) {
        this.completeTime = completeTime;
    }

    public void setSenderType(String senderType) {
        this.senderType = senderType;
    }

    public void setSysErrCount(Integer sysErrCount) {
        this.sysErrCount = sysErrCount;
    }

    public void setUserCfmCount(Integer userCfmCount) {
        this.userCfmCount = userCfmCount;
    }

    public void setUserErrCount(Integer userErrCount) {
        this.userErrCount = userErrCount;
    }

    public static class Builder {
        public static synchronized Builder create() {
            return new Builder();
        }

        private MainInfoEntity mainInfo;
        private Builder self;

        private Builder() {
            this.mainInfo = new MainInfoEntity();
            this.self = this;
        }

        public Builder setExchangeId(String exchangeId) {
            this.mainInfo.exchangeId = exchangeId;
            return self;
        }

        public Builder setClientId(String clientId) {
            this.mainInfo.clientId = clientId;
            return self;
        }

        public Builder setSenderOrgId(String senderOrgId) {
            this.mainInfo.senderOrgId = senderOrgId;
            return self;
        }

        public Builder setSenderUnitId(String senderUnitId) {
            this.mainInfo.senderUnitId = senderUnitId;
            return self;
        }

        public Builder setReceiverCount(Integer receiverCount) {
            this.mainInfo.receiverCount = receiverCount;
            return self;
        }

        public Builder setApplicationId(String applicationId) {
            this.mainInfo.applicationId = applicationId;
            return self;
        }

        public Builder setDocSubject(String docSubject) {
            this.mainInfo.docSubject = docSubject;
            return self;
        }

        public Builder setExpireDate(Timestamp expireDate) {
            this.mainInfo.expireDate = expireDate;
            return self;
        }

        public Builder setClientTime(Timestamp clientTime) {
            this.mainInfo.clientTime = clientTime;
            return self;
        }

        public Builder setServerTime(Timestamp serverTime) {
            this.mainInfo.serverTime = serverTime;
            return self;
        }

        public Builder setProcessTime(Timestamp processTime) {
            this.mainInfo.processTime = processTime;
            return self;
        }

        public Builder setCompleteTime(Timestamp completeTime) {
            this.mainInfo.completeTime = completeTime;
            return self;
        }

        public Builder setSenderType(String senderType) {
            this.mainInfo.senderType = senderType;
            return self;
        }

        public Builder setSysErrCount(Integer sysErrCount) {
            this.mainInfo.sysErrCount = sysErrCount;
            return self;
        }

        public Builder setUserCfmCount(Integer userCfmCount) {
            this.mainInfo.userCfmCount = userCfmCount;
            return self;
        }

        public Builder setUserErrCount(Integer userErrCount) {
            this.mainInfo.userErrCount = userErrCount;
            return self;
        }

        public MainInfoEntity build() {
            return this.mainInfo;
        }
    }
}
