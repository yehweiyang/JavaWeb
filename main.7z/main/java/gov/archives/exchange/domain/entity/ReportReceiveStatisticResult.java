package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by kshsu on 2016/7/28. 收發文狀態統計報表(收文) rptrss
 */
@Alias("ReportReceiveStatistic")
public class ReportReceiveStatisticResult extends ReportResult {
    public enum ColmunEnum {
        title("收文狀態統計"),
        rowIndex("項次"),
        receiverId("機關代碼"),
        receiverName("機關名稱"),
        totalDocumentCount("收文量"),
        userRejectCount("使用者退文量"),
        userRejectPercent("使用者退文比例");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 項次
     */
    private String rowIndex;
    /**
     * 機關代碼
     */
    private String receiverId;
    /**
     * 機關名稱
     */
    private String receiverName;
    /**
     * 收文量
     */
    private int totalDocumentCount;
    /**
     * 使用者退文量
     */
    private int userRejectCount;
    /**
     * 使用者退文比例
     */
    private String userRejectPercent;

    public String getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(String rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public int getTotalDocumentCount() {
        return totalDocumentCount;
    }

    public void setTotalDocumentCount(int totalDocumentCount) {
        this.totalDocumentCount = totalDocumentCount;
    }

    public int getUserRejectCount() {
        return userRejectCount;
    }

    public void setUserRejectCount(int userRejectCount) {
        this.userRejectCount = userRejectCount;
    }

    public String getUserRejectPercent() {
        return userRejectPercent;
    }

    public void setUserRejectPercent(String userRejectPercent) {
        this.userRejectPercent = userRejectPercent;
    }
}
