package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by kshsu on 2016/8/1.
 * 收文統計 rptrecvstate
 */
@Alias("ReportRecvState")
public class ReportRecvStateResult extends ReportResult{
    public enum ColmunEnum {
        title("收文統計"),
        rowIndex("序號"),
        receiverId("收文機關代碼"),
        receiverName("收文機關名稱"),
        totalDocumentCount("收文量");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 序號
     */
    private int rowIndex;
    /**
     * 收文機關代碼
     */
    private String receiverId;
    /**
     * 收文機關名稱
     */
    private String receiverName;
    /**
     * 收文量
     */
    private int totalDocumentCount;

    public int getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public int getTotalDocumentCount() {
        return totalDocumentCount;
    }

    public void setTotalDocumentCount(int totalDocumentCount) {
        this.totalDocumentCount = totalDocumentCount;
    }
}
