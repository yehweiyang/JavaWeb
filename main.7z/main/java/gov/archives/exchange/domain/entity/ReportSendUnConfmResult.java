package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by kshsu on 2016/8/1.
 * 發文待確認 rptsendunconfm
 */
@Alias("ReportSendUnConfm")
public class ReportSendUnConfmResult extends ReportResult {
    public enum ColmunEnum {
        title("發文待確認"),
        rowIndex("序號"),
        applicationId("文號"),
        serverTime("發文日期"),
        senderName("發文單位"),
        receiverName("受文單位"),
        status("狀態"),
        userRejectTime("使用者退文日期"),
        otherFile("附件");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 序號
     */
    private int rowIndex;
    /**
     * 文號
     */
    private String applicationId;
    /**
     * 發文日期
     */
    private String serverTime;
    /**
     * 發文單位
     */
    private String senderName;
    /**
     * 受文單位
     */
    private String receiverName;
    /**
     * 狀態
     */
    private String status;
    /**
     * 使用者退文日期
     */
    private String userRejectTime;
    /**
     * 附件
     */
    private String otherFile;

    public int getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getServerTime() {
        return serverTime;
    }

    public void setServerTime(String serverTime) {
        this.serverTime = serverTime;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserRejectTime() {
        return userRejectTime;
    }

    public void setUserRejectTime(String userRejectTime) {
        this.userRejectTime = userRejectTime;
    }

    public String getOtherFile() {
        return otherFile;
    }

    public void setOtherFile(String otherFile) {
        this.otherFile = otherFile;
    }
}
