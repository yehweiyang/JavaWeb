package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by jslee on 2016/7/5.
 * 發文統計 rptsendst
 */
@Alias("ReportSendState")
public class ReportSendStateResult extends ReportResult{
    public enum ColmunEnum {
        title("發文統計"),
        rowIndex("排名"),
        senderId("發文機關代碼"),
        senderName("發文機關名稱"),
        senderNum("發文量"),
        senderCount("發文總件數");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 排名
     */
    private int rowIndex;
    /**
     * 發文機關代碼
     */
    private String senderId;
    /**
     * 發文機關名稱
     */
    private String senderName;
    /**
     * 發文量
     */
    private int senderNum;
    /**
     * 發文總件數
     */
    private int senderCount;

    public int getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public int getSenderNum() {
        return senderNum;
    }

    public void setSenderNum(int senderNum) {
        this.senderNum = senderNum;
    }

    public int getSenderCount() {
        return senderCount;
    }

    public void setSenderCount(int senderCount) {
        this.senderCount = senderCount;
    }
}
