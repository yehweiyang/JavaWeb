package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by kshsu on 2016/7/28.
 * 收發文狀態統計報表(發文) rptsss
 */
@Alias("ReportSendStatistic")
public class ReportSendStatisticResult extends ReportResult {
    public enum ColmunEnum {
        title("發文狀態統計"),
        rowIndex("項次"),
        senderId("機關代碼"),
        senderName("機關名稱"),
        senderNum("發文量"),
        totalDocumentCount("發文總件數"),
        userConfirmCount("使用者確認量"),
        userConfirmPercent("使用者確認比例"),
        sendExceptionCount("發文異常量"),
        sendExceptionPercent("發文異常比例");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 項次
     */
    private String rowIndex;
    /**
     * 機關代碼
     */
    private String senderId;
    /**
     * 機關名稱
     */
    private String senderName;
    /**
     * 發文量
     */
    private int senderNum;
    /**
     * 發文總件數
     */
    private int totalDocumentCount;
    /**
     * 使用者確認量
     */
    private String userConfirmCount;
    /**
     * 使用者確認比例
     */
    private String userConfirmPercent;
    /**
     * 發文異常量
     */
    private String sendExceptionCount;
    /**
     * 發文異常比例
     */
    private String sendExceptionPercent;

    public String getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(String rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public int getSenderNum() {
        return senderNum;
    }

    public void setSenderNum(int senderNum) {
        this.senderNum = senderNum;
    }

    public int getTotalDocumentCount() {
        return totalDocumentCount;
    }

    public void setTotalDocumentCount(int totalDocumentCount) {
        this.totalDocumentCount = totalDocumentCount;
    }

    public String getUserConfirmCount() {
        return userConfirmCount;
    }

    public void setUserConfirmCount(String userConfirmCount) {
        this.userConfirmCount = userConfirmCount;
    }

    public String getUserConfirmPercent() {
        return userConfirmPercent;
    }

    public void setUserConfirmPercent(String userConfirmPercent) {
        this.userConfirmPercent = userConfirmPercent;
    }

    public String getSendExceptionCount() {
        return sendExceptionCount;
    }

    public void setSendExceptionCount(String sendExceptionCount) {
        this.sendExceptionCount = sendExceptionCount;
    }

    public String getSendExceptionPercent() {
        return sendExceptionPercent;
    }

    public void setSendExceptionPercent(String sendExceptionPercent) {
        this.sendExceptionPercent = sendExceptionPercent;
    }
}
