package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

@Alias("InnerRecord")
public class ExchangeInnerRecordEntity {
    private String transmitOrgCode;
    private String transmitOrgName;
    private String exchangeSerial;
    private String receiverCount;
    private String updateTime;
    private String docSerial;
    private String purport;
    private String transmitType;
    private String adminName;
    private String orgUnitPhone;
    private String orgUnitFax;
    private String adminEmail;
    private String contactInfo;

    public String getTransmitOrgCode() {
        return transmitOrgCode;
    }

    public void setTransmitOrgCode(String transmitOrgCode) {
        this.transmitOrgCode = transmitOrgCode;
    }

    public String getTransmitOrgName() {
        return transmitOrgName;
    }

    public void setTransmitOrgName(String transmitOrgName) {
        this.transmitOrgName = transmitOrgName;
    }

    public String getExchangeSerial() {
        return exchangeSerial;
    }

    public void setExchangeSerial(String exchangeSerial) {
        this.exchangeSerial = exchangeSerial;
    }

    public String getReceiverCount() {
        return receiverCount;
    }

    public void setReceiverCount(String receiverCount) {
        this.receiverCount = receiverCount;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getDocSerial() {
        return docSerial;
    }

    public void setDocSerial(String docSerial) {
        this.docSerial = docSerial;
    }

    public String getPurport() {
        return purport;
    }

    public void setPurport(String purport) {
        this.purport = purport;
    }

    public String getTransmitType() {
        return transmitType;
    }

    public void setTransmitType(String transmitType) {
        this.transmitType = transmitType;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getOrgUnitPhone() {
        return orgUnitPhone;
    }

    public void setOrgUnitPhone(String orgUnitPhone) {
        this.orgUnitPhone = orgUnitPhone;
    }

    public String getOrgUnitFax() {
        return orgUnitFax;
    }

    public void setOrgUnitFax(String orgUnitFax) {
        this.orgUnitFax = orgUnitFax;
    }

    public String getAdminEmail() {
        return adminEmail;
    }

    public void setAdminEmail(String adminEmail) {
        this.adminEmail = adminEmail;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }
}
