package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by kshsu on 2016/7/29.
 * 發文清單 rptsendlist
 */
@Alias("ReportSendList")
public class ReportSendListResult extends ReportResult {
    public enum ColmunEnum {
        title("發文清單"),
        rowIndex("序號"),
        clientInsertTime("發文日期"),
        applicationId("文號"),
        senderName("發文單位"),
        subject("主旨"),
        receiverName("受文單位"),
        status("狀態"),
        otherFile("附件");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 序號
     */
    private int rowIndex;
    /**
     * 發文日期
     */
    private String clientInsertTime;
    /**
     * 文號
     */
    private String applicationId;
    /**
     * 發文單位
     */
    private String senderName;
    /**
     * 主旨
     */
    private String subject;
    /**
     * 受文單位
     */
    private String receiverName;
    /**
     * 狀態
     */
    private String status;
    /**
     * 附件
     */
    private String otherFile;

    public int getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getClientInsertTime() {
        return clientInsertTime;
    }

    public void setClientInsertTime(String clientInsertTime) {
        this.clientInsertTime = clientInsertTime;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOtherFile() {
        return otherFile;
    }

    public void setOtherFile(String otherFile) {
        this.otherFile = otherFile;
    }
}
