package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

@Alias("TransmitDetail")
public class TransmitDetailEntity {
    private String exchangeType;
    private String processSerial;
    private String receiverOrgName;
    private String receiverOrgCode;
    private String receiverUnitCode;
    private String sendDocDateTime;
    private String systemAffirmDateTime;
    private String userAffirmDateTime;
    private Integer msgCode;
    private String messageStatus;
    private String messageInfo;

    public String getExchangeType() {
        return exchangeType;
    }

    public void setExchangeType(String exchangeType) {
        this.exchangeType = exchangeType;
    }

    public String getProcessSerial() {
        return processSerial;
    }

    public void setProcessSerial(String processSerial) {
        this.processSerial = processSerial;
    }

    public String getReceiverOrgName() {
        return receiverOrgName;
    }

    public void setReceiverOrgName(String receiverOrgName) {
        this.receiverOrgName = receiverOrgName;
    }

    public String getReceiverOrgCode() {
        return receiverOrgCode;
    }

    public void setReceiverOrgCode(String receiverOrgCode) {
        this.receiverOrgCode = receiverOrgCode;
    }

    public String getReceiverUnitCode() {
        return receiverUnitCode;
    }

    public void setReceiverUnitCode(String receiverUnitCode) {
        this.receiverUnitCode = receiverUnitCode;
    }

    public String getSendDocDateTime() {
        return sendDocDateTime;
    }

    public void setSendDocDateTime(String sendDocDateTime) {
        this.sendDocDateTime = sendDocDateTime;
    }

    public String getSystemAffirmDateTime() {
        return systemAffirmDateTime;
    }

    public void setSystemAffirmDateTime(String systemAffirmDateTime) {
        this.systemAffirmDateTime = systemAffirmDateTime;
    }

    public String getUserAffirmDateTime() {
        return userAffirmDateTime;
    }

    public void setUserAffirmDateTime(String userAffirmDateTime) {
        this.userAffirmDateTime = userAffirmDateTime;
    }

    public Integer getMsgCode() {
        return msgCode;
    }

    public void setMsgCode(Integer msgCode) {
        this.msgCode = msgCode;
    }

    public String getMessageStatus() {
        return messageStatus;
    }

    public void setMessageStatus(String messageStatus) {
        this.messageStatus = messageStatus;
    }

    public String getMessageInfo() {
        return messageInfo;
    }

    public void setMessageInfo(String messageInfo) {
        this.messageInfo = messageInfo;
    }
}
