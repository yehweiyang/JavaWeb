package gov.archives.exchange.domain.entity;

import org.apache.ibatis.type.Alias;

/**
 * Created by jslee on 2016/7/5. 中心異常排行
 */
@Alias("ReportErrRank")
public class ReportErrRankResult {
    public enum ColmunEnum {
        title("中心異常排行"),
        rowIndex("排名"),
        senderId("機關代碼"),
        senderName("機關名稱"),
        sysRejectCount("系統退文量"),
        userRejectCount("使用者退文量"),
        sendExceptionCount("發文異常量");

        private final String value;

        private ColmunEnum(String s) {
            value = s;
        }

        public boolean equalsName(String otherName) {
            return null != otherName && value.equals(otherName);
        }

        public String getTWName() {
            return this.value;
        }

        public String toString() {
            return this.name();
        }
    }

    /**
     * 排名
     */
    private String rowIndex;

    /**
     * 機關代碼
     */
    private String senderId;

    /**
     * 系統退文量
     */
    private int sysRejectCount;
    /**
     * 使用者退文量
     */
    private int userRejectCount;
    /**
     * 發文異常量
     */
    private int sendExceptionCount;
    /**
     * 機關名稱
     */
    private String senderName;

    public String getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(String rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public int getSysRejectCount() {
        return sysRejectCount;
    }

    public void setSysRejectCount(int sysRejectCount) {
        this.sysRejectCount = sysRejectCount;
    }

    public int getUserRejectCount() {
        return userRejectCount;
    }

    public void setUserRejectCount(int userRejectCount) {
        this.userRejectCount = userRejectCount;
    }

    public int getSendExceptionCount() {
        return sendExceptionCount;
    }

    public void setSendExceptionCount(int sendExceptionCount) {
        this.sendExceptionCount = sendExceptionCount;
    }
}
