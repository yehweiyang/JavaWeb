package gov.archives.exchange.controller;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletContext;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.ServletContextAware;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.entity.ReportErrRankResult;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.exception.ReportException;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/8/17.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + ReportConf.REPORT_TOOL_PATH + "/rptErrRk")
public class ReportErrRankController extends ReportBaseController implements ServletContextAware {

    private static final String REPORT_ERROR_RANK = ReportEnum.REPORT_ERR_RANK.toString();

    private ServletContext servletContext;

    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @RequestMapping(value = ReportConf.LIST_PATH,
            method = RequestMethod.GET)
    public List<ReportErrRankResult> queryReportErrRanks(
            @RequestParam
                    Map<String, Object> requestParams) {

        ReportBaseFilter errRankFilter = super.convertMapToReportFilter(requestParams);

        List<ReportErrRankResult> errRankResults = reportDataGenService.getReportErrRankByFilter(errRankFilter);
        try {
            String fileName =
                    new SimpleDateFormat(CoreConf.DATE_FORMAT).format(new Date())
                            + "_(" + errRankFilter.getDateFrom() + "_" + errRankFilter.getDateTo() + ")";

            reportDataGenService
                    .saveSearchResult(
                            getHistoryPath(fileName),
                            errRankFilter,
                            errRankResults);

            reportDataGenService
                    .saveSearchResult(
                            getTmpFileFullPath(REPORT_ERROR_RANK),
                            errRankFilter,
                            errRankResults);
        } catch (Exception e) {
            ReportUtils.logException(e);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR);
        }
        return errRankResults;
    }

    /**
     * 取得所有查詢暫存檔清單
     */
    @RequestMapping(value = "/history",
            method = RequestMethod.GET)
    public List<String> queryReportErrRankHistoryList() {
        List<String> rptErrRkHistory = new ArrayList<>();
        try {
            String testPath = getHistoryPath();
            Files.walk(Paths.get(testPath)).forEach(fileName -> {
                if (Files.isRegularFile(fileName)) {
                    rptErrRkHistory.add(fileName.toFile().getName().replace(".json", ""));
                }
            });
        } catch (Exception e) {
            ReportUtils.logException(e);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR);
        }
        return rptErrRkHistory;
    }

    /**
     * 重現暫存檔內容
     */
    @RequestMapping(value = "/history/{reportCode}")
    public Map<String, Object> restoreReportErrRankHistory(@PathVariable String reportCode) {
        Map<String, Object> restoreMap = new HashMap<>();
        try {
            Map<String, Object> clazzMap = reportDataPrepareService.getReportFilterAndResultClass(REPORT_ERROR_RANK);

            restoreMap = reportDataGenService
                    .restoreSearchResult(
                            getHistoryPath(reportCode),
                            (Class<?>) clazzMap.get("filterClass"),
                            (Class<?>) clazzMap.get("resultClass"));

            reportDataGenService
                    .saveSearchResult(
                            getTmpFileFullPath(REPORT_ERROR_RANK),
                            restoreMap.get("filterContent"),
                            restoreMap.get("resultContent"));
        } catch (Exception e) {
            ReportUtils.logException(e);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR);
        }
        return restoreMap;
    }

    private String getHistoryPath() {
        String realFilePath =
                servletContext.getRealPath("") +
                        ReportConf.WEB_INFO +
                        ReportConf.REPORT_ROOT +
                        "/" + REPORT_ERROR_RANK +
                        "/history";
        try {
            ReportUtils.initReportFolder(realFilePath);
        } catch (ReportException e) {
            ReportUtils.logException(e);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.SYSTEM_ERROR);
        }
        return realFilePath;
    }

    private String getHistoryPath(String fileName) {
        return getHistoryPath() + "/" + fileName + CoreConf.SUFFIX_JSON;
    }

}
