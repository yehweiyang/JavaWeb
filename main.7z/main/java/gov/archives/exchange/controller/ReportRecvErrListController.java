package gov.archives.exchange.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.entity.ReportRecvErrListResult;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportRecvErrListFilter;
import gov.archives.core.exception.ArchivesException;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/8/17.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + ReportConf.REPORT_TOOL_PATH + "/rptRecvErrList")
public class ReportRecvErrListController extends ReportBaseController {

    private static final String REPORT_RECEIVE_ERR_LIST = ReportEnum.REPORT_RECEIVE_ERR_LIST.toString();

    @RequestMapping(value = ReportConf.LIST_PATH,
            method = RequestMethod.GET)
    public List<ReportRecvErrListResult> queryRecvErrList(
            @RequestParam
                    Map<String, Object> requestParams) {
        try {
            ReportRecvErrListFilter recvErrListFilter = convertMapToReportFilter(requestParams);

            List<ReportRecvErrListResult> recvErrListFilters =
                    reportDataGenService.getReportRecvErrListByRecvErrListFilter(recvErrListFilter);
            reportDataGenService
                    .saveSearchResult(
                            getTmpFileFullPath(REPORT_RECEIVE_ERR_LIST),
                            recvErrListFilter,
                            recvErrListFilters);
            return recvErrListFilters;
        } catch (Exception e) {
            ReportUtils.logException(e);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR);
        }

    }

    @Override
    protected ReportRecvErrListFilter convertMapToReportFilter(Map<String, Object> params) {
        ReportRecvErrListFilter recvErrListFilter =
                (ReportRecvErrListFilter) super.convertMapToReportFilter(params, new ReportRecvErrListFilter());
        if (MapUtils.isNotEmpty(params)) {
            recvErrListFilter.setTimeFrom(MapUtils.getString(params, "timeFrom"));
            recvErrListFilter.setTimeTo(MapUtils.getString(params, "timeTo"));
            recvErrListFilter.setReceiverId(MapUtils.getString(params, "receiverId"));
            recvErrListFilter.setReceiverName(MapUtils.getString(params, "receiverName"));
            recvErrListFilter.setContentFullCmp(MapUtils.getBoolean(params, "contentFullCmp"));
        }

        return recvErrListFilter;
    }

}
