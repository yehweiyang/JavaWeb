package gov.archives.exchange.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.entity.ReportConFirmedDataResult;
import gov.archives.exchange.domain.vo.ReportConFirmedDataFilter;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.core.exception.ArchivesException;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/8/17.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + ReportConf.REPORT_TOOL_PATH + "/rptConfirmed")
public class ReportConFirmedDataController extends ReportBaseController {

    private static final String REPORT_CONFIRMED_QUERY = ReportEnum.REPORT_CONFIRMED_QUERY.toString();

    @RequestMapping(value = ReportConf.LIST_PATH,
            method = RequestMethod.GET)
    public List<ReportConFirmedDataResult> queryReportConFirmedDatas(
            @RequestParam
                    Map<String, Object> requestParams) {

        ReportConFirmedDataFilter conFirmedDataFilter = convertMapToReportFilter(requestParams);

        List<ReportConFirmedDataResult> conFirmedDataResults =
                reportDataGenService.getReportConFirmedDataResultByConFirmedDataFilter(conFirmedDataFilter);
        try {
            reportDataGenService
                    .saveSearchResult(
                            getTmpFileFullPath(REPORT_CONFIRMED_QUERY),
                            conFirmedDataFilter,
                            conFirmedDataResults);
        } catch (Exception e) {
            ReportUtils.logException(e);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR);
        }
        return conFirmedDataResults;
    }

    @Override
    protected ReportConFirmedDataFilter convertMapToReportFilter(Map<String, Object> params) {
        ReportConFirmedDataFilter conFirmedDataFilter =
                (ReportConFirmedDataFilter) super.convertMapToReportFilter(params, new ReportConFirmedDataFilter());
        if (MapUtils.isNotEmpty(params)) {
            conFirmedDataFilter.setGetewayId(MapUtils.getString(params, "getewayId"));
        }

        return conFirmedDataFilter;
    }

}
