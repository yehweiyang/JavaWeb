package gov.archives.exchange.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.ServletContextAware;

import org.iii.common.util.StringUtils;

import gov.archives.common.json.JsonUtils;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.service.ActionLogService;
import gov.archives.exchange.conf.ExchangeConf;
import gov.archives.exchange.domain.entity.vo.ExchangeAbnormalQueryVo;
import gov.archives.exchange.service.ExchangeAbnormalQueryService;
import gov.archives.xmldoc.domain.BaseDocument;
import gov.archives.xmldoc.processor.XmlDocumentReader;
import gov.archives.xmldoc.processor.XmlDocumentReaders;
import gov.archives.xmldoc.util.XMLUtils;

/**
 * ExchangeAbnormalQueryController
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + "/exchange")
public class ExchangeAbnormalQueryController implements ServletContextAware {

    private ActionLogEntity actionLogEntity;
    private XmlDocumentReader<BaseDocument> testReader;
    private static final Logger log = LoggerFactory.getLogger(ExchangeAbnormalQueryController.class);

    public static final String MODULE = "交換異常查詢模組";
    public static final String SUCCESSMESSAGE = "成功";
    //暫存檔案名稱
    public static final String TEMP_FILE_NAME = "account_error_query";
    @Autowired
    private ExchangeAbnormalQueryService queryService;
    @Autowired
    private ActionLogService actionLogService;

    private ServletContext servletContext;

    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @RequestMapping(value = "/exchangeAbnormalQuery",
            method = RequestMethod.GET)
    public List<ExchangeAbnormalQueryVo> queryAll(@RequestParam Map<String, String> requestParams
    ) {

        ExchangeAbnormalQueryVo changeErrorQueryVo = new ExchangeAbnormalQueryVo();
        changeErrorQueryVo.setSenderUnitName(MapUtils.getString(requestParams, "sendOrgName").trim());
        changeErrorQueryVo.setSenderOrgId(MapUtils.getString(requestParams, "sendOrganId").trim());
        changeErrorQueryVo.setReceiverUnitName(MapUtils.getString(requestParams, "receiverOrgName").trim());
        changeErrorQueryVo.setReceiverOrgId(MapUtils.getString(requestParams, "receiverOrgId").trim());
        changeErrorQueryVo.setProcessId(MapUtils.getString(requestParams, "processId").trim());
        changeErrorQueryVo.setExchangeId(MapUtils.getString(requestParams, "exchangeId").trim());
        changeErrorQueryVo.setStartNo(MapUtils.getString(requestParams, "startNo").trim());
        changeErrorQueryVo.setEndNo(MapUtils.getString(requestParams, "endNo").trim());
        changeErrorQueryVo.setDateFrom(MapUtils.getString(requestParams, "dateFrom"));
        changeErrorQueryVo.setTimeFrom(MapUtils.getString(requestParams, "timeFrom"));
        changeErrorQueryVo.setDateTo(MapUtils.getString(requestParams, "dateTo"));
        changeErrorQueryVo.setTimeTo(MapUtils.getString(requestParams, "timeTo"));
        changeErrorQueryVo.setIsCheck(MapUtils.getString(requestParams, "isCheck"));
        String eHub = MapUtils.getString(requestParams, "eHub");
        if (eHub != null) {
            changeErrorQueryVo.seteHub(MapUtils.getString(requestParams, "eHub"));
        } else {
            changeErrorQueryVo.seteHub("");
        }
        return queryService.getErrorQueryList(changeErrorQueryVo);
    }

    @RequestMapping(value = "/exchangeAbnormalQueryID",
            method = RequestMethod.GET)
    public ExchangeAbnormalQueryVo queryID(@RequestParam Map<String, String> requestParams) {
        ExchangeAbnormalQueryVo changeErrorQueryVo = new ExchangeAbnormalQueryVo();
        return queryService.getErrorQueryID(MapUtils.getString(requestParams, "processId"));
    }

    @RequestMapping(value = "/exchangeAbnormalQueryLog",
            method = RequestMethod.GET)
    public void queryLog(HttpServletRequest httpServletRequest) {
        try {
            writeActionLog(httpServletRequest, HttpStatus.OK.getReasonPhrase(), SUCCESSMESSAGE,
                    CoreConf.EVENT_LEVEL_LOW);
        } catch (ArchivesException e) {
            writeActionLog(httpServletRequest, e.getErrorCode(), e.getMessage(), CoreConf.EVENT_LEVEL_LOW);
            throw ArchivesException.getInstanceByErrorCode(e.getErrorCode());
        } catch (RuntimeException e) {
            writeActionLog(httpServletRequest, CoreErrorCode.SYSTEM_ERROR, e.getMessage(), CoreConf.EVENT_LEVEL_MEDIUM);
            throw new RuntimeException(e.getMessage());
        }
    }

    public File toGetFile() {
        File file = new File(servletContext.getRealPath(
                "/" + CoreConf.WEB_INFO + ExchangeConf.TEMP_CONTENT_NAME));
        return file;
    }

    public void createFile(String data) throws IOException {


        File file = new File(this.toGetFile(), TEMP_FILE_NAME + CoreConf.SUFFIX_JSON);
        File file_createDir = new File(this.toGetFile().getAbsolutePath());
        if (!file_createDir.exists()) {
            file_createDir.mkdirs();
        }
        FileWriter fw = new FileWriter(file);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(data);
        bw.close();
    }

    @RequestMapping(value = "/exchangeAbnormalQueryWriteTemp",
            method = RequestMethod.GET)
    public void writeFile(@RequestParam Map<String, String> query_value) {

        try {
            for (String abc : query_value.keySet()) {
                this.createFile(query_value.get(abc));
            }
        } catch (IOException ex) {
            log.error(StringUtils.stackTraceFromException(ex));
        }
    }

    @RequestMapping(value = "/exchangeAbnormalQueryReadTemp",
            method = RequestMethod.GET)
    public Object readFileJs() {
        File file = this.toGetFile();
        File file_name = new File(servletContext.getRealPath(
                "/" + CoreConf.WEB_INFO + ExchangeConf.TEMP_CONTENT_NAME + "/" + TEMP_FILE_NAME +
                        CoreConf.SUFFIX_JSON));
        if (file.exists() && file_name.exists()) {
            return JsonUtils
                    .getJsonTreeByJsonText(readJson(file_name.getPath()));
        } else {
            return "";
        }

    }

    @RequestMapping(value = "/exchangeAbnormalQueryReadXML",
            method = RequestMethod.GET)
    public Object readXMLJs() {
        testReader = XmlDocumentReaders.getDocumentReaderByDocumentType(BaseDocument.class);
        ArrayList<String> ehub = new ArrayList<String>();
        File testFile = new File(
                servletContext.getRealPath(ExchangeConf.getServerConfigLocation() + CoreConf.ORIGIN_EHUB));
        if (testFile.exists()) {
            BaseDocument testDoc = testReader.readDocumentFromFile(testFile);
            java.util.List<org.dom4j.Node> nodes = XMLUtils.getNodesByPathLevel(testDoc.getContent(), "//eHub");

            nodes.stream().forEach(node -> {
                List<String> scope = XMLUtils.getValuesByTags(node, "id");
                int i = 0;
                ehub.add(scope.get(i));
                i++;
            });

            return ehub;
        } else {
            return "";
        }
    }


    public String readJson(String filename) {
        String result = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();
            while (line != null) {
                sb.append(line);
                line = br.readLine();
            }
            result = sb.toString();
        } catch (IOException e) {
            log.error(StringUtils.stackTraceFromException(e));
        }
        return result;
    }

    private void writeActionLog(HttpServletRequest httpServletRequest, String errorCode, String message,
            String eventLevel) {
        String currentUser = httpServletRequest.getRemoteUser();
        if (null == currentUser) { throw new RestApplicationException("Not logged in"); }
        long accessedTime = httpServletRequest.getSession().getLastAccessedTime();
        actionLogEntity = ActionLogEntity.Builder.create()
                                                 .setActionItem(MODULE)
                                                 .setActionResult(message)
                                                 .setErrorCode(errorCode)
                                                 .setEventLevel(eventLevel)
                                                 .setActorAccount(currentUser)
                                                 .setActionTime(new Timestamp(accessedTime))
                                                 .setRemoteIp(httpServletRequest.getRemoteAddr())
                                                 .build();
        actionLogEntity.initSave(currentUser);
        actionLogService.insert(actionLogEntity);
    }

}
