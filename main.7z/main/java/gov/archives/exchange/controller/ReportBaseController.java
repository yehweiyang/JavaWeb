package gov.archives.exchange.controller;

import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;

import gov.archives.core.service.UserInfoService;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.facade.ReportOutputFacade;
import gov.archives.exchange.service.ReportDataGenService;
import gov.archives.exchange.service.ReportDataPrepareService;

/**
 * Created by jslee on 2016/8/17.
 */
public class ReportBaseController {
    @Autowired
    protected ReportOutputFacade reportOutputFacade;

    @Autowired
    protected ReportDataGenService reportDataGenService;

    @Autowired
    protected ReportDataPrepareService reportDataPrepareService;

    @Autowired
    protected UserInfoService userInfoService;

    protected String tmpUserFilePath = "";

    protected String getTmpFileFullPath(String reportName) {
        return reportDataPrepareService.getTempFilePath(reportName, userInfoService.getCurrentAccount());
    }

    protected String getTmpFileFullPath(String reportName, String currentAccountName) {
        return reportDataPrepareService.getTempFilePath(reportName, currentAccountName);
    }

    protected ReportBaseFilter convertMapToReportFilter(Map<String, Object> params) {
        return convertMapToReportFilter(params, new ReportBaseFilter());
    }

    protected ReportBaseFilter convertMapToReportFilter(Map<String, Object> params, ReportBaseFilter baseFilter) {
        if (MapUtils.isNotEmpty(params)) {
            baseFilter.setDateFrom(MapUtils.getString(params, "dateFrom"));
            baseFilter.setDateTo(MapUtils.getString(params, "dateTo"));
            baseFilter.setSortColumnName(MapUtils.getString(params, "sortColumnName"));
            baseFilter.setSortDescending(MapUtils.getBoolean(params, "sortDescending"));
        }
        return baseFilter;
    }

}
