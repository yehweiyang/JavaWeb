package gov.archives.exchange.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.accessor.ClientLogAccessor;
import gov.archives.exchange.domain.entity.AccessorEntity;
import gov.archives.exchange.service.AgencyCertService;

/**
 * Created by wtjiang on 2016/8/29.
 */
@RestController
@RequestMapping(value = "/v1/changerecord/")
public class AgencyCertController {

    @Autowired
    private AgencyCertService accessorService;

    @Autowired
    private ClientLogAccessor clientLogAccessor;

    @RequestMapping(value = "certHash/{orgId}",
            method = RequestMethod.GET)
    public List<AccessorEntity> certHash(@PathVariable String orgId) {
        try {
            return accessorService.getCertHash(orgId);
        } catch (ArchivesException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.ORG_ID_INCORRECT);
        }
    }

    @RequestMapping(value = "searchLogFile",
            method = RequestMethod.POST)
    public List<String> logFile(@RequestParam("orgId") String orgId,
            @RequestParam("certHash") String certHash) {
        try {
            List<String> files = clientLogAccessor.getLocationAllFile(orgId, certHash);
            return clientLogAccessor.getLocationAllFile(orgId, certHash);
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.LOG_FILE_INEXISTENCE);
        }
    }

    @RequestMapping(value = "downLogFile",
            method = RequestMethod.GET)
    public void logFile(HttpServletResponse response, @RequestParam Map<String, String> requestParams) {
        try {
            if (MapUtils.isNotEmpty(requestParams)){
                String orgId = MapUtils.getString(requestParams,"orgId");
                String certHash = MapUtils.getString(requestParams,"certHash");
                String fileName = MapUtils.getString(requestParams,"fileName");

                InputStream inputStream = clientLogAccessor.getLocationFile(orgId, certHash, fileName);

                response.setContentType("application/octet-stream");
                response.setHeader("Content-Disposition","attachment; filename=" + fileName);
                IOUtils.copy(inputStream, response.getOutputStream());
                response.flushBuffer();
                inputStream.close();
            }
        } catch (Exception e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.LOG_FILE_ERROR);
        }
    }
}
