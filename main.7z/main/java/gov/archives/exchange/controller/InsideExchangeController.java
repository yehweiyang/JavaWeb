package gov.archives.exchange.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.controller.RestControllerBase;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.service.ActionLogService;
import gov.archives.exchange.domain.entity.ExchangeInnerRecordEntity;
import gov.archives.exchange.domain.entity.TransmitDetailEntity;
import gov.archives.exchange.message.ExchangeErrorCode;
import gov.archives.exchange.message.ExchangeErrorMessage;
import gov.archives.exchange.service.DetailInfoService;
import gov.archives.exchange.service.MainInfoService;

import static gov.archives.exchange.service.MainInfoService.*;
import static gov.archives.exchange.service.DetailInfoService.*;

@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + "/exchange")
public class InsideExchangeController extends RestControllerBase {
    private static final String MODULE_NAME = "內部傳送查詢模組";
    private static final String SEND_AGENCY_NAME_VO = "sendAgencyName";
    private static final String SEND_AGENCY_ID_VO = "sendAgencyId";
    private static final String START_DOC_ID_VO = "startDocId";
    private static final String END_DOC_ID_VO = "endDocId";
    private static final String START_DATE_TIME = "startUpDateTime";
    private static final String END_DATE_TIME = "endUpDateTime";
    private static final String REST_INSIDE_DETAIL_SUCCESS = "/inside/detail/: Success";
    private static final String REST_INSIDE_TRANSMIT_SUCCESS = "/inside/transmit: Success";

    @Autowired
    private MainInfoService mainInfoService;

    @Autowired
    private DetailInfoService detailInfoService;

    @Autowired
    private ActionLogService actionLogService;

    private List<ExchangeInnerRecordEntity> recordEntityList;

    public InsideExchangeController() {
        this.setModuleName(MODULE_NAME);
    }

    @RequestMapping(value = "/inside/detail/{exchangeSerial}",
                    method = RequestMethod.GET)
    public ResponseEntity<List<TransmitDetailEntity>> getInsideDetailInfoByMap(HttpServletRequest request,
            @PathVariable String exchangeSerial) {
        try {
            if (!validateFiled(exchangeSerial, CoreConf.ALPHANUMERIC_PATTERN)) {
                throw new ArchivesException(ExchangeErrorMessage.ED0016_ERROR_MESSAGE,
                        ExchangeErrorCode.ED0016_EXCHANGE_ID_FORMAT_INCORRECT);
            }
            Map<String, Object> params = new HashMap<>();
            params.put(EXCHANGE_SERIAL, exchangeSerial);
            params.put(EXCHANGE_TYPE, INNER_TYPE);
            List<TransmitDetailEntity> entityList = detailInfoService.getTransmitDetailByMap(params);
            actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                    HttpStatus.OK.getReasonPhrase(),
                    REST_INSIDE_DETAIL_SUCCESS,
                    CoreConf.EVENT_LEVEL_LOW));
            return new ResponseEntity<>(entityList, HttpStatus.OK);
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                            e.getErrorCode() != null ? e.getErrorCode() : UNDEFINE_ERROR_CODE,
                            e.getErrorMessage() != null ? e.getErrorMessage() : UNDEFINE_ERROR_MESSAGE,
                            CoreConf.EVENT_LEVEL_LOW));
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }

    @RequestMapping(value = "/inside/transmit",
                    method = RequestMethod.GET)
    public ResponseEntity<List<ExchangeInnerRecordEntity>> getInsideMainInfoByMap(HttpServletRequest request,
            @RequestParam Map<String, Object> innerSendData) {
        try {
            Object cacheData = innerSendData.get(CACHE_DATE);
            innerSendDataValidate(innerSendData);
            innerSendData.put(SENDER_TYPE_SCHEMA, INNER_TYPE);
            if ("false".equals(cacheData))
                recordEntityList = mainInfoService.getMainInfoByMap(innerSendData);
            else if ("true".equals(cacheData)) {
                if (null == recordEntityList)
                    recordEntityList = mainInfoService.getMainInfoByMap(innerSendData);
            }
            actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                    HttpStatus.OK.getReasonPhrase(),
                    REST_INSIDE_TRANSMIT_SUCCESS,
                    CoreConf.EVENT_LEVEL_LOW));
            return new ResponseEntity<>(recordEntityList, HttpStatus.OK);
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                            e.getErrorCode() != null ? e.getErrorCode() : UNDEFINE_ERROR_CODE,
                            e.getErrorMessage() != null ? e.getErrorMessage() : UNDEFINE_ERROR_MESSAGE,
                            CoreConf.EVENT_LEVEL_LOW));
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }

    private void innerSendDataValidate(Map<String, Object> params) {
        if (!validateFiled((String) params.get(SEND_AGENCY_ID_VO), CoreConf.ALPHANUMERIC_PATTERN)) {
            throw new ArchivesException(ExchangeErrorMessage.ED0006_ERROR_MESSAGE,
                    ExchangeErrorCode.ED0006_AGENCY_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(SEND_AGENCY_NAME_VO), CoreConf.ALPHANUMERIC_NLS_PATTERN)) {
            throw new ArchivesException(ExchangeErrorMessage.ED0014_ERROR_MESSAGE,
                    ExchangeErrorCode.ED0014_AGENCY_NAME_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(EXCHANGE_SERIAL), CoreConf.ALPHANUMERIC_PATTERN)) {
            throw new ArchivesException(ExchangeErrorMessage.ED0016_ERROR_MESSAGE,
                    ExchangeErrorCode.ED0016_EXCHANGE_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(START_DOC_ID_VO), CoreConf.DIGIT_PATTERN)) {
            throw new ArchivesException(ExchangeErrorMessage.ED0015_ERROR_MESSAGE,
                    ExchangeErrorCode.ED0015_DOC_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(END_DOC_ID_VO), CoreConf.DIGIT_PATTERN)) {
            throw new ArchivesException(ExchangeErrorMessage.ED0015_ERROR_MESSAGE,
                    ExchangeErrorCode.ED0015_DOC_ID_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(START_DATE_TIME), CoreConf.DATE_TIME_PATTERN)) {
            throw new ArchivesException(ExchangeErrorMessage.ED0017_ERROR_MESSAGE,
                    ExchangeErrorCode.ED0017_UPDATE_TIME_FORMAT_INCORRECT);
        }
        if (!validateFiled((String) params.get(END_DATE_TIME), CoreConf.DATE_TIME_PATTERN)) {
            throw new ArchivesException(ExchangeErrorMessage.ED0017_ERROR_MESSAGE,
                    ExchangeErrorCode.ED0017_UPDATE_TIME_FORMAT_INCORRECT);
        }
    }
}
