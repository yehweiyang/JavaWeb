package gov.archives.exchange.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.MapUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.entity.ReportReceiveStatisticResult;
import gov.archives.exchange.domain.entity.ReportSendStatisticResult;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportRSStateFilter;
import gov.archives.core.exception.ArchivesException;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/8/11.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + ReportConf.REPORT_TOOL_PATH)
public class ReportRSStateController extends ReportBaseController {

    private static final String REPORT_RECEIVE_STATISTIC = ReportEnum.REPORT_R_STATE_STATIC.toString();

    private static final String REPORT_SEND_STATISTIC = ReportEnum.REPORT_S_STATE_STATIC.toString();

    @RequestMapping(value = "/rptRss" + ReportConf.LIST_PATH,
            method = RequestMethod.GET)
    public List<ReportReceiveStatisticResult> getReceiveStatisticResults(
            @RequestParam Map<String, Object> requestParams) {

        tmpUserFilePath = getTmpFileFullPath(REPORT_RECEIVE_STATISTIC);

        ReportRSStateFilter rsStateFilter = convartMapToReportFilter(requestParams, "收文");

        List<ReportReceiveStatisticResult> receiveStatisticResults =
                reportDataGenService.getReportReceiveStatisticByRSStateFilter(rsStateFilter);

        try {
            reportDataGenService
                    .saveSearchResult(
                            tmpUserFilePath,
                            rsStateFilter,
                            receiveStatisticResults);
        } catch (Exception e) {
            ReportUtils.logException(e);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR);
        }
        return receiveStatisticResults;
    }

    @RequestMapping(value = "/rptSss" + ReportConf.LIST_PATH,
            method = RequestMethod.GET)
    public List<ReportSendStatisticResult> getSendStatisticResults(
            @RequestParam Map<String, Object> requestParams) {

        tmpUserFilePath = getTmpFileFullPath(REPORT_SEND_STATISTIC);

        ReportRSStateFilter rsStateFilter = convartMapToReportFilter(requestParams, "發文");

        List<ReportSendStatisticResult> sendStatisticResults =
                reportDataGenService.getReportSendStatisticByRSStateFilter(rsStateFilter);

        try {
            reportDataGenService
                    .saveSearchResult(
                            tmpUserFilePath,
                            rsStateFilter,
                            sendStatisticResults);
        } catch (Exception e) {
            ReportUtils.logException(e);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_QUERY_ERROR);
        }
        return sendStatisticResults;
    }

    @RequestMapping(value = "/rptRSState/last",
            method = RequestMethod.GET)
    public void getLastModifiedReportName(HttpServletRequest request, HttpServletResponse response) {
        try {
            response.sendRedirect(request.getContextPath() +
                    CoreConf.REST_API_VERSION +
                    ReportConf.REPORT_TOOL_PATH +
                    "/" + reportDataPrepareService
                    .getLastReportOperation(
                            userInfoService.getCurrentAccount(),
                            REPORT_RECEIVE_STATISTIC,
                            REPORT_SEND_STATISTIC) +
                    ReportConf.INIT_PATH);
        } catch (IOException e) {
            ReportUtils.logException(e);
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.REPORT_INIT_ERROR);
        }
    }

    private ReportRSStateFilter convartMapToReportFilter(Map<String, Object> params, String rsStateType) {
        ReportRSStateFilter rsStateFilter =
                (ReportRSStateFilter) super.convertMapToReportFilter(params, new ReportRSStateFilter());

        if (MapUtils.isNotEmpty(params)) {
            rsStateFilter.setTimeFrom(MapUtils.getString(params, "timeFrom"));
            rsStateFilter.setTimeTo(MapUtils.getString(params, "timeTo"));
            rsStateFilter.setOrgId(MapUtils.getString(params, "orgId"));
            rsStateFilter.setOrgName(MapUtils.getString(params, "orgName"));
            rsStateFilter.setContentFullCmp(MapUtils.getBoolean(params, "contentFullCmp"));
            rsStateFilter.setQueryTarget(StringUtils.isEmpty(rsStateType) ? "" : rsStateType);
        }

        return rsStateFilter;
    }
}
