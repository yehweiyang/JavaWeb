package gov.archives.exchange.controller;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;

/**
 * HelpCenterController
 * <p>
 * Created by WeiYang on 2016/9/20.
 */
@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + "/exchange")
public class HelpCenterController {

    Logger log = Logger.getLogger(HelpCenterController.class);

    @RequestMapping(value = "/init",
            method = RequestMethod.GET)
    public void init() {
        log.info("-----");
        log.info("55555555555");
        log.info("-----");
    }
}
