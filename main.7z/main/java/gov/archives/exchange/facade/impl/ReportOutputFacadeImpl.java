package gov.archives.exchange.facade.impl;


import java.util.Locale;

import net.sf.jasperreports.engine.JRParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import gov.archives.core.exception.RestApplicationException;
import gov.archives.exchange.command.OdsToByteArrayCommand;
import gov.archives.exchange.command.OdsToFileCommand;
import gov.archives.exchange.command.OdsToStreamCommand;
import gov.archives.exchange.command.PdfToByteArrayCommand;
import gov.archives.exchange.command.PdfToFileCommand;
import gov.archives.exchange.command.PdfToStreamCommand;
import gov.archives.exchange.command.ReportCommandProcessor;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.facade.ReportOutputFacade;
import gov.archives.exchange.service.ReportCommandService;

/**
 * Created by kshsu on 2016/7/26.
 */
@Service
public class ReportOutputFacadeImpl implements ReportOutputFacade {

    @Autowired
    ApplicationContext appContext;

    @Override
    public void genReportToFile(ReportInputModel reportInputModel) throws RestApplicationException {

        ReportCommandService reportCommandService =
                (ReportCommandService) appContext.getBean(reportInputModel.getReportType() + "CommandService");

        isIgnorePagination(reportInputModel);

        if (ReportConf.PDF.equals(reportInputModel.getReportType().toUpperCase(Locale.ENGLISH))) {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_FILE, new PdfToFileCommand(reportInputModel));
        } else {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_FILE, new OdsToFileCommand(reportInputModel));
        }

        reportCommandService.doProcess(ReportCommandProcessor.TO_FILE);
    }

    @Override
    public void genReportToStream(ReportInputModel reportInputModel) throws RestApplicationException {

        ReportCommandService reportCommandService =
                (ReportCommandService) appContext.getBean(reportInputModel.getReportType() + "CommandService");

        isIgnorePagination(reportInputModel);

        if (ReportConf.PDF.equals(reportInputModel.getReportType().toUpperCase(Locale.ENGLISH))) {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_STREAM, new PdfToStreamCommand(reportInputModel));
        } else {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_STREAM, new OdsToStreamCommand(reportInputModel));
        }

        reportCommandService.doProcess(ReportCommandProcessor.TO_STREAM);
    }

    @Override
    public void genReportToByteArray(ReportInputModel reportInputModel) throws RestApplicationException {

        ReportCommandService reportCommandService =
                (ReportCommandService) appContext.getBean(reportInputModel.getReportType() + "CommandService");

        isIgnorePagination(reportInputModel);

        if (ReportConf.PDF.equals(reportInputModel.getReportType().toUpperCase(Locale.ENGLISH))) {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_BYTE_ARRAY, new PdfToByteArrayCommand(reportInputModel));
        } else {
            reportCommandService.addCommand(
                    ReportCommandProcessor.TO_BYTE_ARRAY, new OdsToByteArrayCommand(reportInputModel));
        }

        reportCommandService.doProcess(ReportCommandProcessor.TO_BYTE_ARRAY);
    }

    /**
     * 設定 輸出檔案是否要分頁數
     */
    private void isIgnorePagination(ReportInputModel reportInputModel) {
        boolean isIgnorePagination;

        if (ReportConf.PDF.equals(reportInputModel.getReportType().toUpperCase(Locale.ENGLISH))) {
            isIgnorePagination = false;
        } else if (ReportConf.ODS.equals(reportInputModel.getReportType().toUpperCase(Locale.ENGLISH))) {
            isIgnorePagination = true;
        } else {
            isIgnorePagination = false;
        }

        reportInputModel.getReportParameter().put(JRParameter.IS_IGNORE_PAGINATION, isIgnorePagination);
    }
}
