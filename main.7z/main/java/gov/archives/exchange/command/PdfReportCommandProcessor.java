package gov.archives.exchange.command;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperRunManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.exception.ErrorCode;
import gov.archives.exchange.exception.ReportException;

/**
 * Created by kshsu on 2016/7/26.
 */
public class PdfReportCommandProcessor extends ReportBaseCommand implements ReportCommandProcessor {
    private static final Logger log = LoggerFactory.getLogger(PdfReportCommandProcessor.class);

    @Override
    public void genReportToFile(ReportInputModel reportInputModel) throws ReportException {
        JasperPrint jasperPrint;
        try {
            jasperPrint = reportConvertTo(
                    getJasperReportFromFileName(reportInputModel.getSourceFileName()),
                    reportInputModel.getReportParameter(),
                    getJRTableDateSourceFromJavaBean(reportInputModel.getJavaBean())
            );
            JasperExportManager.exportReportToPdfFile(jasperPrint, reportInputModel.getDestFileName());
        } catch (Exception ex) {
            throw new ReportException(ex, ErrorCode.EXCEPTION_IN_REPORT_COMMAND_PROCESSOR);
        }
    }

    @Override
    public void genReportToStream(ReportInputModel reportInputModel) throws ReportException {
        JasperPrint jasperPrint;
        try {
            jasperPrint = reportConvertTo(
                    getJasperReportFromFileName(reportInputModel.getSourceFileName()),
                    reportInputModel.getReportParameter(),
                    getJRTableDateSourceFromJavaBean(reportInputModel.getJavaBean())
            );
            JasperExportManager.exportReportToPdfStream(jasperPrint, reportInputModel.getOs());
        } catch (Exception ex) {
            throw new ReportException(ex, ErrorCode.EXCEPTION_IN_REPORT_COMMAND_PROCESSOR);
        }
    }

    @Override
    public void genReportToByteArray(ReportInputModel reportInputModel) throws ReportException {
        try {
            reportInputModel.setOutput(
                    JasperRunManager.runReportToPdf(
                            getJasperReportFromFileName(reportInputModel.getSourceFileName()),
                            reportInputModel.getReportParameter(),
                            getJRTableDateSourceFromJavaBean(reportInputModel.getJavaBean())
                    )
            );
        } catch (Exception ex) {
            throw new ReportException(ex, ErrorCode.EXCEPTION_IN_REPORT_COMMAND_PROCESSOR);
        }
    }
}
