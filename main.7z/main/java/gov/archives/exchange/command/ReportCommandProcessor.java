package gov.archives.exchange.command;

import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.exception.ReportException;

/**
 * Created by kshsu on 2016/7/26.
 */
public interface ReportCommandProcessor {
    String TO_FILE = "toFile";
    String TO_STREAM = "toStream";
    String TO_BYTE_ARRAY = "toByteArray";

    void genReportToFile(ReportInputModel reportInputModel) throws ReportException;

    void genReportToStream(ReportInputModel reportInputModel) throws ReportException;

    void genReportToByteArray(ReportInputModel reportInputModel) throws ReportException;
}
