package gov.archives.exchange.command;

import gov.archives.exchange.domain.vo.ReportInputModel;
import gov.archives.exchange.exception.ReportException;

/**
 * Created by kshsu on 2016/7/26.
 */
public class PdfToByteArrayCommand extends ReportBaseCommand implements ReportCommand {

    private PdfToByteArrayCommand() {}

    public PdfToByteArrayCommand(ReportInputModel reportInputModel) {
        this.sourceFilePath = reportInputModel.getSourceFileName();
        this.javaBean = reportInputModel.getJavaBean();
        this.reportParameter = reportInputModel.getReportParameter();
        this.reportType = reportInputModel.getReportType();
        this.baseReportInputModel = reportInputModel;
    }

    @Override
    public void execute(ReportCommandProcessor reportCommandProcessor) throws ReportException {
        reportCommandProcessor.genReportToByteArray(baseReportInputModel);
    }
}
