package gov.archives.exchange.command;

import gov.archives.exchange.exception.ReportException;

/**
 * Created by kshsu on 2016/7/26.
 */
public interface ReportCommand {
    void execute(ReportCommandProcessor reportCommandProcessor) throws ReportException;
}
