package gov.archives.exchange.accessor;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import org.iii.common.util.IOUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.exchange.conf.ExchangeConf;

/**
 * ClientLogAccessor <br> (尚未描述類別目的與用途) <br> gemhuang, 2016/9/1.
 */
@Service
public class ClientLogAccessor {

    public List<String> getLocationAllFile(String orgId, String certHash) throws IOException {
        String path = ExchangeConf.getClientLogLocation() + orgId + "/" + certHash + "/";
        if (!IOUtils.isFolderExist(path)) {
            new File(path).mkdirs();
        }
        List<String> prepareLocationFileNames = new ArrayList<>();
        Files.walk(Paths.get(path)).forEach(currentFile -> {
            if (Files.isRegularFile(currentFile)) {
                prepareLocationFileNames.add(currentFile.getFileName().toString());
            }
        });
        return prepareLocationFileNames;
    }

    public InputStream getLocationFile(String orgId, String certHash,String fileName){
        String filePath = ExchangeConf.getClientLogLocation() + orgId + "/" + certHash + "/" + fileName;
        File download = new File(filePath);
        try {
            InputStream inputStream = new BufferedInputStream(new FileInputStream(download));
            return inputStream;
        } catch (FileNotFoundException e) {
            throw ArchivesException.getInstanceByErrorCode(CoreErrorCode.LOG_FILE_ERROR);
        }
    }
}
