package gov.archives.exchange.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.iii.common.util.PreconditionUtils;

import gov.archives.core.exception.ArchivesException;
import gov.archives.exchange.domain.entity.ExchangeInnerRecordEntity;
import gov.archives.exchange.conf.ExchangeConf;
import gov.archives.exchange.domain.entity.MainInfoEntity;
import gov.archives.exchange.mapper.query.MainInfoQueryMapper;
import gov.archives.exchange.message.ExchangeErrorCode;
import gov.archives.exchange.message.ExchangeErrorMessage;
import gov.archives.exchange.service.MainInfoService;

/**
 * MainInfoServiceImpl <br> (尚未描述類別目的與用途) <br> gemhuang, 2016/8/16.
 */
@Service
@Transactional
public class MainInfoServiceImpl implements MainInfoService {

    @Autowired
    private MainInfoQueryMapper queryMapper;

    @Override
    @Transactional(value = ExchangeConf.QUERY_TX_MANAGER,
                   readOnly = true)
    public List<ExchangeInnerRecordEntity> getMainInfoByMap(Map<String, Object> params) {
        List<ExchangeInnerRecordEntity> transmitList = queryMapper.findByMap(params);
        if (null == transmitList || 0 == transmitList.size()) {
            throw new ArchivesException(ExchangeErrorMessage.AP0000_ERROR_MESSAGE,
                    ExchangeErrorCode.AP0000_DATA_NOT_FOUND);
        }
        Iterator<ExchangeInnerRecordEntity> iterator = transmitList.iterator();
        while (iterator.hasNext()) {
            ExchangeInnerRecordEntity entity = iterator.next();
            entity.setContactInfo(CONTACT_NAME + entity.getAdminName() +
                    CONTACT_PHONE + entity.getOrgUnitPhone() +
                    CONTACT_FAX + entity.getOrgUnitFax() +
                    CONTACT_EMAIL + entity.getAdminEmail());
        }
        return transmitList;
    }
}
