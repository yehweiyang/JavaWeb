package gov.archives.exchange.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.iii.common.util.StringUtils;

import gov.archives.exchange.domain.entity.ReportConFirmedDataResult;
import gov.archives.exchange.domain.entity.ReportErrRankResult;
import gov.archives.exchange.domain.entity.ReportReceiveStatisticResult;
import gov.archives.exchange.domain.entity.ReportRecvErrListResult;
import gov.archives.exchange.domain.entity.ReportRecvListResult;
import gov.archives.exchange.domain.entity.ReportRecvStateResult;
import gov.archives.exchange.domain.entity.ReportSendErrListResult;
import gov.archives.exchange.domain.entity.ReportSendErrResult;
import gov.archives.exchange.domain.entity.ReportSendListResult;
import gov.archives.exchange.domain.entity.ReportSendRankResult;
import gov.archives.exchange.domain.entity.ReportSendStateResult;
import gov.archives.exchange.domain.entity.ReportSendStatisticResult;
import gov.archives.exchange.domain.entity.ReportSendUnConfmResult;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportConFirmedDataFilter;
import gov.archives.exchange.domain.vo.ReportRSStateFilter;
import gov.archives.exchange.domain.vo.ReportRecvErrListFilter;
import gov.archives.exchange.domain.vo.ReportRecvListFilter;
import gov.archives.exchange.domain.vo.ReportSendErrFilter;
import gov.archives.exchange.domain.vo.ReportSendErrListFilter;
import gov.archives.exchange.domain.vo.ReportSendListFilter;
import gov.archives.exchange.domain.vo.ReportSendUnConfmFilter;
import gov.archives.exchange.exception.ReportException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.exchange.mapper.query.ReportDataQueryMapper;
import gov.archives.exchange.service.ReportDataGenService;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by jslee on 2016/7/5.
 */
@Service
public class ReportDataGenServiceImpl implements ReportDataGenService {
    private static final Logger log = LoggerFactory.getLogger(ReportDataGenServiceImpl.class);

    @Autowired
    private ReportDataQueryMapper reportQueryMapper;

    @Override
    public List<ReportSendRankResult> getReportSendRankByFilter(ReportBaseFilter reportBaseFilter) {
        return reportQueryMapper.findReportSendRankByFilter(reportBaseFilter);
    }

    @Override
    public List<ReportErrRankResult> getReportErrRankByFilter(ReportBaseFilter reportBaseFilter) {
        return reportQueryMapper.findReportErrRankByFilter(reportBaseFilter);
    }

    @Override
    public List<ReportReceiveStatisticResult> getReportReceiveStatisticByRSStateFilter(
            ReportRSStateFilter reportRSStateFilter) {
        return reportQueryMapper.findReportReceiveStatisticByRSStateFilter(reportRSStateFilter);
    }

    @Override
    public List<ReportSendStatisticResult> getReportSendStatisticByRSStateFilter(
            ReportRSStateFilter reportRSStateFilter) {
        return reportQueryMapper.findReportSendStatisticByRSStateFilter(reportRSStateFilter);
    }

    @Override
    public List<ReportSendErrResult> getReportSendErrBySendErrFilter(ReportSendErrFilter reportSendErrFilter) {
        return reportQueryMapper.findReportSendErrBySendErrFilter(reportSendErrFilter);
    }

    @Override
    public List<ReportSendStateResult> getReportSendStateByFilter(ReportBaseFilter reportBaseFilter) {
        return reportQueryMapper.findReportSendStateByFilter(reportBaseFilter);
    }

    @Override
    public List<ReportSendListResult> getReportSendListBySendListFilter(ReportSendListFilter reportSendListFilter) {
        return reportQueryMapper.findReportSendListBySendListFilter(reportSendListFilter);
    }

    @Override
    public List<ReportSendUnConfmResult> getReportSendUnConfmBySendUnConfomFilter(
            ReportSendUnConfmFilter reportSendUnConfmFilter) {
        return reportQueryMapper.findReportSendUnConfmBySendUnConfmFilter(reportSendUnConfmFilter);
    }

    @Override
    public List<ReportSendErrListResult> getReportSendErrListBySendErrListFilter(
            ReportSendErrListFilter reportSendErrListFilter) {
        return reportQueryMapper.findReportSendErrListBySendErrListFilter(reportSendErrListFilter);
    }

    @Override
    public List<ReportRecvStateResult> getReportRecvStateByFilter(ReportBaseFilter reportBaseFilter) {
        return reportQueryMapper.findReportRecvStateByFilter(reportBaseFilter);
    }

    @Override
    public List<ReportRecvListResult> getReportRecvListByRecvListFilter(ReportRecvListFilter reportRecvListFilter) {
        return reportQueryMapper.findReportRecvListByRecvListFilter(reportRecvListFilter);
    }

    @Override
    public List<ReportRecvErrListResult> getReportRecvErrListByRecvErrListFilter(
            ReportRecvErrListFilter reportRecvErrListFilter) {
        return reportQueryMapper.findReportRecvErrListByRecvErrListFilter(reportRecvErrListFilter);
    }

    @Override
    public List<ReportConFirmedDataResult> getReportConFirmedDataResultByConFirmedDataFilter(
            ReportConFirmedDataFilter reportConFirmedDataFilter) {
        return reportQueryMapper.findReportConFirmedByConFirmedDataFilter(reportConFirmedDataFilter);
    }


    @Override
    public void saveSearchResult(String fileName, Object filterBean, Object resultBean)
            throws RestApplicationException {
        try {
            String mergeFilterAndResult = "{" +
                    "\"filterContent\":" + ReportUtils.convertBeanToJsonNode(filterBean) + "," +
                    "\"resultContent\":" + ReportUtils.convertBeanToJsonNode(resultBean) +
                    "}";
            ReportUtils.saveAsJsonFile(fileName, mergeFilterAndResult);
        } catch (ReportException ex) {
            log.error("CAUSE: " + StringUtils.stackTraceFromException(ex));
            throw new RestApplicationException((null != ex.getMessage() ? ex.getMessage() : "no message"), ex);
        }
    }

    @Override
    public Map<String, Object> restoreSearchResult(String fileName, Class<?> filterClass, Class<?> resultClass)
            throws RestApplicationException {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            JsonNode originJson = new ObjectMapper().readTree(ReportUtils.readJsonFileAsString(fileName));

            resultMap.put("filterContent",
                    ReportUtils.convertJsonNodeStringToBean(originJson.get("filterContent").toString(), filterClass));
            resultMap.put("resultContent",
                    ReportUtils
                            .convertJsonNodeStringToBeanList(originJson.get("resultContent").toString(), resultClass));
        } catch (IOException | ReportException ex) {
            log.error("CAUSE: " + StringUtils.stackTraceFromException(ex));
            throw new RestApplicationException((null != ex.getMessage() ? ex.getMessage() : "no message"), ex);
        }
        return resultMap;
    }
}
