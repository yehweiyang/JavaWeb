package gov.archives.exchange.service.impl;

import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.archives.core.util.BeanUtils;
import gov.archives.exchange.domain.entity.ExchangeAbnormalQueryEntity;
import gov.archives.exchange.domain.entity.vo.ExchangeAbnormalQueryVo;
import gov.archives.exchange.mapper.query.ExchangeAbnormalQueryMapper;
import gov.archives.exchange.service.ExchangeAbnormalQueryService;

/**
 * ExchangeAbnormalQueryServiceImpl
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
@Service
@Transactional
public class ExchangeAbnormalQueryServiceImpl implements ExchangeAbnormalQueryService {
    Logger logger =Logger.getLogger("123");
    @Autowired
    ExchangeAbnormalQueryMapper mapper;

    @Override
    public List<ExchangeAbnormalQueryVo> getErrorQueryList(ExchangeAbnormalQueryVo changeErrorQueryVo) {

        List<ExchangeAbnormalQueryVo> resultQuery = new LinkedList<>();
        int i =0;
        for (ExchangeAbnormalQueryEntity entity:mapper.findAllQuery(changeErrorQueryVo)
                ) {
            ExchangeAbnormalQueryVo vo = new ExchangeAbnormalQueryVo();
            BeanUtils.copyProperties(vo, entity);

            resultQuery.add(i,vo);
            i++;

        }
        return resultQuery;
    }

    @Override
    public ExchangeAbnormalQueryVo getErrorQueryID(String ID) {
        ExchangeAbnormalQueryEntity entity =mapper.findIDQuery(ID);
        ExchangeAbnormalQueryVo vo = new ExchangeAbnormalQueryVo();
        BeanUtils.copyProperties(vo, entity);

        switch(vo.getExchangeType()) {
            case "INNER":
                vo.setExchangeType("內部系統");
                break;
            case "OUTTER":
                vo.setExchangeType("外部系統");
                break;
            case "eOldGW":
                vo.setExchangeType("舊系統");
                break;
            default:
        }
        return vo;
    }

}
