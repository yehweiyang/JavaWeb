package gov.archives.exchange.service.impl;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletContext;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.context.ServletContextAware;

import org.iii.common.util.PreconditionUtils;
import org.iii.common.util.StringUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.exchange.conf.ReportConf;
import gov.archives.exchange.domain.vo.ReportAdvancedFilter;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportEnum;
import gov.archives.exchange.domain.vo.ReportRSStateFilter;
import gov.archives.exchange.exception.ReportException;
import gov.archives.exchange.service.ReportDataPrepareService;
import gov.archives.exchange.util.ReportUtils;

/**
 * Created by kshsu on 2016/7/21.
 */
@Service
public class ReportDataPrepareServiceImpl implements ReportDataPrepareService, ServletContextAware {
    private static final Logger log = LoggerFactory.getLogger(ReportDataPrepareServiceImpl.class);

    private static final String DEFAULT_USER_NAME = "user";
    private static final String DEFAULT_HOUR_FROM = "00";
    private static final String DEFAULT_HOUR_TO = "23";
    private static final String DEFAULT_SORT_COLUMN = "rowIndex";
    private static final Boolean DEFAULT_CONTENT_FULL_CMP = false;
    private static final Boolean DEFAULT_SORT_DESCENDING = false;

    private String todayString;
    private String tmpFilePathAndFileName;

    private ServletContext servletContext;

    @Override
    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @Override
    public String getTempFilePath(String reportName) throws RestApplicationException {
        setTempFilePath(reportName, DEFAULT_USER_NAME);
        return tmpFilePathAndFileName;
    }

    @Override
    public String getTempFilePath(String reportName, String userIs) throws RestApplicationException {
        setTempFilePath(reportName, userIs);
        return tmpFilePathAndFileName;
    }

    @Override
    public String getLastReportOperation(String userAccount, String... reportNames) {
        String newerReportName = reportNames[0];
        for (String reportName : reportNames) {
            File newerReport = new File(getTempFilePath(newerReportName, userAccount));
            File eqlReport = new File(getTempFilePath(reportName, userAccount));
            if (newerReport.exists() && eqlReport.exists()) {
                newerReportName = FileUtils.isFileNewer(newerReport, eqlReport) ?
                        newerReportName : reportName;
            }
        }
        return newerReportName;
    }

    @Override
    public Map<String, Object> prepareReportData(String reportName) throws RestApplicationException {
        PreconditionUtils.checkArguments(reportName);

        Map<String, Object> initMap = new HashMap<>();

        todayString = ReportUtils.getTodayString(CoreConf.DATE_FORMAT);

        //PRN001, PRN002, PRN005, PRN009, PRN012
        if (ReportEnum.REPORT_SEND_RANK.equalsName(reportName) ||
                ReportEnum.REPORT_ERR_RANK.equalsName(reportName) ||
                ReportEnum.REPORT_SEND_STATE.equalsName(reportName) ||
                ReportEnum.REPORT_RECEIVE_STATE.equalsName(reportName) ||
                ReportEnum.REPORT_CONFIRMED_QUERY.equalsName(reportName)) {
            initMap.put("filterContent", prepareReportBaseFilter());

            //PRN003
        } else if (ReportEnum.REPORT_R_STATE_STATIC.equalsName(reportName) ||
                ReportEnum.REPORT_S_STATE_STATIC.equalsName(reportName)) {
            initMap.put("filterContent", prepareReportRSStateBaseFilter());

            //PRN004, PRN006, PRN007, PRN008, PRN010, PRN011
        } else if (ReportEnum.REPORT_SEND_ERR.equalsName(reportName) ||
                ReportEnum.REPORT_SEND_LIST.equalsName(reportName) ||
                ReportEnum.REPORT_SEND_UNCONFIRM.equalsName(reportName) ||
                ReportEnum.REPORT_SEND_ERR_LIST.equalsName(reportName) ||
                ReportEnum.REPORT_RECEIVE_LIST.equalsName(reportName) ||
                ReportEnum.REPORT_RECEIVE_ERR_LIST.equalsName(reportName)) {
            initMap.put("filterContent", prepareReportAdvancedFilter());
        } else {
            log.error(this.getClass().getName() + ":prepareReportData => non support report name" + reportName);
            throw new RestApplicationException(
                    this.getClass().getName() + ":prepareReportData => non support report name:" + reportName);
        }

        if (MapUtils.isNotEmpty(initMap)) {
            initAllReportFolder();
        }

        return initMap;
    }

    @Override
    public Map<String, Object> getReportFilterAndResultClass(String reportName) throws RestApplicationException {
        for (Enum reportEnum : ReportEnum.class.getEnumConstants()) {
            if (reportEnum.toString().equals(reportName)) {
                return ((ReportEnum) reportEnum).getFilterResultClassMap();
            }
        }
        log.error(this.getClass().getName() + ":getReportFilterAndResultClass => non support report name" + reportName);
        throw new RestApplicationException(
                this.getClass().getName() + ":getReportFilterAndResultClass => non support report name:" + reportName);
    }

    private void setTempFilePath(String reportName) throws RestApplicationException {
        tmpFilePathAndFileName = servletContext.getRealPath("") +
                ReportConf.WEB_INFO +
                ReportConf.REPORT_ROOT +
                "/" + reportName +
                ReportConf.USER_TEMP_FOLDER;
    }

    private void setTempFilePath(String reportName, String userCode) throws RestApplicationException {
        setTempFilePath(reportName);
        tmpFilePathAndFileName += "/" + userCode + CoreConf.SUFFIX_JSON;
    }

    private void initAllReportFolder() {
        Arrays.stream(ReportEnum.class.getEnumConstants()).forEach(reportEnum -> {
            setTempFilePath(reportEnum.toString());
            try {
                ReportUtils.initReportFolder(tmpFilePathAndFileName);
            } catch (ReportException e) {
                prepareServiceExceptionHandler(e);
            }
        });
    }

    private ReportBaseFilter prepareReportBaseFilter() throws RestApplicationException {
        return prepareReportBaseFilter(new ReportBaseFilter());
    }

    private ReportBaseFilter prepareReportBaseFilter(ReportBaseFilter reportBaseFilter) {
        try {
            // TODO: 缺少初始化月報表, 月報表應由 Service 產生, 且至 Controller 組裝
            reportBaseFilter.setDateFrom(todayString);
            reportBaseFilter.setDateTo(todayString);
            reportBaseFilter.setSortColumnName(DEFAULT_SORT_COLUMN);
            reportBaseFilter.setSortDescending(DEFAULT_SORT_DESCENDING);
        } catch (Exception ex) {
            prepareServiceExceptionHandler(ex);
        }
        return reportBaseFilter;
    }

    private ReportAdvancedFilter prepareReportAdvancedFilter()
            throws RestApplicationException {
        return prepareReportAdvancedFilter(new ReportAdvancedFilter());
    }

    private ReportAdvancedFilter prepareReportAdvancedFilter(ReportAdvancedFilter reportAdvancedFilter)
            throws RestApplicationException {
        try {
            reportAdvancedFilter = (ReportAdvancedFilter) prepareReportBaseFilter(reportAdvancedFilter);
            reportAdvancedFilter.setTimeFrom(DEFAULT_HOUR_FROM);
            reportAdvancedFilter.setTimeTo(DEFAULT_HOUR_TO);
            reportAdvancedFilter.setContentFullCmp(DEFAULT_CONTENT_FULL_CMP);
        } catch (Exception ex) {
            prepareServiceExceptionHandler(ex);
        }
        return reportAdvancedFilter;
    }

    private ReportRSStateFilter prepareReportRSStateBaseFilter() throws RestApplicationException {
        ReportRSStateFilter rsStateFilter = null;
        try {
            rsStateFilter = (ReportRSStateFilter) prepareReportAdvancedFilter(new ReportRSStateFilter());
            rsStateFilter.setQueryTarget("收文");
        } catch (Exception ex) {
            prepareServiceExceptionHandler(ex);
        }
        return rsStateFilter;
    }

    private void prepareServiceExceptionHandler(Throwable throwable) {
        log.error("CAUSE: " + StringUtils.stackTraceFromException(throwable));
        throw new RestApplicationException(
                (null != throwable.getMessage() ?
                        throwable.getMessage() : "no message"), throwable);
    }
}
