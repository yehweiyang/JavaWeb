package gov.archives.exchange.service;

import java.util.Map;

/**
 * Created by jslee on 2016/7/21.
 */
public interface ReportDataPrepareService {

    public Map<String, Object> prepareReportData(String reportName);

    public String getTempFilePath(String reportName);

    public Map<String, Object> getReportFilterAndResultClass(String reportName);

    public String getTempFilePath(String reportName, String userIs);

    public String getLastReportOperation(String userAccount, String... reportNames);
}
