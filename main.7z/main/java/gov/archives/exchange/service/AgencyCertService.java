package gov.archives.exchange.service;

import java.util.List;

import gov.archives.exchange.domain.entity.AccessorEntity;

/**
 * Created by wtjiang on 2016/8/26.
 */
public interface AgencyCertService {
    List<AccessorEntity> getCertHash(String orgId);
}
