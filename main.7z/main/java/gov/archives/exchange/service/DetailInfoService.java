package gov.archives.exchange.service;

import java.util.List;
import java.util.Map;

import gov.archives.exchange.domain.entity.TransmitDetailEntity;

public interface DetailInfoService {
    String EXCHANGE_TYPE = "exchangeType";
    String INNER_EXCHANGE_TYPE = "內部交換";
    String OUT_EXCHANGE_TYPE = "外部交換";
    String OLD_EXCHANGE_TYPE = "舊系統";
    String INNER_TYPE = "INNER";
    String OUT_TYPE = "OUTTER";
    String GOOD_MSG_CODE = "正常";
    String BAD_MSG_CODE = "異常";

    List<TransmitDetailEntity> getTransmitDetailByMap(Map<String, Object> params);

}
