package gov.archives.exchange.conf;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Properties;

import org.iii.common.util.IOUtils;

import gov.archives.core.exception.ArchivesException;

/**
 * ExchangeConf <br> exchange package 之共用設定 <br> gemhuang, 2016/8/16.
 */
public class ExchangeConf {
    public static final String QUERY_TX_MANAGER = "exchangeQueryTxManager";
    public static final String COMMAND_TX_MANAGER = "exchangeCommandTxManager";

    public static final String MANAGE_WEB_PROPERTIES = "manageWeb.properties";
    public static final String PROP_CLIENT_LOG = "client.log.location";
    public static final String PROP_SERVER_CONFIG = "server.config.location";
    public static final String TEMP_CONTENT_NAME = "/tempQuery";
    private static Path clientLogLocation;

    private static Properties prop;

    public static void initProperty() {
        if (null == prop) {
            try {
                prop = new Properties();
                prop.load(IOUtils.loadResourceInClasspath(MANAGE_WEB_PROPERTIES));
            } catch (IOException e) {
                throw ArchivesException.getInstanceByErrorCode("9999");
            }
        }
    }

    public static String getClientLogLocation() {
        if (null == prop) {
            initProperty();
        }
        return prop.getProperty(PROP_CLIENT_LOG);
    }

    public static String getServerConfigLocation() {
        if (null == prop) {
            initProperty();
        }
        return prop.getProperty(PROP_SERVER_CONFIG);
    }
}
