package gov.archives.exchange.conf;

/**
 * Created by jslee on 2016/7/25.
 */
public class ReportConf {

    public static final String REPORT_TEMPLATE_FOLDER = "reportTemplate";
    public static final String REPORT_TOOL_PATH = "/reportTool";
    public static final String LIST_PATH = "/list";
    public static final String INIT_PATH = "/init";
    public static final String DOWNLOAD_PATH = "/download";
    public static final String OVER_WRITE_PATH = "/overwrite";

    public static final String WEB_INFO = "/WEB-INF";
    public static final String REPORT_ROOT = "/report";
    public static final String USER_TEMP_FOLDER = "/tmp";

    public static final String PDF = "PDF";
    public static final String ODS = "ODS";
}
