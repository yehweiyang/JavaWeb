package gov.archives.exchange.mapper.query;

import java.util.List;

import gov.archives.exchange.domain.entity.ReportConFirmedDataResult;
import gov.archives.exchange.domain.entity.ReportErrRankResult;
import gov.archives.exchange.domain.entity.ReportReceiveStatisticResult;
import gov.archives.exchange.domain.entity.ReportRecvErrListResult;
import gov.archives.exchange.domain.entity.ReportRecvListResult;
import gov.archives.exchange.domain.entity.ReportRecvStateResult;
import gov.archives.exchange.domain.entity.ReportSendErrListResult;
import gov.archives.exchange.domain.entity.ReportSendErrResult;
import gov.archives.exchange.domain.entity.ReportSendListResult;
import gov.archives.exchange.domain.entity.ReportSendRankResult;
import gov.archives.exchange.domain.entity.ReportSendStateResult;
import gov.archives.exchange.domain.entity.ReportSendStatisticResult;
import gov.archives.exchange.domain.entity.ReportSendUnConfmResult;
import gov.archives.exchange.domain.vo.ReportConFirmedDataFilter;
import gov.archives.exchange.domain.vo.ReportBaseFilter;
import gov.archives.exchange.domain.vo.ReportRSStateFilter;
import gov.archives.exchange.domain.vo.ReportRecvErrListFilter;
import gov.archives.exchange.domain.vo.ReportRecvListFilter;
import gov.archives.exchange.domain.vo.ReportSendErrFilter;
import gov.archives.exchange.domain.vo.ReportSendErrListFilter;
import gov.archives.exchange.domain.vo.ReportSendListFilter;
import gov.archives.exchange.domain.vo.ReportSendUnConfmFilter;

/**
 * Created by jslee on 2016/7/5.
 */
public interface ReportDataQueryMapper {

    List<ReportSendRankResult> findReportSendRankByFilter(ReportBaseFilter filter);

    List<ReportErrRankResult> findReportErrRankByFilter(ReportBaseFilter filter);

    List<ReportReceiveStatisticResult> findReportReceiveStatisticByRSStateFilter(ReportRSStateFilter rsStateFilter);

    List<ReportSendStatisticResult> findReportSendStatisticByRSStateFilter(ReportRSStateFilter rsStateFilter);

    List<ReportSendErrResult> findReportSendErrBySendErrFilter(ReportSendErrFilter sendErrFilter);

    List<ReportSendStateResult> findReportSendStateByFilter(ReportBaseFilter filter);

    List<ReportSendListResult> findReportSendListBySendListFilter(ReportSendListFilter sendListFilter);

    List<ReportSendUnConfmResult> findReportSendUnConfmBySendUnConfmFilter(ReportSendUnConfmFilter sendUnConfmFilter);

    List<ReportSendErrListResult> findReportSendErrListBySendErrListFilter(ReportSendErrListFilter sendErrListFilter);

    List<ReportRecvStateResult> findReportRecvStateByFilter(ReportBaseFilter filter);

    List<ReportRecvListResult> findReportRecvListByRecvListFilter(ReportRecvListFilter recvListFilter);

    List<ReportRecvErrListResult> findReportRecvErrListByRecvErrListFilter(ReportRecvErrListFilter recvErrListFilter);

    List<ReportConFirmedDataResult> findReportConFirmedByConFirmedDataFilter(ReportConFirmedDataFilter conFirmedDataFilter);

}
