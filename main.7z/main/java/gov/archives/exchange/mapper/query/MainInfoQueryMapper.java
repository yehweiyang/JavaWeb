package gov.archives.exchange.mapper.query;

import java.util.List;
import java.util.Map;

import gov.archives.exchange.domain.entity.ExchangeInnerRecordEntity;
import gov.archives.exchange.domain.entity.MainInfoEntity;

/**
 * MainInfoQueryMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
public interface MainInfoQueryMapper {
	List<ExchangeInnerRecordEntity> findByMap(Map<String, Object> params);
}
