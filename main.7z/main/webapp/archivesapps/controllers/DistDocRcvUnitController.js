angular.module('ArchivesApp').controller('DistDocRcvUnitController',
        function($rootScope, $scope, $http, $timeout, $uibModal, pkiService) {

    $scope.receiverUnitList = [];
    $scope.isQueried = false;
    $scope.orgId = "";
    $scope.unitId = "";
    $scope.orgUnitName = "";
    $scope.exactMatch = false;
    $scope.cardStatus = false;
    $scope.slot = pkiService.querySlot();

    $rootScope.$on('slot:find', function() {
        $scope.cardStatus = true;
    });
    $rootScope.$on('slot:empty', function() {
        $scope.cardStatus = false;
    });

    $scope.queryDistReceiver = function() {
        var url = "/manageWeb/v1/DocumentSystem/listReceiverUnit";
        return $http.get(url, {
            params: {
                orgId: $scope.orgId,
                unitId: $scope.unitId,
                orgUnitName: $scope.orgUnitName,
                exactMatch: $scope.exactMatch
            }
        }).then(function(response) {
            $scope.receiverUnitList = response.data;
            $scope.isQueried = true;
        });
    }

    $scope.reset = function() {
        $scope.orgId = "";
        $scope.unitId = "";
        $scope.orgUnitName = "";
        $scope.exactMatch = false;
    };

    $scope.selected = {
        unit: $scope.receiverUnitList[0]
    };

    $scope.deleteConfirmModal = function() {
        $scope.uibModalInstance = $uibModal.open({
            templateUrl: 'modalConfirmDelete.html',
            scope: $scope,
            size: 'sm'
        });
    };

    $scope.modalDeleteUnit = function() {
        var url = "/manageWeb/v1/DocumentSystem/deleteReceiverUnit";
        $http.post(url, $scope.selected.unit).then(function successCallback(response) {
            var index = $scope.receiverUnitList.indexOf($scope.selected.unit);
            if(index>-1) {
                $scope.receiverUnitList.splice(index, 1);
                $scope.uibModalInstance.dismiss();
            } else {
                exceptionViewer(response, false);
            }
        }, function errorCallback(response) {
            exceptionViewer(response, false);
        });
    };

    $scope.modalCancel = function() {
        $scope.uibModalInstance.dismiss();
    };

    $scope.addReceiverUnit = function() {
        var queryTarget = "SET_RECEIVER";
        openUnitModal(queryTarget);
    };

    var openUnitModal = function(queryTarget, selected) {
        var uibModalInstance = $uibModal.open({
            templateUrl: "archivesapps/views/DocumentSystem/distDocUnitSelector.html",
            controller: "DistDocUnitSelectorController",
            size: 'lg',
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            $rootScope.settings.appPath + '/controllers/DistDocUnitSelectorController.js',
                        ]
                    });
                }],
                target: function() {
                    return queryTarget;
                },
                selected: function() {
                    return selected;
                }
            }
        });
        uibModalInstance.result.then($scope.queryDistReceiver);
    };
});