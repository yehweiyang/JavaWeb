angular.module('ArchivesApp').controller('EditAnnouncementController', function($rootScope, $scope, $http, pkiService, archivesConstant) {
    var restUrl = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH
                       	        + archivesConstant.TOP_MENU_SYSTEMTOOL + "/announce";
	$rootScope.$on('slot:find', function() {   
		$scope.slot = true;
		$scope.btDisabled = false;
    });
	$rootScope.$on('slot:empty', function() {   
		$scope.slot = false;
		$scope.btDisabled = true;
    });
    $scope.toggleModal = function(){
        $scope.showModal = false;
    };
    $scope.announceMessage = null;
    $scope.showAlertMessage = false;
	$rootScope.$on('sign:success', function() {
		$scope.btDisabled = false;
		var announcement = pkiService.getSignatureCert();
		announcement.announceMessage = $scope.announceMessage;
		
    	$http.post(restUrl, announcement)
		.then(function(response){
			$scope.slot = true;
		    $scope.message = archivesConstant.SAVE_SUCCESS_MSG;
            $scope.showModal = true;
		}, 
		function(errResponse) {
			$scope.alertMessage = errResponse.data.errorCode;
	        $scope.showAlertMessage = true;
		});			
    });
	$rootScope.$on('sign:failed', function() {
		$scope.btDisabled = false;
		// fixed not refresh UI
    	$http.get(restUrl)
		.then(function(errResponse) {},
		function(errResponse) {
			var resultCode = pkiService.getResultCode();
			if (resultCode.ret_code == 0x76000006) {
			} else if (resultCode.ret_code == 400) {
                $scope.alertMessage = archivesConstant.NO_INPUT;
			} else {
	            $scope.alertMessage = pkiService.getErrorReason();
	        }
	        $scope.slot = false;
            $scope.btDisabled = true;
	        $scope.showAlertMessage = true;
		});
    });

    $scope.initAnnounce = function() {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + archivesConstant.TOP_MENU_SYSTEMTOOL + "/read/announce";
        $http.get(url)
		.then(function(response) {
    		$scope.announceMessage = response.data.announceMessage;
		},
		function(errResponse) {
		    $scope.announceMessage = "";
		});
    }

	$scope.saveHtmlBt = function() {
	    if ($scope.announceMessage != null) {
	        $scope.showAlertMessage = false;
        	pkiService.openPinModal();
        	$scope.btDisabled = true;
	    } else {
	        $scope.alertMessage = archivesConstant.NO_INPUT;
            $scope.showAlertMessage = true;
	    }
    }

	$scope.slot = pkiService.querySlot();
	$scope.btDisabled = true;
});