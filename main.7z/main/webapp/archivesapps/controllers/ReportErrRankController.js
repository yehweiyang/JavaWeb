includeOtherScript("reportService");

angular.module("ArchivesApp").controller('ReportErrRankController', function($scope, $http, reportService, archivesConstant, reportConstant) {
    var actionAddress;
    var reportName = reportConstant.REPORT_ERROR_RANK;
    $scope.reportService = reportService;

    $scope.$on('$viewContentLoaded', function() {
        actionAddress = $scope.reportService.getInitActionUrl(reportName);
        return $http.get(actionAddress)
            .success(function(data) {
                $scope.dateFrom = new Date(data.filterContent.dateFrom);
                $scope.dateTo = new Date(data.filterContent.dateTo);
                $scope.reportService.sorter.columnName = data.filterContent.sortColumnName;
                $scope.reportService.sorter.descending = data.filterContent.sortDescending;
                $scope.reportService.currentFilter = data.filterContent;
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    });

    $scope.queryAction = function() {
        actionAddress = $scope.reportService.getQueryActionUrl(reportName);

        $scope.reportService.currentFilter = {
            dateFrom: $('#dateFrom').val(),
            dateTo: $('#dateTo').val(),
            sortColumnName: escape($scope.reportService.sorter.columnName),
            sortDescending: escape($scope.reportService.sorter.descending)
        };

        return $http.get(actionAddress, { params: $scope.reportService.currentFilter })
            .success(function(data) {
                setDataTable(data);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.queryHistoryList = function() {
        actionAddress =
                archivesConstant.WEB_ROOT_PATH +
                archivesConstant.REST_API_VERSION_PATH +
                reportConstant.REPORT_TOOL_PATH +
                "/" + reportName +
                "/history";
        return $http.get(actionAddress)
            .success(function(data) {
                $scope.historyList = data;
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.restoreHistoryData = function(reportCode) {
        actionAddress =
                archivesConstant.WEB_ROOT_PATH +
                archivesConstant.REST_API_VERSION_PATH +
                reportConstant.REPORT_TOOL_PATH +
                "/" + reportName +
                "/history" +
                "/" + reportCode;

        return $http.get(actionAddress)
            .success(function(data) {
                $scope.dateFrom = data.filterContent.dateFrom;
                $scope.dateTo = data.filterContent.dateTo;
                $scope.reportService.sorter.columnName = data.filterContent.sorterColumnName;
                $scope.reportService.sorter.descending = data.filterContent.sorterDescending;
                setDataTable(data.resultContent);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.exportAction = function(exportType) {
        actionAddress = $scope.reportService.getDownloadActionUrl(reportName, exportType);
        return $http.get(actionAddress)
            .success(function(data) {
                $scope.reportService.exportReportFile(actionAddress, exportType);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.toggleCalendar = function (datePickerId) {
        $scope[datePickerId] = $scope.reportService.toggleCalendar($scope[datePickerId]);
    };

    $scope.resetAction = function () {
        $scope.toggleResult = false;
        $scope.toggleAlert = false;
        $scope.dateFrom = $scope.reportService.getToday();
        $scope.dateTo = $scope.reportService.getToday();
    };

    function setDataTable(viewData) {
        var hasAnyViewData = $.trim(viewData) !== '';
        $scope.toggleResult = hasAnyViewData;
        angular.forEach(viewData, function(currentView) {
            currentView.rowIndex = parseInt(currentView.rowIndex);
        });
        $scope.queryResult = hasAnyViewData ? viewData : "";
        $scope.toggleAlert = !hasAnyViewData;
    }
});
