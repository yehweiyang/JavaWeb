angular.module('ArchivesApp').controller('InsideSend_ChangeController', function($scope, $http, $state, exchangeService, archivesConstant) {
	var self = this;
	$scope.uibPageBase = 10;
	$scope.showPurport = false;
	$scope.purportMsg = archivesConstant.SHOW_PURPORT_MSG;
	$scope.start = 0;
	$scope.end = $scope.uibPageBase;
	$scope.maxSize = 5;
    $scope.exactMatch = false;
	$scope.pageChanged = function() {
    	$scope.end = $scope.currentPage * $scope.uibPageBase;
    	$scope.start = $scope.end - $scope.uibPageBase;
        exchangeService.setInnerIndexPage($scope.currentPage);
	};

	$scope.today = function() {
		$scope.startDate = new Date();
		$scope.endDate = new Date();
	};

	$scope.stOpen = function(){
    	$scope.stPopup.opened = true;
    };

	$scope.edOpen = function(){
    	$scope.edPopup.opened = true;
    };
    
    $scope.stPopup = {
    	opened: false
    };
    $scope.edPopup = {
      	opened: false
    };
    
	$scope.hourList = [
	    {hour: "00"},
	    {hour: "01"},
	    {hour: "02"},
	    {hour: "03"},
	    {hour: "04"},
	    {hour: "05"},
	    {hour: "06"},
	    {hour: "07"},
	    {hour: "08"},
	    {hour: "09"},
	    {hour: "10"},
	    {hour: "11"},
	    {hour: "12"},
	    {hour: "13"},
	    {hour: "14"},
	    {hour: "15"},
	    {hour: "16"},
	    {hour: "17"},
	    {hour: "18"},
	    {hour: "19"},
	    {hour: "20"},
	    {hour: "21"},
	    {hour: "22"},
	    {hour: "23"},
	];

	$scope.purportBt = function() {
		if ($scope.showPurport) {
			$scope.showPurport = false;
			$scope.purportMsg = archivesConstant.SHOW_PURPORT_MSG;
		} else {
			$scope.showPurport = true;
			$scope.purportMsg = archivesConstant.HIDE_PURPORT_MSG;
		}
	}

	$scope.restExchange = function(cacheData) {
        var innerSendData = {};
        if ($scope.InnerSendData != null)
            innerSendData = $scope.InnerSendData;
        innerSendData.cacheData = cacheData;
        innerSendData.startHour = $scope.hourList.indexOf($scope.selectedStartHour);
        innerSendData.endHour = $scope.hourList.indexOf($scope.selectedEndHour);
	    if (innerSendData.startDocId != null) {
	        if (innerSendData.startDocId.length == 0) {
	            innerSendData.startDocId = null;
	        }
	    }
	    if (innerSendData.endDocId != null) {
	        if (innerSendData.endDocId.length == 0) {
	            innerSendData.endDocId = null;
	        }
	    }
	    innerSendData.startUpDateTime = $scope.startDate.toISOString().substring(0, 10) + " " + $scope
	    .selectedStartHour.hour +
	        ":00:00";
	    innerSendData.endUpDateTime = $scope.endDate.toISOString().substring(0, 10) + " " + $scope
	    .selectedEndHour.hour + ":00:00";
	    innerSendData.exactMatch = $scope.exactMatch;
	    var config = {
            params: innerSendData
    	};
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/exchange/inside/transmit";
        exchangeService.setInnerQueryData(innerSendData);
        $http.get(url, config).then(function(response) {
      	    $scope.exchangeList = response.data;
      	    $scope.totalItems = $scope.exchangeList.length;
      	    $scope.currentPage = exchangeService.getInnerIndexPage();
   		    $scope.start = 0;
   		    $scope.end = $scope.uibPageBase;
   		    $scope.showError = false;
   		    $scope.showTable = true;
            $scope.showLoad = false;
        }, function(errResponse) {
            $scope.errorMessage = errResponse.data.errorMessage;
            $scope.showError = true;
            $scope.showTable = false;
            $scope.showLoad = false;
        });
	}
	
	$scope.queryBt = function(form) {
	    if (form.$valid) {
	        $scope.showLoad = true;
            $scope.restExchange(false);
	    } else {
            $scope.errorMessage = archivesConstant.FORM_INVALID_MSG;
            $scope.showError = true;
            $scope.showTable = false;
	    }
	}
	
	$scope.resetBt = function() {
		$scope.today();
	    $scope.exactMatch = false;
		$scope.selectedStartHour = $scope.hourList[0];
		$scope.selectedEndHour = $scope.hourList[23];
		$scope.showError = false;
		$scope.showTable = false;
		$scope.showPurport = false;
	    $scope.purportMsg = archivesConstant.SHOW_PURPORT_MSG;
	    if ($scope.InnerSendData != null) {
		    $scope.InnerSendData.sendAgencyName = null;
		    $scope.InnerSendData.sendAgencyId = null;
            $scope.InnerSendData.exchangeSerial = null;
		    $scope.InnerSendData.startDocId = null;
            $scope.InnerSendData.endDocId = null;
	    }
	    exchangeService.setExchange(null);
	    exchangeService.setInnerQueryData(null);
	}

	$scope.transmitBt = function(exchange) {
	    exchange.sendType = 'INNER';
        exchangeService.setExchange(exchange);
        $state.go("DocumentExchange");
	}

	$scope.exchange = exchangeService.getExchange();
    $scope.InnerSendData = exchangeService.getInnerQueryData();
    if ($scope.InnerSendData != null) {
    	$scope.startDate = new Date($scope.InnerSendData.startUpDateTime);
    	$scope.endDate = new Date($scope.InnerSendData.endUpDateTime);
        $scope.selectedStartHour = $scope.hourList[$scope.InnerSendData.startHour];
    	$scope.selectedEndHour = $scope.hourList[$scope.InnerSendData.endHour];
        $scope.restExchange(true);
    } else {
        if ($scope.exchange != null && $scope.exchange.sendType == 'INNER') {
            $scope.restExchange(true);
        } else {
    	    $scope.InnerSendData = null;
	        $scope.today();
	        $scope.selectedStartHour = $scope.hourList[0];
	        $scope.selectedEndHour = $scope.hourList[23];
	        exchangeService.setInnerIndexPage(1);
        }
    }
});