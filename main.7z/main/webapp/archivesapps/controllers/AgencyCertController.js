angular.module('ArchivesApp').controller('AgencyCertController', function($rootScope, $scope, $http, archivesConstant) {

    //取得certHash能-開始
    $scope.getCertHash = function(){
        if (!$scope.orgId) {
            alert("機關代碼不可為空");
        }
        $http({
            url : archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +"/changerecord/certHash/" + $scope.orgId,
            method : "GET"
        }).success (function(response) {
            if (response.length != 0) {
                selectOption(response);
            } else {
                alert("機關代碼錯誤");
            }
        }).error(function(response) {
            exceptionViewer(response, false);
        });
    }
    //取得certHash能-結束

    function selectOption(allOrgCert) {
        for (var i = 0;i < allOrgCert.length;i++) {
            $('#changeCerHash').append('<option value="' + allOrgCert[i].signCertHash + '">' + allOrgCert[i].signCertHash + '</option>');
        }
        $('#changeCerHash').css('display','block');
        $('.selectpicker').selectpicker();
    }

    //查詢檔案功能-開始
    $scope.searchLog = function(){

        if (!$scope.certHash || !$scope.orgId) {
            alert('請選擇CertHash');
            return false;
        }

        var orgValue = {
            'orgId' : $scope.orgId,
            'certHash' : $scope.certHash
        };

        $http({
            url : archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH +"/changerecord/searchLogFile",
            method : "POST",
            params : orgValue
        }).success (function(response) {
            $scope.errorMessage = false;
            $scope.file="";
            $scope.file = response;
            if ($scope.file.length == 0) {
                $scope.errorMessage = true;
            }
            $('#logFile').css('display','block');
        }).error(function(response) {
            exceptionViewer(response, false);
        });
    };
    //查詢檔案功能-結束

    //下載檔案功能-開始
    $scope.downloadLogFile = function(fileName){

        var logValue = {
            'orgId' : $scope.orgId,
            'certHash' : $scope.certHash,
            'fileName' : fileName
        };

        $http({
            url : archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/changerecord/downLogFile",
            method : "GET",
            params : logValue
        }).success (function(response) {
            window.location.href = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/changerecord/downLogFile?orgId="+$scope.orgId+"&certHash=" + $scope.certHash + "&fileName=" + fileName;
        }).error(function(response) {
            exceptionViewer(response, false);
        });
    };
    //下載檔案功能-結束

   //清空功能-開始
    $scope.giveUp = function(){
         $("#selectCertHash").empty();
         $("#selectCertHash").append('<select class="selectpicker show-tick form-control" data-live-search="true" ng-model="certHash" id="changeCerHash" style="display:none;"><option class="get-class" value="" disabled selected>請選擇</option></select>');
         $('#logFile').css('display','none');
         $scope.file="";
         $scope.orgId = '';
    };
    //清空功能-結束
});