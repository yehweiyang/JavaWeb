angular.module('ArchivesApp').controller('OutsideReceive_ChangeController', function($scope, $http, $state, exchangeService, archivesConstant) {
	var self = this;
	$scope.uibPageBase = 10;
	$scope.showPurport = false;
	$scope.purportMsg = archivesConstant.SHOW_PURPORT_MSG;
	$scope.start = 0;
	$scope.end = $scope.uibPageBase;
	$scope.maxSize = 5;
    $scope.exactMatch = false;
	$scope.pageChanged = function() {
    	$scope.end = $scope.currentPage * $scope.uibPageBase;
    	$scope.start = $scope.end - $scope.uibPageBase;
	    exchangeService.setOutsideIndexPage($scope.currentPage);
	};

	$scope.today = function() {
		$scope.startDate = new Date();
		$scope.endDate = new Date();
	};

	$scope.stOpen = function(){
    	$scope.stPopup.opened = true;
    };

	$scope.edOpen = function(){
    	$scope.edPopup.opened = true;
    };
    
    $scope.stPopup = {
    	opened: false
    };
    $scope.edPopup = {
      	opened: false
    };
    
	$scope.hourList = [
	    {hour: "00"},
	    {hour: "01"},
	    {hour: "02"},
	    {hour: "03"},
	    {hour: "04"},
	    {hour: "05"},
	    {hour: "06"},
	    {hour: "07"},
	    {hour: "08"},
	    {hour: "09"},
	    {hour: "10"},
	    {hour: "11"},
	    {hour: "12"},
	    {hour: "13"},
	    {hour: "14"},
	    {hour: "15"},
	    {hour: "16"},
	    {hour: "17"},
	    {hour: "18"},
	    {hour: "19"},
	    {hour: "20"},
	    {hour: "21"},
	    {hour: "22"},
	    {hour: "23"},
	];

	$scope.purportBt = function() {
		if ($scope.showPurport) {
			$scope.showPurport = false;
			$scope.purportMsg = archivesConstant.SHOW_PURPORT_MSG;
		} else {
			$scope.showPurport = true;
			$scope.purportMsg = archivesConstant.HIDE_PURPORT_MSG;
		}
	}

	$scope.restExchange = function(cacheData) {
        var outSideData = {};
        if ($scope.OutSideData != null)
            outSideData = $scope.OutSideData;
        outSideData.cacheData = cacheData;
        outSideData.startHour = $scope.hourList.indexOf($scope.selectedStartHour);
        outSideData.endHour = $scope.hourList.indexOf($scope.selectedEndHour);
	    if (outSideData.startDocId != null) {
	        if (outSideData.startDocId.length == 0) {
	            outSideData.startDocId = null;
	        }
	    }
	    if (outSideData.endDocId != null) {
	       if (outSideData.endDocId.length == 0) {
	            outSideData.endDocId = null;
	        }
	    }
	    outSideData.startUpDateTime = $scope.startDate.toISOString().substring(0, 10) + " " + $scope.selectedStartHour.hour +
	        ":00:00";
	    outSideData.endUpDateTime = $scope.endDate.toISOString().substring(0, 10) + " " + $scope.selectedEndHour.hour + ":00:00";
	    outSideData.exactMatch = $scope.exactMatch;
	    var config = {
            params: outSideData
    	};
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/exchange/outside/receive";
        exchangeService.setOutQueryData(outSideData);
        $http.get(url, config).then(function(response) {
            $scope.exchangeList = response.data;
            $scope.totalItems = $scope.exchangeList.length;
      	    $scope.currentPage = exchangeService.getOutsideIndexPage();
    		$scope.start = 0;
    		$scope.end = $scope.uibPageBase;
    		$scope.showError = false;
    		$scope.showTable = true;
            $scope.showLoad = false;
        }, function(errResponse) {
            $scope.errorMessage = errResponse.data.errorMessage;
            $scope.showError = true;
            $scope.showTable = false;
            $scope.showLoad = false;
        });
	}
	
	$scope.queryBt = function(form) {
	    if (form.$valid) {
	    	$scope.showLoad = true;
            $scope.restExchange(false);
	    } else {
            $scope.errorMessage = archivesConstant.FORM_INVALID_MSG;
            $scope.showError = true;
            $scope.showTable = false;
	    }
	}
	
	$scope.resetBt = function() {
		$scope.today();
	    $scope.exactMatch = false;
		$scope.selectedStartHour = $scope.hourList[0];
		$scope.selectedEndHour = $scope.hourList[23];
		$scope.showError = false;
		$scope.showTable = false;
		$scope.showPurport = false;
	    $scope.purportMsg = archivesConstant.SHOW_PURPORT_MSG;
	    if ($scope.OutSideData != null) {
		    $scope.OutSideData.sendAgencyName = null;
		    $scope.OutSideData.sendAgencyId = null;
            $scope.OutSideData.exchangeSerial = null;
		    $scope.OutSideData.startDocId = null;
            $scope.OutSideData.endDocId = null;
	    }
	    exchangeService.setExchange(null);
	    exchangeService.setOutQueryData(null);
	}

	$scope.transmitBt = function(exchange) {
	    exchange.outsideCurrentPage = $scope.currentPage;
	    exchange.sendType = 'OUTSIDE';
        exchangeService.setExchange(exchange);
        $state.go("DocumentExchange");
	}

	$scope.exchange = exchangeService.getExchange();
    $scope.OutSideData = exchangeService.getOutQueryData();
    if ($scope.OutSideData != null) {
	    $scope.startDate = new Date($scope.OutSideData.startUpDateTime);
	    $scope.endDate = new Date($scope.OutSideData.endUpDateTime);
        $scope.selectedStartHour = $scope.hourList[$scope.OutSideData.startHour];
	    $scope.selectedEndHour = $scope.hourList[$scope.OutSideData.endHour];
        $scope.restExchange(true);
    } else {
        if ($scope.exchange != null && $scope.exchange.sendType == 'OUTSIDE') {
            $scope.restExchange(true);
        } else {
            $scope.OutSideData = null;
            $scope.today();
            $scope.selectedStartHour = $scope.hourList[0];
            $scope.selectedEndHour = $scope.hourList[23];
          	exchangeService.setOutsideIndexPage(1);
        }
    }

});