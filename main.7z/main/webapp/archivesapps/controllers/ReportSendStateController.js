includeOtherScript("reportService");

angular.module("ArchivesApp").controller('ReportSendStateController', function($scope, $http, reportService, reportConstant) {
    var actionAddress;
    var reportName = reportConstant.REPORT_SEND_STATE;
    $scope.reportService = reportService;

    $scope.$on('$viewContentLoaded', function() {
        actionAddress = $scope.reportService.getInitActionUrl(reportName);
        return $http.get(actionAddress)
            .success(function(data) {
                var filter = data.filterContent;
                var result = data.resultContent;
                $scope.dateFrom = new Date(filter.dateFrom);
                $scope.dateTo = new Date(filter.dateTo);
                $scope.reportService.sorter.columnName = filter.sortColumnName;
                $scope.reportService.sorter.descending = filter.sortDescending;
                $scope.reportService.currentFilter = filter;
                /* TODO: unknow select dom issue
                $scope.reportListFromMonth = filter.reportListFromMonth;
                $scope.selectedReportFromMonth = null != filter.reportListFromMonth ? $scope.reportListFromMonth[0] : null;
                */

                //load last query result
                setDataTable(result, false);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    });

    $scope.queryAction = function() {
        actionAddress = $scope.reportService.getQueryActionUrl(reportName);

        $scope.reportService.currentFilter = {
            dateFrom: $('#dateFrom').val(),
            dateTo: $('#dateTo').val(),
            sortColumnName: escape($scope.reportService.sorter.columnName),
            sortDescending: escape($scope.reportService.sorter.descending)
        };

        return $http.get(actionAddress, { params: $scope.reportService.currentFilter })
            .success(function(data) {
                setDataTable(data);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.exportAction = function(exportType) {
        actionAddress = $scope.reportService.getDownloadActionUrl(reportName, exportType);
        return $http.get(actionAddress)
            .success(function(data) {
                $scope.reportService.exportReportFile(actionAddress, exportType);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.toggleCalendar = function (datePickerId) {
        $scope[datePickerId] = $scope.reportService.toggleCalendar($scope[datePickerId]);
    };

    $scope.resetAction = function () {
        $scope.toggleResult = false;
        $scope.toggleAlert = false;
        $scope.dateFrom = $scope.reportService.getToday();
        $scope.dateTo = $scope.reportService.getToday();
    };

    function setDataTable(viewData, isInit) {
        var hasAnyViewData = $.trim(viewData) !== '';
        $scope.toggleResult = hasAnyViewData;
        angular.forEach(viewData, function(currentView) {
            currentView.rowIndex = parseInt(currentView.rowIndex);
        });
        $scope.queryResult = hasAnyViewData ? viewData : "";
        $scope.toggleAlert = typeof isInit === "undefined" ?
            !hasAnyViewData : false;
    }
});
