angular.module("ArchivesApp").controller('FormRegisterController', function($scope, $http, registerService, archivesConstant) {
	var self = this;
	$scope.uibPageBase = 10;
	$scope.maxSize = 5;
	$scope.start = 0;
	$scope.end = $scope.uibPageBase;
    $scope.checkCompare = false;
    $scope.toggleForbidden = function(){
    	$scope.forbiddenModal = false;
    };
    $scope.formList = []
	$scope.bigPageChanged = function() {
    	$scope.end = $scope.currentPage * $scope.uibPageBase;
    	$scope.start = $scope.end - $scope.uibPageBase;
    	registerService.setFormIndexPage($scope.currentPage);
	};

	$scope.formStatusList = [
        {formStatus: "全部"},
        {formStatus: "啟用"},
        {formStatus: "暫停"},
        {formStatus: "停用"}
    ];
    
	$scope.formTypeList = [
        {formType: "全部"},
        {formType: "公文交換"},
        {formType: "e管家"}
    ];
    
	$scope.fileTypeList = [
        {fileType: "全部"},
        {fileType: "XML"},
        {fileType: "DOC"},
        {fileType: "PDF"}
    ];
 
	$scope.showFileTypeList = [
        {showFileType: "全部"},
        {showFileType: "無"},
        {showFileType: "PDF"},
        {showFileType: "PNG"},
        {showFileType: "TIF"}
    ];

	$scope.getRestForm = function(cacheData) {
        var queryData = $scope.queryForm;
        queryData.cacheData = cacheData;
        queryData.exactMatch = $scope.checkCompare;
        queryData.statusIndex = $scope.formStatusList.indexOf($scope.selectedFormStatus);
        queryData.formTypeIndex = $scope.formTypeList.indexOf($scope.selectedFormType);
        queryData.fileTypeIndex = $scope.fileTypeList.indexOf($scope.selectedFileType);
        queryData.showFileTypeIndex = $scope.showFileTypeList.indexOf($scope.selectedShowFileType);

        var config = {
            params: queryData
        };
        registerService.setFormQueryData(queryData);
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/form/list";
    	return $http.get(url, config).then(function(response) {
    		$scope.formList = response.data;
    		$scope.totalItems = $scope.formList.length;
    		$scope.currentPage = registerService.getFormIndexPage();
    		$scope.start = 0;
    		$scope.end = $scope.uibPageBase;
    		$scope.showError = false;
    		$scope.showTable = true;
            $scope.showLoad = false;
    	}, function(errResponse) {
            $scope.errorMessage = errResponse.data.errorMessage;
            $scope.showError = true;
            $scope.showTable = false;
            $scope.showLoad = false;
    	});
	}
    
	$scope.queryBt = function() {
	    $scope.showLoad = true;
	    $scope.getRestForm(false);
    }
    
	$scope.resetBt = function() {
		$scope.showTable = false;
		$scope.showError = false;
		$scope.checkCompare = false;
		$scope.selectedFormStatus = $scope.formStatusList[0];
		$scope.selectedFormType = $scope.formTypeList[0];
		$scope.selectedFileType = $scope.fileTypeList[0];
		$scope.selectedShowFileType = $scope.showFileTypeList[0];
    	$scope.queryForm.tableId = null;
    	$scope.queryForm.tableName = null;
    	$scope.queryForm.agencyOrgId = null;
    	$scope.start = 0;
    	$scope.end = $scope.uibPageBase;
    };

    $scope.queryForm = registerService.getFormQueryData();
    if ($scope.queryForm != null) {
        $scope.checkCompare = $scope.queryForm.exactMatch;
        $scope.selectedFormStatus = $scope.formStatusList[$scope.queryForm.statusIndex];
        $scope.selectedFormType = $scope.formTypeList[$scope.queryForm.formTypeIndex];
        $scope.selectedFileType = $scope.fileTypeList[$scope.queryForm.fileTypeIndex];
        $scope.selectedShowFileType = $scope.showFileTypeList[$scope.queryForm.showFileTypeIndex];
        $scope.getRestForm(true);
    } else {
        $scope.queryForm = {};
	    $scope.selectedFormStatus = $scope.formStatusList[0];
	    $scope.selectedFormType = $scope.formTypeList[0];
	    $scope.selectedFileType = $scope.fileTypeList[0];
	    $scope.selectedShowFileType = $scope.showFileTypeList[0];
        registerService.setFormIndexPage(1);
    }
});
