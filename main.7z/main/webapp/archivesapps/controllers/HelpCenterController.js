angular.module("ArchivesApp").controller('HelpCenterController', function($scope, $http,archivesConstant ) {
    $('.selectpicker').selectpicker();
    $('.archives-checkbox').checkboxpicker();

    $scope.$on('$viewContentLoaded', function() {
      console.log('77777');
    var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/exchange/init";
     $http.get(url)
                    .success(function(data) {
                    console.log('6666666');
                    })

        });
});
