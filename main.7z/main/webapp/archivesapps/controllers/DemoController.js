angular.module('ArchivesApp').controller('DemoController', function($rootScope, $scope, $http, $timeout) {
    $scope.name = "frank";
});