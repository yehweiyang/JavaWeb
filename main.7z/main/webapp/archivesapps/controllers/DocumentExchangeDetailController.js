angular.module('ArchivesApp').controller('DocumentExchangeDetailController', function($scope, $state, exchangeService, archivesConstant) {
	$scope.exchange = exchangeService.getExchange();
    $scope.transmitMsg = exchangeService.getTransmitDetail();
    if ($scope.exchange == null || $scope.transmitMsg == null) {
        $state.go("InsideSend_Change");
    } else {
        if ($scope.exchange.transmitType == archivesConstant.INNER_TRANSMIT_TYPE) {
            $scope.detailTitle = archivesConstant.INNER_TITLE_MSG;
        } else if ($scope.exchange.transmitType == archivesConstant.OUT_TRANSMIT_TYPE) {
            $scope.detailTitle = archivesConstant.OUT_TITLE_MSG;
        }
    }
});