angular.module('ArchivesApp').controller('DistDocUnitController',
        function($rootScope, $scope, $http, $timeout, $uibModal, pkiService) {

    $scope.senderUnitList = [];
    $scope.isQueried = false;
    $scope.orgId = "";
    $scope.unitId = "";
    $scope.orgUnitName = "";
    $scope.exactMatch = false;
    $scope.cardStatus = false;
    $scope.slot = pkiService.querySlot();

    $rootScope.$on('slot:find', function() {
        $scope.cardStatus = true;
    });
    $rootScope.$on('slot:empty', function() {
        $scope.cardStatus = false;
    });

    $scope.queryDistSender = function() {
        var url = "/manageWeb/v1/DocumentSystem/listSenderUnit";
        console.log("OrgID: "+$scope.orgId+", UnirID: "+$scope.unitId+", OrgUnitName: "+$scope.orgUnitName);
        return $http.get(url, {
            params: {
                orgId: $scope.orgId,
                unitId: $scope.unitId,
                orgUnitName: $scope.orgUnitName,
                exactMatch: $scope.exactMatch
            }
        }).then(function(response) {
            $scope.senderUnitList = response.data;
            $scope.isQueried = true;
        });
    };

    $scope.reset = function() {
        $scope.orgId = "";
        $scope.unitId = "";
        $scope.orgUnitName = "";
        $scope.exactMatch = false;
    };

    $scope.selected = {
        unit: $scope.senderUnitList[0]
    };

    $scope.deleteConfirmModal = function() {
        $scope.uibModalInstance = $uibModal.open({
            templateUrl: 'modalConfirmDelete.html',
            scope: $scope,
            size: 'sm'
        });
    };

    $scope.modalDeleteUnit = function() {
        var url = "/manageWeb/v1/DocumentSystem/deleteSenderUnit";
        $http.post(url, $scope.selected.unit).then(function successCallback(response) {
            var index = $scope.senderUnitList.indexOf($scope.selected.unit);
            if(index>-1) {
                $scope.senderUnitList.splice(index, 1);
                $scope.uibModalInstance.dismiss();
            } else {
                exceptionViewer(response, false);
            }
        }, function errorCallback(response) {
            exceptionViewer(response, false);
        });
    };

    $scope.modalCancel = function() {
        $scope.uibModalInstance.dismiss();
    }

    $scope.addSenderUnit = function() {
        var queryTarget = "SET_SENDER";
        openUnitModal(queryTarget);
    }

    $scope.setMapping = function() {
        var queryTarget = "SET_MAPPING";
        openUnitModal(queryTarget, $scope.selected.unit);
    }

    var openUnitModal = function(queryTarget, selected) {
        var uibModalInstance = $uibModal.open({
            templateUrl: "archivesapps/views/DocumentSystem/distDocUnitSelector.html",
            controller: "DistDocUnitSelectorController",
            size: 'lg',
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            $rootScope.settings.appPath + '/controllers/DistDocUnitSelectorController.js',
                        ]
                    });
                }],
                target: function() {
                    return queryTarget;
                },
                selected: function() {
                    return selected;
                }
            }
        });
        uibModalInstance.result.then($scope.queryDistSender);
    }
});