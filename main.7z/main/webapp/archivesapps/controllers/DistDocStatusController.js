angular.module('ArchivesApp').controller('DistDocStatusController',
        function($scope, $http, $timeout, $uibModal) {
    $scope.$on('$viewContentLoaded', function() {
        $scope.reset();
    });
    $scope.statusEnum = {"全部":0, "轉文處理中":1, "轉文待簽收":2, "轉文已簽收":3, "轉文退文":4};
    $scope.docList = [];
    $scope.isQueried = false;
    $scope.selected = {
        doc: $scope.docList[0]
    };

    $scope.hourList = (function getHourArray() {
        var array = [];
        for(var i=0; i<24; i++) {
            var h = i;
            if(i<10)
                h="0"+h;
            else
                h=h.toString();
            array.push(h);
        }
        return array;
    })();

    $scope.openDatePickerFrom = function() {
        $scope.datePickerFrom.opened = true;
    };
    $scope.datePickerFrom = {
        opened: false
    };
    $scope.openDatePickerTo = function() {
        $scope.datePickerTo.opened = true;
    };
    $scope.datePickerTo = {
        opened: false
    };

    $scope.reset = function() {
        $scope.processId = "";
        $scope.status = 0;
        $scope.fromOrgId = "";
        $scope.fromUnitId = "";
        $scope.fromOrgUnitName = "";
        $scope.toOrgId = "";
        $scope.toUnitId = "";
        $scope.toOrgUnitName = "";
        $scope.fromDate = null;
        $scope.toDate = null;
        $scope.fromHour = $scope.hourList[0];
        $scope.toHour = $scope.hourList[$scope.hourList.length-1];
        $scope.exactMatch = false;
    };

    $scope.query = function() {
        if($scope.fromDate)
            $scope.fromDate.setHours($scope.fromHour);
        if($scope.toDate)
            $scope.toDate.setHours($scope.toHour, 59, 59, 999);

        var url = "/manageWeb/v1/DocumentSystem/listDistDoc";
        console.log("ProcessID: "+$scope.processId
                    + ", Status: "+$scope.status
                    + ", FromOrgId: "+$scope.fromOrgId
                    + ", FromUnitId: "+$scope.fromUnitId
                    + ", FromOrgUnitName: "+$scope.fromOrgUnitName
                    + ", ToOrgId: "+$scope.toOrgId
                    + ", ToUnitId: "+$scope.toUnitId
                    + ", ToOrgUnitName: "+$scope.toOrgUnitName
                    + ", FromDate: "+$scope.fromDate
                    + ", ToDate: "+$scope.toDate
                    );
        return $http.get(url, {
            params: {
                processId: $scope.processId,
                status: $scope.status,
                fromOrgId: $scope.fromOrgId,
                fromUnitId: $scope.fromUnitId,
                fromOrgUnitName: $scope.fromOrgUnitName,
                toOrgId: $scope.toOrgId,
                toUnitId: $scope.toUnitId,
                toOrgUnitName: $scope.toOrgUnitName,
                fromTime: $scope.fromDate,
                toTime: $scope.toDate,
                exactMatch: $scope.exactMatch
            }
        }).then(function(response) {
            $scope.docList = response.data;
            $scope.isQueried = true;
        });
    };

    $scope.openFlowHistory = function() {
        $scope.uibModalInstance = $uibModal.open({
            templateUrl: 'modalFlowHistory.html',
            scope: $scope,
            size: 'lg'
        });
        $scope.uibModalInstance.opened.then(function() {
            getFlowHistory();
        });
    };

    var getFlowHistory = function() {
        var url = "/manageWeb/v1/DocumentSystem/listFlowHistory";
        return $http.get(url, {
            params: {
                processId: $scope.selected.doc.processId
            }
        }).then(function(response) {
            $scope.historyList = response.data;
        });
    };

    $scope.closeFlowHistory = function() {
        $scope.uibModalInstance.close();
    };
});