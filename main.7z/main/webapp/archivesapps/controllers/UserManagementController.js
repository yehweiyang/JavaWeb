angular.module('ArchivesApp')
.filter('activeStatusFilter', function() {
    return function(users, status) {
        var filteredUserList = [];
        angular.forEach(users, function(user) {
            if(status.active==true && user.activeStatus==1)
                filteredUserList.push(user);
            else if(status.inactive==true && user.activeStatus==0)
                filteredUserList.push(user);
        });
        return filteredUserList;
    };
})
.controller('UserManagementController', function($scope, $http, $uibModal) {
        $scope.$on('$viewContentLoaded', function() {
            $scope.queryUsers();
        });

        $scope.userList = [];
        $scope.status = {active:true, inactive: true};
        $scope.queryUsers = function() {
            var url = "/manageWeb/v1/systemTools/user/list";

            return $http.get(url).then(function(response) {
              $scope.userList = response.data;
            });
        };

    $scope.selected = {
        user: $scope.userList[0]
    };

    $scope.openUserDetail = function() {
        var modalInstance = $uibModal.open({
            templateUrl: "archivesapps/views/userAccountModification.html",
            controller: "UserAccountModificationController",
            size: 'lg',
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            $rootScope.settings.appPath + '/controllers/UserAccountModificationController.js',
                        ]
                    });
                }],
                userList: function() {
                    return $scope.userList;
                },
                user: function () {
                    return $scope.selected.user;
                }
            }
        });
    };
});

