angular.module('ArchivesApp')
.filter('activeStatusFilter', function() {
    return function(users, status) {
        var filteredUserList = [];
        angular.forEach(users, function(user) {
            if(status.active==true && user.activeStatus==1)
                filteredUserList.push(user);
            else if(status.inactive==true && user.activeStatus==0)
                filteredUserList.push(user);
        });
        return filteredUserList;
    };
})
.controller('UserManagementController', function($scope, $http, $uibModal, archivesService, archivesConstant) {
    $scope.$on('$viewContentLoaded', function() {
        $scope.queryUsers();
    });

    $scope.userList = [];
    $scope.isQueried = false;
    $scope.status = {active:true, inactive: true};

    $scope.archivesService = archivesService;
    $scope.archivesService.sorter.columnName = "account";

    $scope.queryUsers = function() {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH
                + archivesConstant.TOP_MENU_SYSTEMTOOL +"/user/list";

        return $http.get(url).then(function successCallback(response) {
            $scope.userList = response.data;
            $scope.isQueried = true;
        }, function errorCallback(response) {

            $scope.isQueried = true;
        });
    };

    $scope.selected = {
        user: $scope.userList[0]
    };

    $scope.openUserDetail = function() {
        var uibModalInstance = $uibModal.open({
            templateUrl: archivesConstant.APP_PATH + "/views/SystemTool/userAccountModification.html",
            controller: "UserAccountModificationController",
            size: 'lg',
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            $rootScope.settings.appPath + '/controllers/UserAccountModificationController.js',
                        ]
                    });
                }],
                userList: function() {
                    return $scope.userList;
                },
                user: function () {
                    return $scope.selected.user;
                }
            }
        });
    };
});

