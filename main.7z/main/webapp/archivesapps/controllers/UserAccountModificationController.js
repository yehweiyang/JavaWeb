angular.module('ArchivesApp').controller('UserAccountModificationController',
        function($rootScope, $scope, $http, $modalInstance, pkiService, userList, user) {

    $modalInstance.opened.then(function(){
        queryRoles();
    });

    $rootScope.$on('slot:find', function() {
        $scope.slot = "卡片存在";
        $scope.cardStatus = true;
    });
    $rootScope.$on('slot:empty', function() {
        $scope.slot = "卡片不存在";
        $scope.cardStatus = false;
    });

    $scope.userList = userList;
    $scope.user = user;
    $scope.shadowUser = angular.copy(user);
    $scope.roleList =[];
    $scope.slot = pkiService.querySlot();
    $scope.cardStatus = false;

    queryRoles = function() {
        var url = "/manageWeb/v1/systemTool/role/listRoleName";
        return $http.get(url)
                    .then(function(response) {
                        $scope.roleList = response.data;
        });
    };

    $scope.searchRoleName = function(keyword) {
        angular.forEach($scope.roleList, function(role) {
            if(role.roleName.match(keyword))
                $scope.shadowUser.roleName = role.roleName;
        });
    };

    var successCallback = function(){
        $modalInstance.close();
        console.log("updated!");
    };

    var errorCallback = function() {
        console.log("error!");
    };

    $scope.save = function() {
        var url = "/manageWeb/v1/systemTools/user/saveUser";
        if($scope.userDetailForm.$pristine) {
            $modalInstance.close();
            return;
        }
        $scope.shadowUser.phoneNumber = $scope.shadowUser.phoneAreaCode+"-"+$scope.shadowUser.phoneLocalNumber
                +($scope.shadowUser.phoneExtNumber?("#"+$scope.shadowUser.phoneExtNumber):"");
        angular.copy($scope.shadowUser, $scope.user);
        var userJson = angular.toJson($scope.user);
        $http.post(url, userJson).then(successCallback, errorCallback);
    };

    $scope.rollback = function() {
        angular.copy($scope.user, $scope.shadowUser);
        $scope.userDetailForm.$setPristine();
    };

    $scope.cancel = function() {
        $modalInstance.dismiss('cancel');
    };
});