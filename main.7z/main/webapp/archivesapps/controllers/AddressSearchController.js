angular.module("ArchivesApp").controller('AddressSearchController', function($scope, $http, registerService, archivesConstant) {
	var self = this;
	$scope.uibPageBase = 10;
    $scope.checkTestUnit = 'no';
    $scope.checkCompare = false;
    $scope.start = 0;
    $scope.end = $scope.uibPageBase;
    $scope.showTable = false;
    $scope.centerLists = [];
    $scope.addressBookList = [];
    $scope.showModal = false;
    $scope.showDetail = false;
    $scope.forbiddenModal = false;
	$scope.maxSize = 5;
	$scope.totalItems = 0;
    $scope.toggleModal = function(){
    	$scope.showModal = false;
    };
    $scope.toggleDetail = function(){
    	$scope.showDetail = false;
    };
    $scope.toggleForbidden = function(){
    	$scope.forbiddenModal = false;
    };
    var fetchCenterList = function() {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH
                + archivesConstant.TOP_MENU_ADDRESSSEARCH + "/center/list";
    	return $http.get(url).then(function(response) {
    		$scope.centerLists = response.data;
            $scope.queryData = registerService.getAddressQueryData();
            if ($scope.queryData != null) {
                $scope.selectedCenterList = $scope.centerLists[$scope.queryData.centerIndex];
                $scope.selectedCenterStatus = $scope.statusList[$scope.queryData.statusIndex];
                $scope.checkCompare = $scope.queryData.exactMatch;
                $scope.checkTestUnit = $scope.queryData.showTestUnit;
                $scope.restAddress(true);
            } else {
                $scope.queryData = {};
    	        $scope.selectedCenterList = $scope.centerLists[0];
    	        $scope.selectedCenterStatus = $scope.statusList[0];
    	        registerService.setAddressCurrentPage(1);
            }
    	}, function(errResponse) {
            $scope.errorMessage = errResponse.data.errorMessage;
            $scope.showError = true;
            $scope.showTable = false;
            $scope.showLoad = false;
    	});
    };

	$scope.bigPageChanged = function() {
		$scope.end = $scope.currentPage * $scope.uibPageBase
		$scope.start = $scope.end - $scope.uibPageBase
		registerService.setAddressCurrentPage($scope.currentPage);
	};

	$scope.restAddress = function(cacheData) {
        var queryData = $scope.queryData;
	    queryData.cacheData = cacheData;
    	var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH
    	            + archivesConstant.TOP_MENU_ADDRESSSEARCH +"/list";
        queryData.centerIndex = $scope.centerLists.indexOf($scope.selectedCenterList);
        queryData.statusIndex = $scope.statusList.indexOf($scope.selectedCenterStatus);
        queryData.exactMatch = $scope.checkCompare;
        queryData.showTestUnit = $scope.checkTestUnit;
        var config = {
            params: queryData
        };
        registerService.setAddressQueryData(queryData);
    	$http.get(url, config).then(function(response) {
    	    $scope.addressBookList = response.data;
    		$scope.totalItems = $scope.addressBookList.length;
            $scope.currentPage = registerService.getAddressCurrentPage();
            $scope.start = 0;
    		$scope.end = $scope.uibPageBase
    		$scope.showError = false;
    		$scope.showTable = true;
            $scope.showLoad = false;
        }, function(errResponse) {
            $scope.errorMessage = errResponse.data.errorMessage;
            $scope.showError = true;
            $scope.showTable = false;
            $scope.showLoad = false;
    	});
	}

	$scope.queryBt = function(form) {
        if (form.$valid) {
        	$scope.showLoad = true;
            $scope.restAddress(false);
		} else {
            $scope.errorMessage = archivesConstant.FORM_INVALID_MSG;
            $scope.showError = true;
        }
    };

    $scope.detailBt = function(addressBook) {
        var queryDetail = {};
        queryDetail.agencyId = addressBook.agencyId;
        queryDetail.agencyUnitId = addressBook.agencyUnitId;
        var config = {
            params: queryDetail
        };
    	var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH
    	        + archivesConstant.TOP_MENU_ADDRESSSEARCH +"/detail";
    	return $http.get(url, config).then(function(response) {
    		$scope.addressBookDetail = response.data;
    		$scope.showDetail = true;
    	}, function(errResponse) {
    	    $scope.message = errResponse.data.errorMessage;
            $scope.btMsg = archivesConstant.BUTTON_SUBMIT_MSG;
            $scope.showModal = true;
    	});
    };

    $scope.statusList = [
        {centerStatus: archivesConstant.ALL_CENTER_STATUS},
        {centerStatus: archivesConstant.ACTIVE_CENTER_STATUS},
        {centerStatus: archivesConstant.PAUSE_CENTER_STATUS},
        {centerStatus: archivesConstant.STOP_CENTER_STATUS}
    ];

    $scope.resetBt = function() {
    	$scope.selectedCenterList = $scope.centerLists[0];
    	$scope.selectedCenterStatus = $scope.statusList[0];
    	$scope.showTable = false;
    	$scope.queryData.agencyId = null;
    	$scope.queryData.agencyUnitId = null;
    	$scope.queryData.agencyName = null;
    	$scope.checkTestUnit = 'no';
    	$scope.checkCompare = false;
    	$scope.start = 0;
    	$scope.end = $scope.uibPageBase
    	$scope.showDetail = false;
    	$scope.showError = false;
    	registerService.setAddressQueryData(null);
    };

    fetchCenterList();
});
