includeOtherScript("reportService");

angular.module("ArchivesApp").controller('ReportRSStateController', function($scope, $http, reportService, archivesConstant, reportConstant) {
    var actionAddress;
    var errMsg = "Oh snap! You got an error!";
    var lastActiveReportName;
    $scope.reportService = reportService;
    $scope.reportService.setHoursRangeFromDomId("timeTo");
    $scope.reportService.setHoursRangeFromDomId("timeFrom");
    $(".selectpicker").selectpicker("refresh");

    $scope.$on('$viewContentLoaded', function() {
        actionAddress =
                archivesConstant.WEB_ROOT_PATH +
                archivesConstant.REST_API_VERSION_PATH +
                reportConstant.REPORT_TOOL_PATH +
                "/" + reportConstant.REPORT_RS_STATE_STATIC +
                "/last";

        return $http.get(actionAddress)
            .success(function(data) {
                var filter = data.filterContent;
                var result = data.resultContent;
                $scope.dateFrom = new Date(filter.dateFrom);
                $scope.dateTo = new Date(filter.dateTo);
                $scope.orgId = filter.orgId;
                $scope.orgName = filter.orgName;
                $scope.queryTarget = filter.queryTarget;
                $scope.contentFullCmp = filter.contentFullCmp;
                $scope.reportService.sorter.columnName = filter.sortColumnName;
                $scope.reportService.sorter.descending = filter.sortDescending;
                $scope.reportService.currentFilter = filter;
                $('#timeFrom').selectpicker("val", filter.timeFrom);
                $('#timeTo').selectpicker("val", filter.timeTo);

                setDataTable(result, false);
				setLastActiveReportName();
				$scope.reportService.currentReportName = lastActiveReportName;
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    });

    $scope.queryAction = function() {
        actionAddress = $scope.reportService.getQueryActionUrl(getReportNameFromQueryTarget());
        $scope.reportService.sorter.columnName = "rowIndex";
        $scope.reportService.sorter.descending = false;

        $scope.reportService.currentFilter = {
            dateFrom: $('#dateFrom').val(),
            dateTo: $('#dateTo').val(),
            timeFrom: $('#timeFrom').val(),
            timeTo: $('#timeTo').val(),
            orgId: $scope.orgId,
            orgName: $scope.orgName,
            contentFullCmp: $scope.contentFullCmp,
            sortColumnName: escape($scope.reportService.sorter.columnName),
            sortDescending: escape($scope.reportService.sorter.descending)
        };

        return $http.get(actionAddress, { params: $scope.reportService.currentFilter })
            .success(function(data) {
                setDataTable(data);
				setLastActiveReportName();
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.exportAction = function(exportType) {
        actionAddress = $scope.reportService.getDownloadActionUrl(lastActiveReportName, exportType);
        return $http.get(actionAddress)
            .success(function(data) {
                $scope.reportService.exportReportFile(actionAddress, exportType);
            })
            .error(function(response) {
                exceptionViewer(response, false);
            });
    };

    $scope.toggleCalendar = function (datePickerId) {
        $scope[datePickerId] = $scope.reportService.toggleCalendar($scope[datePickerId]);
    };

    $scope.resetAction = function () {
        $scope.toggleRssResult = false;
        $scope.toggleSssResult = false;
        $scope.toggleAlert = false;
        $scope.dateFrom = $scope.reportService.getToday();
        $scope.dateTo = $scope.reportService.getToday();
        $scope.orgId = "";
        $scope.orgName = "";
        $scope.queryTarget = "收文";
        $scope.contentFullCmp = false;
        $('#timeFrom').selectpicker("val", "00");
        $('#timeTo').selectpicker("val", "23");

		setLastActiveReportName();
    };

    function setDataTable(viewData, isInit) {
        if ($.trim(viewData) !== '') {
            setLastActiveReportName();
            if (lastActiveReportName === reportConstant.REPORT_R_STATE_STATIC) {
                $scope.toggleRssResult = true;
                $scope.toggleSssResult = false;
                angular.forEach(viewData, function(currentView) {
                    currentView.rowIndex = parseInt(currentView.rowIndex);
                });
                $scope.queryRssResult = viewData;
            } else {
                $scope.toggleRssResult = false;
                $scope.toggleSssResult = true;
                angular.forEach(viewData, function(currentView) {
                    currentView.rowIndex = parseInt(currentView.rowIndex);
                    currentView.userConfirmCount = parseInt(currentView.userConfirmCount);
                    currentView.userConfirmPercent = parseFloat(currentView.userConfirmPercent);
                    currentView.sendExceptionCount = parseInt(currentView.sendExceptionCount);
                    currentView.sendExceptionPercent = parseFloat(currentView.sendExceptionPercent);
                });
                $scope.querySssResult = viewData;
            }
        } else {
            $scope.toggleRssResult = false;
            $scope.toggleSssResult = false;
        }
        $scope.toggleAlert = typeof isInit === "undefined" ?
                ($.trim(viewData) === "") : false;
    }

    function getReportNameFromQueryTarget() {
        return $scope.queryTarget === "收文" ?
                reportConstant.REPORT_R_STATE_STATIC :
                reportConstant.REPORT_S_STATE_STATIC;
    }

	function setLastActiveReportName() {
		lastActiveReportName = getReportNameFromQueryTarget();
	}

});
