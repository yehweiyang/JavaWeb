
var ArchivesApp = angular.module("ArchivesApp", [
    "ui.router",
    "ui.bootstrap",
    "oc.lazyLoad",
    "ngSanitize"
]);

ArchivesApp.config(['$ocLazyLoadProvider', function ($ocLazyLoadProvider) {
    $ocLazyLoadProvider.config({
    });
}]);


ArchivesApp.config(['$controllerProvider', function ($controllerProvider) {
    $controllerProvider.allowGlobals();
}]);

ArchivesApp.factory('userService', function($q, $injector) {
	var authorization = null;

	var service = {
		getAuthorization: function() {
		    return authorization;
	    }, setAuthorization: function(auth) {
    		authorization = auth;
    	}
	};
    return service;
});

ArchivesApp.config(function ($httpProvider) {
	$httpProvider.interceptors.push(function($q, $injector, userService) {
		return {
			request: function(request)
			{
				request.headers.authorization = userService.getAuthorization();
				return request;
			},
			response: function(response) {
				response.data.status = response.status;
				return response;
			},
			responseError: function(rejection) {
				return $q.reject(rejection);
			}
		}
	});
});


ArchivesApp.factory('settings', ['$rootScope', function ($rootScope) {
    var settings = {
        layout: {
            pageSidebarClosed: false,
            pageContentWhite: true,
            pageBodySolid: false,
            pageAutoScrollOnLoad: 1000
        },
        appPath: 'archivesapps',
        assetsPath: 'resources/assets',
        globalPath: 'resources/assets/global',
        layoutPath: 'resources/assets/layouts/layout',
    };

    $rootScope.settings = settings;

    return settings;
}]);

ArchivesApp.controller('AppController', ['$scope', '$rootScope', function ($scope, $rootScope) {
    $scope.$on('$viewContentLoaded', function () {

    });
}]);

ArchivesApp.controller('HeaderController', ['$scope', function ($scope) {
    $scope.$on('$includeContentLoaded', function () {

    });
}]);


ArchivesApp.controller('SidebarController', ['$scope', '$http', function ($scope, $http) {
    $scope.$on('$includeContentLoaded', function () {
        $http.get('/manageWeb/v1/core/menu').then(function (response) {
               $scope.menus = response.data.menu;
         });
    });
}]);


ArchivesApp.controller('PageHeadController', ['$scope', 'userService',  function ($scope, userService) {
    $scope.init = function(auth)
    {
    	userService.setAuthorization(auth);
    }
}]);


ArchivesApp.controller('ThemePanelController', ['$scope', function ($scope) {
    $scope.$on('$includeContentLoaded', function () {

    });
}]);

ArchivesApp.controller('FooterController', ['$scope', function ($scope) {
    $scope.$on('$includeContentLoaded', function () {

    });
}]);

ArchivesApp.run(["$rootScope", "settings", "$state", function ($rootScope, settings, $state) {
    $rootScope.$state = $state;
    $rootScope.$settings = settings;
}]);

