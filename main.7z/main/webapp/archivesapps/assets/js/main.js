
var ArchivesApp = angular.module("ArchivesApp", [
    "ui.router",
    "ui.bootstrap",
    "oc.lazyLoad",
    "ngSanitize"
]);

ArchivesApp.config(['$ocLazyLoadProvider', function ($ocLazyLoadProvider) {
    $ocLazyLoadProvider.config({
    });
}]);


ArchivesApp.config(['$controllerProvider', function ($controllerProvider) {
    $controllerProvider.allowGlobals();
}]);

ArchivesApp.config(function ($httpProvider) {
    var auth = document.getElementById("auth").value;
	$httpProvider.interceptors.push(function($q, $injector) {
		return {
			request: function(request)
			{
				request.headers.authorization = auth;
				return request;
			},
			response: function(response) {
				response.data.status = response.status;
				return response;
			},
			responseError: function(rejection) {
				return $q.reject(rejection);
			}
		}
	});
});


ArchivesApp.factory('settings', ['$rootScope', function ($rootScope) {
    var settings = {
        layout: {
            pageSidebarClosed: false,
            pageContentWhite: true,
            pageBodySolid: false,
            pageAutoScrollOnLoad: 1000
        },
        appPath: 'archivesapps',
        assetsPath: 'resources/assets',
        globalPath: 'resources/assets/global',
        layoutPath: 'resources/assets/layouts/layout',
    };

    $rootScope.settings = settings;

    return settings;
}]);

ArchivesApp.controller('AppController', ['$scope', '$rootScope', function ($scope, $rootScope) {
    $scope.$on('$viewContentLoaded', function () {

    });
}]);

ArchivesApp.controller('HeaderController', ['$scope', '$http', 'archivesConstant', function ($scope, $http, archivesConstant) {
	$scope.$on('$includeContentLoaded', function () {
		$http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + archivesConstant.TOP_MENU_SYSTEMTOOL +'/user/currentAccount').then(function(response) {
			$scope.account = response.data.account;
		});
	});
}]);


ArchivesApp.controller('SidebarController', ['$scope', '$http', '$rootScope', 'archivesConstant', function ($scope, $http, $rootScope, archivesConstant) {
	$scope.$on('$includeContentLoaded', function () {
		$http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/core/menu').then(function (response) {
			$rootScope.menus = response.data.menu;
		});
	});
}]);



ArchivesApp.controller('PageHeadController', ['$scope',  function ($scope) {

}]);


ArchivesApp.controller('FooterController', ['$scope', function ($scope) {
    $scope.$on('$includeContentLoaded', function () {

    });
}]);

ArchivesApp.run(["$rootScope", "settings", "$state", function ($rootScope, settings, $state) {
    $rootScope.$state = $state;
    $rootScope.$settings = settings;
}]);

ArchivesApp.factory('exchangeService', function() {
    var self = this;
    self.innerQueryData;
    self.outQueryData;
	self.exchangeInfo;
	self.detailInfo;

    self.innerIndexPage;
    self.outsideIndexPage;

	var service = {
		getExchange: function() {
		    return self.exchangeInfo;
	    }, setExchange: function(exchange) {
    		self.exchangeInfo = exchange;
    	}, getTransmitDetail: function() {
            return self.detailInfo;
        }, setTransmitDetail: function(detail) {
            self.detailInfo = detail;
        }, getInnerQueryData: function() {
            return self.innerQueryData;
        }, setInnerQueryData: function(data) {
            self.innerQueryData = data;
        }, getOutQueryData: function() {
            return self.outQueryData;
        }, setOutQueryData: function(data) {
            self.outQueryData = data;
        }, getInnerIndexPage: function() {
            return self.innerIndexPage;
        }, setInnerIndexPage: function(index) {
            self.innerIndexPage = index;
        }, getOutsideIndexPage: function() {
            return self.outsideIndexPage;
        }, setOutsideIndexPage: function(index) {
            self.outsideIndexPage = index;
        }
	};
    return service;
});

ArchivesApp.factory('registerService', function() {
    var self = this;
    self.addressQueryData;
    self.addressIndexPage;

    self.numberQueryData;
    self.numberIndexPage;

    self.formQueryData;
    self.formIndexPage;

    self.expireIndexPage;

	var service = {
        getAddressQueryData: function() {
            return self.addressQueryData;
        }, setAddressQueryData: function(data) {
            self.addressQueryData = data;
        }, getAddressCurrentPage: function() {
            return self.addressIndexPage;
        }, setAddressCurrentPage: function(index) {
            self.addressIndexPage = index;
        }, getNumberQueryData: function() {
            return self.numberQueryData;
        }, setNumberQueryData: function(data) {
            self.numberQueryData = data;
        }, getNumberCurrentPage: function() {
            return self.numberIndexPage;
        }, setNumberCurrentPage: function(index) {
            self.numberIndexPage = index;
        }, getFormQueryData: function() {
            return self.formQueryData;
        }, setFormQueryData: function(data) {
            self.formQueryData = data;
        }, getFormIndexPage: function() {
            return self.formIndexPage;
        }, setFormIndexPage: function(index) {
            self.formIndexPage = index;
        }, getExpireIndexPage: function() {
            return self.expireIndexPage;
        }, setExpireIndexPage: function(index) {
            self.expireIndexPage = index;
        }
	};
    return service;
});

