		var Login = function () {

			var handleLogin = function() {
				$('.login-form').validate({
			            errorElement: 'span',
			            errorClass: 'help-block',
			            focusInvalid: false,
			            rules: {
			                userName: {
			                    required: true
			                },
			                password: {
			                    required: true
			                }
			            },

			            messages: {
			               userName: {
	                                required: "請輸入使用者帳號"
	                        },
	                        password: {
	                                required: "請輸入卡片pin碼"
	                        }
			            },

			            invalidHandler: function (event, validator) {
			                $('.alert-danger', $('.login-form')).show();
			            },

			            highlight: function (element) {
			                $(element)
			                    .closest('.form-group').addClass('has-error');
			            },

			            success: function (label) {
			                label.closest('.form-group').removeClass('has-error');
			                label.remove();
			            },

			            errorPlacement: function (error, element) {
			                error.insertAfter(element.closest('.input-icon'));
			            },

			            submitHandler: function (form) {
			                form.submit();
			            }
			        });

			        $('.login-form input').keypress(function (e) {
			            if (e.which == 13) {
			                if ($('.login-form').validate().form()) {
			                    $('.login-form').submit();
			                }
			                return false;
			            }
			        });
			}

			var handleForgetPassword = function () {
				$('.forget-form').validate({
			            errorElement: 'span',
			            errorClass: 'help-block',
			            focusInvalid: false,
			            ignore: "",
			            rules: {
			                eMailAddr: {
			                    required: true,
			                    eMailAddr: true
			                }
			            },

			            messages: {
			                eMailAddr: {
			                    required: "請填入Email"
			                }
			            },

			            invalidHandler: function (event, validator) {

			            },

			            highlight: function (element) {
			                $(element)
			                    .closest('.form-group').addClass('has-error');
			            },

			            success: function (label) {
			                label.closest('.form-group').removeClass('has-error');
			                label.remove();
			            },

			            errorPlacement: function (error, element) {
			                error.insertAfter(element.closest('.input-icon'));
			            },

			            submitHandler: function (form) {
			                form.submit();
			            }
			        });

			        $('.forget-form input').keypress(function (e) {
			            if (e.which == 13) {
			                if ($('.forget-form').validate().form()) {
			                    $('.forget-form').submit();
			                }
			                return false;
			            }
			        });

			        jQuery('#forget-password').click(function () {
			            jQuery('.login-form').hide();
			            jQuery('.forget-form').show();
			        });

			        jQuery('#back-btn').click(function () {
			            jQuery('.login-form').show();
			            jQuery('.forget-form').hide();
			        });

			}

			var handleRegister = function () {

				        function format(state) {
		            if (!state.id) { return state.text; }
		            var $state = $(
		             '<span><img src="../assets/global/img/flags/' + state.element.value.toLowerCase() + '.png" class="img-flag" /> ' + state.text + '</span>'
		            );
		            
		            return $state;
		        }

		        if (jQuery().select2 && $('#country_list').size() > 0) {
		            $("#country_list").select2({
			            placeholder: '<i class="fa fa-map-marker"></i>&nbsp;Select a Country',
			            templateResult: format,
		                templateSelection: format,
		                width: 'auto', 
			            escapeMarkup: function(m) {
			                return m;
			            }
			        });


			        $('#country_list').change(function() {
			            $('.register-form').validate().element($(this));
			        });
		    	}


		         $('.register-form').validate({
			            errorElement: 'span',
			            errorClass: 'help-block',
			            focusInvalid: false,
			            ignore: "",
			            rules: {			                
			                userName: {
			                    required: true
			                },
			                fullName: {
			                    required: true
			                },
			                eMailAddr: {
			                    required: true,
			                    eMailAddr: true
			                },
			                phoneLocal: {
			                    required: true
			                },			
			                phoneNum: {
			                    required: true
			                },			
			                phonExt: {
			                    required: true
			                },			
			                captcha: {
			                	required: true
			                }       
			            },

			            messages: {
			                userName: {
			                    required: "請填入帳號"
			                },
			                fullName: {
			                    required: "請填入姓名"
			                },
			                eMailAddr: {
			                    required: "請填入Email",
			                    eMailAddr: "請填入正確的Email"
			                },			                
			                phoneLocal: {
			                    required: "請填入電話區號"
			                },			
			                phoneNum: {
			                    required: "請填入電話"
			                },			
			                phonExt: {
			                    required: "請填入電話分號 "
			                },
			                 captcha: {
			                	required: "請填入圖形驗證嗎"
			                }     	
			                		               
			            },

			            invalidHandler: function (event, validator) {

			            },

			            highlight: function (element) {
			                $(element)
			                    .closest('.form-group').addClass('has-error');
			            },

			            success: function (label) {
			                label.closest('.form-group').removeClass('has-error');
			                label.remove();
			            },

			            errorPlacement: function (error, element) {
			                if (element.attr("name") == "tnc") {
			                    error.insertAfter($('#register_tnc_error'));
			                } else if (element.closest('.input-icon').size() === 1) {
			                    error.insertAfter(element.closest('.input-icon'));
			                } else {
			                	error.insertAfter(element);
			                }
			            },

			            submitHandler: function (form) {
			                form.submit();
			            }
			        });

					$('.register-form input').keypress(function (e) {
			            if (e.which == 13) {
			                if ($('.register-form').validate().form()) {
			                    $('.register-form').submit();
			                }
			                return false;
			            }
			        });

			        jQuery('#register-btn').click(function () {
			            jQuery('.login-form').hide();
			            jQuery('.register-form').show();
			        });

			        jQuery('#register-back-btn').click(function () {
			            jQuery('.login-form').show();
			            jQuery('.register-form').hide();
			        });
			}
		    
		    return {
		        init: function () {
		        	
		            handleLogin();
		            handleForgetPassword();
		            handleRegister();    

				     $.backstretch([
		                                "img/bg/1.jpg",
		                                "img/bg/2.jpg",
		                                "img/bg/3.jpg",
		                                "img/bg/4.jpg"
		                                ], {
		                                  fade: 1000,
		                                  duration: 8000
		                                }
		                            );
		        }
		    };
		}();
		jQuery(document).ready(function() {
		    Login.init();
		});