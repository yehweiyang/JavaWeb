ArchivesApp.constant('archivesConstant', {
    WEB_ROOT_PATH: $('#ng_load_plugins_before').attr("value"),
    REST_API_VERSION_PATH: '/v1',
    APP_PATH: 'archivesapps',
    TOP_MENU_SYSTEMTOOL: '/systemTool',
    TOP_MENU_ADDRESSSEARCH: '/addressSearch',

    ROLE: '權限',
    CHOICE: '請選擇',
    INPUT: '請輸入',
    CANT_EMPTY: '不可為空',
    NO_UPDATE: '尚未做任何修改',
    NO_INPUT: '尚未輸入資料',
    INPUT_ERROR: '輸入格式錯誤',

    INSERT_SUCCESS_MSG: '新增成功',
    UPDATE_SUCCESS_MSG: '修改成功',
    DELETA_SUCCESS_MSG: '刪除成功',

    ALL_CENTER_STATUS: '全部',
    ACTIVE_CENTER_STATUS: '啟用',
    PAUSE_CENTER_STATUS: '暫停',
    STOP_CENTER_STATUS: '停用',

    SHOW_PURPORT_MSG: '顯示主旨訊息',
    HIDE_PURPORT_MSG: '隱藏主旨訊息',
    SENDER_TITLE_MSG: ' 交換記錄彙整 / 公文傳送訊息',
    RECEIVE_TITLE_MSG: ' 交換記錄彙整 / 公文接收訊息',
    INNER_TITLE_MSG: '內部對內部交換',
    OUT_TITLE_MSG: '內部對外部交換',
    INNER_TRANSMIT_TYPE: 'INNER',
    OUT_TRANSMIT_TYPE: 'OUTTER',
    SAVE_SUCCESS_MSG: '儲存成功',

    BUTTON_SUBMIT_MSG: '確定',
    BUTTON_EXPORT_MSG: '轉檔成功',
    BUTTON_RETURN_MSG: '返回列表',
    FORM_INVALID_MSG: '輸入格式錯誤'
});