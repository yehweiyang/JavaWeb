ArchivesApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {

    var toLowerCamelCase = function(menuCode) {
        return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
    }
console.log('2222222');
    var appPath = 'archivesapps';
    $.post('/manageWeb/v1/core/router').then(function(response) {
    console.log('1111111111');
console.log(response)

var Name = null;
var Code = null;
var Id =null;
var number= 1;
        angular.forEach(response, function(menuName, menuCode) {
        var i =1;
        angular.forEach(menuName, function(Code1,Name1 ) {
        if(Name1=='menuCode'){
        console.log("1111111----"+i);
        i++;
        Code = Code1;
        }else if(Name1=='menuName'){
        console.log("2222222----"+i);
         i++;
        Name = Code1;
        }else{
        console.log("3333333----"+i);
        Id=Code1;
        }
        if(i==5){
        console.log("有幾次RRRRR===>"+number);
        number++;

        }
        console.log('Code==>'+Code);
        console.log('Name==>'+Name);
        console.log('Id==>'+Id);

//        console.log('Name1==>'+i+'        '+Name1)
//        console.log('Code1==>'+i+'        '+Code1)
        i++;
        })
//console.log('menuName==>'+menuName)
//console.log('menuCode==>'+menuCode)
            $stateProvider
                .state(menuCode, {
                    url: '/'+menuCode,
                    views: {
                        "content": {
                            templateUrl: appPath + '/views/' +
                                    toLowerCamelCase(menuCode) + '.html'
                            ,
                            controller: menuCode + "Controller"
                        }
                    },
                    data: {
                        pageTitle: menuName
                    },
                    resolve: {
                        deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                            return $ocLazyLoad.load({
                                name: 'ArchivesApp',
                                insertBefore: '#ng_load_plugins_before',
                                files: [
                                    $rootScope.settings.appPath + '/controllers/' + menuCode + 'Controller.js',
                                ]
                            });
                        }]
                    }
                })
        })

        $stateProvider
            .state('home', {
                url: '/home',
                views: {
                    "content": {
                        templateUrl:  appPath + '/views/home.html'
                        ,
                        controller: "HomeController"
                    }
                },
                resolve: {
                    deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                        return $ocLazyLoad.load({
                            name: 'ArchivesApp',
                            insertBefore: '#ng_load_plugins_before',
                            files: [
                                $rootScope.settings.appPath + '/controllers/HomeController.js',
                            ]
                        });
                    }]
                }
            })



    })
}]);