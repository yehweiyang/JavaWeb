ArchivesApp.config(['$stateProvider', '$urlRouterProvider', 'archivesConstant', function($stateProvider, $urlRouterProvider, archivesConstant) {
    $urlRouterProvider.otherwise("/home");

    //html名稱改小寫駝峰

    var toLowerCamelCase = function(menuCode) {
        return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
    };
        //定義父menu
    var topMenuCode = null;
    //project名
    $.ajaxSetup({
        async: false
    });
    // 使用get解決csrf保護
    $.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/core/router').then(function(response) {
        angular.forEach(response, function(value, key) {
            angular.forEach(value, function(value1, key1) {
                //給父menu賦值
                topMenuCode = value1.menuCode;
                angular.forEach(value1, function(value2, key2) {
                    angular.forEach(value2, function(value3, key3) {
                        if (typeof value3.menuName != 'undefined') {
                            $stateProvider
                                .state(value3.menuCode, {
                                    url: '/' + topMenuCode + '/' + value3.menuCode,
                                    views: {
                                        "content": {
                                            templateUrl: archivesConstant.APP_PATH + '/views/' + topMenuCode + '/' +
                                                toLowerCamelCase(value3.menuCode) + '.html',
                                            controller: value3.menuCode + "Controller"
                                        }
                                    },
                                    data: {
                                        pageTitle: value3.menuName
                                    },
                                    resolve: {
                                        deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                                            return $ocLazyLoad.load({
                                                name: 'ArchivesApp',
                                                insertBefore: '#ng_load_plugins_before',
                                                files: [
                                                    archivesConstant.APP_PATH + '/controllers/' + value3.menuCode + 'Controller.js',
                                                ]
                                            });
                                        }]
                                    }
                                })
                        }
                    });
                });
            });
        });
    })
    $stateProvider
        .state('home', {
            url: '/home',
            views: {
                "content": {
                    templateUrl: archivesConstant.APP_PATH + '/views/home.html',
                    controller: "HomeController"
                }
            },
            data: {
                pageTitle: ''
            },
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            archivesConstant.APP_PATH + '/controllers/HomeController.js',
                        ]
                    });
                }]
            }
        })
        .state('DocumentExchange', {
            url: "/ChangeRecord/DocumentExchange",
            views: {
                "content": {
                    templateUrl: archivesConstant.APP_PATH + "/views/ChangeRecord/documentExchange.html",
                    controller: "DocumentExchangeController"
                }
            },
            data: {pageTitle: '交換記錄彙整'},
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            archivesConstant.APP_PATH + '/controllers/DocumentExchangeController.js',
                        ]
                    });
                }]
            }
        })
        .state('DocumentExchangeDetail', {
            url: "/ChangeRecord/DocumentExchangeDetail",
            views: {
                "content": {
                    templateUrl: archivesConstant.APP_PATH + "/views/ChangeRecord/documentExchangeDetail.html",
                    controller: "DocumentExchangeDetailController"
                }
            },
            data: {pageTitle: '交換記錄彙整'},
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function ($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            archivesConstant.APP_PATH + '/controllers/DocumentExchangeDetailController.js',
                        ]
                    });
                }]
            }
        })
}]);