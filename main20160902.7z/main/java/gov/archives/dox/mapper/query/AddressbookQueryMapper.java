package gov.archives.dox.mapper.query;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import gov.archives.dox.domain.entity.AddressBookInfoEntity;
import gov.archives.dox.domain.entity.AddressbookEntity;

/**
 * AddressbookQueryMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
public interface AddressbookQueryMapper {
    String KEY_ORG_ID = "agencyId";
    String KEY_UNIT_ID = "agencyUnitId";

    public List<AddressBookInfoEntity> findByLikeMap(Map<String, Object> queryMap);

    public List<AddressBookInfoEntity> findByExactMatchMap(Map<String, Object> queryMap);

    AddressbookEntity findByOrgUnitId(Map<String, Object> queryMap);
}
