package gov.archives.dox.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.controller.RestControllerBase;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.service.ActionLogService;
import gov.archives.dox.conf.DoxConf;
import gov.archives.dox.domain.entity.AddressBookInfoEntity;
import gov.archives.dox.domain.entity.AddressbookEntity;
import gov.archives.dox.domain.entity.CenterEntity;
import gov.archives.dox.message.DoxErrorCode;
import gov.archives.dox.message.DoxErrorMessage;
import gov.archives.dox.service.AddressbookService;
import gov.archives.dox.service.CenterListService;

@RestController
@RequestMapping(path = CoreConf.REST_API_VERSION + "/addressSearch")
public class RegisterSearchController extends RestControllerBase {
    private static final String GATEWAY_ID = "gatewayId";
    private static final String AGENCY_ID = "agencyId";
    private static final String AGENCY_UNIT_ID = "agencyUnitId";
    private static final String AGENCY_NAME = "agencyName";
    private static final String MODULE_NAME = "地址簿查詢模組";

    @Autowired
    CenterListService centerListService;

    @Autowired
    AddressbookService addressBookService;

    @Autowired
    private ActionLogService actionLogService;

    public RegisterSearchController() {
        this.setModuleName(MODULE_NAME);
    }

    @RequestMapping(value = "/center/list",
                    method = RequestMethod.GET)
    public ResponseEntity<List<CenterEntity>> getAllCenter() {
        return new ResponseEntity<>(centerListService.getAllCenterInfo(), HttpStatus.OK);
    }

    @RequestMapping(value = "/list",
                    method = RequestMethod.GET)
    public ResponseEntity<List<AddressBookInfoEntity>> getAllAddressBook(HttpServletRequest request,
            @RequestParam Map<String, Object>
                    params) {
        try {
            addressBookParamsValidate(params);
            List<AddressBookInfoEntity> entityList = addressBookService.getAllAddressBook(params);
            actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                    HttpStatus.OK.getReasonPhrase(),
                    DoxConf.SUCCESS_MSG,
                    CoreConf.EVENT_LEVEL_LOW));
            return new ResponseEntity<>(addressBookService.getAllAddressBook(params), HttpStatus.OK);
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(), e.getErrorCode(),
                            e.getErrorMessage(),
                            CoreConf.EVENT_LEVEL_LOW));
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }

    private void addressBookParamsValidate(Map<String, Object> params) {
        Object gatewayId = params.get(GATEWAY_ID);
        if (!validateFiled((String) gatewayId, CoreConf.DIGIT_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0013_ERROR_MESSAGE,
                    DoxErrorCode.ED0013_CENTER_ID_FORMAT_INCORRECT);
        }
        Object agencyId = params.get(AGENCY_ID);
        if (!validateFiled((String) agencyId, CoreConf.ALPHANUMERIC_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0006_ERROR_MESSAGE,
                    DoxErrorCode.ED0006_AGENCY_ID_FORMAT_INCORRECT);
        }
        Object agencyUnitId = params.get(AGENCY_UNIT_ID);
        if (!validateFiled((String) agencyUnitId, CoreConf.ALPHANUMERIC_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0008_ERROR_MESSAGE,
                    DoxErrorCode.ED0008_UNIT_ID_FORMAT_INCORRECT);
        }
        Object agencyName = params.get(AGENCY_NAME);
        if (!validateFiled((String) agencyName, CoreConf.ALPHANUMERIC_NLS_PATTERN)) {
            throw new ArchivesException(DoxErrorMessage.ED0014_ERROR_MESSAGE,
                    DoxErrorCode.ED0014_AGENCY_NAME_FORMAT_INCORRECT);
        }
    }

    @RequestMapping(value = "/detail",
                    method = RequestMethod.GET)
    public ResponseEntity<AddressbookEntity> getAddressBookDetail(HttpServletRequest request, @RequestParam Map<String, Object>
            params) {
        try {
            addressBookParamsValidate(params);
            AddressbookEntity entity = addressBookService.getByOrgUnitId(params);
            actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                    HttpStatus.OK.getReasonPhrase(),
                    DoxConf.SUCCESS_MSG,
                    CoreConf.EVENT_LEVEL_LOW));
            return new ResponseEntity<>(entity, HttpStatus.OK);
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(), e.getErrorCode(),
                            e.getErrorMessage(),
                            CoreConf.EVENT_LEVEL_LOW));
            throw new ArchivesException(e.getErrorMessage(), e.getErrorCode());
        }
    }
}
