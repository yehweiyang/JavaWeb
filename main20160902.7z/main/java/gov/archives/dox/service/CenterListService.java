package gov.archives.dox.service;

import java.util.List;

import gov.archives.dox.domain.entity.CenterEntity;

public interface CenterListService {
    List<CenterEntity> getAllCenterInfo();
}
