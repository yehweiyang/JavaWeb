# DOX Service

包含註冊資料查詢、分文轉文機關查詢與設定、備援機制切換與查詢等功能之 Service