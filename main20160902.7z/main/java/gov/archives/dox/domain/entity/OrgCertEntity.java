package gov.archives.dox.domain.entity;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

@Alias("OrgCertInfo")
public class OrgCertEntity {
    private String applyType;
    private String smartCardType;
    private String signDigitalNum;
    private String encryptDigitalNum;
    private String effectBegin;
    private String effectEnd;
    private boolean isDefault;
    private String DefaultCert;
    private String certCardSerial;
    private String publicKeySerial;

    public String getSmartCardType() {
        return smartCardType;
    }

    public void setSmartCardType(String smartCardType) {
        this.smartCardType = smartCardType;
    }

    public String getApplyType() {
        return applyType;
    }

    public void setApplyType(String applyType) {
        this.applyType = applyType;
    }

    public String getEncryptDigitalNum() {
        return encryptDigitalNum;
    }

    public void setEncryptDigitalNum(String encryptDigitalNum) {
        this.encryptDigitalNum = encryptDigitalNum;
    }

    public String getSignDigitalNum() {
        return signDigitalNum;
    }

    public void setSignDigitalNum(String signDigitalNum) {
        this.signDigitalNum = signDigitalNum;
    }

    public String getEffectBegin() {
        return effectBegin;
    }

    public void setEffectBegin(String effectBegin) {
        this.effectBegin = effectBegin;
    }

    public String getEffectEnd() {
        return effectEnd;
    }

    public void setEffectEnd(String effectEnd) {
        this.effectEnd = effectEnd;
    }

    public boolean isDefault() {
        return isDefault;
    }

    public void setDefault(boolean aDefault) {
        isDefault = aDefault;
    }

    public String getDefaultCert() {
        return DefaultCert;
    }

    public void setDefaultCert(String defaultCert) {
        DefaultCert = defaultCert;
    }

    public String getCertCardSerial() {
        return certCardSerial;
    }

    public void setCertCardSerial(String certCardSerial) {
        this.certCardSerial = certCardSerial;
    }

    public String getPublicKeySerial() {
        return publicKeySerial;
    }

    public void setPublicKeySerial(String publicKeySerial) {
        this.publicKeySerial = publicKeySerial;
    }
}
