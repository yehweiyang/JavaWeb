package gov.archives.exchange.conf;

/**
 * ExchangeConf
 * <br>
 * exchange package 之共用設定
 * <br>
 * gemhuang, 2016/8/16.
 */
public class ExchangeConf {
    public static final String QUERY_TX_MANAGER = "exchangeQueryTxManager";
    public static final String COMMAND_TX_MANAGER = "exchangeCommandTxManager";
}
