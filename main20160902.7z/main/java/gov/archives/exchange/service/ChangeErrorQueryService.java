package gov.archives.exchange.service;

import java.util.List;
import java.util.Map;

import gov.archives.exchange.domain.entity.ChangeErrorQueryEntity;
import gov.archives.exchange.domain.entity.vo.ChangeErrorQueryVo;

/**
 * ChangeErrorQueryService
 * <p>
 * Created by WeiYang on 2016/8/17.
 */
public interface ChangeErrorQueryService {
    List<ChangeErrorQueryVo> getErrorQueryList(ChangeErrorQueryVo changeErrorQueryVo);
    ChangeErrorQueryVo getErrorQueryID(String ID);

}
