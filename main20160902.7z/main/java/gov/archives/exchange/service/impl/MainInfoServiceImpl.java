package gov.archives.exchange.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import org.iii.common.util.PreconditionUtils;

import gov.archives.exchange.conf.ExchangeConf;
import gov.archives.exchange.domain.entity.MainInfoEntity;
import gov.archives.exchange.mapper.query.MainInfoQueryMapper;
import gov.archives.exchange.service.MainInfoService;

/**
 * MainInfoServiceImpl
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
@Service
@Transactional
public class MainInfoServiceImpl implements MainInfoService {

    @Autowired
    private MainInfoQueryMapper queryMapper;

    @Override
    @Transactional(value = ExchangeConf.QUERY_TX_MANAGER,
            readOnly = true)
    public MainInfoEntity getByExchangeId(String exchangeId) {
        PreconditionUtils.checkArguments(exchangeId);

        return queryMapper.findByExchangeId(exchangeId);
    }
}
