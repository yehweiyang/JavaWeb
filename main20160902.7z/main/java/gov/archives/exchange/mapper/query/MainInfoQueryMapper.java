package gov.archives.exchange.mapper.query;

import gov.archives.exchange.domain.entity.MainInfoEntity;

/**
 * MainInfoQueryMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/8/16.
 */
public interface MainInfoQueryMapper {
    MainInfoEntity findByExchangeId(String exchangeId);
}
