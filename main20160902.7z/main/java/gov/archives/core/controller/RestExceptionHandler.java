package gov.archives.core.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import static org.springframework.http.HttpStatus.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import gov.archives.core.domain.vo.ExceptionMessage;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;

@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(RestExceptionHandler.class);

    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
            HttpStatus status, WebRequest request) {
        log.error("getRemoteUser: " + request.getRemoteUser());
        log.error("body: " + body);
        String error = ex.getMessage();
        log.error("getMessage: " + error);
        log.error("HttpStatus: " + status.value());
        return new ResponseEntity<Object>(body, headers, status);
    }

    @ExceptionHandler({ArchivesException.class})
    public ResponseEntity<Object> handleArchivesException(final ArchivesException ex, final WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(ex,
                ExceptionMessage.getInstanceByCodeAndMessage(ex.getErrorCode(), ex.getMessage()), headers,
                BAD_REQUEST, request);
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<Object> handleDefaultException(final Exception ex, final WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return handleExceptionInternal(ex,
                ExceptionMessage.getInstanceByCodeAndMessage(CoreErrorCode.SYSTEM_ERROR,
                        CoreErrorMessage.findByCode(CoreErrorCode.SYSTEM_ERROR)),
                headers, BAD_REQUEST, request);
    }
}
