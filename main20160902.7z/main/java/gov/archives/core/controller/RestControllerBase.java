package gov.archives.core.controller;

import java.sql.Timestamp;
import java.util.regex.Pattern;

import org.springframework.http.HttpStatus;

import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.exception.RestApplicationException;

public class RestControllerBase {
    private String moduleName;

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    protected ActionLogEntity initializeLogEntity(String account, String remoteIp, String errorCode, String resultMessage,
            String eventLevel) {
        if (null == account) { throw new RestApplicationException(HttpStatus.UNAUTHORIZED.getReasonPhrase()); }
        ActionLogEntity actionLogEntity = new ActionLogEntity();
        actionLogEntity.initSave(account);
        actionLogEntity.setActionItem(moduleName);
        actionLogEntity.setActionResult(resultMessage);
        actionLogEntity.setErrorCode(errorCode);
        actionLogEntity.setEventLevel(eventLevel);
        actionLogEntity.setActorAccount(account);
        actionLogEntity.setRemoteIp(remoteIp);
        actionLogEntity.setActionTime(new Timestamp(System.currentTimeMillis()));
        return actionLogEntity;
    }

    protected boolean validateFiled(final String filed, String regex) {
        if (null != filed && 0 < filed.length()) {
            return Pattern.compile(regex).matcher(filed).matches();
        }
        return true;
    }

    protected boolean validateNotEmptyFiled(final String filed, String regex) {
        if (null != filed && 0 < filed.length()) {
            return Pattern.compile(regex).matcher(filed).matches();
        }
        return false;
    }
}
