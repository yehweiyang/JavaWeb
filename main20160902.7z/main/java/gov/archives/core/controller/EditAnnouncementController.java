package gov.archives.core.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;

import static org.springframework.http.HttpStatus.*;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static gov.archives.core.conf.CoreConf.*;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.SystemAnnounceVO;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.service.SmartCardIdentityService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.EscapeUtils;

@RestController
@RequestMapping(path = REST_API_VERSION + "/systemTool")
public class EditAnnouncementController extends RestControllerBase {
    private static final String HTML_TOP = "<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">"
            + "<title></title></head><body><div>";
    private static final String HTML_BOTTOM = "</div></body></html>";
    private static final String HTML_FILE_DIR = "AnnounceHtmlFiles";
    private static final String HTML_FILE_NAME = "Announcement-";
    private static final String HTML_FILE_SUFFIX = ".html";
    private static final String REST_ANNOUNCE = "/announce";
    private static final String MODULE_NAME = "編輯系統公告模組";

    @Autowired
    private SmartCardIdentityService smartCardIdentityService;

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private ActionLogService actionLogService;

    public EditAnnouncementController() {
        this.setModuleName(MODULE_NAME);
    }

    private void transHtmlFile(String realPath, String fileName, String notifyMessage) {
        String certPath = realPath + HTML_FILE_DIR;
        // creates the save directory if it does not exists
        File htmlSaveDir = new File(certPath, fileName);
        boolean isExits = true;
        if (!htmlSaveDir.getParentFile().exists()) {
            isExits = htmlSaveDir.getParentFile().mkdir();
        }
        if (isExits) {
            try {
                String html = new String("".getBytes(), Charset.forName("UTF-8"));
                html += HTML_TOP;
                html += notifyMessage;
                html += HTML_BOTTOM;
                FileUtils.writeStringToFile(htmlSaveDir, html, Charset.forName("UTF-8"));
            } catch (IOException e) {
                throw new ArchivesException(CoreErrorCode.FILE_SAVE_FAIL);
            }
        }
    }

    @RequestMapping(value = REST_ANNOUNCE,
                    method = RequestMethod.POST)
    public ResponseEntity<Void> postAnnouncement(HttpServletRequest request, @RequestBody SystemAnnounceVO annonce) {
        try {
            if (null == annonce.getAnnounceMessage()) {
                throw new ArchivesException(CoreErrorMessage.findByCode(CoreErrorCode.SYSTEM_ERROR), CoreErrorCode.SYSTEM_ERROR);
            }
            UserInfoEntity userInfo = userInfoService.getByAccount(request.getRemoteUser());
            File file =
                    new File(request.getServletContext().getRealPath("") + CERT_FOLDER, userInfo.getCertCardNum() + SUFFIX_CERT);
            smartCardIdentityService.smartCarVerifyHandler(annonce,
                    file,
                    userInfo.getCertHash(),
                    UUID.fromString(annonce.getToken()),
                    System.currentTimeMillis());

            annonce.setAnnounceMessage(EscapeUtils.escapeHtml(annonce.getAnnounceMessage()));
            String realPath = request.getServletContext().getRealPath("");
            String date = LocalDateTime.now().toDateTime().toString(DATE_FORMAT);
            String fileName = HTML_FILE_NAME + date + HTML_FILE_SUFFIX;
            transHtmlFile(realPath, fileName, annonce.getAnnounceMessage());
            actionLogService.insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(),
                    HttpStatus.OK.getReasonPhrase(),
                    "Success",
                    CoreConf.EVENT_LEVEL_LOW));
            return new ResponseEntity<>(CREATED);
        } catch (ArchivesException e) {
            actionLogService
                    .insert(initializeLogEntity(request.getRemoteUser(), request.getRemoteAddr(), e.getErrorCode(),
                            e.getErrorMessage(),
                            CoreConf.EVENT_LEVEL_LOW));
            throw ArchivesException.getInstanceByErrorCode(e.getMessage());
        }
    }
}
