package gov.archives.core.mapper.command;

import java.util.UUID;

import gov.archives.core.domain.entity.RoleMenuMappingEntity;

/**
 * RoleMenuMappingCommandMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/19.
 */
public interface RoleMenuMappingCommandMapper {
    void save(RoleMenuMappingEntity entity);

    void removeByRoleSysId(UUID roleSysId);
}
