package gov.archives.core.mapper.query;

import java.util.Map;

import gov.archives.core.domain.entity.LogInControlEntity;

/**
 * LogInControlQueryMapper
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
public interface LogInControlQueryMapper {
    String KEY_SESSION_ID = "sessionId";
    String KEY_LOGIN_ACCOUNT = "loginAccount";

    LogInControlEntity findBySessionIdAndAccount(Map<String, String> params);
    LogInControlEntity findBySessionIdAndAccountMaxlimitTime(Map<String, String> params);
}
