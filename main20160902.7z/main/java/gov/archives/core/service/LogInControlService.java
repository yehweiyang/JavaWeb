package gov.archives.core.service;

import gov.archives.core.domain.entity.LogInControlEntity;

/**
 * LogInControlService
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
public interface LogInControlService {
    void insert(LogInControlEntity loginCtrl);
    void update(LogInControlEntity loginCtrl);

    void delete(LogInControlEntity loginCtrl);

    LogInControlEntity getBySessionIdAndAccount(String sessionId, String loginAccount);
    LogInControlEntity getBySessionIdAndAccountMaxlimitTime(String sessionId, String loginAccount);

}
