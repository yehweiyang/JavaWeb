package gov.archives.core.service.impl;

import java.io.File;
import java.util.Date;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;
import org.iii.security.conf.SecurityConfig;
import org.iii.security.hash.HashGenerators;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.SignCertData;
import gov.archives.core.domain.vo.VerifyResult;
import gov.archives.core.message.CoreErrorCode;
import gov.archives.core.security.DigitalSignHandle;
import gov.archives.core.service.SmartCardIdentityService;

@Service
public class SmartCardIdentityServiceImpl implements SmartCardIdentityService {
    private static final Logger log = LoggerFactory.getLogger(SmartCardIdentityServiceImpl.class);

    @Autowired
    private DigitalSignHandle pkcs1Handle;

    @Override
    public void smartCarVerifyHandler(SignCertData signCert, File file, String signCertHash, UUID uuid,
            long lastAccessedTime) {
        if (file.exists()) {
            String derASN1 = pkcs1Handle.readCertFile(file);
            if (pkcs1Handle.isCredentialsExpired(new Date(lastAccessedTime))) {
                throw new CredentialsExpiredException(CoreErrorCode.CARD_EXPIRED);
            }
            String signCertSHA256Hash =
                    HashGenerators.getInstanceByAlgorithm(SecurityConfig.ALGORITHM_SHA256).getHashByString(derASN1);
            if (!signCertHash.equals(signCertSHA256Hash)) {
                throw new BadCredentialsException(CoreErrorCode.CARD_NOT_MATCH_DATA);
            }

            if (!uuid.toString()
                     .equals(signCert.getToken()) || !pkcs1Handle.verifySignature(signCert)) {
                throw new BadCredentialsException(CoreErrorCode.SIGNATURE_ERROR);
            }
        } else {
            throw new BadCredentialsException(CoreErrorCode.CARD_NOT_AVAILABLE);
        }
    }

    @Override
    public void checkSignCert(File file, long lastAccessedTime) {
        if (file.exists()) {
            pkcs1Handle.readCertFile(file);
            if (pkcs1Handle.isCredentialsExpired(new Date(lastAccessedTime))) {
                throw new CredentialsExpiredException(CoreErrorCode.CARD_EXPIRED);
            }
        } else {
            throw new BadCredentialsException(CoreErrorCode.CARD_NOT_AVAILABLE);
        }
    }

    @Override
    public String saveRequestCertificate(String base64Cert, File file, String certCardNum, long lastAccessedTime) {
        String certSHA256Hash = pkcs1Handle.transBase64CertIntoX509Cert(base64Cert);
        if (pkcs1Handle.isCredentialsExpired(new Date(lastAccessedTime))) {
            throw new CredentialsExpiredException(CoreErrorCode.CARD_EXPIRED);
        }
        File certPath = file.toPath().resolve(CoreConf.CERT_FOLDER).toFile();
        File resultFile = new File(certPath, certCardNum + CoreConf.SUFFIX_CERT);
        if (!IOUtils.isFileExist(resultFile)) {
            FileSystemUtils.checkFolder(certPath);
            pkcs1Handle.saveCertFile(resultFile);
        }
        return certSHA256Hash;
    }

    @Override
    public void cleanSignCertFile(File certFile) {
        IOUtils.deleteFile(certFile);
    }

    @Override
    public VerifyResult userIdentityException(AuthenticationException e) {
        VerifyResult verifyResult = pkcs1Handle.getVerifyResult();
        verifyResult.setIsVerify(false);
        verifyResult.setErrorCode(e.getMessage());
        verifyResult.setErrorMessage(e.getMessage());
        log.error("userIdentityException: " + verifyResult.toString());
        return verifyResult;
    }
}
