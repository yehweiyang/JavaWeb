package gov.archives.core.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.LogInControlEntity;
import gov.archives.core.mapper.command.LogInControlCommandMapper;
import gov.archives.core.mapper.query.LogInControlQueryMapper;
import gov.archives.core.service.LogInControlService;

/**
 * LogInControlServiceImpl
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
@Service
@Transactional
public class LogInControlServiceImpl implements LogInControlService {

    @Autowired
    private LogInControlQueryMapper queryMapper;

    @Autowired
    private LogInControlCommandMapper commandMapper;

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void insert(LogInControlEntity loginControlEntry) {
        PreconditionUtils.checkArguments(loginControlEntry);

        commandMapper.save(loginControlEntry);
    }

    public void update(LogInControlEntity loginCtrl) {
        PreconditionUtils.checkArguments(loginCtrl);

        commandMapper.update(loginCtrl);
    }

    @Override
    @Transactional(value = CoreConf.COMMAND_TX_MANAGER,
            readOnly = false,
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class})
    public void delete(LogInControlEntity loginControlEntry) {
        PreconditionUtils.checkArguments(loginControlEntry);

        commandMapper.remove(loginControlEntry);
    }

    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public LogInControlEntity getBySessionIdAndAccount(String sessionId, String loginAccount) {
        PreconditionUtils.checkArguments(sessionId, loginAccount);

        Map<String, String> params = new HashMap<>();
        params.put(LogInControlQueryMapper.KEY_SESSION_ID, sessionId);
        params.put(LogInControlQueryMapper.KEY_LOGIN_ACCOUNT, loginAccount);

        return queryMapper.findBySessionIdAndAccount(params);
    }
    @Override
    @Transactional(value = CoreConf.QUERY_TX_MANAGER,
            readOnly = true)
    public LogInControlEntity getBySessionIdAndAccountMaxlimitTime(String sessionId, String loginAccount) {
        PreconditionUtils.checkArguments(sessionId, loginAccount);

        Map<String, String> params = new HashMap<>();
        params.put(LogInControlQueryMapper.KEY_SESSION_ID, sessionId);
        params.put(LogInControlQueryMapper.KEY_LOGIN_ACCOUNT, loginAccount);

        return queryMapper.findBySessionIdAndAccountMaxlimitTime(params);
    }
}
