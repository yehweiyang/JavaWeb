package gov.archives.core.service;

import gov.archives.core.domain.entity.ActionLogEntity;

/**
 * ActionLogService
 * <br>
 * (尚未描述類別目的與用途)
 * <br>
 * gemhuang, 2016/7/18.
 */
public interface ActionLogService {

    void insert(ActionLogEntity actionLog);

    void delete(ActionLogEntity actionLog);

    ActionLogEntity getLastLogInByAccount(String actorAccount);

    ActionLogEntity getLogInCountByAccount(String actorAccount);
}
