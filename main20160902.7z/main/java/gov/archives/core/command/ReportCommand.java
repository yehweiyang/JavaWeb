package gov.archives.core.command;

import gov.archives.core.exception.ReportException;

/**
 * Created by kshsu on 2016/7/26.
 */
public interface ReportCommand {
    void execute(ReportCommandProcessor reportCommandProcessor) throws ReportException;
}
