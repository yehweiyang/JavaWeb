package gov.archives.core.domain.vo;

/**
 * Created by kshsu on 2016/7/22.
 */
public enum ReportEnum {
    /**
     * 中心交換量排行 001
     */
    REPORT_SEND_RANK("rptsendrank"),
    /**
     * 中心異常排行 002
     */
    REPORT_ERR_RANK("rpterrrk"),
    /**
     * 收文狀態統計 003
     */
    REPORT_R_STATE_STATIC("rptrss"),
    /**
     * 收發文狀態統計 003
     */
    REPORT_S_STATE_STATIC("rptsss"),
    /**
     * 交換異常統計 004
     */
    REPORT_SEND_ERR("rptsenderr"),
    /**
     * 發文統計 005
     */
    REPORT_SEND_STATE("rptsendst"),
    /**
     * 發文清單 006
     */
    REPORT_SEND_LIST("rptsendlist"),
    /**
     * 發文待確認 007
     */
    REPORT_SEND_UNCONFIRM("rptsendunconfm"),
    /**
     * 發文異常清單 008
     */
    REPORT_SEND_ERR_LIST("rptsenderrlist"),
    /**
     * 收文統計 009
     */
    REPORT_RECEIVE_STATE("rptrecvstate"),
    /**
     * 收文清單 010
     */
    REPORT_RECEIVE_LIST("rptrecvlist"),
    /**
     * 收文異常清單 011
     */
    REPORT_RECEIVE_ERR_LIST("rptrecverrlist"),
    /**
     * 確認率查詢 012
     */
    REPORT_CONFIRMED_QUERY("rptconfirmed"),
    PDF("PDF"),
    CSV("CSV"),
    XLS("XLS"),
    ODS("ODS");

    private final String value;

    private ReportEnum(String s) {
        value = s;
    }

    public boolean equalsName(String otherName) {
        return null != otherName && value.equals(otherName);
    }

    public String toString() {
        return this.value;
    }

    public String getTWName() {
        switch (value) {
            case "rptsendrank":
                return "中心交換量排行";
            case "rpterrrk":
                return "中心異常排行";
            case "rptrss":
            case "rptsss":
                return "收發文狀態統計";
            case "rptsenderr":
                return "交換異常統計";
            case "rptsendst":
                return "發文統計";
            case "rptsendlist":
                return "發文清單";
            case "rptsendunconfm":
                return "發文待確認";
            case "rptsenderrlist":
                return "發文異常清單";
            case "rptrecvstate":
                return "收文統計";
            case "rptrecvlist":
                return "收文清單";
            case "rptrecverrlist":
                return "收文異常清單";
            case "rptconfirmed":
                return "確認率查詢";
            default:
                return value;
        }
    }
}
