package gov.archives.core.domain.vo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import gov.archives.core.conf.CoreConf;

@Component
public class AccountModelValidator implements Validator {
    private Pattern pattern;
    private Pattern pattern1;
    private Pattern pattern2;
    private Matcher matcher;
    private Matcher matcher1;
    private Matcher matcher2;

    public AccountModelValidator() {
        pattern = Pattern.compile(CoreConf.EMAIL_PATTERN);
        pattern1 = Pattern.compile(CoreConf.ALPHANUMERIC_NLS_PATTERN);
        pattern2 = Pattern.compile(CoreConf.DIGIT_PATTERN);
    }

    public boolean validateMaile(final String mailAddr) {
        matcher = pattern.matcher(mailAddr);
        return matcher.matches();
    }

    public boolean validateName(final String userPattern) {
        matcher1 = pattern1.matcher(userPattern);
        return matcher1.matches();
    }

    public boolean validateNum(final String numPattern) {
        matcher2 = pattern2.matcher(numPattern);
        return matcher2.matches();
    }

    @Override
    public boolean supports(Class<?> clazz) {
        // TODO Auto-generated method stub
        if (clazz.getSimpleName()
                 .equals(AccountForm.class.getSimpleName())) { return true; }
        return false;
    }

    @Override
    public void validate(Object target, Errors errors) {
        // TODO Auto-generated method stub
        AccountForm account = (AccountForm) target;

        String userName = account.getUserName();
        if (userName == null|| userName.length() == 0) {
            errors.rejectValue("userName", "userName.required");
        } else if (userName.length() > 0) {
           if (userName.length() > 20) {
                errors.rejectValue("userName", "userName.maxvalue");
           }
           if (!validateName(userName)) {
            errors.rejectValue("userName", "userName.isNotCharacter");
            }
        }
        String fullName = account.getFullName();
        if (fullName == null || fullName.length() == 0) {
            errors.rejectValue("fullName", "fullName.required");
        } else if (fullName.length() > 0) {
        if (fullName.length() > 20) {
            errors.rejectValue("fullName", "fullName.maxvalue");
        }
        if (!validateName(fullName)) {
            errors.rejectValue("fullName", "fullName.isNotCharacter");
        }
        }
        String phoneLocal = account.getPhoneLocal();
        if (phoneLocal.length() > 4) {
            errors.rejectValue("phoneLocal", "phoneLocal.maxvalue");
        } else if (phoneLocal.length() > 0) {
            if (phoneLocal.length() < 2) {
                errors.rejectValue("phoneLocal", "phoneLocal.minvalue");
            }
            if (!validateNum(phoneLocal)) {
                errors.rejectValue("phoneLocal", "phoneLocal.isNotNumber");
            }
        } else {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phoneLocal", "phoneLocal.required");
        }

        String phoneNum = account.getPhoneNum();
        if (phoneNum.length() > 10) {
            errors.rejectValue("phoneNum", "phoneNum.maxvalue");
        } else if (phoneNum.length() > 0) {
            if (!validateNum(phoneNum)) {
                errors.rejectValue("phoneNum", "phoneNum.isNotNumber");
            }
        } else {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phoneNum", "phoneNum.required");
        }

        String phonExt = account.getPhonExt();
        if (phonExt.length() > 6) {
            errors.rejectValue("phonExt", "phonExt.maxvalue");
        } else if (phonExt.length() > 0) {
            if (!validateNum(phonExt)) {
                errors.rejectValue("phonExt", "phonExt.isNotNumber");
            }
        }

        String mobileLocal = account.getMobileLocal();
        if (mobileLocal.length() > 0) {
            if (mobileLocal.length() < 2) {
                errors.rejectValue("mobileLocal", "mobileLocal.minvalue");
            }
            if (!validateNum(mobileLocal)) {
                errors.rejectValue("mobileLocal", "mobileLocal.isNotNumber");
            }
        }
        String mobileNum = account.getMobileNum();
        if (mobileNum.length() > 0) {
            if (!validateNum(mobileNum)) {
                errors.rejectValue("mobileNum", "mobileNum.isNotNumber");
            }
        }
        String eMailAddr = account.geteMailAddr();
        if (eMailAddr.length() > 0) {
            if (!validateMaile(eMailAddr)) {
                errors.rejectValue("eMailAddr", "eMailAddr.error");
            }
        } else {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eMailAddr", "eMailAddr.required");
        }
    }

}