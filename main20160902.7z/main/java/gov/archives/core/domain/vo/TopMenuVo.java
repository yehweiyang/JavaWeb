package gov.archives.core.domain.vo;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import gov.archives.core.domain.entity.MenuEntity;

/**
 * Created by 140631 on 2016/7/25.
 */
public class TopMenuVo {
    private String menuCode;
    private String menuName;
    private Map<Integer, MenuEntity> subMenus;

    public String getMenuCode() {
        return menuCode;
    }

    public void setMenuCode(String menuCode) {
        this.menuCode = menuCode;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public Map<Integer, MenuEntity> getSubMenus() {
        return subMenus;
    }

    public void setSubMenus(Map<Integer, MenuEntity> subMenus) {
        this.subMenus = subMenus;
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public static class Builder {
        public static Builder create() {
            return new Builder();
        }

        private TopMenuVo menu;
        private Map<Integer, MenuEntity> subMenus;
        private Builder self;

        private Builder() {
            this.menu = new TopMenuVo();
            this.subMenus = new HashMap<>();
            this.menu.subMenus = this.subMenus;
            this.self = this;
        }

        public Builder setMenuCode(String menuCode) {
            this.menu.menuCode = menuCode;

            return self;
        }

        public Builder setMenuName(String menuName) {
            this.menu.menuName = menuName;

            return self;
        }

        public Builder setSubMenus(Map<Integer, MenuEntity> subMenus) {
            this.subMenus.putAll(subMenus);

            return self;
        }

        public Builder addSubMenu(Integer menuSeq, MenuEntity subMenu) {
            this.subMenus.put(menuSeq, subMenu);

            return self;
        }

        public TopMenuVo build() {
            return this.menu;
        }
    }
}
