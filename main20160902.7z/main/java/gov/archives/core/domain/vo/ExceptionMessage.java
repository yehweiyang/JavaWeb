package gov.archives.core.domain.vo;

import org.springframework.http.HttpHeaders;

/**
 * Created by 140631 on 2016/8/12.
 */
public class ExceptionMessage {
    private String errorCode;
    private String errorMessage;

    public static ExceptionMessage getInstanceByCodeAndMessage(String errorCode, String message) {
        ExceptionMessage exMsg = new ExceptionMessage();

        exMsg.setErrorCode(errorCode);
        exMsg.setErrorMessage(message);

        return exMsg;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
