# facade

## 目的

負責 service 與 controller 之間介接