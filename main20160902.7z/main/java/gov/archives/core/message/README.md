# message

## 目的

message 在於定義本 package 下之訊息內容
