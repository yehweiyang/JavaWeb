package gov.archives.core.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.regex.Pattern;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;

import gov.archives.core.domain.entity.ReportResult;
import gov.archives.core.exception.ErrorCode;
import gov.archives.core.exception.ReportException;

/**
 * Created by jslee on 2016/7/7.
 * 應付各類報表轉型需求
 */
public abstract class ReportUtils {

    private static final Logger log = LoggerFactory.getLogger(ReportUtils.class);

    private ReportUtils() { }

    public static Date convertDateFromString(String strDate) {
        String[] splitDate =
                !strDate.isEmpty() && isDateFormat(strDate) ?
                        strDate.split("/") : new String[0];
        return convertGregorianDateFromStringArray(splitDate);
    }

    public static Date convertDateFromString(String strDate, String strHours) {
        String[] splitDate = new String[0];
        if (!(strDate.isEmpty() && strHours.isEmpty())
                && isDateFormat(strDate)) {
            splitDate = strDate.split("/");
            splitDate = Arrays.copyOf(splitDate, splitDate.length + 1);
            splitDate[splitDate.length - 1] = strHours;
        }
        return convertGregorianDateFromStringArray(splitDate);
    }

    public static JsonNode convertBeanToJsonNode(Object resultBean) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectWriter objectWriter =
                objectMapper.writer()
                            .withDefaultPrettyPrinter();
        return objectMapper.readTree(objectWriter.writeValueAsString(resultBean));
    }

    public static Object convertJsonNodeStringToBean(String jsonNode, Class<?> clazz)
            throws ClassNotFoundException, IOException {
        return new ObjectMapper().readValue(jsonNode, clazz);
    }

    public static List convertJsonNodeStringToBeanList(String jsonNode, Class<?> clazz)
            throws ClassNotFoundException, IOException {
        return Arrays
                .asList(new ObjectMapper()
                        .readValue(jsonNode,
                                ((Object[]) Array.newInstance(clazz, 0)).getClass()));
    }

    public static void saveAsJsonFile(String fileName, String strJson) throws IOException {
        FileWriter fw = new FileWriter(fileName);
        fw.write(strJson.toString());
        fw.flush();
        fw.close();
    }

    public static String readJsonFileAsString(String fileName) throws IOException {
        FileReader fr = new FileReader(fileName);
        BufferedReader br = new BufferedReader(fr);
        String readJsonAsStr = "";
        while (br.ready()) {
            readJsonAsStr += br.readLine();
        }
        br.close();

        return readJsonAsStr;
    }

    private static Date convertGregorianDateFromStringArray(String[] strArrayDate) {
        GregorianCalendar greCalendar = new GregorianCalendar();
        if (strArrayDate.length >= 3) {
            int[] intDateMap = Arrays.stream(strArrayDate)
                                     .mapToInt(Integer::parseInt).toArray();
            greCalendar
                    .set(intDateMap[0], intDateMap[1] - 1, intDateMap[2],
                            (intDateMap.length > 3 ? intDateMap[3] : 0), 0);
        }
        return greCalendar.getTime();
    }

    private static boolean isDateFormat(String strDate) {
        String regex = "[\\d+]{4}\\/[0-1]{1}[0-9]{1}\\/[0-3]{1}[0-9]{1}";
        return Pattern.matches(regex, strDate);
    }

    public static String getTodayString(String datePattern) {
        return new SimpleDateFormat(datePattern).format(Calendar.getInstance().getTime());
    }

    public static String getLastMonthTodayString(String datePattern) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -1);
        return new SimpleDateFormat(datePattern).format(calendar.getTime());
    }

    /**
     * 取得 Result Column 對應的中文名稱
     */
    public static <T> String getColumnTWName(Class<? extends ReportResult> resultClass, String columnName)
            throws ReportException {

        String returnValue = "";

        try {

            PreconditionUtils.checkArguments(resultClass, columnName);

            Class<?>[] resultClassColmunEnums = resultClass.getDeclaredClasses();
            for (Class<?> resultClassColmunEnum : resultClassColmunEnums) {
                Object[] consts = resultClassColmunEnum.getEnumConstants();

                for (Object object : consts) {
                    Class<?> subEnum = object.getClass();
                    Method method;
                    method = subEnum.getDeclaredMethod("toString");
                    String val;
                    val = (String) method.invoke(object);
                    if (val.equals("title")) {
                        method = subEnum.getDeclaredMethod("getTWName");
                        returnValue = (String) method.invoke(object);
                    }
                }
            }
        } catch (Exception ex) {
            throw new ReportException(ex, ErrorCode.EXCEPTION_IN_REPORT_UTILS);
        }
        return returnValue;
    }

    public static void initFolder(String folderPath) {
        if (!IOUtils.isFolderExist(folderPath)) {
            new File(folderPath).mkdirs();
        }
    }
}
