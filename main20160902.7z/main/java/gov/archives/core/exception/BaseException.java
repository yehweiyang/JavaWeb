package gov.archives.core.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.iii.common.util.StringUtils;

/**
 * Created by kshsu on 2016/8/9.
 */
public class BaseException extends Exception {
    private static final Logger log = LoggerFactory.getLogger(BaseException.class);

    public BaseException() {
        super();
    }

    public BaseException(String message) {
        super(message);
        log.error(message);
    }

    public BaseException(ErrorCode errorCode) {
        log.error("errorCode: " + errorCode.getErrorCode() + " errorMessage: " + errorCode.getErrorMessage());
    }

    public BaseException(String message, ErrorCode errorCode) {
        super(message);
        log.error("errorCode: " + errorCode.getErrorCode() + " errorMessage: " + errorCode.getErrorMessage() +
                " default message: " + message);
    }

    public BaseException(String message, Throwable cause) {
        super(message, cause);
        log.error("default message: " + message, cause);
    }

    public BaseException(String message, Throwable cause, ErrorCode errorCode) {
        super(message, cause);
        log.error("errorCode: " + errorCode.getErrorCode() + " errorMessage: " + errorCode.getErrorMessage() +
                " default message: " + message, cause);
    }

    public BaseException(Throwable cause) {
        super(cause);
        log.error("CAUSE: " + StringUtils.stackTraceFromException(cause));
    }

    public BaseException(Throwable cause, ErrorCode errorCode) {
        super(cause);
        log.error("errorCode: " + errorCode.getErrorCode() + " errorMessage: " + errorCode.getErrorMessage(), cause);
    }

    protected BaseException(String message, Throwable cause,
            boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        log.error("default message: " + message + " enableSuppression:" + enableSuppression + " writableStackTrace:" +
                writableStackTrace, cause);
    }
}
