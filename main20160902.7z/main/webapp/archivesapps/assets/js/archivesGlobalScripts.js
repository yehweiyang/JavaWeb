function includeOtherScript(yourScriptName) {
    if (typeof yourScriptName === 'string' && $('#' + yourScriptName).length === 0) {
        $('head').append($("<script></script>").attr({
            id : yourScriptName,
            src : $('#ng_load_plugins_before').attr("value") + "/archivesapps/assets/js/" + yourScriptName + ".js",
            type : "text/javascript"
        }));
    }
}

function exceptionViewer(exceptionResponse, redirectAction) {
    redirectAction = typeof redirectAction === 'boolean' ? redirectAction : false;
    $('#archivesExceptionViewer').modal("show");
    $('#archivesExceptionMsg').text(exceptionResponse.data.errorMessage);
    if (redirectAction) {
        window.setTimeout(function() {
            window.location.href = $('#ng_load_plugins_before').attr("value");
        }, 3000);
    }
}

function successViewer(msg) {
    $('#archivesSuccessViewer').modal("show");
    $('#archivesSuccessMsg').text(msg);
}

