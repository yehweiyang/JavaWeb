
var ArchivesApp = angular.module("ArchivesApp", [
    "ui.router",
    "ui.bootstrap",
    "oc.lazyLoad",
    "ngSanitize"
]);

ArchivesApp.config(['$ocLazyLoadProvider', function ($ocLazyLoadProvider) {
    $ocLazyLoadProvider.config({
    });
}]);


ArchivesApp.config(['$controllerProvider', function ($controllerProvider) {
    $controllerProvider.allowGlobals();
}]);

ArchivesApp.config(function ($httpProvider) {
    var auth = document.getElementById("auth").value;
	$httpProvider.interceptors.push(function($q, $injector) {
		return {
			request: function(request)
			{
				request.headers.authorization = auth;
				return request;
			},
			response: function(response) {
				response.data.status = response.status;
				return response;
			},
			responseError: function(rejection) {
				return $q.reject(rejection);
			}
		}
	});
});


ArchivesApp.factory('settings', ['$rootScope', function ($rootScope) {
    var settings = {
        layout: {
            pageSidebarClosed: false,
            pageContentWhite: true,
            pageBodySolid: false,
            pageAutoScrollOnLoad: 1000
        },
        appPath: 'archivesapps',
        assetsPath: 'resources/assets',
        globalPath: 'resources/assets/global',
        layoutPath: 'resources/assets/layouts/layout',
    };

    $rootScope.settings = settings;

    return settings;
}]);

ArchivesApp.controller('AppController', ['$scope', '$rootScope', function ($scope, $rootScope) {
    $scope.$on('$viewContentLoaded', function () {

    });
}]);

ArchivesApp.controller('HeaderController', ['$scope', '$http', function ($scope, $http) {
	$scope.$on('$includeContentLoaded', function () {
		$http.get('/manageWeb/v1/systemTool/user/currentAccount').then(function(response) {
			$scope.account = response.data.account;
		});
	});
}]);


ArchivesApp.controller('SidebarController', ['$scope', '$http', '$rootScope', 'archivesConstant', function ($scope, $http, $rootScope, archivesConstant) {
	$scope.$on('$includeContentLoaded', function () {
		$http.get(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/core/menu').then(function (response) {
			$rootScope.menus = response.data.menu;
		});
	});
}]);


ArchivesApp.controller('PageHeadController', ['$scope',  function ($scope) {
}]);


ArchivesApp.controller('FooterController', ['$scope', function ($scope) {
    $scope.$on('$includeContentLoaded', function () {

    });
}]);

ArchivesApp.run(["$rootScope", "settings", "$state", function ($rootScope, settings, $state) {
    $rootScope.$state = $state;
    $rootScope.$settings = settings;
}]);

