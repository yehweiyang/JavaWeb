angular.module('ArchivesApp').controller('EditAnnouncementController', function($rootScope, $scope, $http, pkiService) {
	$rootScope.$on('slot:find', function() {   
		$scope.slot = "卡片存在";
		$scope.btDisabled = false;
    });
	$rootScope.$on('slot:empty', function() {   
		$scope.slot = "卡片不存在";
		$scope.btDisabled = true;
    });
    $scope.toggleModal = function(){
        $scope.showModal = false;
    };
    $scope.announceMessage = null;
    $scope.showAlertMessage = false;
	$rootScope.$on('sign:success', function() {
		$scope.btDisabled = false;
		var announcement = pkiService.getSignatureCert();
		announcement.announceMessage = $scope.announceMessage;
		
    	$http.post("/manageWeb/v1/systemTool/announce", announcement)
		.then(function(response){
			$scope.slot = "卡片存在";
		    $scope.message = "儲存成功";
            $scope.showModal = true;
		}, 
		function(errResponse) {
			$scope.alertMessage = errResponse.data.errorCode;
	        $scope.showAlertMessage = true;
		});			
    });
	$rootScope.$on('sign:failed', function() {
		$scope.btDisabled = false;
		// fixed not refresh UI
    	$http.get("/manageWeb/v1/systemTool/announce")
		.then(function(errResponse) {},
		function(errResponse) {
			var resultCode = pkiService.getResultCode();
			if (resultCode.ret_code == 0x76000006) {
				$scope.slot = "卡片不存在";
				$scope.btDisabled = true;
			}
	        $scope.alertMessage = pkiService.getErrorReason();
	        $scope.showAlertMessage = true;
		});	

    });
	$scope.slot = pkiService.querySlot();
	$scope.btDisabled = true;
	$scope.saveHtmlBt = function() {
	    if ($scope.announceMessage != null) {
	        $scope.showAlertMessage = false;
        	pkiService.openPinModal();
        	$scope.btDisabled = true;
	    } else {
	        $scope.alertMessage = "未輸入資料";
            $scope.showAlertMessage = true;
	    }
    }
});