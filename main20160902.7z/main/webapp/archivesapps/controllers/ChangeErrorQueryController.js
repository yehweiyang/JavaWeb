angular.module('ArchivesApp').controller('ChangeErrorQueryController',
    function($scope, $http, $rootScope, $uibModal, $log, $q,archivesConstant,archivesService) {
    var deferred = $q.defer();
$scope.archivesConstant = archivesConstant;
$scope.archivesService=archivesService;
$scope.archivesService.pager = {
    itemsPerPage : 100,
    pagerMaxSize : 7,
    firstItemDataNum : 0,
    currentPage : 1
};
        $scope.userList = [];
        $scope.userID = [];
        var convQueryFromJson =[];




                $scope.saveHtmlBt = function(id) {
                            var queryProcessId = {
                                processId: id.processId
                            };
console.log('id===>'+id.processId);
                                                console.log('bbbbbbbb');
                                                $http.get('/manageWeb/v1/change/changeErrorQueryID', {
                                                params: queryProcessId
                                                }).success( function(response, status, headers, config) {
                                                $scope.abc= response;
                                                console.log("\\\\\\\\\\\\\\");
                                                 console.log($scope.abc)
                                                 console.log("/////////////")

                                                    console.log('------Really good-------')
                                                    return  $scope.abc;
                                                         console.log( $scope.abc)

                                                    })
                                                    .error(function(errResp) {
                                                    console.log('------Really bad-------')
                                                    });
                    var modal = $uibModal.open({
                        templateUrl: "archivesapps/views/ChangeRecord/demoForm2.html",
                        scope : $scope,
                        size: 'lg'
                    });

                }


        $scope.checkErr = function(timeFrom, timeTo) {
            $scope.errMessage = '';

            if (timeFrom > timeTo) {
                $scope.errorValid = true
                $scope.errorCode = false;
            } else {
                $scope.errorValid = false
                $scope.errorCode = true;
            }
        };


//        function validateDates() {
//            console.log('rest~~!!');
//            if (!$scope.error) return;
//            //depending on whether the user used the date picker or typed it, this will be different (text or date type).
//            //creating a new date object takes care of that.
//            var endDate = new Date($scope.error.dateTo);
//            var startDate = new Date($scope.error.dateFrom);
//            var endTime = $scope.error.timeTo;
//            var startTime = $scope.error.timeFrom;
//            if (endDate != 'Invalid Date' && startDate != 'Invalid Date') {
//                if (endDate < startDate || ((endDate = startDate) && (endTime < startTime))) {
//                    $scope.errorValid = true
//                    $scope.errorCode = true;
//
//                } else {
//                    $scope.errorValid = false
//                    $scope.errorCode = false;
//
//                }
//            }
//
//            //$scope.error.dateFrom.$setValidity("endBeforeStart", endDate >= startDate);
//        }


        $scope.$watch('hideOrShow', function() {
            $scope.toggleText = $scope.hideOrShow ? '開啟異常訊息' : '隱藏異常訊息!';
        })


        $scope.test = function() {
            console.log('test...............');
            $scope.error.sendOrganName = "廉政署",
                $scope.error.sendOrganId = "A123",
                $scope.error.receiverOrgName = "社會救助及社工司",
                $scope.error.receiverOrgId = "ABC5",
                $scope.error.processId = "F126864546",
                $scope.error.exchangeId = "H223103399",
                $scope.error.startNo = "1059981010",
                $scope.error.endNo = "1059981011",
                $scope.error.dateFrom = "2016/08/01",
                $scope.error.timeFrom = "12",
                $scope.error.dateTo = "2016/08/02",
                $scope.error.timeTo = "13"
        }

        $scope.query = function() {
            if (!$scope.error) return;
            console.log('query...............');
            var error = $scope.error;

console.log(error.sendOrgNameCheck)
console.log(error.receiverOrgNameCheck)

             convQueryFromJson = {
                sendOrganName: error.sendOrganName,
                sendOrganId: error.sendOrganId,
                receiverOrgName: error.receiverOrgName,
                receiverOrgId: error.receiverOrgId,
                processId: error.processId,
                exchangeId: error.exchangeId,
                startNo: error.startNo,
                endNo: error.endNo,
                dateFrom: error.dateFrom,
                timeFrom: error.timeFrom,
                dateTo: error.dateTo,
                timeTo: error.timeTo,
                sendOrgNameCheck: error.sendOrgNameCheck,
                receiverOrgNameCheck: error.receiverOrgNameCheck
            };
            $http.get('/manageWeb/v1/change/changeErrorQuery', {
                params: convQueryFromJson
            }).then(function(response) {

                if (response.data.length != 0) {
                    $scope.userList = response.data;

                    $scope.noResult = false;
                    $scope.myVar = true;
                    $scope.hideOrShow = true;
                    //寫入暫存檔
                    response

                    //寫入暫存檔

                } else {
                    $scope.noResult = true;
                    $scope.myVar = false;
                }
                $scope.error = null;
             console.log('---------');
             console.log($scope.error)
            })

        }

//
//          $scope.error={
//          timeFrom: $scope.options.mstep,
//          timeTo: $scope.options.mstep
//          }
var member = {
    "number": "1020501",
    "name": "小傑",
    "age": 32,
    "sex": "M",
    "interest": [
        "網頁設計",
        "撰寫文章"
    ]
};

console.log(
    JSON.stringify(member)  // 序列化成 JSON 字串
);
        $scope.reset = function() {
            $scope.error = '';
            $scope.noResult = '';
            $scope.myVar = '';
            $scope.errorCode = false;
            $scope.error.sendOrgNameCheck='false';
            $scope.error.receiverOrgNameCheck='true';

        }

          $scope.prop = {   "type": "select",
            "value00": "00",
            "value23": "23",
            "values": [ "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12","13", "14", "15", "16", "17", "18", "19", "20", "21",
                                       "22", "23"]
          };


        var writeLog = function(){
        $http.get('/manageWeb/v1/change/changeErrorQueryLog')
        console.log('writeLog');
        }
        writeLog();



        $scope.openDateFromCalendar = function() {
            $scope.dateFromCalendar.opened = true;
        };


        $scope.openDateToCalendar = function() {
            $scope.dateToCalendar.opened = true;
        };
        $scope.dateFromCalendar = {
            opened: false
        };

        $scope.dateToCalendar = {
            opened: false
        };

    });